export const environment = {
  production: true,
  apiURL: 'https://begin2.mybrokerhub.ca'
};
