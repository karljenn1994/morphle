export const environment = {
  production: true,
  apiURL: 'https://higgins.brunvalleytech.com'
};
