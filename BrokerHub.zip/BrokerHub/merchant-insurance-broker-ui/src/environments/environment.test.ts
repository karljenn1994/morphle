export const environment = {
  production: true,
  apiURL: 'https://test.brunvalleytech.com'
};
