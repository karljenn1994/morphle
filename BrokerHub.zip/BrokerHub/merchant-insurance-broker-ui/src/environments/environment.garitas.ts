export const environment = {
  production: true,
  apiURL: 'https://garitas.mybrokerhub.ca'
};
