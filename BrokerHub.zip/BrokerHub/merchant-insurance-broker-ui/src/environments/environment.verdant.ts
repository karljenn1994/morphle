export const environment = {
  production: true,
  apiURL: 'https://verdant.mybrokerhub.ca'
};
