import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ToastModule } from 'primeng/toast';
import { MessageModule } from 'primeng/message';
import { SessionDebugComponent } from './session-debug.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,        // for <router-outlet>
    ToastModule,         // for <p-toast>
    MessageModule,       // for <p-message> if you use it
    SessionDebugComponent // for <app-session-debug>
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {}
