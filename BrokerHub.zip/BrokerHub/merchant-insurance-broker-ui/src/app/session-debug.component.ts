import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription, interval } from 'rxjs';
import { IdleService } from './services/service-idle';
import { AuthenticationService } from './services/service-authentication';

@Component({
  selector: 'app-session-debug',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="isAdmin" class="debug-panel" [class.open]="panelOpen">
      <div class="debug-content" *ngIf="panelOpen">
        <p>🕒 Idle time remaining: {{ formatTime(idleTimeRemaining) }}</p>
        <p>🔐 Access token remaining: {{ formatTime(accessTokenRemaining) }}</p>
        <p>♻️ Refresh token remaining: {{ formatTime(refreshTokenRemaining) }}</p>
      </div>

      <button class="debug-toggle" (click)="togglePanel()" type="button">
        {{ panelOpen ? '▼ Session' : '▶ Session' }}
      </button>
    </div>
  `,
  styles: [`
    .debug-panel {
      position: fixed;
      bottom: 0;
      right: 0;
      background: rgba(0, 0, 0, 0.5);
      color: #00ff00;
      font-family: monospace;
      font-size: 14px;
      z-index: 9999;
      border-top-left-radius: 8px;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      overflow: hidden;
    }

    .debug-content {
      padding: 12px;
      text-align: right;
    }

    .debug-toggle {
      background: none;
      border: none;
      color: #00ff00;
      font-family: monospace;
      font-size: 14px;
      cursor: pointer;
      padding: 4px 8px;
      text-decoration: none;
      align-self: flex-end;
    }

    .debug-toggle:hover {
      text-decoration: none;
    }
  `]
})
export class SessionDebugComponent implements OnInit, OnDestroy {
  idleTimeRemaining = 0;
  accessTokenRemaining = 0;
  refreshTokenRemaining = 0;
  panelOpen = false;
  isAdmin = false;

  private roleSub: Subscription | null = null;
  private idleSub: Subscription | null = null;
  private intervalSub: Subscription | null = null;

  constructor(
    private idleService: IdleService,
    private authService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.roleSub = this.authService.role$.subscribe(role => {
      this.isAdmin = role === 'admin';

      if (this.isAdmin) {
        this.idleSub = this.idleService.idleTimeRemaining$.subscribe(seconds => {
          this.idleTimeRemaining = seconds;
        });

        this.intervalSub = interval(1000).subscribe(() => {
          this.accessTokenRemaining = this.authService.accessTokenRemainingSeconds ?? 0;
          this.refreshTokenRemaining = this.authService.refreshTokenRemainingSeconds ?? 0;
        });
      }
    });
  }

  ngOnDestroy(): void {
    this.roleSub?.unsubscribe();
    this.idleSub?.unsubscribe();
    this.intervalSub?.unsubscribe();
  }

  togglePanel(): void {
    this.panelOpen = !this.panelOpen;
  }

  formatTime(totalSeconds: number): string {
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    const pad = (n: number) => String(n).padStart(2, '0');

    return `${days}d ${pad(hours)}h ${pad(minutes)}m ${pad(seconds)}s`;
  }
}
