import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { ChartModule } from 'primeng/chart';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ProgressBarModule } from 'primeng/progressbar';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../components/module-components';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SelectModule } from 'primeng/select';
import { FormPage } from './page-form/page-form';
import { FormRoutingModule } from './form-routing.module';
import { SurveyModule } from 'survey-angular-ui';
import { FormService } from '../services/service-form';

@NgModule({
  declarations: [
    FormPage,
  ],
  imports: [
    ButtonModule,
    ChartModule,
    CheckboxModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    SelectModule,
    FormsModule,
    InputTextModule,
    ProgressBarModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    SelectButtonModule,
    TableModule,
    FormRoutingModule,
    SurveyModule,
  ],
  providers: [
    FormService,  
  ]
})
export class FormModule {}
