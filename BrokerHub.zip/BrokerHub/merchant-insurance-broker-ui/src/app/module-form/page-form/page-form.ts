import { Component, OnInit } from '@angular/core';
import { ToastProvider } from '../../providers/provider-toast';
import { FormService } from '../../services/service-form';
import { SettingsService } from '../../services/service-settings';
import { Model } from 'survey-core';
import { RoutingService } from '../../services/service-routing';

@Component({
    selector: 'form-page',
    templateUrl: './page-form.html',
    styleUrls: ['./page-form.scss'],
    host: { class: 'col pt-0 px-0 w-full' },
    standalone: false
})
export class FormPage implements OnInit {
  loading = false;
  model!: Model;
  token!: string;
  systemPubUrl!: string;

  constructor(
    public routing: RoutingService,
    private formService: FormService,
    private settingsService: SettingsService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    try {
      let thisPtr = this;
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl')!;
      this.token = this.routing.getQueryParameters()?.get('token')!;
      let res = await this.formService.loadFormInstanceByToken(this.token);
      this.model = new Model(JSON.parse(res.form));
      this.model.data = JSON.parse(res.form_data);
      this.model.onComplete.add((survey: Model) => thisPtr.saveSurvey(survey));
      this.model.onCurrentPageChanged.add((model: Model, options) => {
        thisPtr.saveSurvey(model);
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  // Save the survey state to localStorage
  async saveSurvey(survey: Model) {
    try {
      this.loading = true;
      await this.formService.saveResult(this.token, survey.data)
    }
    catch(error: any) {
      this.toast.show(error);
    }
    finally {
      this.loading = false;
    }
  }
}
