import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SelectItem } from 'primeng/api';
import { LayoutService } from '../../../layout/service/layout.service';
import { ToastProvider } from '../../../providers/provider-toast';
import { AdminService } from '../../../services/service-admin';
import { RoutingService } from '../../../services/service-routing';
import { PoliciesService } from '../../../services/service-policies';

@Component({
    selector: 'admin-user-page',
    templateUrl: './page-admin-policy-add.html',
    styleUrls: ['./page-admin-policy-add.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminPolicyAddPage implements OnInit {
  loading = false;

  companies: SelectItem[] = [];
  company: SelectItem = { value: '' };

  lobs: SelectItem[] = [
    { label: 'Auto', value: 'AUTO' },
    { label: 'Property', value: 'HABL' },
  ];
  lob: SelectItem = { value: '' };

  form: any;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private formBuilder: FormBuilder,
    private adminService: AdminService,
    private policiesService: PoliciesService,
    public layoutService: LayoutService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group({
      policy_number: new FormControl<string | null>(null, [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(20),
      ]),
      company: new FormControl<string | null>(null, [Validators.required]),
      lob: new FormControl<string | null>(null, [Validators.required]),
    });    
  }

  ngOnInit() {
    this.routing.addRoute($localize`Add Policy`, false);

    this.adminService
      .listCompanies()
      .then((companies: any) => {
        this.companies = companies;
      })
      .catch((error) => {
        this.toast.show(error);
      });
  }

  onSubmit() {
    // Stop here if form is invalid.
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.loading = true;

    this.policiesService
      .addPolicy(
        this.form.controls['policy_number'].value!,
        this.form.controls['company'].value!.toUpperCase(),
        this.form.controls['lob'].value!
      )
      .then(() => {
        this.routing.popRoute(null).navigate();
        this.toast.success($localize`Added`);
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }
}
