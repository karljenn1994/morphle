import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { ChartModule } from 'primeng/chart';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { InputNumberModule } from 'primeng/inputnumber';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../components/module-components';
import { AdminDashboardPage } from './page-admin-dashboard/page-admin-dashboard';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { FloatLabelModule } from 'primeng/floatlabel';
import { AdminPoliciesMinePage } from './page-admin-policies-mine/page-admin-policies-mine';
import { AdminPoliciesUserPage } from './page-admin-policies-user/page-admin-policies-user';
import { AdminPoliciesPage } from './page-admin-policies/page-admin-policies';
import { AdminPolicyAddPage } from './page-admin-policy-add/page-admin-policy-add';
import { AdminPolicyPage } from './page-admin-policy/page-admin-policy';
import { AdminRenewalPage } from './page-admin-renewal/page-admin-renewal';
import { AdminRenewalsMinePage } from './page-admin-renewals-mine/page-admin-renewals-mine';
import { AdminRenewalsPage } from './page-admin-renewals/page-admin-renewals';
import { AdminUserAddPage } from './page-admin-user-add/page-admin-user-add';
import { AdminUserPage } from './page-admin-user/page-admin-user';
import { AdminUsersPage } from './page-admin-users/page-admin-users';
import { PortfolioRoutingModule } from './portfolio-routing.module';
import { PopoverModule } from 'primeng/popover';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TooltipModule } from 'primeng/tooltip';
import { MenuModule } from 'primeng/menu';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { ToggleSwitchModule } from 'primeng/toggleswitch';


@NgModule({
  declarations: [
    AdminDashboardPage,
    AdminPolicyPage,
    AdminPolicyAddPage,
    AdminPoliciesPage,
    AdminPoliciesUserPage,
    AdminPoliciesMinePage,
    AdminRenewalsMinePage,
    AdminRenewalsPage,
    AdminRenewalPage,
    AdminUserPage,
    AdminUserAddPage,
    AdminUsersPage,
  ],
  imports: [
    BreadcrumbModule,
    ButtonModule,
    ChartModule,
    CheckboxModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FloatLabelModule,
    FormsModule,
    InputNumberModule,
    MenuModule,
    PopoverModule,
    PortfolioRoutingModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    SelectModule,
    TableModule,
    TieredMenuModule,
    ToggleSwitchModule,
    TooltipModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class PortfolioModule {}
