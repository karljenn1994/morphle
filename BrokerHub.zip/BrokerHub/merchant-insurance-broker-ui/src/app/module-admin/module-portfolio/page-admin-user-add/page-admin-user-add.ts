import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../../services/service-admin';
import { Validators, FormBuilder, FormControl } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { LayoutService } from '../../../layout/service/layout.service';
import { RoutingService } from '../../../services/service-routing';
import { PoliciesService } from '../../../services/service-policies';

@Component({
  selector: 'admin-user-page',
  templateUrl: './page-admin-user-add.html',
  styleUrls: ['./page-admin-user-add.scss'],
  host: { class: 'col pt-0' },
  standalone: false,
})
export class AdminUserAddPage implements OnInit {
  loading = false;
  user: any;
  form: any;
  policyId: string | null = null;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private formBuilder: FormBuilder,
    private adminService: AdminService,
    private policyService: PoliciesService,
    public layoutService: LayoutService,
    private toast: ToastProvider,
  ) {
    this.form = this.formBuilder.group({
      first_name: new FormControl<string>('', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]),
      last_name: new FormControl<string>('', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]),
      email: new FormControl<string>('', [
        Validators.required,
        Validators.email,
        Validators.minLength(5),
        Validators.maxLength(255),
      ]),
      admin: new FormControl<boolean>(false),
    });
  }

  ngOnInit() {
    this.policyId = this.routing.getQueryParameters()?.get('policy_id') ?? null;
    this.routing.addRoute($localize`Add User`, false);
  }

  ngOnDestroy(): void {}

  async onSubmit() {
    // Stop here if form is invalid.
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.loading = true;

    try {
      await this.adminService.addUser(
        this.form.controls['email'].value!,
        [this.form.controls['first_name'].value!, this.form.controls['last_name'].value!].join(' '),
        this.form.controls['first_name'].value!,
        this.form.controls['last_name'].value!,
        false,
        this.policyId,
      );

      this.toast.success($localize`Added`);
      this.routing.popRoute(null).navigate();

    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }
}
