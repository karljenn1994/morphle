import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../services/service-authentication';
import { RoutingService } from '../../../services/service-routing';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'admin-renewals-mine-page',
  templateUrl: './page-admin-renewals-mine.html',
  styleUrls: ['./page-admin-renewals-mine.scss'],
  host: { class: 'pt-0 pl-0 col' },
  standalone: false,
})
export class AdminRenewalsMinePage implements OnInit {
  user: any;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,

    private authProvider: AuthenticationService,
    public routing: RoutingService,
  ) {
    this.user = {
      id: authProvider.userId,
      first_name: authProvider.firstName,
      last_name: authProvider.lastName,
    };
  }

  ngOnInit() {
    this.routing.addRoute(this.authProvider.firstName + ' ' + this.authProvider.lastName, true);
  }

  openPolicies() {
    this.router.navigate(['/admin/portfolio/policies-mine']);
  }
}
