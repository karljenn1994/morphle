import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { UIChart } from 'primeng/chart';
import { LayoutService } from '../../../layout/service/layout.service';
import { ToastProvider } from '../../../providers/provider-toast';
import { DashboardService } from '../../../services/service-dashboard';

@Component({
    templateUrl: './page-admin-dashboard.html',
    styleUrls: ['./page-admin-dashboard.scss'],
    host: { class: 'w-full pt-0' },
    standalone: false
})
export class AdminDashboardPage implements OnInit, OnDestroy {
  @ViewChild('userChart') userChart!: UIChart;
  @ViewChild('policyChart') policyChart!: UIChart;

  loading: boolean = true;
  metricsData: any;
  showPolicyErrors: boolean = false;
  policyErrors: any;

  items!: MenuItem[];
  userPieData: any;
  userPieOptions: any;

  policyPieData: any;
  policyPieOptions: any;

  activityPieData: any;
  activityPieOptions: any;

  usageData: any;
  usageOptions: any;

  barData: any;
  barOptions: any;

  activeNotMobile: any;
  guestNotMobile: any;
  mobileUsers: any;

  chartWidth: string = '400px';
  chartHeight: string = '350px';
  private resizeListener: (() => void) | undefined = undefined;

  constructor(
    public layoutService: LayoutService,
    private dashboardService: DashboardService,
    private toast: ToastProvider
  ) {}

  ngOnInit() {
    this.loading = true;
    const documentStyle = getComputedStyle(document.documentElement);

    this.dashboardService
      .loadMetrics()
      .then((m: any) => {
        console.log('Metrics data loaded:', m);
        this.metricsData = m;

        this.policyErrors = this.metricsData?.['policy_errors'] || [];

        const totalUsers = this.metricsData?.['counters']?.['total_users'] || 0;
        this.mobileUsers = this.metricsData?.['counters']?.['connected_users'] || 0;

        const activeUsers = this.metricsData?.['counters']?.['active_users'] || 0;
        this.activeNotMobile =
          this.metricsData?.['counters']?.['active_not_connected_users'] || 0;

        const guestUsers = this.metricsData?.['counters']?.['guest_users'] || 0;
        this.guestNotMobile =
          this.metricsData?.['counters']?.['guest_not_connected_users'] || 0;

        const non_users =
          totalUsers -
          this.mobileUsers -
          this.activeNotMobile -
          this.guestNotMobile;

        const adjustedNonUsers = non_users < 0 ? 0 : non_users;

        this.userPieData = {
          labels: [
            $localize`:@@Dashboard.Mobile:Mobile`,
            $localize`:@@Dashboard.Web:Web`,
            $localize`:@@Dashboard.WebGuest:Web Guest`,
            $localize`:@@Dashboard.NotUsing:Not Using`,
          ],
          datasets: [
            {
              data: [
                this.mobileUsers,
                this.activeNotMobile,
                this.guestNotMobile,
                adjustedNonUsers,
              ],
              backgroundColor: ['#26A69A', '#9FA8DA', '#3F51B5', '#AB47BC'],
              hoverBackgroundColor: ['#26A69A', '#9FA8DA', '#3F51B5', '#AB47BC'],
            },
          ],
        };

        // all policies we know about
        // const totalPolicies = this.metricsData?.['counters']?.['total_policies'] || 0;

        // policies downloaded that are not mapped to a client (came from download but not export)
        const unmappedPolicies =
          this.metricsData?.['counters']?.['total_unmapped_policies'] || 0;

        // policies mapped to a client that is not active
        const inactivePolicies =
          this.metricsData?.['counters']?.['total_inactive_policies'] || 0;

        // policies mapped to an active client
        const activePolicies =
          this.metricsData?.['counters']?.['total_active_policies'] || 0;

        this.policyPieData = {
          labels: [
            $localize`:@@Dashboard.Active:Active`,
            $localize`:@@Dashboard.Inactive:Inactive`,
            $localize`:@@Dashboard.Unassigned:Unassigned`,
          ],
          datasets: [
            {
              data: [activePolicies, inactivePolicies, unmappedPolicies],
              backgroundColor: [
                '#26A69A', // Teal-500 equivalent (vibrant teal)
                '#3F51B5', // Indigo-500 equivalent (deep indigo)
                '#AB47BC', // Purple-500 equivalent (rich purple)
              ],
              hoverBackgroundColor: [
                '#4DB6AC', // Teal-400 equivalent (slightly lighter teal)
                '#5C6BC0', // Indigo-400 equivalent (lighter indigo)
                '#BA68C8', // Purple-400 equivalent (lighter purple)
              ],
            },
          ],
        };

        console.log('userPieData:', this.userPieData);
        console.log('policyPieData:', this.policyPieData);
        console.log('metricsData for row 1:', this.metricsData?.['counters']);
        console.log('Values for row 3:', {
          totalUsers: this.metricsData?.['counters']?.['total_users'],
          connectedUsers: this.metricsData?.['counters']?.['connected_users'],
          activeNotMobile: this.activeNotMobile,
          guestNotMobile: this.guestNotMobile,
          mobileUsers: this.mobileUsers,
        });

        this.loading = false;

        // Initial resize to set chart dimensions
        this.onResize();
      })
      .catch((error) => {
        console.error('Error loading metrics:', error);
        this.loading = false;
        this.toast.show(error);
      });

    // Add window resize event listener
    this.resizeListener = () => {
      this.onResize();
    };
    window.addEventListener('resize', this.resizeListener);
  }

  ngOnDestroy() {
    // Clean up the resize event listener
    if (this.resizeListener) {
      window.removeEventListener('resize', this.resizeListener);
    }
  }

  onResize() {
    // Update chart dimensions based on container size
    const containerWidth = window.innerWidth >= 1200 ? 350 : window.innerWidth >= 992 ? 300 : 250;
    const containerHeight = containerWidth * 0.85; // Height is 75% of width

    this.chartWidth = `${containerWidth}px`;
    this.chartHeight = `${containerHeight}px`;

    // Force the charts to redraw with updated dimensions
    if (this.userChart) {
      this.userChart.chart.canvas.parentNode.style.width = this.chartWidth;
      this.userChart.chart.canvas.parentNode.style.height = this.chartHeight;
      this.userChart.refresh();
    }
    if (this.policyChart) {
      this.policyChart.chart.canvas.parentNode.style.width = this.chartWidth;
      this.policyChart.chart.canvas.parentNode.style.height = this.chartHeight;
      this.policyChart.refresh();
    }
  }

  toInt(n: string) {
    return parseInt(n);
  }
}
