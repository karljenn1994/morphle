import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { PoliciesService } from '../../../services/service-policies';
import { RoutingService } from '../../../services/service-routing';
import { UserService } from '../../../services/service-user';
import { PoliciesWidget } from '../../../components/widget-policies/widget-policies';
import { AdminService } from '../../../services/service-admin';
import { CampaignDialogWidget } from '../../../components/widget-campaign-dialog/widget-campaign-dialog';

@Component({
  selector: 'admin-policies-page-user',
  templateUrl: './page-admin-policies-user.html',
  styleUrls: ['./page-admin-policies-user.scss'],
  host: { class: 'col pt-0 px-0 w-full' },
  standalone: false,
})
export class AdminPoliciesUserPage implements OnInit {
  loading: boolean = false;
  user: any;
  loadingPolicies: boolean = false;
  showAddPolicyDialog = false;
  totalPolicies: number = -1;
  policyList: any[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  searchText: string | null = null;
  sort: string | null = null;
  sortDirection: string | null = null;
  index: number = 0;
  rowsPerPage: number = 10;
  showRemoveDialog: boolean = false;
  policyToRemove: any = null;
  notifyPolicy: any = null;

  @ViewChild(CampaignDialogWidget) campaignDialog!: CampaignDialogWidget;
  @ViewChild(PoliciesWidget) policiesWidget!: PoliciesWidget;

  constructor(
    public routing: RoutingService,
    private router: Router,
    private userService: UserService,
    private adminService: AdminService,
    private policyService: PoliciesService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      let user_id = this.routing.getQueryParameters()?.get('id')!;
      this.routing.addRoute('', false);
      this.user = await this.adminService.readUser(user_id);
      this.routing.setLabel(this.user?.account_name);
      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.search();
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.index = 0;
    this.loadPolicies();
  }

  searchChanged() {
    if (this.searchText != null) {
      this.searchSubject.next(this.searchText);
    }
  }

  clearSearch() {
    this.searchText = null;
    this.search();
  }

  onLoadPolicies(event: any) {
    if (!this.loadingPolicies) {
      this.rowsPerPage = event.rows;
      this.index = event.first;
      this.sort = event.sortField;
      this.sortDirection = event.sortOrder;
      this.loadPolicies();
    }
  }

  async loadPolicies() {
    try {
      this.loadingPolicies = true;
      if (!this.showAddPolicyDialog) {
        return;
      }

      if (this.totalPolicies == -1) {
        this.totalPolicies = await this.policyService.totalPolicies();
      }

      this.policyList =
        (await this.policyService.listPolicies(
          this.rowsPerPage,
          this.index / this.rowsPerPage,
          this.sort,
          this.sortDirection,
          this.searchText,
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loadingPolicies = false;
    }
  }

  onEditUser() {
    this.router.navigate(['/admin/portfolio/user'], {
      queryParams: {
        id: this.user.id,
      },
    });
  }

  onStartAddPolicy() {
    this.showAddPolicyDialog = true;
    this.loadPolicies();
  }

  async onAddPolicy(policy: any) {
    try {
      var policyId = policy.id;
      await this.userService.addPolicy(this.user.id, policyId, false);
      this.policiesWidget.refresh();
      this.toast.success($localize`Added`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loadingPolicies = false;
      this.showAddPolicyDialog = false;
    }
  }

  onViewPolicy(policy_id: any) {
    if (policy_id) {
      this.router.navigate(['/admin/portfolio/policy'], {
        queryParams: {
          id: policy_id,
        },
      });
    }
  }

  onNotifyUser(ev: any) {
    this.notifyPolicy = ev.policy ?? null;
    this.campaignDialog.type = ev.type;
    this.campaignDialog.user = this.user;
    this.campaignDialog.policy = this.notifyPolicy;
    this.campaignDialog.visible = true;
  }

  handleCampaignExecuted(campaignId: string): void {
    console.log('Campaign executed:', campaignId);
    this.campaignDialog.visible = false;
  }

  onStartRemovePolicy(policyCard: any) {
    if (this.user) {
      this.policyToRemove = policyCard;
      this.showRemoveDialog = true;
    }
  }

  async onRemovePolicy(event: any) {
    try {
      this.loading = true;
      event.stopPropagation();

      if (this.user == null || this.policyToRemove == null) {
        return;
      }

      await this.userService.removePolicy(this.user.id, this.policyToRemove.id);
      this.toast.success($localize`Removed`);
      this.policiesWidget.refresh();
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
      this.showRemoveDialog = false;
      this.policyToRemove = null;
    }
  }
}
