import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { AdminService } from '../../../services/service-admin';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { CampaignsService } from '../../../services/service-campaigns';
import { CampaignDialogWidget } from '../../../components/widget-campaign-dialog/widget-campaign-dialog';

@Component({
  selector: 'admin-users-page',
  templateUrl: './page-admin-users.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./page-admin-users.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminUsersPage implements OnInit {
  loading: boolean = true;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  popoverPanel: any = null;
  totalUsers: number = 0;
  userList: any[] = [];
  user: any;
  selectedUser: any;
  showDeleteDialog = false;
  loadingCampaigns = true;
  searchCampaignSubject: Subject<string> = new Subject<string>();
  searchCampaignSubscription: Subscription | null = null;
  totalCampaigns: number = 0;
  campaignList: { [key: string]: any }[] = [];
  showCampaignDialog = false;
  campaignType: string | null = null;
  campaignCategory: string | null = null;
  searchSortCampaigns: SearchSortService = new SearchSortService();
  menuModel: MenuItem[] = [];

  @ViewChild(CampaignDialogWidget) campaignDialog!: CampaignDialogWidget;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private adminService: AdminService,
    public searchSortService: SearchSortService,
    public campaignService: CampaignsService,
    private toast: ToastProvider,
  ) {}

  get marketingList(): { [key: string]: any }[] {
    return this.campaignList.filter((campaign) => campaign['type'] === 'client');
  }

  async ngOnInit() {
    try {
      this.loading = true;
      this.routing.addRoute($localize`Clients`, true);
      this.searchSortService.context = 'AdminUsersPage';
      this.totalUsers = await this.adminService.totalUsers();
      await this.loadUsers();
      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.search();
      });
      this.searchCampaignSubscription = this.searchCampaignSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.searchCampaign();
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
    this.searchCampaignSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadUsers();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadUsers(event: any) {
    if (!this.loading) {
      this.searchSortService.rowsPerPage = event.rows;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadUsers();
    }
  }

  async loadUsers() {
    try {
      this.loading = true;
      this.userList = await this.adminService
        .listUsers(
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText,
          null,
          null,
        )
    } catch (error: any) {
      this.userList = [];
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onToggleMenu(event: MouseEvent, popoverPanel: any): void {
    event.stopPropagation();
    this.popoverPanel?.hide();
    this.popoverPanel = popoverPanel;
    this.popoverPanel.toggle(event);
  }

  onOpenUser(user: any) {
    this.user = user;
    this.router.navigate(['/admin/portfolio/policies-user'], {
      queryParams: {
        id: user.id,
      },
    });
  }

  onAddClient() {
    this.router.navigate(['/admin/portfolio/user-add']);
  }

  onStartDeleteUser(user: Map<string, any>) {
    this.selectedUser = user;
    this.showDeleteDialog = true;
  }

  onDeleteUser(event: any) {
    event.stopPropagation();

    if (this.selectedUser) {
      this.loading = true;

      this.adminService
        .deleteUser(this.selectedUser.id)
        .then(() => {
          this.toast.success($localize`Deleted`);
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.loading = false;
          this.showDeleteDialog = false;
          this.selectedUser = null;
          this.loadUsers();
        });
    }
  }

  searchCampaign() {
    this.searchSortCampaigns.index = 0;
    this.loadCampaigns();
  }

  searchCampaignChanged() {
    if (this.searchSortCampaigns.searchText != null) {
      this.searchCampaignSubject.next(this.searchSortCampaigns.searchText);
    }
  }

  clearCampaignSearch() {
    this.searchSortCampaigns.searchText = null;
    this.searchCampaign();
  }

  async onOpenCampaign(event: any, user: Map<string, any>, campaignType: string, campaignCategory: string) {
    event.stopPropagation();

    try {
      this.loadingCampaigns = true;
      this.popoverPanel?.hide();
      this.selectedUser = user;
      this.campaignType = campaignType;
      this.campaignCategory = campaignCategory;
      this.campaignList = [];
      this.searchSortCampaigns = new SearchSortService();
      this.showCampaignDialog = true;
      this.totalCampaigns = await this.campaignService.totalCampaigns(this.campaignType);
      this.loadCampaigns();
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loadingCampaigns = false;
    }
  }

  onLoadCampaigns(event: any) {
    if (!this.loading) {
      this.searchSortCampaigns.rowsPerPage = event.rows;
      this.searchSortCampaigns.index = event.first;
      this.searchSortCampaigns.sort = event.sortField ?? this.searchSortCampaigns.sort;
      this.searchSortCampaigns.sortDirection = event.sortOrder;
      this.loadCampaigns();
    }
  }

  async loadCampaigns() {
    try {
      this.loadingCampaigns = true;
      this.campaignList =
        (await this.campaignService.listCampaigns(
          this.campaignType,
          this.searchSortCampaigns.rowsPerPage,
          this.searchSortCampaigns.index / this.searchSortCampaigns.rowsPerPage,
          this.searchSortCampaigns.sort,
          this.searchSortCampaigns.sortDirection,
          this.searchSortCampaigns.searchText,
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loadingCampaigns = false;
    }
  }

  onExecuteMarketingCampaign(event: any, campaignId: string) {
    event.stopPropagation();

    if (this.selectedUser && this.selectedUser.id && campaignId) {
      this.campaignService
        .runCampaign(campaignId, this.selectedUser.id, null, false, true)
        .then((results: any) => {
          this.toast.success($localize`Success`);
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.showCampaignDialog = false;
        });
    }
  }

  onNotifyClient(type: any, user: any) {
    this.selectedUser = user;
    this.campaignDialog.type = type;
    this.campaignDialog.user = this.selectedUser;
    this.campaignDialog.visible = true;
  }

  handleCampaignExecuted(campaignId: string): void {
    console.log('Campaign executed:', campaignId);
    this.campaignDialog.visible = false;
  }

  onMenuClick(event: Event, menu: any, user: any): void {
    event.stopPropagation();
    this.selectedUser = user;
    this.menuModel = [
      {
        label: $localize`Notify`,
        icon: 'pi pi-arrow-circle-up',
        items: [
          {
            label: 'Marketing',
            command: (event) => this.onNotifyClient('client', this.selectedUser),
          },
          {
            label: 'Survey',
            command: (event) => this.onNotifyClient('survey', this.selectedUser),
          },
          {
            label: 'Questionnaire',
            command: (event) => this.onNotifyClient('questionnaire', this.selectedUser),
          },
        ],
      },
      {
        label: $localize`Remove Client`,
        icon: 'pi pi-trash',
        command: () => this.onStartDeleteUser(this.selectedUser),
        styleClass: 'delete-menu-item',
      },
    ];

    menu.toggle(event);
  }
}
