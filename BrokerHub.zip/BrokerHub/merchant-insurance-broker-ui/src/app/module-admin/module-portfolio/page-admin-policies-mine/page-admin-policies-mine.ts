import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AuthenticationService } from '../../../services/service-authentication';
import { RoutingService } from '../../../services/service-routing';
import { Router } from '@angular/router';

@Component({
    selector: 'admin-policies-mine-page',
    templateUrl: './page-admin-policies-mine.html',
    styleUrls: ['./page-admin-policies-mine.scss'],
    host: { class: 'pt-0 pl-0 col' },
    standalone: false
})
export class AdminPoliciesMinePage implements OnInit {
  user: any;

  constructor(
    private authProvider: AuthenticationService,
    public routing: RoutingService,
    private router: Router,
  ) {
    this.user = {
      id: authProvider.userId,
      first_name: authProvider.firstName,
      last_name: authProvider.lastName,
    };
  }

  ngOnInit() {
    this.routing.addRoute(this.authProvider.firstName + ' ' + this.authProvider.lastName, true);
  }

  onViewPOI(policyCard: any) {
    if (policyCard) {
      this.router.navigate(['/user/pink-cards'], {
        queryParams: {
          id: policyCard.id,
        },
      });
    }
  }  
}
