import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { SearchSortService } from '../../../services/service-search-sort';
import { RenewalsService } from '../../../services/service-renewals';
import { NumberUtils } from '../../../utils/utils_number';
import { SettingsService } from '../../../services/service-settings';
import { FilterService } from '../../../services/service-filter';

@Component({
  templateUrl: './page-admin-renewals.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./page-admin-renewals.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminRenewalsPage implements OnInit {
  loading: boolean = true;
  totalRenewals: number = 0;
  renewalList: any[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  renewalThreshold: number = 0;
  showFilter: boolean = false;
  tempFilterIssues: number[] | null = null;
  totalRules: number = 0;
  validations: any[] | null = null;

  constructor(
    private router: Router,
    public returnService: RoutingService,
    private renewalService: RenewalsService,
    public searchSortService: SearchSortService,
    public filterService: FilterService,

    public settingsService: SettingsService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.loading = true;
    this.returnService.addRoute('Renewals', true);
    this.searchSortService.context = 'AdminRenewalsPage';
    this.filterService.context = 'AdminRenewalsPage';
    this.filterService.index = 0;
    this.renewalThreshold = parseFloat(this.settingsService.getSetting('renewalsPremiumChangePercentThreshold') ?? '5');

    this.renewalService
      .totalRenewals()
      .then((total: number) => {
        this.totalRenewals = total;
        this.loadRenewals();
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });

    this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
      this.search();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadRenewals();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadRenewals(event: any) {
    if (!this.loading) {
      this.searchSortService.rowsPerPage = event.rows;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadRenewals();
    }
  }

  loadRenewals() {
    this.loading = true;
    this.renewalService
      .listRenewals(
        this.searchSortService.rowsPerPage,
        this.searchSortService.index / this.searchSortService.rowsPerPage,
        this.searchSortService.sort,
        this.searchSortService.sortDirection,
        this.searchSortService.searchText,
        this.filterService.values,
      )
      .then((renewals) => {
        this.renewalList = renewals ?? [];
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  onOpenRenewal(policy: any) {
    this.router.navigate(['/admin/portfolio/renewal'], {
      queryParams: {
        id: policy.id,
        policy_number: policy.policy_number,
        company: policy.company,
        lob: policy.lob,
      },
    });
  }

  onPolicySearch() {
    var searchText = this.searchSortService.searchText;
    this.searchSortService.context = 'AdminPoliciesPage';
    this.searchSortService.searchText = searchText;
    this.router.navigate(['/admin/portfolio/portfolio/policies']);
  }

  onShowAdvanced() {
    this.renewalService
      .totalValidationRules()
      .then((total: number) => {
        this.totalRules = total;
        this.loadRules();
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  onLoadRules(event: any) {
    if (!this.loading) {
      this.filterService.rowsPerPage = event.rows;
      this.filterService.index = event.first;
      this.loadRules();
    }
  }

  loadRules() {
    this.loading = true;
    this.renewalService
      .listValidationRules(null, null, 'description', null, null)
      .then((validations) => {
        this.validations = validations ?? [];
        this.tempFilterIssues = [...(this.filterService.values ?? [])];
        this.showFilter = true;
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  onFilter() {
    // Make a copy.
    if (this.tempFilterIssues != null) this.filterService.values = [...this.tempFilterIssues];
    else this.filterService.values = null;
    this.showFilter = false;
    this.loadRenewals();
  }

  onClearFilter() {
    this.tempFilterIssues = null;
    this.filterService.values = null;
    this.showFilter = false;
    this.loadRenewals();
  }

  formatDollarAmount(dollarAmount: number | null): string {
    return NumberUtils.formatDollarAmount(dollarAmount);
  }

  formatPercent(amount: number | null): string {
    return NumberUtils.formatPercent(amount);
  }
}
