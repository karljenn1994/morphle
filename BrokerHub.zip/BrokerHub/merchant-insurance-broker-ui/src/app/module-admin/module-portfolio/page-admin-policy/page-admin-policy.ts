import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastProvider } from '../../../providers/provider-toast';
import { PoliciesService } from '../../../services/service-policies';
import { RoutingService } from '../../../services/service-routing';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { AdminService } from '../../../services/service-admin';
import { NumberUtils } from '../../../utils/utils_number';
import { CampaignDialogWidget } from '../../../components/widget-campaign-dialog/widget-campaign-dialog';
import { MenuItem } from 'primeng/api';
import { NotifierService } from '../../../services/service-notifier';

@Component({
  selector: 'admin-policy-page',
  templateUrl: './page-admin-policy.html',
  styleUrls: ['./page-admin-policy.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminPolicyPage implements OnInit {
  loading = false;

  policyReport: any;
  showRemoveUserDialog = false;
  loadingUsers = false;
  showAddUserDialog = false;
  totalUsers: number = -1;
  totalMappedUsers: number = 0;
  userList: any[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  searchText: string | null = null;
  sort: string | null = null;
  sortDirection: string | null = null;
  index: number = 0;
  rowsPerPage: number = 10;
  policyCard: any = null;
  selectedUser: any = null;
  selectedPolicy: any = null;
  menuModel: MenuItem[] = [];

  @ViewChild(CampaignDialogWidget) campaignDialog!: CampaignDialogWidget;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public routing: RoutingService,
    private policiesService: PoliciesService,
    private adminService: AdminService,
    private notifierService: NotifierService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      var policy_id = this.routing.getQueryParameters()?.get('id');
      var policy_number = this.routing.getQueryParameters()?.get('policy_number');
      var company = this.routing.getQueryParameters()?.get('company');
      var lob = this.routing.getQueryParameters()?.get('lob');

      this.routing.addRoute(policy_number ?? $localize`Policy`, false);
      var getPolicyReport;

      if (policy_id) {
        getPolicyReport = this.policiesService.getPolicyReport(policy_id, null, null, null);
      } else if (policy_number && lob && company) {
        getPolicyReport = this.policiesService.getPolicyReport(null, policy_number, company, lob);
      } else if (policy_number) {
        getPolicyReport = this.policiesService.getPolicyReport(null, policy_number, null, null);
      }

      this.policyReport = await getPolicyReport;

      for (let policy of this.policyReport.policies) {
        for (let card of policy) {
          if (card.type == 'policy') {
            if (this.policyCard == null) {
              this.policyCard = card;

              if (this.policyCard?.fields?.policy_number != null) {
                this.routing.setLabel(this.policyCard?.fields?.policy_number);
              }
            }

            console.log('POLICY EDI');
            console.log(card['edi']);
            console.log('POLICY JSON');
            console.log(card['json']);
          }
        }
      }

      for (let policy of this.policyReport.renewals) {
        for (let policy_card of policy) {
          if (policy_card.type == 'policy') {
            console.log('RENEWAL EDI');
            console.log(policy_card['edi']);
            console.log('RENEWAL JSON');
            console.log(policy_card['json']);
          }
        }
      }

      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.search();
      });

      this.totalMappedUsers = this.policyReport?.users.length ?? 0;
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.index = 0;
    this.loadUsers();
  }

  searchChanged() {
    if (this.searchText != null) {
      this.searchSubject.next(this.searchText);
    }
  }

  clearSearch() {
    this.searchText = null;
    this.search();
  }

  formatDollarAmount(amount: any | null): string {
    return NumberUtils.formatDollarAmount(amount);
  }

  lookupRenewal(policy: any) {
    if (policy == null) return null;
    var policy_card = this.getPolicyCard(policy);
    if (policy_card == null) return null;

    var policyNumber = policy_card?.fields?.policy_number;
    var policyCompany = policy_card?.fields?.company_code;
    var policyLob = policy_card?.fields?.lob;
    var renewals = this.policyReport['renewals'];

    if (renewals) {
      for (var renewal of renewals) {
        var renewal_policy_card = this.getPolicyCard(renewal);
        var renewalPolicyNumber = renewal_policy_card?.fields?.policy_number;
        var renewalCompany = renewal_policy_card?.fields?.company_code;
        var renewalLob = renewal_policy_card?.fields?.lob;

        if (renewalPolicyNumber == policyNumber && renewalLob == policyLob && renewalCompany == policyCompany) {
          return renewal;
        }
      }
    }
    return null;
  }

  lookupHistory(policy: any) {
    if (policy == null) return null;
    var policy_card = this.getPolicyCard(policy);
    if (policy_card == null) return null;
    return policy_card['history'];
  }

  getPolicyCard(policy: any) {
    var policyCard: any;

    for (let card of policy) {
      if (card.type == 'policy') {
        policyCard = card;
        break;
      }
    }
    return policyCard;
  }

  onLoadUsers(event: any) {
    if (!this.loadingUsers) {
      this.rowsPerPage = event.rows;
      this.index = event.first;
      this.sort = event.sortField;
      this.sortDirection = event.sortOrder;
      this.loadUsers();
    }
  }

  loadUsers() {
    if (!this.showAddUserDialog || this.loadingUsers) {
      return;
    }

    this.loadingUsers = true;

    if (this.totalUsers == -1) {
      this.adminService
        .totalUsers(null)
        .then((total: number) => {
          this.totalUsers = total;
        })
        .catch((error) => {
          this.toast.show(error);
        });
    }

    this.adminService
      .listUsers(
        this.rowsPerPage,
        this.index / this.rowsPerPage,
        this.sort,
        this.sortDirection,
        this.searchText,
        null,
        null,
      )
      .then((users) => {
        this.loadingUsers = false;
        this.userList = users ?? [];
      })
      .catch((error) => {
        this.loadingUsers = false;
        this.toast.show(error);
      });
  }

  openUser(user: any) {
    this.router.navigate(['/admin/portfolio/policies-user'], { queryParams: { id: user.id } });
  }

  onStartAddUser(event: any) {
    event.stopPropagation();
    this.showAddUserDialog = true;
    this.loadUsers();
  }

  getPolicyId() {
    var policy_id = null;

    // Try to add the policy to the user.
    if ('id' in this.policyCard) {
      policy_id = this.policyCard['id'];
    }

    if (!policy_id) {
      // If we only have a renewal, then try to add the user to the
      // renewal.
      let policy = this.policyReport.policies[0];
      let r = this.lookupRenewal(policy);

      if (r) {
        let p = this.getPolicyCard(r);

        if (p) {
          policy_id = p['id'];
        }
      }
    }

    return policy_id;
  }

  onAddUser(user: any, notify: boolean) {
    const userId = user.id;
    const policy_id = this.getPolicyId();

    if (policy_id) {
      this.policiesService
        .addUser(policy_id, userId, notify)
        .then(() => {
          // Prevent duplicate entries in UI
          const users = this.policyReport.users;
          const alreadyAdded = users.some((u: any) => u.id === userId);

          if (!alreadyAdded) {
            users.push(user);
            this.totalMappedUsers = users.length;
            this.toast.success($localize`Added`);
          } else {
            this.toast.success($localize`User is already mapped`);
          }
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.loading = false;
          this.showAddUserDialog = false;
          this.selectedUser = null;
        });
    }
  }

  onNewUser() {
    this.router.navigate(['/admin/portfolio/user-add'], {
      queryParams: {
        policy_id: this.getPolicyId(),
      },
    });
  }

  onStartRemoveUser(user: any) {
    this.showRemoveUserDialog = true;
  }

  onRemoveUser() {
    if (this.selectedUser) {
      this.loading = true;

      var policyId = this.getPolicyId();

      if (policyId) {
        this.policiesService
          .removeUser(policyId, this.selectedUser.id)
          .then(() => {
            // Now remove from the report.
            const users = this.policyReport.users;
            const idx = users.findIndex((user: { id: any }) => user.id === this.selectedUser.id);

            if (idx !== -1) this.policyReport.users.splice(idx, 1);
            this.totalMappedUsers = this.policyReport?.users.length ?? 0;
            this.toast.success($localize`Deleted`);
          })
          .catch((error) => {
            this.toast.show(error);
          })
          .finally(() => {
            this.loading = false;
            this.showRemoveUserDialog = false;
            this.selectedUser = null;
          });
      }
    }
  }

  onNotifyClient(type: any, user: any) {
    this.selectedUser = user;
    this.selectedPolicy = null;
    this.campaignDialog.type = type;
    this.campaignDialog.policy = this.selectedPolicy;
    this.campaignDialog.user = this.selectedUser;
    this.campaignDialog.visible = true;
  }

  onNotifyClients(ev: any) {
    this.selectedUser = null;
    this.selectedPolicy = ev.policy;
    this.campaignDialog.type = ev.type;
    this.campaignDialog.policy = this.selectedPolicy;
    this.campaignDialog.user = this.selectedUser;
    this.campaignDialog.visible = true;
  }

  handleCampaignExecuted(campaignId: string): void {
    console.log('Campaign executed:', campaignId);
    this.campaignDialog.visible = false;
  }

  onToggleNotifications(user: any, enabled: boolean) {
    if (this.selectedUser) {
      this.loading = true;
      var policyId = this.getPolicyId();

      if (policyId) {
        this.notifierService
          .toggleNotifications(user.id, policyId, enabled)
          .then(() => {
            user.notify = enabled;
            this.toast.success($localize`Notifications ` + (enabled ? 'enabled' : 'disabled'));
          })
          .catch((error) => {
            this.toast.show(error);
          })
          .finally(() => {
            this.loading = false;
            this.selectedUser = null;
          });
      }
    }
  }

  onMenuClick(event: Event, menu: any, user: any): void {
    event.stopPropagation();
    this.selectedUser = user;

    const notificationsEnabled = user.notify > 0;

    this.menuModel = [
      {
        label: $localize`Notify`,
        icon: 'pi pi-arrow-circle-up',
        disabled: !notificationsEnabled,
        items: [
          {
            label: 'Marketing',
            command: () => this.onNotifyClient('client', this.selectedUser),
          },
          {
            label: 'Survey',
            command: () => this.onNotifyClient('survey', this.selectedUser),
          },
          {
            label: 'Questionnaire',
            command: () => this.onNotifyClient('questionnaire', this.selectedUser),
          },
        ],
      },
      {
        label: notificationsEnabled ? $localize`Disable Notifications` : $localize`Enable Notifications`,
        icon: notificationsEnabled ? 'pi pi-bell-slash' : 'pi pi-bell',
        styleClass: 'white-space-nowrap',
        command: () => this.onToggleNotifications(this.selectedUser, !notificationsEnabled),
      },
      { separator: true },
      {
        label: $localize`Remove Client`,
        icon: 'pi pi-trash',
        command: () => this.onStartRemoveUser(this.selectedUser),
        styleClass: 'delete-menu-item',
      },
    ];

    menu.toggle(event);
  }

  getUserTooltip(user: any): string | undefined {
    const parts: string[] = [];

    if (user?.date_of_birth) {
      parts.push(`DOB: ${user.date_of_birth}`);
    }

    if (user?.postal_code) {
      parts.push(`Postal: ${user.postal_code}`);
    }

    if (user?.province) {
      parts.push(`Prov: ${user.province}`);
    }

    return parts.length ? parts.join('<br>') : undefined;
  }
}
