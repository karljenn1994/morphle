import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardPage } from './page-admin-dashboard/page-admin-dashboard';
import { AdminPoliciesMinePage } from './page-admin-policies-mine/page-admin-policies-mine';
import { AdminPoliciesUserPage } from './page-admin-policies-user/page-admin-policies-user';
import { AdminPoliciesPage } from './page-admin-policies/page-admin-policies';
import { AdminPolicyAddPage } from './page-admin-policy-add/page-admin-policy-add';
import { AdminPolicyPage } from './page-admin-policy/page-admin-policy';
import { AdminRenewalsMinePage } from './page-admin-renewals-mine/page-admin-renewals-mine';
import { AdminRenewalsPage } from './page-admin-renewals/page-admin-renewals';
import { AdminUserAddPage } from './page-admin-user-add/page-admin-user-add';
import { AdminUserPage } from './page-admin-user/page-admin-user';
import { AdminUsersPage } from './page-admin-users/page-admin-users';
import { AdminRenewalPage } from './page-admin-renewal/page-admin-renewal';

const routes: Routes = [
  { path: '', component: AdminDashboardPage },
  { path: 'policy', component: AdminPolicyPage },
  { path: 'renewal', component: AdminRenewalPage },
  { path: 'policy-add', component: AdminPolicyAddPage },
  { path: 'policies', component: AdminPoliciesPage },
  { path: 'policies-user', component: AdminPoliciesUserPage },
  { path: 'policies-mine', component: AdminPoliciesMinePage },
  { path: 'NBS', component: AdminPoliciesMinePage },
  { path: 'PCH', component: AdminPoliciesMinePage },
  { path: 'XLN', component: AdminPoliciesMinePage },
  { path: 'renewals-mine', component: AdminRenewalsMinePage },
  { path: 'RWL', component: AdminRenewalsMinePage },
  { path: 'renewals', component: AdminRenewalsPage },
  { path: 'users', component: AdminUsersPage },
  { path: 'user', component: AdminUserPage },
  { path: 'user-add', component: AdminUserAddPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class PortfolioRoutingModule {}
