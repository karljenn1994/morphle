import { Component, OnInit } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { ToastProvider } from '../../../providers/provider-toast';
import { ClaimsService } from '../../../services/service-claims';
import { RefreshService } from '../../../services/service-refresh';
import { RoutingService } from '../../../services/service-routing';
import { SettingsService } from '../../../services/service-settings';
import { NumberUtils } from '../../../utils/utils_number';

@Component({
  selector: 'admin-claim-page',
  templateUrl: './page-admin-claim.html',
  styleUrls: ['./page-admin-claim.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminClaimPage implements OnInit {
  loading = false;
  claimId!: string;
  claimReport: any;
  systemPubUrl: string | null = null;
  images: { src: string }[] = [];

  responsiveOptions = [
    { breakpoint: '1024px', numVisible: 3 },
    { breakpoint: '768px', numVisible: 2 },
    { breakpoint: '560px', numVisible: 1 },
  ];

  statuses: any[] = [
    { name: $localize`Received`, value: 'received' },
    { name: $localize`Review`, value: 'reviewing' },
    { name: $localize`Complete`, value: 'completed' },
  ];

  getStatus(): string {
    const statusValue = this.claimReport['status']?.toLowerCase();
    const matched = this.statuses.find((s) => s.value === statusValue);
    return matched ? matched.name : (statusValue ?? '');
  }

  claimTypes: any[] = [
    { name: $localize`Backed Into Car`, value: '1' },
    { name: $localize`Changed Lanes`, value: '2' },
    { name: $localize`Collision with Animal`, value: '3' },
    { name: $localize`Collision - Head-on`, value: '4' },
    { name: $localize`Collision - Rear-ended`, value: '5' },
    { name: $localize`Collision - Multi-vehicle`, value: '6' },
    { name: $localize`Collision - Other`, value: '7' },
    { name: $localize`Disobeyed Stop Sign/Red Light`, value: '8' },
    { name: $localize`Fire`, value: '16' },
    { name: $localize`Flood`, value: '17' },
    { name: $localize`Glass/Windshield`, value: '18' },
    { name: $localize`Hit & Run`, value: '19' },
    { name: $localize`Hit Pedestrian`, value: '20' },
    { name: $localize`Lightning`, value: '21' },
    { name: $localize`Parking Lot`, value: '22' },
    { name: $localize`Theft`, value: '31' },
    { name: $localize`Vandalism`, value: '34' },
    { name: $localize`Windstorm/Hail`, value: '36' },
    { name: $localize`Wrong Way - One-way Street`, value: '37' },
  ];

  getClaimType(): string {
    const statusValue = this.claimReport['claim']['claim']['type']['code']?.toLowerCase();
    const matched = this.claimTypes.find((s) => s.value === statusValue);
    return matched ? matched.name : (statusValue ?? '');
  }

  coverage_descriptions: any = {
    TPPD: 'Property Damage Liability',
    AB: 'Accident Benefits',
    TPBI: 'Bodily Injury Liability',
    TPDC: 'Direct Compensation Property Damage',
    CMP: 'Comprehensive',
    COL: 'Collision',
    UA: 'Uninsured Automobile',
    '44': '44 - Family Protection',
    FLOOD: 'Flood Damage (Surface Water)',
    DWELL: 'Dwelling (A)',
    PL: 'Liability (E)',
    SEWER: 'Sewer Back-up Coverage',
    WATER: 'Water Damage Endorsement',
    ByLaws: 'Bylaws Endorsement',
    CLFRE: 'Claim Free Protection',
  };

  constructor(
    private claimsService: ClaimsService,
    public routing: RoutingService,
    private refreshService: RefreshService,
    private settingsService: SettingsService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.claimId = this.routing.getQueryParameters()?.get('id')!;
      this.routing.addRoute($localize`Claim`, false);
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
      this.claimReport = await this.claimsService.getClaimReport(this.claimId);

      for (let image of this.claimReport.images) {
        const url = `${this.systemPubUrl}/claims/${this.claimId}/${image}`;
        this.images.push({ src: url });
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  getDriverName() {
    var driver = this.claim.driver;

    if (driver.name) {
      return driver.name;
    } else if (driver.first_name && driver.last_name) {
      return driver.first_name + ' ' + driver.last_name;
    }

    return '';
  }

  getPDFLink(pdf: any) {
    return environment.apiURL + '/' + pdf.download_link;
  }

  get claim() {
    var claim = this.claimReport.claim;

    for (var key of Object.keys(claim)) {
      var card = claim[key];

      if (key == 'claim' || card.type == 'claim') return card;
    }

    return null;
  }

  get vehicles() {
    var vehs = [];
    var claim = this.claimReport.claim;

    for (var key of Object.keys(claim)) {
      var card = claim[key];

      if (card.type == 'vehicle') vehs.push(card);
    }

    return vehs;
  }

  get property() {
    var claim = this.claimReport.claim;

    for (var key of Object.keys(claim)) {
      var card = claim[key];

      if (card.type == 'property') return card;
    }

    return null;
  }

  get insured() {
    var claim = this.claimReport.claim;

    for (var key of Object.keys(claim)) {
      var card = claim[key];

      if (card.type == 'individual') return card;
    }

    return null;
  }

  get policy() {
    var claim = this.claimReport.claim;

    for (var key of Object.keys(claim)) {
      var card = claim[key];

      if (card.type == 'policy') return card;
    }

    return null;
  }

  async onStatusChanged(event: any) {
    try {
      this.loading = true;
      var status = event.option.value;
      await this.claimsService.changeStatus(this.claimId, status);
      this.refreshService.emitRefresh();
      this.claimReport.status = status;
      var dt = new Date();
      var now = dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2) + '-' + ('0' + dt.getDate()).slice(-2);
      this.claimReport.modified_date = now;
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  formatDollarAmount(dollarAmount: number | null): string {
    return NumberUtils.formatDollarAmount(dollarAmount);
  }
}
