import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../components/module-components';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { GalleriaModule } from 'primeng/galleria';

import { ClaimsRoutingModule } from './claims-routing.module';
import { AdminClaimPage } from './page-admin-claim/page-admin-claim';
import { AdminClaimsPage } from './page-admin-claims/page-admin-claims';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
  declarations: [AdminClaimPage, AdminClaimsPage],
  imports: [
    BreadcrumbModule,
    ButtonModule,
    ClaimsRoutingModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FieldsetModule,
    FormsModule,
    GalleriaModule,
    PanelModule,
    ProgressSpinnerModule,
    SelectButtonModule,
    SelectModule,
    TableModule,
    TooltipModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class ClaimsModule {}
