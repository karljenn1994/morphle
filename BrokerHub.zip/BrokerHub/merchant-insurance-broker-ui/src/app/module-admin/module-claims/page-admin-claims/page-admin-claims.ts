import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { ClaimsService } from '../../../services/service-claims';
import { RefreshService } from '../../../services/service-refresh';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';


@Component({
  templateUrl: './page-admin-claims.html',
  styleUrls: ['./page-admin-claims.scss'],
  providers: [MessageService, ConfirmationService],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminClaimsPage implements OnInit {
  loading: boolean = true;
  totalClaims: number = 0;
  claimList: any[] = [];
  claimToDelete: any;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private claimService: ClaimsService,
    private refreshService: RefreshService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.loading = true;
    this.routing.addRoute($localize`Claims Received`, true);
    this.searchSortService.context = 'AdminClaimsPage';

    this.claimService
      .totalClaims()
      .then((total: number) => {
        this.totalClaims = total;
        this.loadClaims();
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });

    this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
      this.search();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadClaims();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadClaims(event: any) {
    if (!this.loading) {
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadClaims();
    }
  }

  loadClaims() {
    this.loading = true;
    this.claimService
      .listClaims(
        this.searchSortService.rowsPerPage,
        this.searchSortService.index / this.searchSortService.rowsPerPage,
        this.searchSortService.sort,
        this.searchSortService.sortDirection,
        this.searchSortService.searchText,
      )
      .then((claims) => {
        this.loading = false;
        this.claimList = claims ?? [];
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
  }

  onOpenClaim(claim: any) {
    this.router.navigate(['/admin/claims/claim'], {
      queryParams: {
        id: claim.id,
      },
    });
  }

  onStartDeleteClaim(event: any, claim: Map<string, any>) {
    event.stopPropagation();
    this.claimToDelete = claim;
    this.showDeletedDialog = true;
  }

  onDeleteClaim(event: any) {
    event.stopPropagation();

    if (this.claimToDelete) {
      this.loading = true;

      this.claimService
        .deleteClaim(this.claimToDelete.id)
        .then(() => {
          this.refreshService.emitRefresh();
          this.toast.success($localize`Deleted`);
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.loading = false;
          this.showDeletedDialog = false;
          this.claimToDelete = null;
          this.loadClaims();
        });
    }
  }
}
