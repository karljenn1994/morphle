import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminClaimPage } from './page-admin-claim/page-admin-claim';
import { AdminClaimsPage } from './page-admin-claims/page-admin-claims';

const routes: Routes = [
  { path: '', component: AdminClaimsPage },
  { path: 'claims', component: AdminClaimsPage },
  { path: 'claim', component: AdminClaimPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class ClaimsRoutingModule {}
