import { Component, OnInit } from '@angular/core';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { Router } from '@angular/router';
import { ValidatorService } from '../../../services/service-validators';
import { MenuItem } from 'primeng/api';

@Component({
    selector: 'admin-validators-page',
    templateUrl: './page-admin-validators.html',
    styleUrls: ['./page-admin-validators.scss'],
    providers: [],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminValidatorsPage implements OnInit {
  loading: boolean = true;
  validators: any;
  validatorToDelete: any;
  showDeleteDialog = false;
  selectedValidator: any;
  menuItems: MenuItem[] = [];

  constructor(
    private router: Router,
    public routing: RoutingService,
    public searchSortService: SearchSortService,
    public validatorsService: ValidatorService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    this.routing.addRoute($localize`Validations`, true);

    this.menuItems = [
      {
        label: 'Auto Renewal',
        icon: 'pi pi-fw pi-car',
        command: () => this.onNewAutoRenewalValidator(),
      },
      {
        label: 'Property Renewal',
        icon: 'pi pi-fw pi-home',
        command: () => this.onNewHabRenewalValidator(),
      },
    ];

    await this.loadValidators();
  }

  async loadValidators() {
    try {
      this.loading = true;
      this.validators = await this.validatorsService.listValidators();
    }
    catch(error: any) {
      this.toast.show(error);
    }
    finally {
      this.loading = false;
    }
  }

  onOpenValidator(event: any, validator: any) {
    this.loading = true;
    event.stopPropagation();
    this.router.navigate(['/admin/validation/validator'], {
      queryParams: {
        id: validator.id,
        type: validator.type
      }
    });
  }

  onNewAutoRenewalValidator() {
    this.loading = true;
    this.router.navigate(['/admin/validation/validator'], {
      queryParams: {
        type: 'renewal_auto',
      },
    });
  }

  onNewHabRenewalValidator() {
    this.loading = true;
    this.router.navigate(['/admin/validation/validator'], {
      queryParams: {
        type: 'renewal_habl',
      },
    });
  }

  async onSelectValidations(validations: any) {
    try {
      this.loading = true;
      await this.validatorsService.updateValidatorValidations(this.selectedValidator.id, validations.id)
      this.toast.success($localize`Updated`);
      await this.loadValidators();
    }
    catch(error: any) {
      this.toast.show(error);
    }
    finally {
      this.loading = false;
    }
  }

  onStartDeleteValidator(event: any, event_obj: Map<string, any>) {
    event.stopPropagation();
    this.validatorToDelete = event_obj;
    this.showDeleteDialog = true;
  }

  async onDeleteValidator(event: any) {
    try {
      event.stopPropagation();
      this.loading = true;
      
      if (this.validatorToDelete) {
        this.validatorsService.deleteValidator(this.validatorToDelete.id);
        this.toast.success($localize`Updated`);
        await this.loadValidators();
      }
    }
    catch(error: any) {

    }
    finally {
      this.loading = false;
      this.showDeleteDialog = false;
    }
  }
}
