import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { InputNumberModule } from 'primeng/inputnumber';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../components/module-components';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { MenuModule } from 'primeng/menu';
import { AccordionModule } from 'primeng/accordion';
import { FloatLabelModule } from 'primeng/floatlabel';

import { AdminValidationPage } from './page-admin-validation/page-admin-validation';
import { AdminValidationsPage } from './page-admin-validations/page-admin-validations';
import { AdminValidatorPage } from './page-admin-validator/page-admin-validator';
import { AdminValidatorsPage } from './page-admin-validators/page-admin-validators';
import { ValidationRoutingModule } from './validation-routing.module';
import { InputTextModule } from 'primeng/inputtext';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { TooltipModule } from 'primeng/tooltip';
import { Tab, TabsModule } from "primeng/tabs";

@NgModule({
  declarations: [AdminValidationPage, AdminValidationsPage, AdminValidatorPage, AdminValidatorsPage],
  imports: [
    AccordionModule,
    BreadcrumbModule,
    ButtonModule,
    CheckboxModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FloatLabelModule,
    FormsModule,
    InputNumberModule,
    InputTextModule,
    MenuModule,
    MultiSelectModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    SelectModule,
    TableModule,
    TabsModule,
    ToggleSwitchModule,
    TooltipModule,
    ValidationRoutingModule,
    NgCircleProgressModule.forRoot({
        radius: 100,
        outerStrokeWidth: 16,
        innerStrokeWidth: 8,
        outerStrokeColor: '#78C000',
        innerStrokeColor: '#C7E596',
        animationDuration: 300,
    }),
    Tab
],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class ValidationModule {}
