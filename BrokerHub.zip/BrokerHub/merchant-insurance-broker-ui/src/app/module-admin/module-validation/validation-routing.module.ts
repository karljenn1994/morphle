import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminValidationPage } from './page-admin-validation/page-admin-validation';
import { AdminValidationsPage } from './page-admin-validations/page-admin-validations';
import { AdminValidatorPage } from './page-admin-validator/page-admin-validator';
import { AdminValidatorsPage } from './page-admin-validators/page-admin-validators';

const routes: Routes = [
  { path: 'validation', component: AdminValidationPage },
  { path: 'validations', component: AdminValidationsPage },
  { path: 'validator', component: AdminValidatorPage },
  { path: 'validators', component: AdminValidatorsPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class ValidationRoutingModule {}
