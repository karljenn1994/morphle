import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';

import { SelectItem } from 'primeng/api';
import { ValidatorService } from '../../../services/service-validators';
import { v4 as uuidv4 } from 'uuid';

@Component({
    selector: 'admin-validation-page',
    templateUrl: './page-admin-validation.html',
    styleUrls: ['./page-admin-validation.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminValidationPage implements OnInit {
  loading = false;
  form: any;
  validation: any = {
    id: uuidv4(),
  };
  validationType!: string;
  validation_types: SelectItem[] = [
    { label: $localize`:@@Validation.Renewal:Renewal`, value: 'renewal' },
    { label: $localize`:@@Validation.Policy:Policy`, value: 'policy' },
  ];

  severity: SelectItem[] = [
    { label: 'Error', value: 'error' },
    { label: 'Warn', value: 'warn' },
  ];

  constructor(
    public routing: RoutingService,
    private formBuilder: FormBuilder,
    public validatorService: ValidatorService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group({
      name: new FormControl<string>('', [Validators.required, Validators.minLength(1), Validators.maxLength(100)]),
      description: new FormControl<string>('', [Validators.maxLength(255)]),
    });    
  }

  async ngOnInit() {
    try {
      this.loading = true;
      let  validationId = this.routing.getQueryParameters()?.get('id') ?? null;
      this.validationType = this.routing.getQueryParameters()?.get('type') ?? 'renewal_auto';
      this.routing.addRoute($localize`New Rules`, false);

      var rules = null;

      if (validationId) {
        this.validation = await this.validatorService.loadValidation(validationId);
        rules = await this.validatorService.listValidationRules(validationId);
        this.routing.setLabel(this.validation.name);
        this.form.controls['name'].setValue(this.validation.name);
        this.form.controls['description'].setValue(this.validation.description);
  
      } else {
        rules = await this.validatorService.listValidationRuleTemplates(this.validationType);
      }

      rules.forEach((rule: any) => {
        rule.cfg = JSON.parse(rule.cfg);
      });

      this.validation.rules = rules;

    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  hasConfigItems(rule: any): boolean {
    if ('cfg' in rule) {
      for (var i in rule['cfg']) {
        var item = rule['cfg'][i];
        if (this.getType(item) != 'hidden') {
          return true;
        }
      }
    }

    return false;
  }

  getName(cfg: any): string {
    return cfg['name'];
  }

  getDescription(cfg: any): string {
    return cfg['description'];
  }

  getType(cfg: any): string {
    return cfg.type;
  }

  getValue(cfg: any) {
    return cfg['value'];
  }

  get rules() {
    return this.validation.rules;
  }

  get generalRules() {
    return this.validation.rules.filter((rule: any) => rule.type == 'policy');
  }

  get coverageRules() {
    return this.validation.rules.filter(
      (rule: any) => rule.type == 'coverage' || rule.type == 'limit' || rule.type == 'deductible'
    );
  }

  get driverRules() {
    return this.validation.rules.filter((rule: any) => rule.type == 'driver');
  }

  get discountRules() {
    return this.validation.rules.filter((rule: any) => rule.type == 'discount');
  }

  setValue(cfg: any, v: any) {
    cfg['value'] = v;
  }

  getEnabled(rule: any): boolean {
    return rule.enabled == 1;
  }

  setEnabled(rule: any, v: boolean) {
    rule.enabled = v;
  }

  getSeverity(rule: any): boolean {
    return rule.severity;
  }

  setSeverity(rule: any, s: any) {
    rule.severity = s
  }

  async onSave() {
    try {
      this.loading = true;

      if (this.form.invalid) {
        Object.keys(this.form.controls).forEach((field) => {
          const control = this.form.get(field);
          control?.markAsTouched({ onlySelf: true });
        });

        return;
      }

      await this.validatorService.upsertValidation(
        this.validation.id,
        this.form.controls['name'].value ?? '',
        this.form.controls['description'].value ?? '',
        this.validationType,
        this.validation.rules
      );

      this.form.markAsPristine();
      this.toast.success($localize`Saved`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }
}
