import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastProvider } from '../../../providers/provider-toast';
import { ValidatorService } from '../../../services/service-validators';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { MenuItem } from 'primeng/api';

@Component({
    selector: 'admin-validations-page',
    templateUrl: './page-admin-validations.html',
    styleUrls: ['./page-admin-validations.scss'],
    providers: [],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminValidationsPage implements OnInit {
  loading: boolean = true;
  validations: any;
  validationToDelete: any;
  showDeleteDialog = false;
  selectedMessage: any;
  menuItems: MenuItem[] = [];

  constructor(
    private router: Router,
    public routing: RoutingService,
    public searchSortService: SearchSortService,
    public validatorService: ValidatorService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    this.routing.addRoute($localize`Rules`, true);

    this.menuItems = [
      {
        label: 'Auto Renewal',
        icon: 'pi pi-fw pi-car',
        command: () => this.onNewAutoRenewalValidations(),
      },
      {
        label: 'Property Renewal',
        icon: 'pi pi-fw pi-home',
        command: () => this.onNewHabRenewalValidations(),
      },
    ];

    this.loadValidations();
  }

  async loadValidations() {
    try {
      this.loading = true;
      this.validations = await this.validatorService.listValidations(null);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onOpenValidations(event: any, validation: any) {
    event.stopPropagation();
    this.router.navigate(['/admin/validation/validation'], {
      queryParams: {
        id: validation.id,
        type: validation.type,
      },
    });
  }

  onNewAutoRenewalValidations() {
    this.loading = true;
    this.router.navigate(['/admin/validation/validation'], {
      queryParams: {
        type: 'renewal_auto',
      },
    });
  }

  onNewHabRenewalValidations() {
    this.loading = true;
    this.router.navigate(['/admin/validation/validation'], {
      queryParams: {
        type: 'renewal_habl',
      },
    });
  }

  onStartDeleteValidation(event: any, validations: Map<string, any>) {
    event.stopPropagation();
    this.validationToDelete = validations;
    this.showDeleteDialog = true;
  }

  async onDeleteValidation(event: any) {
    try {
      event.stopPropagation();
      this.loading = true;

      if (this.validationToDelete) {
        await this.validatorService.deleteValidation(this.validationToDelete.id)
        this.toast.success($localize`Deleted`);
      }
    }
    catch(error: any) {
      this.toast.show(error);

    }
    finally {
      this.loading = false;
      this.loadValidations();
      this.showDeleteDialog = false;
    }
  }
}
