import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { MenuItem, SelectItem } from 'primeng/api';
import { AdminService } from '../../../services/service-admin';
import { ValidatorService } from '../../../services/service-validators';
import { v4 as uuidv4 } from 'uuid';

@Component({
    selector: 'admin-validator-page',
    templateUrl: './page-admin-validator.html',
    styleUrls: ['./page-admin-validator.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminValidatorPage implements OnInit {
  loading = false;
  isNew = false;
  running = false;
  systemPubUrl: string | null = null;
  form: any;

  validations: any;
  activeItem: MenuItem | undefined;

  company_list: SelectItem[] = [];

  policies: any = null;
  showDryRun: boolean = false;

  validator: any = {
    id: uuidv4(),
  };
  validatorType!: string;

  items: MenuItem[] = [
    { id: 'status', label: $localize`:@@Validator.Status:Status` },
    { id: 'general', label: $localize`:@@Validator.General:General` },
    { id: 'rules', label: $localize`:@@Validator.Rules:Rules` },
  ];

  event_list: SelectItem[] = [
    { label: 'None', value: null },
    { label: 'New Business', value: $localize`:@@ValidatorTrigger.NBS:NBS` },
    { label: 'Policy Change', value: $localize`:@@ValidatorTrigger.PCH:PCH` },
    { label: 'Renewal', value: $localize`:@@ValidatorTrigger.RWL:RWL` },
    { label: 'Reissue', value: $localize`:@@ValidatorTrigger.RII:RII` },
    { label: 'Cancellation', value: $localize`:@@ValidatorTrigger.XLN:XLN` },
  ];

  constructor(
    public routing: RoutingService,
    private formBuilder: FormBuilder,
    public adminService: AdminService,
    public validatorService: ValidatorService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group({
      active: new FormControl<boolean>(false),
      name: new FormControl<string | null>(null, [Validators.required, Validators.minLength(1), Validators.maxLength(100)]),
      description: new FormControl<string | null>(null, [Validators.maxLength(255)]),
      validation_id: new FormControl<string | null>(null, [Validators.required]),
      trigger: new FormControl<string | null>(null),
      companies: new FormControl<string[]>([]),
    });
  }

  async ngOnInit() {
    try {
      this.loading = true;
      this.routing.addRoute($localize`New Validation`, false);
      let validatorId = this.routing.getQueryParameters()?.get('id') ?? null;
      this.validatorType = this.routing.getQueryParameters()?.get('type')!;
      this.activeItem = this.items[0];

      if (validatorId) {
        this.validator = await this.validatorService.loadValidator(validatorId);
        this.routing.setLabel(this.validator.name);
        this.form.controls['active'].setValue(this.validator.active == 1 ? true : false);
        this.form.controls['validation_id'].setValue(this.validator.validation_id);
        this.form.controls['name'].setValue(this.validator.name);
        this.form.controls['description'].setValue(this.validator.description);
        this.form.controls['trigger'].setValue(this.validator.trigger_event);

        if (this.validator.rules) {
          var rules: any = JSON.parse(this.validator.rules);

          if (rules) {
            this.form.controls['companies'].setValue(rules.companies);
          }
        }
      }

      let data: any = await this.validatorService.lists(this.validatorType);
      this.validations = data.validations;
      this.company_list = data.companies;
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  async loadValidations() {
    try {
      this.loading = true;
      this.form.controls['validation_id'].setValue(null);
      this.validations = (await this.validatorService.listValidations(this.validatorType))!;
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onActiveItemChange(event: any) {
    this.activeItem = event;
  }

  async onSave() {
    try {
      // stop here if form is invalid
      if (this.form.invalid) {
        Object.keys(this.form.controls).forEach((field) => {
          const control = this.form.get(field);
          control?.markAsTouched({ onlySelf: true });
        });

        return;
      }

      var rules: any = {
        companies: this.form.controls['companies'].value,
      };

      await this.validatorService.upsertValidator(
        this.validator.id,
        this.form.controls['active'].value ?? false,
        this.validatorType,
        this.form.controls['validation_id'].value ?? '',
        this.form.controls['name'].value ?? '',
        this.form.controls['description'].value ?? '',
        this.form.controls['trigger'].value,
        rules
      );
      this.form.markAsPristine();
      this.toast.success($localize`Saved`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onDryRunValidator() {
    this.running = true;
    this.showDryRun = true;

    this.validatorService
      .runValidator(this.validator.id, true)
      .then((results: any) => {})
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.running = false;
      });
  }

  onContinue() {
    this.running = true;

    this.validatorService
      .runValidator(this.validator.id, false)
      .then((results: any) => {
        this.toast.success($localize`Success`);
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.showDryRun = false;
        this.running = false;
      });
  }
}
