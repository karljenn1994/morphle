import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../components/module-components';

import { AdminRenewalsReportPage } from './page-admin-report-renewals/page-admin-report-renewals';
import { AdminUmappedPoliciesReportPage } from './page-admin-report-unmapped-policies/page-admin-report-unmapped-policies';
import { ReportsRoutingModule } from './reports-routing.module';
import { AdminOnHoldReportPage } from './page-admin-report-on-hold/page-admin-report-on-hold';
import { MenuModule } from 'primeng/menu';

@NgModule({
  declarations: [AdminUmappedPoliciesReportPage, AdminRenewalsReportPage, AdminOnHoldReportPage],
  imports: [
    BreadcrumbModule,
    ButtonModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FormsModule,
    MenuModule,
    ReportsRoutingModule,
    TableModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class ReportsModule {}
