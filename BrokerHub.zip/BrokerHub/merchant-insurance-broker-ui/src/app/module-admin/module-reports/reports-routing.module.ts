import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminUmappedPoliciesReportPage } from './page-admin-report-unmapped-policies/page-admin-report-unmapped-policies';
import { AdminRenewalsReportPage } from './page-admin-report-renewals/page-admin-report-renewals';
import { AdminOnHoldReportPage } from './page-admin-report-on-hold/page-admin-report-on-hold';

const routes: Routes = [
    { 
        path: 'report-renewals', 
        component: AdminRenewalsReportPage
    },
    { 
        path: 'report-unmapped-policies', 
        component: AdminUmappedPoliciesReportPage
    },
    { 
        path: 'report-on-hold', 
        component: AdminOnHoldReportPage
    },    
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class ReportsRoutingModule {}
