import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { PoliciesService } from '../../../services/service-policies';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { RefreshService } from '../../../services/service-refresh';

@Component({
  templateUrl: './page-admin-report-on-hold.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./page-admin-report-on-hold.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminOnHoldReportPage implements OnInit {
  loading: boolean = true;
  totalPolicies: number = 0;
  policyList: any[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  menuModel: MenuItem[] = [];

  constructor(
    private router: Router,
    public returnService: RoutingService,
    private policyService: PoliciesService,
    public searchSortService: SearchSortService,
    private refreshService: RefreshService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.loading = true;
    this.returnService.clear();
    this.returnService.addRoute($localize`On Hold`, true);
    this.searchSortService.context = 'AdminOnHoldReportPage';

    this.policyService
      .totalOnHold()
      .then((total: number) => {
        this.totalPolicies = total;
        this.loadPolicies();
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });

    this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
      this.search();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadPolicies();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadPolicies(event: any) {
    if (!this.loading) {
      this.searchSortService.rowsPerPage = event.rows;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadPolicies();
    }
  }

  loadPolicies() {
    this.loading = true;
    this.policyService
      .listOnHold(
        this.searchSortService.rowsPerPage,
        this.searchSortService.index / this.searchSortService.rowsPerPage,
        this.searchSortService.sort,
        this.searchSortService.sortDirection,
        this.searchSortService.searchText,
      )
      .then((policies) => {
        this.loading = false;
        this.policyList = policies ?? [];
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
  }

  onOpenPolicy(policy: any) {
    this.router.navigate(['/admin/portfolio/policy'], {
      queryParams: {
        id: policy.id,
        policy_number: policy.policy_number,
        company: policy.company,
        lob: policy.lob,
      },
    });
  }

  onMenuClick(event: Event, policy: any, menu: any): void {
    event.stopPropagation();
    this.menuModel = [
      {
        label: $localize`Release`,
        icon: 'pi pi-lock-open',
        command: () => this.onRelease(policy),
      },
    ];

    menu.toggle(event);
  }

  onRelease(policy: any) {
    this.policyService
      .releaseOnHold(policy.id)
      .then(() => {
        this.refreshService.emitRefresh();
        this.toast.success($localize`Released`);
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
        this.loadPolicies();
      });
  }
}
