import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { SearchSortService } from '../../../services/service-search-sort';
import { RenewalsService } from '../../../services/service-renewals';
import { NumberUtils } from '../../../utils/utils_number';
import { SettingsService } from '../../../services/service-settings';

@Component({
  templateUrl: './page-admin-report-renewals.html',
  styleUrls: ['./page-admin-report-renewals.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminRenewalsReportPage implements OnInit {
  loading: boolean = true;
  totalRenewals: number = 0;
  renewalList: any[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  renewalThreshold: number = 0;

  constructor(
    private router: Router,
    public returnService: RoutingService,
    private renewalService: RenewalsService,
    public searchSortService: SearchSortService,
    public settingsService: SettingsService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.returnService.addRoute('Renewals', true);
      this.searchSortService.context = 'AdminReportRenewalsPage';

      this.renewalThreshold = parseFloat(this.settingsService.getSetting('renewalsReportThreshold') ?? '5');
      this.totalRenewals = await this.renewalService.totalRenewals(this.renewalThreshold);
      this.loadRenewals();
      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.search();
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadRenewals();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadRenewals(event: any) {
    if (!this.loading) {
      this.searchSortService.rowsPerPage = event.rows;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadRenewals();
    }
  }

  loadRenewals() {
    this.loading = true;
    this.renewalService
      .listRenewals(
        this.searchSortService.rowsPerPage,
        this.searchSortService.index / this.searchSortService.rowsPerPage,
        this.searchSortService.sort,
        this.searchSortService.sortDirection,
        this.searchSortService.searchText,
        null,
        this.renewalThreshold,
      )
      .then((renewals) => {
        this.renewalList = renewals ?? [];
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  onOpenRenewal(policy: any) {
    this.router.navigate(['/admin/portfolio/renewal'], {
      queryParams: {
        id: policy.id,
        policy_number: policy.policy_number,
        company: policy.company,
        lob: policy.lob,
      },
    });
  }

  onPolicySearch() {
    var searchText = this.searchSortService.searchText;
    this.searchSortService.context = 'AdminPoliciesPage';
    this.searchSortService.searchText = searchText;
    this.router.navigate(['/admin/portfolio/portfolio/policies']);
  }

  formatDollarAmount(dollarAmount: number | null): string {
    return NumberUtils.formatDollarAmount(dollarAmount);
  }

  formatPercent(amount: number | null): string {
    return NumberUtils.formatPercent(amount);
  }
}
