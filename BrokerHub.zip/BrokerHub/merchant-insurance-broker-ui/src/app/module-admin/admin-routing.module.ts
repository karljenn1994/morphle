import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminRoleGuard } from '../guards/guard-role-admin';
import { AppLayout } from '../layout/component/app.layout';

const routes: Routes = [
  {
    path: '',
    component: AppLayout,
    canActivate: [AdminRoleGuard],
    children: [
      {
        path: 'portfolio',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-portfolio/portfolio.module').then((m) => m.PortfolioModule),
      },
      {
        path: 'NBS',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-portfolio/portfolio.module').then((m) => m.PortfolioModule),
      },
      {
        path: 'PCH',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-portfolio/portfolio.module').then((m) => m.PortfolioModule),
      },
      {
        path: 'XLN',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-portfolio/portfolio.module').then((m) => m.PortfolioModule),
      },
      {
        path: 'RWL',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-portfolio/portfolio.module').then((m) => m.PortfolioModule),
      },
      {
        path: 'claims',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-claims/claims.module').then((m) => m.ClaimsModule),
      },
      {
        path: 'campaigns',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-campaigns/campaigns.module').then((m) => m.CampaignsModule),
      },
      {
        path: 'validation',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-validation/validation.module').then((m) => m.ValidationModule),
      },
      {
        path: 'opportunities',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-opportunities/opportunities.module').then((m) => m.OpportunitiesModule),
      },
      {
        path: 'reports',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-reports/reports.module').then((m) => m.ReportsModule),
      },
      {
        path: 'system',
        canActivate: [AdminRoleGuard],
        loadChildren: () => import('./module-system/system.module').then((m) => m.SystemModule),
      },
    ],
  },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class AdminRoutingModule {}
