import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ComponentsModule } from '../components/module-components';
import { AdminRoutingModule } from './admin-routing.module';

@NgModule({
  declarations: [],
  imports: [AdminRoutingModule, CommonModule, ComponentsModule],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class AdminModule {}
