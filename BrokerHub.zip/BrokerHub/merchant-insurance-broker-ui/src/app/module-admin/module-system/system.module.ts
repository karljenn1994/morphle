import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BadgeModule } from 'primeng/badge';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { DialogModule } from 'primeng/dialog';
import { FieldsetModule } from 'primeng/fieldset';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ComponentsModule } from '../../components/module-components';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DatePickerModule } from 'primeng/datepicker';

import { SystemRoutingModule } from './system-routing.module';
import { AdminAdministratorPage } from './page-admin-administrator/page-admin-administrator';
import { AdminAdministratorsPage } from './page-admin-administrators/page-admin-administrators';
import { AdminSettingsPage } from './page-admin-settings/page-admin-settings';
import { AdminTasksPage } from './page-admin-tasks/page-admin-tasks';
import { AdminTaskWidget } from './page-admin-tasks/widget-admin-task';
import { AdminNotificationRecipientsPage } from './page-admin-notification-recipients/page-admin-notification-recipients';
import { AdminNotificationsDraftPage } from './page-admin-notifications-draft/page-admin-notifications-draft';
import { AdminNotifictionsOutboxPage } from './page-admin-notifications-outbox/page-admin-notifications-outbox';
import { AdminNotificationsSentPage } from './page-admin-notifications-sent/page-admin-notifications-sent';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { MenuModule } from 'primeng/menu';
import { TooltipModule } from 'primeng/tooltip';
import { TieredMenuModule } from 'primeng/tieredmenu';

@NgModule({
  declarations: [
    AdminAdministratorPage,
    AdminAdministratorsPage,
    AdminTasksPage,
    AdminTaskWidget,
    AdminSettingsPage,
    AdminNotificationRecipientsPage,
    AdminNotificationsDraftPage,
    AdminNotifictionsOutboxPage,
    AdminNotificationsSentPage,
  ],
  imports: [
    BadgeModule,
    BreadcrumbModule,
    ButtonModule,
    CommonModule,
    ComponentsModule,
    DatePickerModule,
    DialogModule,
    FieldsetModule,
    FloatLabelModule,
    FormsModule,
    InputNumberModule,
    InputTextModule,
    MenuModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    SelectButtonModule,
    SystemRoutingModule,
    TableModule,
    TieredMenuModule,
    TooltipModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class SystemModule {}
