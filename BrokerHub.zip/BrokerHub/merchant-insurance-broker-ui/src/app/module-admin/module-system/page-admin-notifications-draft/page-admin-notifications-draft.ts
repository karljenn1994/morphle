import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { NotifierService } from '../../../services/service-notifier';
import { RefreshService } from '../../../services/service-refresh';
import { SearchSortService } from '../../../services/service-search-sort';
import { RoutingService } from '../../../services/service-routing';

@Component({
  selector: 'draft-page',
  templateUrl: './page-admin-notifications-draft.html',
  providers: [MessageService, ConfirmationService],
  styleUrls: ['./page-admin-notifications-draft.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminNotificationsDraftPage implements OnInit {
  loading: boolean = true;
  totalNotifications: number = 0;
  notificationList: any[] = [];
  notificationToDelete: any;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  activeMessage: any;
  menuModel: MenuItem[] = [];
  
  constructor(
    private notifierService: NotifierService,
    public routing: RoutingService,
    private router: Router,
    private refreshService: RefreshService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.routing.addRoute($localize`Draft Notifications`, true);
    this.searchSortService.context = 'AdminNotificationsDraftPage';

    this.loading = true;
    this.notifierService
      .totalNotifications('draft')
      .then((total: number) => {
        this.totalNotifications = total;
        this.loadNotifications();
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
    this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
      this.search();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadNotifications();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadNotifications(event: any) {
    if (!this.loading) {
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.searchSortService.index = event.first;
      this.loadNotifications();
    }
  }

  loadNotifications() {
    this.loading = true;
    this.notifierService
      .listNotifications(
        'draft',
        this.searchSortService.rowsPerPage,
        this.searchSortService.index / this.searchSortService.rowsPerPage,
        this.searchSortService.sort,
        this.searchSortService.sortDirection,
        this.searchSortService.searchText,
      )
      .then((notifications) => {
        this.loading = false;
        this.notificationList = notifications ?? [];
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
  }

  onMenuClick(event: Event, message: any, menu: any): void {
    event.stopPropagation();
    this.activeMessage = message;
    this.menuModel = [
      {
        label: $localize`Approve`,
        icon: 'pi pi-send',
        command: () => this.onApprove(this.activeMessage),
      },
      {
        label: $localize`Delete Notification`,
        icon: 'pi pi-trash',
        command: () => this.onStartDeleteNotification(this.activeMessage),
        styleClass: 'delete-menu-item'
      },
    ];

    menu.toggle(event);
  }

  onOpenNotification(message: any) {
    this.router.navigate(['/admin/system/recipients'], {
      queryParams: {
        id: message.id,
        mailbox: 'draft',
      },
    });
  }

  onStartDeleteNotification(user: Map<string, any>) {
    this.notificationToDelete = user;
    this.showDeletedDialog = true;
  }

  onDeleteNotification() {
    if (this.notificationToDelete) {
      this.loading = true;

      this.notifierService
        .deleteNotification(this.notificationToDelete?.id)
        .then(() => {
          this.refreshService.emitRefresh();
          this.toast.success($localize`Deleted`);
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.loading = false;
          this.showDeletedDialog = false;
          this.notificationToDelete = null;
          this.loadNotifications();
        });
    }
  }

  onApprove(notification: any) {
    this.notifierService
      .approve(notification?.id)
      .then(() => {
        this.refreshService.emitRefresh();
        this.toast.success($localize`Approved`);
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
        this.showDeletedDialog = false;
        this.notificationToDelete = null;
        this.totalNotifications -= 1;
        this.loadNotifications();
      });
  }
}
