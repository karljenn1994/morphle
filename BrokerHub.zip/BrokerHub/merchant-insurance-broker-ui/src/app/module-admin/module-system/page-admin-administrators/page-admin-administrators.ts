import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MessageService, ConfirmationService } from 'primeng/api';
import { AdminService } from '../../../services/service-admin';
import { ToastProvider } from '../../../providers/provider-toast';
import { Router } from '@angular/router';
import { RoutingService } from '../../../services/service-routing';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { SearchSortService } from '../../../services/service-search-sort';

@Component({
    selector: 'admin-administrators-page',
    templateUrl: './page-admin-administrators.html',
    providers: [MessageService, ConfirmationService],
    styleUrls: ['./page-admin-administrators.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminAdministratorsPage implements OnInit {
  loading: boolean = true;
  totalUsers: number = 0;
  userList: any[] = [];
  user: any | null = null;
  userToDelete: any;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;

  constructor(
    private router: Router,
    private routing: RoutingService,
    private adminService: AdminService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.routing.addRoute($localize`Administrators`, true);
      this.searchSortService.context = 'AdminAdministratorsPage';

      this.totalUsers = await this.adminService.totalUsers('admin');
      await this.loadUsers();

      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.search();
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadUsers();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadUsers(event: any) {
    if (!this.loading) {
      this.searchSortService.rowsPerPage = event.rows;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadUsers();
    }
  }

  async loadUsers() {
    try {
      this.loading = true;
      this.userList =
        (await this.adminService.listUsers(
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText,
          'admin',
          null
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onAddUser() {
    this.user = null;
    this.router.navigate(['/admin/system/administrator']);
  }

  onOpenUser(user: any) {
    this.user = user;
    this.router.navigate(['/admin/system/administrator'], {
      queryParams: {
        id: this.user.id,
      },
    });
  }

  onStartDeleteUser(event: any, user: Map<string, any>) {
    event.stopPropagation();
    this.userToDelete = user;
    this.showDeletedDialog = true;
  }

  async onDeleteUser(event: any) {
    try {
      event.stopPropagation();
      this.loading = true;

      if (this.userToDelete) {
        await this.adminService.deleteUser(this.userToDelete?.id);
        this.toast.success($localize`Deleted`);
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
      this.showDeletedDialog = false;
      this.userToDelete = null;
      this.totalUsers -= 1;
      this.loadUsers();
    }
  }
}
