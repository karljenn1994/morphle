import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../../services/service-admin';
import { Validators, FormBuilder, FormControl } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { LayoutService } from '../../../layout/service/layout.service';
import { RoutingService } from '../../../services/service-routing';

@Component({
    selector: 'admin-administrator-page',
    templateUrl: './page-admin-administrator.html',
    styleUrls: ['./page-admin-administrator.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminAdministratorPage implements OnInit {
  loading = false;
  user: any;
  form: any;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private formBuilder: FormBuilder,
    private adminService: AdminService,
    public layoutService: LayoutService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group({
      first: new FormControl<string>('', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]),
      last: new FormControl<string>('', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]),
      email: new FormControl<string>('', [
        Validators.required,
        Validators.email,
        Validators.minLength(5),
        Validators.maxLength(255),
      ]),
      admin: new FormControl<boolean>(false),
    });
  }

  async ngOnInit() {
    try {
      this.loading = true;
      let user_id = this.routing.getQueryParameters()?.get('id') ?? null;
      this.routing.addRoute($localize`New`, false);

      if (user_id) {
        this.user = await this.adminService.readUser(user_id);
        this.form.controls['email'].setValue(this.user?.email ?? '');
        this.form.controls['first'].setValue(this.user?.first ?? '');
        this.form.controls['last'].setValue(this.user?.last ?? '');
        this.routing.setLabel((this.user?.first ?? '') + ' ' + (this.user?.last ?? ''));
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {}

  async onSubmit() {
    try {
      // stop here if form is invalid
      if (this.form.invalid) {
        Object.keys(this.form.controls).forEach((field) => {
          const control = this.form.get(field);
          control?.markAsTouched({ onlySelf: true });
        });

        return;
      }

      this.loading = true;

      if (this.user == null) {
        await this.adminService.addUser(
          this.form.controls['email'].value!,
          null,
          this.form.controls['first'].value!,
          this.form.controls['last'].value!,
          true,
          null
        );
        this.toast.success($localize`An invitation has been sent`);
      } else {
        await this.adminService.updateUser(
          this.user.id,
          this.form.controls['email'].value!,
          [this.form.controls['first'].value!, this.form.controls['last'].value!].join(' '),
          this.form.controls['first'].value!,
          this.form.controls['last'].value!,
          true
        );
        this.toast.success($localize`Saved`);
      }

      this.routing.popRoute(null).navigate()
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  async saveRole(role: string) {
    try {
      this.loading = true;
      await this.adminService.updateRole(this.user.id, role);
      this.user.role = role;
      this.toast.success($localize`Saved`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  async saveStatus(status: string) {
    try {
      this.loading = true;
      await this.adminService.updateStatus(this.user.id, status);
      this.user.accountStatus = status;
      this.toast.success($localize`Saved`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }
}
