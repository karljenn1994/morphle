import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { ToastProvider } from '../../../providers/provider-toast';
import { NotifierService } from '../../../services/service-notifier';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { RefreshService } from '../../../services/service-refresh';
import { SearchSortService } from '../../../services/service-search-sort';
import { RoutingService } from '../../../services/service-routing';

@Component({
    selector: 'sent-page',
    templateUrl: './page-admin-notifications-sent.html',
    providers: [MessageService, ConfirmationService],
    styleUrls: ['./page-admin-notifications-sent.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminNotificationsSentPage implements OnInit {
  loading: boolean = true;
  totalNotifications: number = 0;
  notificationList: any[] = [];
  notificationToDelete: any;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  
  constructor(
    private notifierService: NotifierService,
    public routing: RoutingService,
    private router: Router,
    private refreshService: RefreshService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider
  ) {}

  ngOnInit() {
    this.routing.addRoute($localize`Sent Notifications`, true);
    this.searchSortService.context = 'AdminNotifictionsSentPage';

    this.loading = true;
    this.notifierService
      .totalNotifications('sent')
      .then((total: number) => {
        this.totalNotifications = total;
        this.loadNotifications();
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });

    this.searchSubscription = this.searchSubject
      .pipe(debounceTime(1000))
      .subscribe((s) => {
        this.search();
      });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadNotifications();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadNotifications(event: any) {
    if (!this.loading) {
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.searchSortService.index = event.first;
      this.loadNotifications();
    }
  }

  loadNotifications() {
    this.loading = true;
    this.notifierService
      .listNotifications(
        'sent',
        this.searchSortService.rowsPerPage,
        this.searchSortService.index / this.searchSortService.rowsPerPage,
        this.searchSortService.sort,
        this.searchSortService.sortDirection,
        this.searchSortService.searchText
      )
      .then((notifications) => {
        this.loading = false;
        this.notificationList = notifications ?? [];
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
  }

  onOpenNotification(message: any) {
    this.router.navigate(['/admin/system/recipients'], {
      queryParams: {
        id: message.id,
        mailbox: 'sent',
      },
    });
  }

  onStartDeleteNotification(event: Event, notification: Map<string, any>) {
    event.stopPropagation();
    this.notificationToDelete = notification;
    this.showDeletedDialog = true;
  }

  onDeleteNotification() {
    if (this.notificationToDelete) {
      this.loading = true;

      this.notifierService
        .deleteNotification(this.notificationToDelete.id)
        .then(() => {
          this.refreshService.emitRefresh()
          this.toast.success($localize`Deleted`);
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.loading = false;
          this.showDeletedDialog = false;
          this.notificationToDelete = null;
          this.totalNotifications -= 1;
          this.loadNotifications();
        });
    }
  }  
}
