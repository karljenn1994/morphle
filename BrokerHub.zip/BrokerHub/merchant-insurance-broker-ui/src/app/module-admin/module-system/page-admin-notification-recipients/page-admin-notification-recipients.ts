import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { NotifierService } from '../../../services/service-notifier';
import { RefreshService } from '../../../services/service-refresh';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { MenuItem } from 'primeng/api';

@Component({
    selector: 'notification-recipients',
    templateUrl: './page-admin-notification-recipients.html',
    styleUrls: ['./page-admin-notification-recipients.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminNotificationRecipientsPage implements OnInit {
  loading: boolean = true;
  notificationId!: string;
  mailbox: string | null = null;
  notification: any;
  totalRecipients: number = 0;
  recipientList: any[] = [];
  selectedUser: any;
  showDeletedDialog = false;
  showPreviewDialog = false;
  previewSubject: string = '';
  previewBody: string = '';
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  menuModel: MenuItem[] = [];
  
  @ViewChild('previewIframe') previewIframe!: ElementRef<HTMLIFrameElement>;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private notifierService: NotifierService,
    public searchSortService: SearchSortService,
    private refreshService: RefreshService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.notificationId = this.routing.getQueryParameters()?.get("id")!;
      this.mailbox = this.routing.getQueryParameters()?.get("mailbox")!;
      this.routing.addRoute($localize`Recipients`, false);
      this.searchSortService.context = 'AdminNotificationRecipientsPage';

      this.notification = await this.notifierService.loadNotification(this.notificationId);

      this.totalRecipients = await this.notifierService.totalRecipients(this.notificationId);
      await this.loadRecipients();

      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe(() => {
        this.search();
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadRecipients();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadRecipients(event: any) {
    if (!this.loading) {
      this.searchSortService.rowsPerPage = event.rows;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadRecipients();
    }
  }

  async loadRecipients() {
    try {
      this.loading = true;
      this.recipientList =
        (await this.notifierService.listRecipients(
          this.notificationId,
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onGoToUser(event: any, recipient: any) {
    event.stopPropagation();
    this.router.navigate(['/admin/portfolio/policies-user'], {
      queryParams: {
        id: recipient.id,
      },
    });
  }

  async onPreviewNotification(recipient: any) {
    try {
      const result = await this.notifierService.testNotification(this.notificationId, recipient.recipient_id);
      this.previewSubject = result.subject;
      this.previewBody = result.body;
      this.showPreviewDialog = true;

      setTimeout(() => {
        const iframe = this.previewIframe?.nativeElement;
        if (iframe?.contentDocument) {
          iframe.contentDocument.open();
          iframe.contentDocument.write(this.previewBody);
          iframe.contentDocument.close();

          const links = iframe.contentDocument.querySelectorAll('a');
          links.forEach((link: HTMLAnchorElement) => {
            link.removeAttribute('href');
            link.style.pointerEvents = 'none';
            link.style.cursor = 'default';
          });
        }
      });
    } catch (error: any) {
      this.toast.show(error);
    }
  }

  onStartDeleteRecipient(recipient: Map<string, any>) {
    this.selectedUser = recipient;
    this.showDeletedDialog = true;
  }

  async onDeleteRecipient() {
    try {
      this.loading = true;

      if (this.selectedUser) {
        await this.notifierService.deleteRecipient(this.selectedUser.recipient_id);
        this.refreshService.emitRefresh();
        this.toast.success($localize`Deleted`);
        this.loadRecipients();
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
      this.showDeletedDialog = false;
      this.selectedUser = null;
    }
  }

  onMenuClick(event: Event, menu: any, user: any): void {
    event.stopPropagation();
    this.selectedUser = user;
    this.menuModel = [
      {
        label: $localize`Preview Notification`,
        icon: 'pi pi-envelope',
        command: () => this.onPreviewNotification(this.selectedUser),
      },      
      {
        label: $localize`Remove Client`,
        icon: 'pi pi-trash',
        command: () => this.onStartDeleteRecipient(this.selectedUser),
        styleClass: 'delete-menu-item',
      },
    ];

    menu.toggle(event);
  }  
}
