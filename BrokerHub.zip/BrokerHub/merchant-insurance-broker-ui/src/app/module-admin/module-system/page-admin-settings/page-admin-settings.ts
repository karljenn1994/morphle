import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastProvider } from '../../../providers/provider-toast';
import { SettingsService } from '../../../services/service-settings';
import { LayoutService } from '../../../layout/service/layout.service';
import { TieredMenu } from 'primeng/tieredmenu';

@Component({
  selector: 'admin-settings-page',
  templateUrl: './page-admin-settings.html',
  styleUrls: ['./page-admin-settings.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminSettingsPage implements OnInit {
  loading = false;
  user: Map<string, any> | null = null;
  form: any;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private settingsService: SettingsService,
    public layoutService: LayoutService,
    private toast: ToastProvider,
  ) {
    this.form = this.formBuilder.group({
      brokerageId: new FormControl<string>('', []),
      brokerageName: new FormControl<string>('', []),
      brokerageWebsiteUrl: new FormControl<string>('', []),
      brokerageWebsiteContactUrl: new FormControl<string>('', []),
      brokeragePhone: new FormControl<string>('', []),
      brokerageAddress: new FormControl<string>('', []),
      brokerageHours: new FormControl<string>('', []),
      brokerageSlogan_en: new FormControl<string>('', []),
      brokerageSlogan_fr: new FormControl<string>('', []),
      brokerageSlogan_zh_CN: new FormControl<string>('', []),
      brokerageSlogan_zh_TW: new FormControl<string>('', []),

      csioNetUsername: new FormControl<string>('', []),
      csioNetPassword: new FormControl<string>('', []),

      importGmailAccount: new FormControl<string>('', []),
      importExpectedRecipientPrefix: new FormControl<string>('', []),

      lifesWalletApiKey: new FormControl<string>('', []),
      lifesWalletCollectionApiUrl: new FormControl<string>('', []),
      lifesWalletMessagingApiUrl: new FormControl<string>('', []),
      lifesWalletPassApiUrl: new FormControl<string>('', []),

      renewalsPremiumChangePercentThreshold: new FormControl<string>('', []),

      sendGridApiKey: new FormControl<string>('', []),
      sendGridFromEmail: new FormControl<string>('', []),
      sendGridReplyEmail: new FormControl<string>('', []),
      sendGridGroupId: new FormControl<string>('', []),

      systemJwtSecret: new FormControl<string>('', []),
      systemJwtAccessTokenExpires: new FormControl<number | null>(null, []),
      systemJwtRefreshTokenExpires: new FormControl<number | null>(null, []),
      systemIdleTimeout: new FormControl<number | null>(null, []),
      systemUIUrl: new FormControl<string>('', []),
      systemPubUrl: new FormControl<string>('', []),
      systemFolder: new FormControl<string>('', []),
      systemDomain: new FormControl<string>('', []),
      systemNotificationDelay: new FormControl<string>('', []),

      renewalsReportThreshold: new FormControl<number | null>(null),
      renewalsReportEmail: new FormControl<string>('', []),
    });
  }

  ngOnInit() {
    this.loading = true;
    var settings_map: Map<string, string> = this.settingsService.settings!;

    for (let [name, value] of settings_map) {
      this.form?.get(name)?.setValue(value);
    }
    this.form.markAsPristine();
    this.loading = false;
  }

  ngOnDestroy(): void {}

  onSubmit() {
    // stop here if form is invalid
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.loading = true;
    let settings_map = new Map<string, string>();

    Object.keys(this.form.controls).forEach((field) => {
      settings_map.set(field, this.form?.get(field)?.value ?? '');
    });

    this.settingsService
      .updateSettings(settings_map)
      .then(() => {
        this.loading = false;
        this.toast.success($localize`Saved`);
        this.form.markAsPristine();
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }
}
