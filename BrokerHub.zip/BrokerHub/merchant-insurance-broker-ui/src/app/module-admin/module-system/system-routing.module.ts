import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminAdministratorPage } from './page-admin-administrator/page-admin-administrator';
import { AdminAdministratorsPage } from './page-admin-administrators/page-admin-administrators';
import { AdminSettingsPage } from './page-admin-settings/page-admin-settings';
import { AdminTasksPage } from './page-admin-tasks/page-admin-tasks';
import { AdminNotificationRecipientsPage } from './page-admin-notification-recipients/page-admin-notification-recipients';
import { AdminNotificationsDraftPage } from './page-admin-notifications-draft/page-admin-notifications-draft';
import { AdminNotifictionsOutboxPage } from './page-admin-notifications-outbox/page-admin-notifications-outbox';
import { AdminNotificationsSentPage } from './page-admin-notifications-sent/page-admin-notifications-sent';

const routes: Routes = [
  { path: 'administrators', component: AdminAdministratorsPage },
  { path: 'administrator', component: AdminAdministratorPage },
  { path: 'tasks', component: AdminTasksPage },
  { path: 'settings', component: AdminSettingsPage },
  { path: 'recipients', component: AdminNotificationRecipientsPage },
  { path: 'drafts', component: AdminNotificationsDraftPage },
  { path: 'outbox', component: AdminNotifictionsOutboxPage },
  { path: 'sent', component: AdminNotificationsSentPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class SystemRoutingModule {}
