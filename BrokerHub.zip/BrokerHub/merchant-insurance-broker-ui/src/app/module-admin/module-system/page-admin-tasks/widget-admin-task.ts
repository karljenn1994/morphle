// widget-admin-task.ts
import {
  Component,
  Input,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { TasksService } from '../../../services/service-tasks';
import { LayoutService } from '../../../layout/service/layout.service';

@Component({
  selector: 'admin-task',
  templateUrl: './widget-admin-task.html',
  styleUrls: ['./widget-admin-task.scss'],
  standalone: false,
})
export class AdminTaskWidget implements OnInit, OnDestroy {
  @Input() title: string = '';
  @Input() subTitle: string = '';
  @Input() name: string = '';

  showJournal = false;
  run_status: string | null = null;
  run_status_timestamp: Date | null = null;
  run_last_successful: Date | null = null;
  journal: String[] | null = null;

  loading = false;
  statuses: any[] = [
    { name: $localize`Enabled`, value: 'enabled' },
    { name: $localize`Disabled`, value: 'disabled' },
  ];

  daysOfWeek: any[] = [
    { name: $localize`All`, value: '*' },
    { name: $localize`Mon`, value: '1' },
    { name: $localize`Tue`, value: '2' },
    { name: $localize`Wed`, value: '3' },
    { name: $localize`Thu`, value: '4' },
    { name: $localize`Fri`, value: '5' },
    { name: $localize`Sat`, value: '6' },
    { name: $localize`Sun`, value: '0' },
  ];

  monthsOfYear: any[] = [
    { name: $localize`All`, value: '*' },
    { name: $localize`Jan`, value: '1' },
    { name: $localize`Feb`, value: '2' },
    { name: $localize`Mar`, value: '3' },
    { name: $localize`Apr`, value: '4' },
    { name: $localize`May`, value: '5' },
    { name: $localize`Jun`, value: '6' },
    { name: $localize`Jul`, value: '7' },
    { name: $localize`Aug`, value: '8' },
    { name: $localize`Sep`, value: '9' },
    { name: $localize`Oct`, value: '10' },
    { name: $localize`Nov`, value: '11' },
    { name: $localize`Dec`, value: '12' },
  ];

  formGroup!: FormGroup;
  pollingTimer: any;
  animationTimer: any;
  runningDots: string = '';
  dotStates = ['.', '..', '...'];
  dotIndex = 0;

  constructor(
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private tasksService: TasksService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.loading = true;

    this.formGroup = this.formBuilder.group({
      status: new FormControl<string>('disabled', [Validators.required]),
      daysOfWeek: new FormControl<string[]>([], [Validators.required]),
      monthsOfYear: new FormControl<string[]>([], [Validators.required]),
      time: new FormControl<Date>(new Date(), [Validators.required]),
    });

    this.tasksService
      .getTask(this.name)
      .then((details: Map<string, string | string[]>) => {
        const getSingleValue = (key: string, fallback: string = ''): string => {
          const value = details.get(key);
          return Array.isArray(value) ? value[0] : (value ?? fallback);
        };

        const getArrayValue = (key: string): string[] => {
          const value = details.get(key);
          return Array.isArray(value) ? value : typeof value === 'string' ? [value] : [];
        };

        const getDateValue = (key: string): Date | null => {
          const value = details.get(key);
          const raw = Array.isArray(value) ? value[0] : value;
          return raw ? new Date(raw) : null;
        };

        this.formGroup?.controls['status'].setValue(getSingleValue('status', 'disabled'));
        this.formGroup?.controls['daysOfWeek'].setValue(getArrayValue('days_of_week'));
        this.formGroup?.controls['monthsOfYear'].setValue(getArrayValue('months_of_year'));
        this.formGroup?.controls['time'].setValue(this.get_local_time(details));

        this.run_status = getSingleValue('run_status');
        this.run_status_timestamp = getDateValue('run_status_timestamp');
        this.run_last_successful = getDateValue('run_last_successful');
        this.journal = getArrayValue('journal');

        if (this.run_status === 'running') {
          this.startPolling();
          this.startRunningAnimation();
        }
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  ngOnDestroy(): void {
    this.stopPolling();
    this.stopRunningAnimation();
  }

  runNow(event: any) {
    event.preventDefault();
    this.loading = true;
    this.tasksService
      .runNow(this.name)
      .then(() => {
        this.run_status = 'running';
        this.startPolling();
        this.startRunningAnimation();
        this.toast.success($localize`Running`);
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  isRunNowDisabled(): boolean {
    return this.loading || this.run_status === 'running';
  }

  startPolling(): void {
    if (this.pollingTimer) return;
    this.pollingTimer = setInterval(() => {
      this.tasksService.getTask(this.name).then((details: Map<string, string | string[]>) => {
        const getSingleValue = (key: string, fallback: string = ''): string => {
          const value = details.get(key);
          return Array.isArray(value) ? value[0] : (value ?? fallback);
        };

        const getArrayValue = (key: string): string[] => {
          const value = details.get(key);
          return Array.isArray(value) ? value : typeof value === 'string' ? [value] : [];
        };

        const getDateValue = (key: string): Date | null => {
          const value = details.get(key);
          const raw = Array.isArray(value) ? value[0] : value;
          return raw ? new Date(raw) : null;
        };

        this.run_status = getSingleValue('run_status');
        this.run_status_timestamp = getDateValue('run_status_timestamp');
        this.run_last_successful = getDateValue('run_last_successful');
        this.journal = getArrayValue('journal');

        if (this.run_status !== 'running') {
          this.stopPolling();
          this.stopRunningAnimation();
        }
      });
    }, 3000);
  }

  stopPolling(): void {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = null;
    }
  }

  startRunningAnimation(): void {
    if (this.animationTimer) return;
    this.animationTimer = setInterval(() => {
      this.dotIndex = (this.dotIndex + 1) % this.dotStates.length;
      this.runningDots = this.dotStates[this.dotIndex];
    }, 500);
  }

  stopRunningAnimation(): void {
    if (this.animationTimer) {
      clearInterval(this.animationTimer);
      this.animationTimer = null;
      this.runningDots = '';
    }
  }

  isUpdateDisabled(): boolean {
    return this.loading || !(this.formGroup.valid && this.formGroup.dirty);
  }

  onOptionClicked(event: any, control: string) {
    var currentDays: any = this.formGroup.controls[control].value;

    if (event.option.value != '*' && currentDays.includes('*')) {
      const index = currentDays.indexOf('*', 0);
      currentDays.splice(index, 1);
      this.formGroup.controls[control].setValue(currentDays);
    } else if (event.option.value == '*' && currentDays.includes('*')) {
      this.formGroup.controls[control].setValue(['*']);
    }
  }

  onSubmit(form: FormGroup) {
    if (form.invalid) {
      Object.keys(form.controls).forEach((field) => {
        const control = form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });
      return;
    }

    this.loading = true;
    var taskStatus = form?.get('status')?.value;
    var daysOfWeek = form?.get('daysOfWeek')?.value;
    var monthsOfYear = form?.get('monthsOfYear')?.value;
    var taskTime: Date = form?.get('time')?.value;

    var minute: number = taskTime.getUTCMinutes();
    var hour: number = taskTime.getUTCHours();

    this.tasksService
      .update(this.name, taskStatus, minute.toString(), hour.toString(), daysOfWeek, monthsOfYear)
      .then(() => {
        this.loading = false;
        this.toast.success($localize`Saved`);
        this.formGroup.markAsPristine();
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  get_local_time(details: Map<string, string | string[]>): Date {
    var time: Date = new Date();

    if (details.has('hour') && details.has('minute')) {
      var minute: number = parseInt(details.get('minute') as string);
      var hour: number = parseInt(details.get('hour') as string);
      var year: number = time.getFullYear();
      var month: number = time.getMonth() + 1;
      var day: number = time.getDay() + 1;

      var offset = new Date().getTimezoneOffset() / 60;
      var utc_date = new Date(year, month, day, hour, minute);
      utc_date.setHours(utc_date.getHours() - offset);

      var local_hours: number = utc_date.getHours();
      var local_minutes: number = utc_date.getMinutes();
      time.setHours(local_hours);
      time.setMinutes(local_minutes);
    }

    return time;
  }
}
