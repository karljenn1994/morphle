import { Component, OnInit } from '@angular/core';
import { LayoutService } from '../../../layout/service/layout.service';

@Component({
    selector: 'admin-tasks-page',
    templateUrl: './page-admin-tasks.html',
    styleUrls: ['./page-admin-tasks.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminTasksPage implements OnInit {
  loading = false;

  constructor(
    public layoutService: LayoutService,
  ) {}

  ngOnInit() {
    this.loading = true;
  }

  ngOnDestroy(): void {}
}
