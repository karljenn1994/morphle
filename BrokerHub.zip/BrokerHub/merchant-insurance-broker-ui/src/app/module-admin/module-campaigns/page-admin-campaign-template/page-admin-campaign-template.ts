import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { SettingsService } from '../../../services/service-settings';
import { v4 as uuidv4 } from 'uuid';
import { LocaleUtils } from '../../../utils/utils_locale';
import { CampaignsService } from '../../../services/service-campaigns';

@Component({
  selector: 'admin-template-page',
  templateUrl: './page-admin-campaign-template.html',
  styleUrls: ['./page-admin-campaign-template.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminCampaignTemplatePage implements OnInit {
  loading = false;
  systemPubUrl: string | null = null;

  isNew = false;
  template: any = {
    id: uuidv4(),
  };
  templateType!: string;
  language: string = 'en';
  showEmailDialog: boolean = false;

  form: any;
  emailform: any;
  displayLanguages: { label: string; value: string }[] = [];
  contentControls: { locale: string; subject: FormControl; body: FormControl }[] = [];

  constructor(
    public routing: RoutingService,
    private formBuilder: FormBuilder,
    public campaignService: CampaignsService,
    private settingsService: SettingsService,
    private toast: ToastProvider,
    private cdr: ChangeDetectorRef
  ) {
    this.form = this.formBuilder.group({
      name: new FormControl<string>('', { validators: [Validators.required, Validators.minLength(1), Validators.maxLength(100)], nonNullable: true }),
      description: new FormControl<string>('', { validators: [Validators.maxLength(255)], nonNullable: true }),
      contents: this.formBuilder.array([]),
    });

    this.emailform = this.formBuilder.group({
      email: new FormControl<string>('', [
        Validators.required,
        Validators.email,
        Validators.minLength(5),
        Validators.maxLength(255),
      ]),
      language: new FormControl<string>('en', [Validators.required]),
    });
  }

  async ngOnInit() {
    try {
      this.loading = true;
      let templateId = this.routing.getQueryParameters()?.get('id') ?? null;
      this.templateType = this.routing.getQueryParameters()?.get('type')!;
      this.routing.addRoute($localize`New`, false);

      for (const locale of LocaleUtils.supportedLocales) {
        this.addContent(locale);
      }

      this.language = LocaleUtils.languages[0].value;
      this.updateDisplayLanguages();

      if (templateId != null) {
        this.template = await this.campaignService.loadTemplate(templateId);
        if (this.template) {
          this.routing.setLabel(this.template?.name ?? 'Error');
          for (const content of JSON.parse(this.template.contents)) {
            this.updateContent(content);
          }
          this.form.controls['name'].setValue(this.template.name);
          this.form.controls['description'].setValue(this.template.description);
        }
      }

      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');

      this.form.statusChanges.subscribe(() => {
        this.updateDisplayLanguages();
        this.cdr.markForCheck();
      });

      this.cdr.markForCheck();
    } catch (error: any) {
      this.toast.show(error);
      this.cdr.markForCheck();
    } finally {
      this.loading = false;
      this.cdr.markForCheck();
    }
  }

  get contents(): FormArray {
    return this.form.controls['contents'] as FormArray;
  }

  get languages() {
    return LocaleUtils.languages;
  }

  private updateDisplayLanguages() {
    this.displayLanguages = this.languages.map(lang => ({
      label: lang.label,
      value: lang.value,
      styleClass: this.hasErrorsForLanguage(lang.value) ? 'tab-error' : '',
    }));
  }

  private updateContentControls() {
    const newControls = this.contents.controls.map((_, i) => ({
      locale: this.getLocaleControl(i).value,
      subject: this.getSubjectControl(i),
      body: this.getBodyControl(i),
    }));
      this.contentControls = newControls;
  }

  getLocaleControl(index: number): FormControl {
    const control = this.contents.at(index).get('locale');
    if (!(control instanceof FormControl)) {
      throw new Error(`Expected FormControl for locale at index ${index}`);
    }
    return control;
  }

  getSubjectControl(index: number): FormControl {
    console.log("getSubjectControl")
    const control = this.contents.at(index).get('subject');
    if (!(control instanceof FormControl)) {
      throw new Error(`Expected FormControl for subject at index ${index}`);
    }
    return control;
  }

  getBodyControl(index: number): FormControl {
    const control = this.contents.at(index).get('body');
    if (!(control instanceof FormControl)) {
      throw new Error(`Expected FormControl for body at index ${index}`);
    }
    return control;
  }

  addContent(locale: any) {
    this.contents.push(
      this.formBuilder.group({
        locale: new FormControl<string>(locale, { nonNullable: true }),
        subject: new FormControl<string>('', { validators: [Validators.required], nonNullable: true }),
        body: new FormControl<string>('', { validators: [Validators.required], nonNullable: true }),
      }),
    );
    this.updateContentControls();
    this.cdr.markForCheck();
  }

  updateContent(content: any) {
    for (let i = 0; i < this.contents.controls.length; i++) {
      if (content.locale === this.getLocaleControl(i).value) {
        this.getSubjectControl(i).setValue(content.subject);
        this.getBodyControl(i).setValue(content.body);
        break;
      }
    }
    this.updateContentControls();
    this.cdr.markForCheck();
  }

  onLanguageChange(value: string | number) {
    this.language = value as string;
    this.updateDisplayLanguages();
    this.cdr.markForCheck();
  }

  hasErrorsForLanguage(locale: string): boolean {
    const index = this.contentControls.findIndex(c => c.locale === locale);
    if (index === -1) return false;

    const subject = this.contentControls[index].subject;
    const body = this.contentControls[index].body;

    return (
      (subject?.invalid && (subject.dirty || subject.touched)) ||
      (body?.invalid && (body.dirty || body.touched))
    );
  }

  stripHtml(html: string): string {
    const div = document.createElement('div');
    div.innerHTML = html;
    let text = div.textContent || div.innerText || '';
    text = text.replace(/\u00A0/g, ' ');
    text = text.replace(/\s+/g, ' ').trim();
    return text;
  }

  private markFormGroupTouched(group: FormGroup | FormArray) {
    Object.values(group.controls).forEach((control) => {
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup || control instanceof FormArray) {
        this.markFormGroupTouched(control);
      }
    });
  }

  async onSave() {
    try {
      if (this.form.invalid) {
        this.markFormGroupTouched(this.form);
        this.cdr.markForCheck();
        return;
      }

      const contents = [];
      for (let i = 0; i < this.contents.controls.length; i++) {
        const subject = this.stripHtml(this.getSubjectControl(i).value);
        const body = this.getBodyControl(i).value;

        if (subject.length > 0 && body.length > 0) {
          contents.push({
            locale: this.getLocaleControl(i).value,
            subject,
            body,
          });
        }
      }

      await this.campaignService.upsertTemplate(
        this.template.id,
        this.form.controls['name'].value,
        this.form.controls['description'].value,
        this.templateType,
        JSON.stringify(contents),
      );

      this.toast.success($localize`Saved`);
      this.form.markAsPristine();
      this.cdr.markForCheck();
    } catch (error: any) {
      this.toast.show(error);
      this.cdr.markForCheck();
    } finally {
      this.loading = false;
      this.cdr.markForCheck();
    }
  }

  async onSendEmail() {
    try {
      if (this.emailform.invalid) {
        Object.keys(this.emailform.controls).forEach((field) => {
          const control = this.emailform.get(field);
          control?.markAsTouched({ onlySelf: true });
        });
        this.cdr.markForCheck();
        return;
      }

      const locale = this.emailform.controls['language'].value;
      let subject = '';
      let body = '';

      for (let i = 0; i < this.contentControls.length; i++) {
        if (this.contentControls[i].locale === locale) {
          subject = this.stripHtml(this.contentControls[i].subject.value);
          body = this.contentControls[i].body.value;
          break;
        }
      }

      await this.campaignService.sendTestEmail(
        this.templateType,
        this.emailform.controls.email.value ?? '',
        subject,
        body,
      );
      this.toast.success($localize`Sent`);
      this.showEmailDialog = false;
      this.cdr.markForCheck();
    } catch (error: any) {
      this.toast.show(error);
      this.cdr.markForCheck();
    } finally {
      this.loading = false;
      this.cdr.markForCheck();
    }
  }
}