import { Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { ToastProvider } from '../../../providers/provider-toast';
import { FormControl } from '@angular/forms';

import {
  AngularEditorComponent,
  AngularEditorConfig,
  AngularEditorService,
  UploadResponse,
} from '@wfpena/angular-wysiwyg';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpEvent, HttpResponse } from '@angular/common/http';
import { Observable, from, map, catchError } from 'rxjs';

@Component({
  selector: 'admin-template-content',
  templateUrl: './widget-admin-campaign-template-content.html',
  styleUrls: ['./widget-admin-campaign-template-content.scss'],
  standalone: false,
})
export class AdminCampaignTemplateContentWidget implements OnInit {
  @Input() subjectFormControl!: FormControl;
  @Input() bodyFormControl!: FormControl;
  @Input() templateId: string | null = null;
  @Input() templateType: string | null = null;

  @ViewChild('editorWrapper') editorWrapper!: ElementRef;
  editorFocused = false;

  editorSubjectConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: '',
    defaultParagraphSeparator: '',
    defaultFontName: 'Lato, sans-serif',
    defaultFontSize: '2',
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      [
        'toggleEditorMode',
        'undo',
        'redo',
        'bold',
        'italic',
        'underline',
        'strikeThrough',
        'subscript',
        'superscript',
        'justifyLeft',
        'justifyCenter',
        'justifyRight',
        'justifyFull',
        'indent',
        'outdent',
        'insertUnorderedList',
        'insertOrderedList',
        'heading',
        'fontName',
      ],
      [
        'fontSize',
        'textColor',
        'backgroundColor',
        'customClasses',
        'link',
        'unlink',
        'insertImage',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
      ],
    ],
  };

  editorBodyConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '200px',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: '',
    defaultParagraphSeparator: '',
    defaultFontName: 'Lato, sans-serif',
    defaultFontSize: '2',
    sanitize: false,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [],
    uploadUrl: 'broker-api/web/v1/ui/pub',
    upload: (file: File): Observable<HttpEvent<UploadResponse>> => {
      const formData = new FormData();
      formData.append('file', file, file.name);

      return new Observable<HttpEvent<UploadResponse>>((observer) => {
        this.http
          .post<UploadResponse>(this.editorBodyConfig.uploadUrl!, formData, {
            reportProgress: true,
            observe: 'events',
            withCredentials: true,
          })
          .subscribe({
            next: (event) => {
              if (event instanceof HttpResponse) {
                observer.next(event);
                observer.complete();
              }
            },
            error: (err) => {
              console.error('Upload failed', err);
              observer.error({
                status: 500,
                message: 'Image upload failed.',
              });
            },
          });
      });
    },
  };

  @ViewChild('editorBody', { static: false })
  textAreaBody!: AngularEditorComponent;

  constructor(
    private http: HttpClient,
    private toast: ToastProvider,
  ) {}
  ngOnInit() {
    this.editorBodyConfig.uploadUrl = `${environment.apiURL}/broker-api/web/v1/ui/pub/${this.templateId}`;
  }

  onEditorFocus() {
    this.editorFocused = true;
  }

  insertURL(event: any, variable: string) {
    const textArea: AngularEditorComponent = this.textAreaBody;
    var editorService: AngularEditorService = textArea['editorService'];
    var selectedText = editorService.selectedText;

    if (selectedText) {
      editorService.executeCommand(
        'insertHtml',
        "<a clicktracking=off href='" + variable + "'>" + selectedText + '</a>',
      );
    } else {
      this.toast.error('Please select the text you would like to turn into a hyperlink');
    }
  }
}
