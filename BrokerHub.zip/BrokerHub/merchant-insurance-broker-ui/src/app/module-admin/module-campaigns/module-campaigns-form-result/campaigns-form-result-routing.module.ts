import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminCampaignFormResultPage } from './page-admin-campaign-form-result/page-admin-campaign-form-result';

const routes: Routes = [
  { path: '', component: AdminCampaignFormResultPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class CampaignsFormResultRoutingModule {}
