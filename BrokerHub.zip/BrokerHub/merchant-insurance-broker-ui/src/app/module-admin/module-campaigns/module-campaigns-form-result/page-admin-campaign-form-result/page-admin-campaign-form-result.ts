import { Component, OnInit } from '@angular/core';
import { ToastProvider } from '../../../../providers/provider-toast';
import { RoutingService } from '../../../../services/service-routing';
import { Model } from 'survey-core';
import { FormService } from '../../../../services/service-form';

@Component({
    selector: 'admin-campaign-form-result-page',
    templateUrl: './page-admin-campaign-form-result.html',
    styleUrls: ['./page-admin-campaign-form-result.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminCampaignFormResultPage implements OnInit {
  loading = false;
  model!: Model;

  constructor(
    private formService: FormService, 
    public routing: RoutingService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    let userId = this.routing.getQueryParameters()?.get('user_id')!;
    let formId = this.routing.getQueryParameters()?.get('form_id')!;

    try {
      let res = await this.formService.loadFormInstanceById(userId, formId);
      this.model = new Model(JSON.parse(res.form));
      this.model.data = JSON.parse(res.form_data);
      this.model.mode = 'display';

      this.model.questionsOnPageMode = 'singlePage';

    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }
}
