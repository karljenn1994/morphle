import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../../components/module-components';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { SurveyModule } from 'survey-angular-ui';
import { SurveyCreatorModule } from 'survey-creator-angular';
import { FloatLabelModule } from 'primeng/floatlabel';

import { CampaignsFormEditorRoutingModule } from './campaigns-form-editor-routing.module';
import { AdminCampaignFormPage } from './page-admin-campaign-form/page-admin-campaign-form';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { TabsModule } from 'primeng/tabs';
import { TooltipModule } from 'primeng/tooltip';
import { FormService } from '../../../services/service-form';

@NgModule({
  declarations: [AdminCampaignFormPage],
  imports: [
    BreadcrumbModule,
    ButtonModule,
    CampaignsFormEditorRoutingModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FloatLabelModule,
    FormsModule,
    InputTextModule,
    MultiSelectModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    SelectModule,
    SurveyModule,
    SurveyCreatorModule,
    TableModule,
    TabsModule,
    TieredMenuModule,
    ToggleSwitchModule,
    TooltipModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi()), FormService],
})
export class CampaignsFormEditorModule {}
