import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminCampaignFormPage } from './page-admin-campaign-form/page-admin-campaign-form';

const routes: Routes = [
  { path: '', component: AdminCampaignFormPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class CampaignsFormEditorRoutingModule {}
