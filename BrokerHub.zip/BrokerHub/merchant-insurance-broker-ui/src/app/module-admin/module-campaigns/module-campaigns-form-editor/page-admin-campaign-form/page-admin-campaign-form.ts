import { Component, OnInit } from '@angular/core';
import { ToastProvider } from '../../../../providers/provider-toast';
import { RoutingService } from '../../../../services/service-routing';
import { FormService } from '../../../../services/service-form';
import { LocaleUtils } from '../../../../utils/utils_locale';
import { slk } from 'survey-core';
import { SurveyCreatorModel } from 'survey-creator-core';
import { v4 as uuidv4 } from 'uuid';
import { surveyLocalization } from 'survey-core';
import { editorLocalization } from 'survey-creator-core';
import 'survey-creator-core/survey-creator-core.i18n';
import 'survey-creator-core/i18n/english';
import 'survey-creator-core/i18n/french';

const creatorOptions = {
  showLogicTab: true,
  isAutoSave: false,
};

surveyLocalization.supportedLocales = ['en', 'fr'];
editorLocalization.currentLocale = LocaleUtils.locale;

@Component({
    selector: 'admin-campaign-form-page',
    templateUrl: './page-admin-campaign-form.html',
    styleUrls: ['./page-admin-campaign-form.scss'],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminCampaignFormPage implements OnInit {
  loading = false;
  formId!: string;
  formType!: string;
  formName: string = '';
  formDescription: string = '';
  systemPubUrl: string | null = null;
  model!: SurveyCreatorModel;

  constructor(public routing: RoutingService, private formService: FormService, private toast: ToastProvider) {}

  async ngOnInit() {
    slk('YTM3MWZiMzgtNWJmMi00MmFhLWI0MDUtN2UwZjZmMDc3NGMyOzE9MjAyNi0wMi0xOQ==');

    this.formId = this.routing.getQueryParameters()?.get('id')!;
    this.formType = this.routing.getQueryParameters()?.get('type')!;
    this.routing.addRoute(!this.formId ? 'New' : '', false);

    this.model = new SurveyCreatorModel(creatorOptions);
    let thisPtr = this;
    this.model.saveSurveyFunc = (saveNo: number, callback: Function) => thisPtr.save(saveNo, callback);

    if (!this.formId) {
      this.formId = uuidv4();
    } else {
      // We are editting an existing form.
      this.loading = true;

      try {
        let resp = await this.formService.loadForm(this.formId);
        this.routing.setLabel(resp.name);
        this.model.text = resp.form;
      } catch (error: any) {
        this.toast.show(error);
      } finally {
        this.loading = false;
      }
    }
  }

  async save(saveNo: number, callback: Function) {
    try {
      this.loading = true;

      await this.formService.saveForm(
        this.formId,
        this.formType,
        this.model.JSON.title ?? 'New',
        this.model.JSON.description ?? '',
        this.model
      );

      callback(saveNo, true);
    } catch (error: any) {
      this.toast.show(error);
      callback(saveNo, false);
    } finally {
      this.loading = false;
    }
  }
}
