import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { RefreshService } from '../../../services/service-refresh';
import { SearchSortService } from '../../../services/service-search-sort';
import { FormService } from '../../../services/service-form';

@Component({
    templateUrl: './page-admin-campaign-form-results.html',
    styleUrls: ['./page-admin-campaign-form-results.scss'],
    providers: [MessageService, ConfirmationService],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminCampaignFormResultsPage implements OnInit {
  loading: boolean = true;
  totalForms: number = 0;
  formList: any[] = [];
  formData: any;
  formToDelete: string | null = null;
  userToDelete: string | null = null;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  campaignId!: string;
  campaignName!: string;
  formId!: string;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private formService: FormService,
    private refreshService: RefreshService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    this.loading = true;

    this.campaignId = this.routing.getQueryParameters()?.get('campaign_id')!;
    this.campaignName = this.routing.getQueryParameters()?.get('campaign_name')!;
    this.formId = this.routing.getQueryParameters()?.get('form_id')!;

    this.routing.addRoute($localize`Results`, false);

    this.searchSortService.context = 'AdminCampaignFormResultsPage';

    try {
      this.totalForms = await this.formService.totalResults(this.formId);
      await this.loadForms();
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }

    this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
      this.search();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadForms();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  async onLoadForms(event: any) {
    if (!this.loading) {
      this.loading = true;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      await this.loadForms();
      this.loading = false;
    }
  }

  async loadForms() {
    try {
      this.formList =
        (await this.formService.listResults(
          this.formId,
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText,
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    }
  }

  onOpenForm(user_id: string) {
    this.router.navigate(['/admin/campaigns/form-result'], {
      queryParams: {
        campaign_id: this.campaignId,
        campaign_name: this.campaignName,
        form_id: this.formId,
        user_id: user_id,
      },
    });
  }

  onStartDeleteForm(event: any, form_id: string, user_id: string) {
    event.stopPropagation();
    this.formToDelete = form_id;
    this.userToDelete = user_id
    this.showDeletedDialog = true;
  }

  async onDeleteForm(event: any) {
    event.stopPropagation();

    if (this.formToDelete) {
      this.loading = true;

      try {
        await this.formService.deleteResult(this.formToDelete!, this.userToDelete!);
        this.refreshService.emitRefresh();
        this.toast.success($localize`Deleted`);
      } catch (error: any) {
        this.toast.show(error);
      } finally {
        this.loading = false;
        this.showDeletedDialog = false;
        this.formToDelete = null;
        this.loadForms();
      }
    }
  }
}
