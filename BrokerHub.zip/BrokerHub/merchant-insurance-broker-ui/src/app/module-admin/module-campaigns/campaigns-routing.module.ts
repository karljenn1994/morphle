import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminCampaignFormResultsPage } from './page-admin-campaign-form-results/page-admin-campaign-form-results';
import { AdminCampaignFormsPage } from './page-admin-campaign-forms/page-admin-campaign-forms';
import { AdminCampaignTemplatePage } from './page-admin-campaign-template/page-admin-campaign-template';
import { AdminCampaignTemplatesPage } from './page-admin-campaign-templates/page-admin-campaign-templates';
import { AdminCampaignPage } from './page-admin-campaign/page-admin-campaign';
import { AdminCampaignsPage } from './page-admin-campaigns/page-admin-campaigns';
import { AdminCampaignRecipientsPage } from './page-admin-campaign-recipients/page-admin-campaign-recipients';

const routes: Routes = [
  { path: 'marketing-campaigns', component: AdminCampaignsPage },
  { path: 'marketing-templates', component: AdminCampaignTemplatesPage },
  { path: 'survey-campaigns', component: AdminCampaignsPage },
  { path: 'survey-templates', component: AdminCampaignTemplatesPage },
  { path: 'survey-forms', component: AdminCampaignFormsPage },
  { path: 'questionnaire-campaigns', component: AdminCampaignsPage },
  { path: 'questionnaire-templates', component: AdminCampaignTemplatesPage },
  { path: 'questionnaire-forms', component: AdminCampaignFormsPage },
  { path: 'campaign', component: AdminCampaignPage },
  { path: 'template', component: AdminCampaignTemplatePage },
  {
    path: 'form',
    loadChildren: () =>
      import('./module-campaigns-form-editor/campaigns-form-editor.module').then((m) => m.CampaignsFormEditorModule),
  },
  { path: 'form-results', component: AdminCampaignFormResultsPage },
  {
    path: 'form-result',
    loadChildren: () =>
      import('./module-campaigns-form-result/campaigns-form-result.module').then((m) => m.CampaignsFormResultModule),
  },
  { path: 'recipients', component: AdminCampaignRecipientsPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class CampaignsRoutingModule {}
