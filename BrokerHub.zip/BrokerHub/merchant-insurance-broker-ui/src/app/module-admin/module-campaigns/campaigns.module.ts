import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularEditorModule } from '@wfpena/angular-wysiwyg';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../components/module-components';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { FloatLabelModule } from 'primeng/floatlabel';

import { CampaignsRoutingModule } from './campaigns-routing.module';
import { AdminCampaignFormResultsPage } from './page-admin-campaign-form-results/page-admin-campaign-form-results';
import { AdminCampaignFormsPage } from './page-admin-campaign-forms/page-admin-campaign-forms';
import { AdminCampaignTemplatePage } from './page-admin-campaign-template/page-admin-campaign-template';
import { AdminCampaignTemplateContentWidget } from './page-admin-campaign-template/widget-admin-campaign-template-content';
import { AdminCampaignTemplatesPage } from './page-admin-campaign-templates/page-admin-campaign-templates';
import { AdminCampaignPage } from './page-admin-campaign/page-admin-campaign';
import { AdminCampaignsPage } from './page-admin-campaigns/page-admin-campaigns';
import { CommonModule } from '@angular/common';
import { FormService } from '../../services/service-form';
import { InputTextModule } from 'primeng/inputtext';
import { AdminCampaignRecipientsPage } from './page-admin-campaign-recipients/page-admin-campaign-recipients';
import { TooltipModule } from 'primeng/tooltip';
import { TabsModule } from 'primeng/tabs';

@NgModule({
  declarations: [
    AdminCampaignRecipientsPage,
    AdminCampaignTemplatePage,
    AdminCampaignTemplatesPage,
    AdminCampaignTemplateContentWidget,
    AdminCampaignPage,
    AdminCampaignsPage,
    AdminCampaignFormsPage,
    AdminCampaignFormResultsPage,
  ],
  imports: [
    AngularEditorModule,
    BreadcrumbModule,
    ButtonModule,
    CampaignsRoutingModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FloatLabelModule,
    FormsModule,
    InputTextModule,
    MultiSelectModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    SelectModule,
    TableModule,
    TabsModule,
    TieredMenuModule,
    ToggleSwitchModule,
    TooltipModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi()), FormService],
})
export class CampaignsModule {}
