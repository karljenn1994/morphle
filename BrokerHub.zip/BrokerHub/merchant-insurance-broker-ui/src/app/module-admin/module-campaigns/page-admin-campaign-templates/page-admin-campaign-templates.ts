import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastProvider } from '../../../providers/provider-toast';
import { CampaignsService } from '../../../services/service-campaigns';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { MenuItem } from 'primeng/api';

@Component({
    selector: 'admin-campaign-templates-page',
    templateUrl: './page-admin-campaign-templates.html',
    styleUrls: ['./page-admin-campaign-templates.scss'],
    providers: [],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminCampaignTemplatesPage implements OnInit {
  loading: boolean = true;
  templates: any;
  templateToDelete: any;
  showDeleteDialog = false;
  selectedMessage: any;
  templateTypes: string | string[] | null = null;
  menuItems: MenuItem[] | null = null;
  
  constructor(
    private router: Router,
    public routing: RoutingService,
    public searchSortService: SearchSortService,
    public campaignService: CampaignsService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    this.templateTypes = this.routing.getQueryParameters()?.getAll('type') ?? null;
    this.routing.addRoute($localize`Templates`, true);
    await this.loadTemplates();

    if (this.templateTypes?.includes('policy') || this.templateTypes?.includes('client')) {
      this.menuItems = [
        { label: 'Client Template', command: () => this.onNewTemplate('client') },
        { label: 'Policy Template', command: () => this.onNewTemplate('policy') },
      ];
    }

  }

  async loadTemplates() {
    try {
      this.loading = true;
      this.templates = await this.campaignService.listTemplates(this.templateTypes);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onNewTemplate(templateType: string) {
    // Switch to loading mode to get rid of weird transition UI artifacts.
    this.loading = true;
    this.router.navigate(['/admin/campaigns/template'], {
      queryParams: {
        type: templateType,
      },
    });
  }

  onOpenTemplate(event: any, template: any) {
    // Switch to loading mode to get rid of weird transition UI artifacts.
    this.loading = true;
    event.stopPropagation();
    this.router.navigate(['/admin/campaigns/template'], {
      queryParams: {
        id: template.id,
        type: template.type,
      },
    });
  }

  onStartDeleteTemplate(event: any, template: Map<string, any>) {
    event.stopPropagation();
    this.templateToDelete = template;
    this.showDeleteDialog = true;
  }

  async onDeleteTemplate(event: any) {
    try {
      this.loading = true;
      event.stopPropagation();

      if (this.templateToDelete) {
        await this.campaignService.deleteTemplate(this.templateToDelete.id);
        this.toast.success($localize`Updated`);
        this.loadTemplates();
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
      this.showDeleteDialog = false;
    }
  }
}
