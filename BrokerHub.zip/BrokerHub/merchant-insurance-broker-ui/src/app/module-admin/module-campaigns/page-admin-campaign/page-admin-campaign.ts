import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastProvider } from '../../../providers/provider-toast';
import { CampaignsService } from '../../../services/service-campaigns';
import { RoutingService } from '../../../services/service-routing';
import { MenuItem, SelectItem } from 'primeng/api';
import { AdminService } from '../../../services/service-admin';
import { Router } from '@angular/router';
import { StringUtils } from '../../../utils/utils_string';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'admin-campaign-page',
  templateUrl: './page-admin-campaign.html',
  styleUrls: ['./page-admin-campaign.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminCampaignPage implements OnInit {
  loading = false;
  running = false;
  systemPubUrl: string | null = null;
  form: any;

  campaign: any = {};
  campaignType!: string;
  trigger: string | null = null;

  templates: SelectItem[] = [];
  forms: SelectItem[] = [];

  total_email_delivered: number = 0;
  total_email_not_delivered: number = 0;
  total_email_bounced: number = 0;
  total_email_views: number = 0;
  total_email_clicked: number = 0;

  companyList: SelectItem[] = [];
  userStatuses: SelectItem[] = [];

  total_recipients: number = 0;
  total_new_recipients: number = 0;
  recipients: any = null;
  showDryRun: boolean = false;

  items: MenuItem[] = [
    { id: 'status', label: $localize`:@@Campaign.Status:Status` },
    { id: 'general', label: $localize`:@@Campaign.General:General` },
    { id: 'rules', label: $localize`:@@Campaign.Rules:Rules` },
  ];

  lobList: SelectItem[] = [
    { value: 'AUTO', label: 'Auto' },
    { value: 'HABL', label: 'Property' },
  ];

  // The label and value may appear confusing here. The label we show the user is "'1 day before' the user's birthday".
  // However, the value is '1 day after'. This is because we apply the value using dateparser and apply it to a target date.
  // So for birthdays, we are applying '1 day after' to "today" to see if that lands on the user's date of birth.
  dateDaysList: SelectItem[] = [
    { value: null, label: 'None' },
    { value: 'today', label: $localize`:@@CampaignDate.sameDay:when` },
    { value: '1 day after', label: $localize`:@@CampaignDate.oneDay:1 day before` },
    { value: '7 days after', label: $localize`:@@CampaignDate.oneWeek:1 week before` },
    { value: '14 days after', label: $localize`:@@CampaignDate.twoWeeks:2 weeks before` },
    { value: '30 days after', label: $localize`:@@CampaignDate.oneMonth:1 month before` },
    { value: '60 days after', label: $localize`:@@CampaignDate.twoMonths:2 months before` },
    { value: '90 days after', label: $localize`:@@CampaignDate.threeMonths:3 months before` },
  ];

  dateTypeList: SelectItem[] = [
    { value: null, label: 'None' },
    { value: 'date_of_birth', label: $localize`:@@CampaignDay.date_of_birth:it's their birthday` },
    {
      value: 'drivers_licence_expiration',
      label: $localize`:@@CampaignDay.driversLicenceExpiration: their driver's licence expires`,
    },
  ];

  provincesList: SelectItem[] = [
    { value: 'AB', label: 'Alberta' },
    { value: 'BC', label: 'British Columbia' },
    { value: 'MB', label: 'Manitoba' },
    { value: 'NB', label: 'New Brunswick' },
    { value: 'NL', label: 'Newfoundland' },
    { value: 'NS', label: 'Nova Scotia' },
    { value: 'ON', label: 'Ontario' },
    { value: 'PE', label: 'Prince Edward Island' },
    { value: 'QC', label: 'Quebec' },
    { value: 'SK', label: 'Saskatchewan' },
    { value: 'NT', label: 'Northwest Territories' },
    { value: 'NU', label: 'Nunavut' },
    { value: 'YT', label: 'Yukon' },
  ];

  constructor(
    public routing: RoutingService,
    private router: Router,
    private formBuilder: FormBuilder,
    public adminService: AdminService,
    public campaignService: CampaignsService,
    private toast: ToastProvider,
  ) {
    this.form = this.formBuilder.group({
      active: new FormControl<boolean>(false),
      approval: new FormControl<boolean>(false),
      marketing: new FormControl<boolean>(false),
      name: new FormControl<string | null>(null, [
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(100),
      ]),
      description: new FormControl<string | null>(null, [Validators.maxLength(255)]),
      replyTo: new FormControl<string | null>(null, [Validators.maxLength(255)]),
      scheduled: new FormControl<boolean>(false),
      templateId: new FormControl<string>('', [Validators.required]),
      formId: new FormControl<string | null>(null, []),
      dateDays: new FormControl<number | null>(null),
      dateType: new FormControl<string | null>(null),
      companies: new FormControl<string[]>([]),
      lobs: new FormControl<string[]>([]),
      userStatuses: new FormControl<string[]>([]),
      applyChangeThreshold: new FormControl<boolean>(false),
      policyRequired: new FormControl<boolean>(false),
      policyNotExpired: new FormControl<boolean>(false),
      policyNotCancelled: new FormControl<boolean>(false),
      provinces: new FormControl<string | null>(null),
    });
  }

  async ngOnInit() {
    try {
      this.loading = true;
      let campaignId = this.routing.getQueryParameters()?.get('id') ?? null;
      this.campaignType = this.routing.getQueryParameters()?.get('type')!;
      this.trigger = this.routing.getQueryParameters()?.get('trigger') ?? null;
      this.routing.addRoute($localize`New`, false);

      // Load the campaign.
      if (campaignId != null) {
        this.campaign = await this.campaignService.loadCampaign(campaignId);
        this.routing.setLabel(this.campaign.name);
      }

      this.campaignType = this.campaign.type ?? this.campaignType;
      this.trigger = this.campaign.trigger_event ?? this.trigger;

      this.form.controls['active'].setValue(this.campaign.active == 1 ? true : false);
      this.form.controls['approval'].setValue(this.campaign.approval == 1 ? true : false);
      this.form.controls['marketing'].setValue(this.campaign.marketing == 1 ? true : false);
      this.form.controls['templateId'].setValue(this.campaign.template_id);
      this.form.controls['formId'].setValue(this.campaign.form_id);
      this.form.controls['name'].setValue(this.campaign.name);
      this.form.controls['description'].setValue(this.campaign.description);
      this.form.controls['replyTo'].setValue(this.campaign.reply_to);
      this.form.controls['scheduled'].setValue(this.campaign.scheduled == 1);

      if (this.campaignType == 'survey' || this.campaignType == 'questionnaire') {
        this.form.get('formId')?.setValidators([Validators.required]);
      }

      // if (!this.campaign.permanent) {
      //   this.items.splice(1, 0, { id: 'general', label: $localize`:@@Campaign.General:General` });
      // }

      if (this.campaign.rules) {
        var rules: any = JSON.parse(this.campaign.rules);

        if (rules) {
          this.form.controls['companies'].setValue(rules.companies);
          this.form.controls['lobs'].setValue(rules.lobs);
          this.form.controls['userStatuses'].setValue(rules.user_statuses);
          this.form.controls['applyChangeThreshold'].setValue(rules.apply_change_threshold);
          this.form.controls['provinces'].setValue(rules.location_provinces);
          this.form.controls['dateType'].setValue(rules.date_type);
          this.form.controls['dateDays'].setValue(rules.date_days);
          this.form.controls['policyRequired'].setValue(rules.policy_required);
          this.form.controls['policyNotExpired'].setValue(rules.policy_not_expired);
          this.form.controls['policyNotCancelled'].setValue(rules.policy_not_cancelled);
        }
      }

      // Load rule lists.
      let lists = await this.campaignService.lists(this.campaignType);
      this.templates = lists.templates;
      this.forms = lists.forms;
      this.companyList = lists.companies;
      this.userStatuses = lists.user_statuses;

      // Load campaign results.
      let results = await this.campaignService.loadCampaignResults(this.campaign.id);
      this.total_email_delivered = results.total_email_delivered;
      this.total_email_not_delivered = results.total_email_not_delivered;
      this.total_email_bounced = results.total_email_bounced;
      this.total_email_views = results.total_email_views;
      this.total_email_clicked = results.total_email_clicked;
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  capitalize(s: string) {
    return StringUtils.capitalize(s);
  }

  findInvalidControls(formGroup: FormGroup): void {
    const invalidControls = [];
    const controls = formGroup.controls;

    for (const name in controls) {
      if (controls[name].invalid) {
        console.log(`Invalid field: ${name}`);
        console.log(`Errors:`, controls[name].errors);
        invalidControls.push(name);
      }
    }

    if (invalidControls.length === 0) {
      console.log('All fields are valid!');
    }
  }

  async onSave() {
    try {
      // Stop here if form is invalid.
      if (this.form.invalid) {
        this.findInvalidControls(this.form);

        Object.keys(this.form.controls).forEach((field) => {
          const control = this.form.get(field);
          control?.markAsTouched({ onlySelf: true });
        });

        return;
      }

      var rules: any = {};

      if (this.form.controls['companies'].value && this.form.controls['companies'].value.length > 0) {
        rules['companies'] = this.form.controls['companies'].value;
      }

      if (this.form.controls['lobs'].value && this.form.controls['lobs'].value.length > 0) {
        rules['lobs'] = this.form.controls['lobs'].value;
      }

      if (this.form.controls['userStatuses'].value && this.form.controls['userStatuses'].value.length > 0) {
        rules['user_statuses'] = this.form.controls['userStatuses'].value;
      }

      if (this.form.controls['provinces'].value && this.form.controls['provinces'].value.length > 0) {
        rules['provinces'] = this.form.controls['provinces'].value;
      }

      if (this.form.controls['dateType'].value) {
        rules['date_type'] = this.form.controls['dateType'].value;
      }

      if (this.form.controls['dateDays'].value) {
        rules['date_days'] = this.form.controls['dateDays'].value;
      }

      if (this.campaignType == 'policy') {
        rules['apply_change_threshold'] = this.form.controls['applyChangeThreshold'].value;
      } else if (this.campaignType == 'client') {
        rules['policy_required'] = this.form.controls['policyRequired'].value;
        rules['policy_not_expired'] = this.form.controls['policyNotExpired'].value;
        rules['policy_not_cancelled'] = this.form.controls['policyNotCancelled'].value;
      }

      if (!this.campaign.id) {
        this.campaign.id = uuidv4();
      }

      await this.campaignService.upsertCampaign(
        this.campaign.id,
        this.form.controls['active'].value ?? false,
        this.form.controls['approval'].value ?? true,
        this.form.controls['marketing'].value ?? true,
        this.campaignType,
        this.form.controls['templateId'].value ?? '',
        this.form.controls['formId'].value ?? '',
        this.form.controls['name'].value ?? '',
        this.form.controls['description'].value ?? '',
        this.form.controls['replyTo'].value ?? '',
        this.form.controls['scheduled'].value ?? false,
        this.trigger,
        rules,
      );
      this.toast.success($localize`Saved`);
      this.form.markAsPristine();
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  async onDryRunCampaign() {
    try {
      this.running = true;
      this.showDryRun = true;
      let results = await this.campaignService.runCampaign(this.campaign.id, null, null, true);
      this.total_recipients = results.total_recipients;
      this.total_new_recipients = results.total_new_recipients;
      this.recipients = results.recipients;
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.running = false;
    }
  }

  async onContinue() {
    try {
      this.running = true;
      await this.campaignService.runCampaign(this.campaign.id, null, null, false);
      this.toast.success($localize`Success`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.showDryRun = false;
      this.running = false;
    }
  }

  onOpenResults() {
    this.router.navigate(['/admin/campaigns/form-results'], {
      queryParams: {
        campaign_id: this.campaign.id,
        campaign_name: this.campaign.name,
        form_id: this.campaign.form_id,
      },
    });
  }

  onOpenRecipients() {
    this.router.navigate(['/admin/campaigns/recipients'], {
      queryParams: {
        campaign_id: this.campaign.id,
        campaign_name: this.campaign.name,
        form_id: this.campaign.form_id,
      },
    });
  }
}
