import { Component, OnInit } from '@angular/core';
import { ToastProvider } from '../../../providers/provider-toast';
import { CampaignsService } from '../../../services/service-campaigns';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'admin-campaigns-page',
  templateUrl: './page-admin-campaigns.html',
  styleUrls: ['./page-admin-campaigns.scss'],
  providers: [],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminCampaignsPage implements OnInit {
  loading: boolean = true;
  campaigns: any;
  campaignToDelete: any;
  showDeleteDialog = false;
  selectedCampaign: any;
  campaignTypes: string | string[] | null = null;
  menuItems: MenuItem[] | null = null;

  constructor(
    private router: Router,
    public routing: RoutingService,
    public searchSortService: SearchSortService,
    public campaignService: CampaignsService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.campaignTypes = this.routing.getQueryParameters()?.getAll('type') ?? null;
    this.routing.addRoute($localize`Campaigns`, true);

    if (this.campaignTypes?.includes('policy') || this.campaignTypes?.includes('client')) {
      this.menuItems = [
        { label: 'Client Campaign', command: () => this.onNewCampaign('client') },
        {
          label: 'Policy Campaign',
          class: 'policy-campaign-menu',
          items: [
            { label: 'Download Triggers', disabled: true },
            { separator: true },
            { label: 'Renewal', command: () => this.onNewCampaign('policy', 'RWL') },
            { label: 'Reissue', command: () => this.onNewCampaign('policy', 'RII') },
            { label: 'New Business', command: () => this.onNewCampaign('policy', 'NBS') },
            { label: 'Policy Change', command: () => this.onNewCampaign('policy', 'PCH') },
            { label: 'Cancellation', command: () => this.onNewCampaign('policy', 'XLN') },
            { separator: true },
            { label: 'Manual', command: () => this.onNewCampaign('policy') },
          ],
        },
      ];
    }

    this.loadCampaigns();
  }

  loadCampaigns() {
    this.loading = true;
    this.campaignService
      .listCampaigns(this.campaignTypes, null, null, null, null, null)
      .then((events: any) => {
        this.campaigns = events;
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loading = false;
      });
  }

  onNewCampaign(campaignType: string, trigger: string | null = null) {
    // Switch to loading mode to get rid of weird transition UI artifacts.
    this.loading = true;
    this.router.navigate(['/admin/campaigns/campaign'], {
      queryParams: {
        type: campaignType,
        trigger: trigger,
      },
    });
  }

  onOpenCampaign(event: any, campaign: any) {
    // Switch to loading mode to get rid of weird transition UI artifacts.
    this.loading = true;
    event.stopPropagation();
    this.router.navigate(['/admin/campaigns/campaign'], {
      queryParams: {
        id: campaign.id,
        type: campaign.type,
        trigger: campaign.trigger_event,
      },
    });
  }

  onSelectTemplate(template: any) {
    this.campaignService
      .updateCampaignTemplate(this.selectedCampaign.id, template.id)
      .then(() => {
        this.toast.success($localize`Updated`);
      })
      .catch((error) => {
        this.toast.show(error);
      })
      .finally(() => {
        this.loadCampaigns();
      });
  }

  onStartDeleteCampaign(event: any, event_obj: Map<string, any>) {
    event.stopPropagation();
    this.campaignToDelete = event_obj;
    this.showDeleteDialog = true;
  }

  onDeleteCampaign(event: any) {
    event.stopPropagation();

    if (this.campaignToDelete) {
      this.loading = true;

      this.campaignService
        .deleteCampaign(this.campaignToDelete.id)
        .then(() => {
          this.toast.success($localize`Updated`);
        })
        .catch((error) => {
          this.toast.show(error);
        })
        .finally(() => {
          this.loadCampaigns();
          this.loading = false;
          this.showDeleteDialog = false;
        });
    }
  }
}
