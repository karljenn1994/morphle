import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { RefreshService } from '../../../services/service-refresh';
import { SearchSortService } from '../../../services/service-search-sort';
import { FormService } from '../../../services/service-form';
import { StringUtils } from '../../../utils/utils_string';

@Component({
    templateUrl: './page-admin-campaign-forms.html',
    styleUrls: ['./page-admin-campaign-forms.scss'],
    providers: [MessageService, ConfirmationService],
    host: { class: 'col pt-0 px-0' },
    standalone: false
})
export class AdminCampaignFormsPage implements OnInit {
  loading: boolean = true;
  formType!: string;
  totalForms: number = 0;
  formList: any[] = [];
  formToDelete: string | null = null;
  showDeletedDialog = false;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private formService: FormService,
    private refreshService: RefreshService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    this.loading = true;
    this.formType = this.routing.getQueryParameters()?.get('type')!;
    this.routing.addRoute(this.capitalize(this.formType) + 's', true);

    try {
      this.totalForms = await this.formService.totalForms(this.formType);
      await this.loadForms();
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  capitalize(s: string) {
    return StringUtils.capitalize(s);
  }

  getFormTypeName(formType: string) {
    switch(formType) {
      case "questionnaire":
        return $localize`Questionnaire`;

      case "survey":
        return $localize`Survey`;
    }
    return ""
  }

  async onLoadForms(event: any) {
    if (!this.loading) {
      this.loading = true;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      await this.loadForms();
      this.loading = false;
    }
  }

  async loadForms() {
    try {
      this.formList =
        (await this.formService.listForms(
          this.formType,
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    }
  }

  onNewForm() {
    this.router.navigate(['/admin/campaigns/form'], { queryParams: { type: this.formType } });
  }

  onOpenForm(form_id: string) {
    this.router.navigate(['/admin/campaigns/form'], {
      queryParams: {
        id: form_id,
        type: this.formType,
      },
    });
  }

  onStartDeleteForm(event: any, form_id: string) {
    event.stopPropagation();
    this.formToDelete = form_id;
    this.showDeletedDialog = true;
  }

  async onDeleteForm(event: any) {
    event.stopPropagation();

    if (this.formToDelete) {
      this.loading = true;

      try {
        await this.formService.deleteForm(this.formToDelete!);
        this.refreshService.emitRefresh();
        this.toast.success($localize`Deleted`);
      } catch (error: any) {
        this.toast.show(error);
      } finally {
        this.loading = false;
        this.showDeletedDialog = false;
        this.formToDelete = null;
        this.loadForms();
      }
    }
  }
}
