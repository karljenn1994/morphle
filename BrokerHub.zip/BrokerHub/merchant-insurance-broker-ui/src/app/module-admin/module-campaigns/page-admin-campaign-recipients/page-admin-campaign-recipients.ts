import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';
import { CampaignsService } from '../../../services/service-campaigns';
import { AdminService } from '../../../services/service-admin';

@Component({
  templateUrl: './page-admin-campaign-recipients.html',
  styleUrls: ['./page-admin-campaign-recipients.scss'],
  providers: [MessageService, ConfirmationService],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminCampaignRecipientsPage implements OnInit {
  loading: boolean = true;
  totalRecipients: number = 0;
  recipientList: any[] = [];
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;
  campaignId!: string;
  campaignName!: string;
  menuModel: MenuItem[] = [];

  constructor(
    private router: Router,
    public routing: RoutingService,
    private adminService: AdminService,
    private campaignsService: CampaignsService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    this.loading = true;

    this.campaignId = this.routing.getQueryParameters()?.get('campaign_id')!;
    this.campaignName = this.routing.getQueryParameters()?.get('campaign_name')!;
    this.routing.addRoute($localize`Recipients`, false);
    this.searchSortService.context = 'AdminCampaignRecipientsPage';

    try {
      this.totalRecipients = await this.campaignsService.totalRecipients(this.campaignId);
      await this.loadRecipients();
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }

    this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
      this.search();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadRecipients();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  async onLoadRecipients(event: any) {
    if (!this.loading) {
      this.loading = true;
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      await this.loadRecipients();
      this.loading = false;
    }
  }

  async loadRecipients() {
    try {
      this.recipientList =
        (await this.campaignsService.listRecipients(
          this.campaignId,
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText,
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    }
  }

  onOpenRecipient(user_id: string) {
    this.router.navigate(['/admin/portfolio/policies-user'], {
      queryParams: {
        id: user_id,
      },
    });
  }

  async onResend(recipient: any) {
    try {
      this.loading = true;
      this.adminService.resendNotification(recipient.notifier_recipient_id);
      this.toast.success($localize`Sent`);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onMenuClick(event: Event, menu: any, recipient: any): void {
    event.stopPropagation();
    this.menuModel = [
      {
        label: $localize`Resend`,
        icon: 'pi pi-envelope',
        command: () => this.onResend(recipient),
      },
    ];

    menu.toggle(event);
  }
}
