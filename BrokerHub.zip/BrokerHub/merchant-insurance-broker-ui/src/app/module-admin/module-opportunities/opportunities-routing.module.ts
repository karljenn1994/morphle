import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminQuotePage } from './page-admin-quote/page-admin-quote';
import { AdminQuotesPage } from './page-admin-quotes/page-admin-quotes';
import { AdminLeadsPage } from './page-admin-leads/page-admin-leads';

const routes: Routes = [
  { path: 'quotes', component: AdminQuotesPage },
  { path: 'quote', component: AdminQuotePage },
  { path: 'leads', component: AdminLeadsPage },
];

@NgModule({ imports: [RouterModule.forChild(routes)], exports: [RouterModule] })
export class OpportunitiesRoutingModule {}
