import { CommonModule } from '@angular/common';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BadgeModule } from 'primeng/badge';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { DialogModule } from 'primeng/dialog';
import { PanelModule } from 'primeng/panel';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../../components/module-components';
import { NgCircleProgressModule } from 'ng-circle-progress';

import { OpportunitiesRoutingModule } from './opportunities-routing.module';
import { AdminQuotePage } from './page-admin-quote/page-admin-quote';
import { AdminQuotesPage } from './page-admin-quotes/page-admin-quotes';
import { AdminLeadsPage } from './page-admin-leads/page-admin-leads';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
  declarations: [AdminQuotePage, AdminQuotesPage, AdminLeadsPage],
  imports: [
    BadgeModule,
    BreadcrumbModule,
    ButtonModule,
    CommonModule,
    ComponentsModule,
    DialogModule,
    FormsModule,
    PanelModule,
    ProgressSpinnerModule,
    OpportunitiesRoutingModule,
    SelectButtonModule,
    TableModule,
    TooltipModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
    }),
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())],
})
export class OpportunitiesModule {}
