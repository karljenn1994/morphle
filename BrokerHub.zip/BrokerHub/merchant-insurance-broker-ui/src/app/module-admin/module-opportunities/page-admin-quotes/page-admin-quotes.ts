import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { QuotesService } from '../../../services/service-quotes';
import { RefreshService } from '../../../services/service-refresh';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';

@Component({
  templateUrl: './page-admin-quotes.html',
  styleUrls: ['./page-admin-quotes.scss'],
  providers: [MessageService, ConfirmationService],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminQuotesPage implements OnInit {
  loading: boolean = true;
  totalQuotes: number = 0;
  quoteList: any[] = [];
  quoteToDelete: any;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private quoteService: QuotesService,
    private refreshService: RefreshService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.routing.addRoute($localize`Quotes Received`, true);
      this.searchSortService.context = 'AdminQuotesPage';
      this.totalQuotes = await this.quoteService.totalQuotes();
      await this.loadQuotes();

      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => {
        this.search();
      });
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadQuotes();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadQuotes(event: any) {
    if (!this.loading) {
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadQuotes();
    }
  }

  async loadQuotes() {
    try {
      this.loading = true;
      this.quoteList =
        (await this.quoteService.listQuotes(
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText,
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onOpenQuote(quote: any) {
    this.router.navigate(['/admin/opportunities/quote'], {
      queryParams: {
        id: quote.id,
      },
    });
  }

  onStartDeleteQuote(event: any, quote: Map<string, any>) {
    event.stopPropagation();
    this.quoteToDelete = quote;
    this.showDeletedDialog = true;
  }

  async onDeleteQuote(event: any) {
    try {
      event.stopPropagation();
      this.loading = true;

      if (this.quoteToDelete) {
        await this.quoteService.deleteQuote(this.quoteToDelete.id);
        this.refreshService.emitRefresh();
        this.toast.success($localize`Deleted`);
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
      this.showDeletedDialog = false;
      this.quoteToDelete = null;
      this.loadQuotes();
    }
  }
}
