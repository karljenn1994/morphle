import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { ToastProvider } from '../../../providers/provider-toast';
import { QuotesService } from '../../../services/service-quotes';
import { RefreshService } from '../../../services/service-refresh';
import { RoutingService } from '../../../services/service-routing';
import { NumberUtils } from '../../../utils/utils_number';

@Component({
  selector: 'admin-quote-page',
  templateUrl: './page-admin-quote.html',
  styleUrls: ['./page-admin-quote.scss'],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminQuotePage implements OnInit {
  loading = false;
  quoteReport: any;
  quoteId!: string;

  statuses: any[] = [
    { name: $localize`Received`, value: 'received' },
    { name: $localize`Review`, value: 'reviewing' },
    { name: $localize`Complete`, value: 'completed' },
  ];

  getStatus(): string {
    const statusValue = this.quoteReport['status']?.toLowerCase();
    const matched = this.statuses.find((s) => s.value === statusValue);
    return matched ? matched.name : (statusValue ?? '');
  }

  coverage_descriptions: any = {
    TPPD: $localize`Property Damage Liability`,
    AB: $localize`Accident Benefits`,
    TPBI: $localize`Bodily Injury Liability`,
    TPDC: $localize`Direct Compensation Property Damage`,
    CMP: $localize`Comprehensive`,
    COL: $localize`Collision`,
    UA: $localize`Uninsured Automobile`,
    '44': $localize`44 - Family Protection`,
    FLOOD: $localize`Flood Damage (Surface Water)`,
    DWELL: $localize`Dwelling (A)`,
    PL: $localize`Liability (E)`,
    SEWER: $localize`Sewer Back-up Coverage`,
    WATER: $localize`Water Damage Endorsement`,
    ByLaws: $localize`Bylaws Endorsement`,
    CLFRE: $localize`Claim Free Protection`,
  };

  constructor(
    private router: Router,
    private quotesService: QuotesService,
    public routing: RoutingService,
    private refreshService: RefreshService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.quoteId = this.routing.getQueryParameters()?.get('id')!;
      this.routing.addRoute(this.quoteId, false);
      this.quoteReport = await this.quotesService.getQuoteReport(this.quoteId);
      this.routing.setLabel(this.quoteReport.email);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  getPrimaryDriverFullName(driver_id: string | null) {
    if (driver_id == null) {
      return '';
    }

    var quote = this.quoteReport.quote;

    for (var key of Object.keys(quote)) {
      var card = quote[key];

      if (card.id == driver_id) {
        return card.fields.full_name;
      }
    }

    return '';
  }

  getCoverageDescription(code: string) {
    return this.coverage_descriptions[code] ?? code;
  }

  getPDFLink(pdf: any) {
    return environment.apiURL + '/' + pdf.download_link;
  }

  get quote() {
    var quote = this.quoteReport.quote;

    for (var key of Object.keys(quote)) {
      var card = quote[key];

      if (card.type == 'quote') return card;
    }

    return null;
  }

  get vehicles() {
    var vehs = [];
    var quote = this.quoteReport.quote;

    for (var key of Object.keys(quote)) {
      var card = quote[key];

      if (card.type == 'vehicle') vehs.push(card);
    }

    return vehs;
  }

  get properties() {
    var vehs = [];
    var quote = this.quoteReport.quote;

    for (var key of Object.keys(quote)) {
      var card = quote[key];

      if (card.type == 'property') vehs.push(card);
    }

    return vehs;
  }

  get individuals() {
    var vehs = [];
    var quote = this.quoteReport.quote;

    for (var key of Object.keys(quote)) {
      var card = quote[key];

      if (card.type == 'individual') vehs.push(card);
    }

    return vehs;
  }

  onStatusChanged(event: any) {
    this.loading = true;
    var status = event.option.value;
    this.quotesService
      .changeStatus(this.quoteId, status)
      .then(() => {
        this.refreshService.emitRefresh();
        this.quoteReport.status = status;

        var dt = new Date();
        var now = dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2) + '-' + ('0' + dt.getDate()).slice(-2);
        this.quoteReport.modified_date = now;

        this.loading = false;
      })
      .catch((error) => {
        this.toast.show(error);
        this.loading = false;
      });
  }

  formatDollarAmount(dollarAmount: number | null): string {
    return NumberUtils.formatDollarAmount(dollarAmount);
  }
}
