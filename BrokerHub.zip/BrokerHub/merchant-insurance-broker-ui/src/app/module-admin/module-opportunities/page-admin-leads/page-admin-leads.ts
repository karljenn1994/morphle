import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ToastProvider } from '../../../providers/provider-toast';
import { LeadsService } from '../../../services/service-leads';
import { RoutingService } from '../../../services/service-routing';
import { SearchSortService } from '../../../services/service-search-sort';

@Component({
  templateUrl: './page-admin-leads.html',
  styleUrls: ['./page-admin-leads.scss'],
  providers: [MessageService, ConfirmationService],
  host: { class: 'col pt-0 px-0' },
  standalone: false,
})
export class AdminLeadsPage implements OnInit {
  loading: boolean = true;
  totalLeads: number = 0;
  leadList: any[] = [];
  lead: Map<string, any> | null = null;
  leadToDelete: any;
  showDeletedDialog = false;
  searchSubject: Subject<string> = new Subject<string>();
  searchSubscription: Subscription | null = null;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private leadsService: LeadsService,
    public searchSortService: SearchSortService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    try {
      this.loading = true;
      this.routing.addRoute($localize`Leads Received`, true);
      this.searchSortService.context = 'AdminLeadsPage';

      this.totalLeads = await this.leadsService.totalLeads();
      await this.loadLeads();
      this.searchSubscription = this.searchSubject.pipe(debounceTime(1000)).subscribe((s) => this.search());
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
  }

  search() {
    this.searchSortService.index = 0;
    this.loadLeads();
  }

  searchChanged() {
    if (this.searchSortService.searchText != null) {
      this.searchSubject.next(this.searchSortService.searchText);
    }
  }

  clearSearch() {
    this.searchSortService.searchText = null;
    this.search();
  }

  onLoadLeads(event: any) {
    if (!this.loading) {
      this.searchSortService.index = event.first;
      this.searchSortService.sort = event.sortField ?? this.searchSortService.sort;
      this.searchSortService.sortDirection = event.sortOrder;
      this.loadLeads();
    }
  }

  async loadLeads() {
    try {
      this.loading = true;
      this.leadList =
        (await this.leadsService.listLeads(
          this.searchSortService.rowsPerPage,
          this.searchSortService.index / this.searchSortService.rowsPerPage,
          this.searchSortService.sort,
          this.searchSortService.sortDirection,
          this.searchSortService.searchText,
        )) ?? [];
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onOpenUser(user: any) {
    this.router.navigate(['/admin/portfolio/policies-user'], {
      queryParams: {
        id: user.id,
      },
    });

    this.loading = true;
  }
}
