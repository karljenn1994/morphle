import { Routes } from '@angular/router';
import { AppRouter } from './app-router';
import { LandingGuard } from './guards/guard-landing';
import { AdminRoleGuard } from './guards/guard-role-admin';
import { UserRoleGuard } from './guards/guard-role-user';

export const appRoutes: Routes = [
  {
    path: '',
    canActivate: [],
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./module-landing/landing.module').then((m) => m.LandingModule),
      },
      {
        path: 'main',
        component: AppRouter,
        canActivate: [LandingGuard],
      },
      {
        path: 'landing',
        loadChildren: () =>
          import('./module-landing/landing.module').then((m) => m.LandingModule),
      },
      {
        path: 'auth',
        loadChildren: () =>
          import('./module-auth/auth.module').then((m) => m.AuthModule),
      },
      {
        path: 'form',
        loadChildren: () =>
          import('./module-form/form.module').then((m) => m.FormModule),
      },
      {
        path: 'admin',
        loadChildren: () =>
          import('./module-admin/admin.module').then((m) => m.AdminModule),
        canActivate: [AdminRoleGuard],
      },
      {
        path: 'user',
        loadChildren: () =>
          import('./module-user/user.module').then((m) => m.UserModule),
        canActivate: [UserRoleGuard],
      },
    ],
  },
];
