import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Injectable()
export class ToastProvider {
  private messageQueue = new Subject<{ severity: string; summary?: string; detail: string }>();
  private messageCounts = new Map<string, number>();
  private readonly DEBOUNCE_TIME = 300;

  constructor(private messageService: MessageService) {
    this.messageQueue.pipe(debounceTime(this.DEBOUNCE_TIME)).subscribe(() => {
      this.showConsolidatedMessage();
    });
  }

  success(message: string) {
    this.addToQueue({
      severity: 'success',
      detail: message,
    });
  }

  error(message: string) {
    this.addToQueue({
      severity: 'error',
      summary: 'Error',
      detail: message,
    });
  }

  show(ex: any): void {
    const err = ex?.error ?? ex;
    const severity = err?.severity ?? 'error';
    const message = err?.message ?? String(err);

    this.addToQueue({
      severity,
      summary: severity,
      detail: message,
    });
  }

  private addToQueue(message: { severity: string; summary?: string; detail: string }) {
    const key = `${message.severity}:${message.summary || ''}:${message.detail}`;
    const currentCount = this.messageCounts.get(key) || 0;
    this.messageCounts.set(key, currentCount + 1);
    this.messageQueue.next(message);
  }

  private showConsolidatedMessage() {
    if (this.messageCounts.size === 0) return;

    let maxCount = 0;
    let mostFrequentKey = '';
    for (const [key, count] of this.messageCounts) {
      if (count > maxCount) {
        maxCount = count;
        mostFrequentKey = key;
      }
    }

    const [severity, , detail] = mostFrequentKey.split(':');

    this.messageService.add({
      key: 'tst',
      severity: severity,
      summary: detail,
    });

    this.messageCounts.clear();
  }
}
