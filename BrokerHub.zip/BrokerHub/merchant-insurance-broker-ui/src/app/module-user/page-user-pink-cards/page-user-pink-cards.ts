import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PoliciesService } from '../../services/service-policies';
import { UserService } from '../../services/service-user';
import { AuthenticationService } from '../../services/service-authentication';
import { ToastProvider } from '../../providers/provider-toast';
import { RoutingService } from '../../services/service-routing';
import { ApplePassService } from '../../services/service-pass-apple'; // Import the service
import { GooglePassService } from '../../services/service-pass-google';
import { LocaleUtils } from '../../utils/utils_locale';
import { SettingsService } from '../../services/service-settings';

@Component({
  selector: 'pink-cards',
  templateUrl: './page-user-pink-cards.html',
  styleUrls: ['./page-user-pink-cards.scss'],
  host: { class: 'col pt-0 px-0 w-full' },
  standalone: false,
})
export class UserPinkCardsPage implements OnInit {
  policyData: any[] = [];
  loading = false;
  isIphone = false;
  isAndroid = false;

  constructor(
    private route: ActivatedRoute,
    public routing: RoutingService,
    private settingsService: SettingsService,
    private authService: AuthenticationService,
    private userService: UserService,
    private toast: ToastProvider,
    private applePassService: ApplePassService,
    private googlePassService: GooglePassService,
  ) {}

  async ngOnInit() {
    try {
      // Detect device type
      const userAgent = navigator.userAgent.toLowerCase();
      this.isIphone = /iphone|ipad|ipod/.test(userAgent) && !/android/.test(userAgent);
      this.isAndroid = /android/.test(userAgent);

      this.loading = true;
      const policy_id = this.route.snapshot.queryParams['id'];
      this.routing.addRoute($localize`Proof of Insurance`, false);

      if (policy_id) {
        this.policyData = await this.userService.getPolicy(this.authService.userId!, policy_id);
        this.loading = false;
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  get locale() {
    return LocaleUtils.locale;
  }

  get brokerageName() {
    return this.settingsService.getSetting('brokerageName');
  }

  get vehicles() {
    return this.policyData.filter((item) => item.type === 'vehicle');
  }

  get policy() {
    return this.policyData.find((item) => item.type === 'policy');
  }

  get insuredInfo() {
    const policy = this.policy;
    if (!policy) return { name: '', address: '' };
    const name = policy.fields.names || 'Unknown Insured';
    const address = `${policy.fields.address}, ${policy.fields.city}, ${policy.fields.province_code} ${policy.fields.postal_code}`;
    return { name, address };
  }

  get company() {
    const policy = this.policy;
    return policy?.fields.company_name || '';
  }

  get policyNumber() {
    const policy = this.policy;
    return policy?.fields.policy_number || '';
  }

  get effectiveExpiryDates() {
    const policy = this.policy;
    if (!policy) return 'Unknown Dates';
    const effective = new Date(policy.fields.effective_date).toLocaleDateString('en-US', {
      month: 'long',
      day: '2-digit',
      year: 'numeric',
    });
    const expiry = new Date(policy.fields.expiry_date).toLocaleDateString('en-US', {
      month: 'long',
      day: '2-digit',
      year: 'numeric',
    });
    return `${effective} - ${expiry}`;
  }

  async addToAppleWallet(vehicle: any) {
    try {
      // Filter policyData to keep only the vehicle of interest
      const filteredPolicyData = this.policyData.filter((item) => {
        if (item.type === 'vehicle') {
          return item.fields.vin === vehicle.fields.vin; // Keep only the matching vehicle
        }
        return true; // Keep non-vehicle items (e.g., policy details)
      });

      const requestData = {
        cards: filteredPolicyData, // Send the filtered policyData under the cards key
      };

      // Call the ApplePassService to get the .pkpass file
      const pkpassBlob = await this.applePassService.getPinkCard(requestData);

      // Create a blob URL for the .pkpass file
      const blob = new Blob([pkpassBlob], { type: 'application/vnd.apple.pkpass' });
      const url = window.URL.createObjectURL(blob);

      // Create a temporary link element to trigger the download
      const link = document.createElement('a');
      link.href = url;
      link.download = `pink-card-${vehicle.fields.vin}.pkpass`; // Name the file
      document.body.appendChild(link);
      link.click();

      // Clean up
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      this.toast.success('Apple Wallet pass downloaded successfully.');
    } catch (error: any) {
      this.toast.error('Failed to generate Apple Wallet pass: ' + (error.message || 'Unknown error'));
    }
  }

  async addToGoogleWallet(vehicle: any) {
    try {
      // Filter policyData to keep only the vehicle of interest
      const filteredPolicyData = this.policyData.filter((item) => {
        if (item.type === 'vehicle') {
          return item.fields.vin === vehicle.fields.vin; // Keep only the matching vehicle
        }
        return true; // Keep non-vehicle items (e.g., policy details)
      });

      const requestData = {
        cards: filteredPolicyData, // Send the filtered policyData under the cards key
      };

      // Call the backend to generate the Google Wallet pass
      const response = await this.googlePassService.getPinkCard(requestData);

      // If the API call is successful, you should get the link to add the pass to Google Wallet
      if (response && response.passLink) {
        // Direct user to the pass link to save it to Google Wallet
        const passLink = response.passLink;

        // Open the link in a new tab for the user to add it to Google Wallet
        window.open(passLink, '_blank');

        this.toast.success('Google Wallet pass added successfully!');
      } else {
        this.toast.error('Failed to generate Google Wallet pass: Missing pass link.');
      }
    } catch (error: any) {
      this.toast.error('Failed to generate Google Wallet pass: ' + (error.message || 'Unknown error'));
    }
  }
}
