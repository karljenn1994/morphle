import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserProfilePage } from './page-user-profile/user-profile-page';
import { UserPasswordPage } from './page-user-password/page-user-password';
import { UserPoliciesPage } from './page-user-policies/page-user-policies';
import { UserRoleGuard } from '../guards/guard-role-user';
import { UserRenewalsPage } from './page-user-renewals/page-user-renewals';
import { AppLayout } from '../layout/component/app.layout';
import { UserPinkCardsPage } from './page-user-pink-cards/page-user-pink-cards';

const routes: Routes = [
  {
    path: '',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserPoliciesPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },
  {
    path: 'policies',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserPoliciesPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },
  {
    path: 'pink-cards',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserPinkCardsPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },  
  {
    path: 'NBS',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserPoliciesPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },   
  {
    path: 'PCH',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserPoliciesPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },
  {
    path: 'XLN',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserPoliciesPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },  
  {
    path: 'renewals',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserRenewalsPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },
  {
    path: 'RWL',
    component: AppLayout,
    children: [
      {
        path: '',
        component: UserRenewalsPage,
        canActivate: [UserRoleGuard],
      },
    ],
  },
  {
    path: 'profile',
    component: UserProfilePage,
    canActivate: [UserRoleGuard],
  },
  {
    path: 'password',
    component: UserPasswordPage,
    canActivate: [UserRoleGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserRoutingModule {}
