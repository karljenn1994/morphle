import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  AbstractControlOptions,
} from '@angular/forms';
import { MustMatch } from '../../validators/validator-must-match';
import { Router } from '@angular/router';
import { UserService } from '../../services/service-user';
import { ToastProvider } from '../../providers/provider-toast';
import { LayoutService } from '../../layout/service/layout.service';
import { SettingsService } from '../../services/service-settings';

@Component({
    selector: 'user-password-page',
    templateUrl: './page-user-password.html',
    styleUrls: ['./page-user-password.scss'],
    standalone: false
})
export class UserPasswordPage implements OnInit {
  loading = false;
  brokerageName: string | null = null;
  systemPubUrl: string | null = null; 
  form: any;

  constructor(
    private router: Router,
    private userService: UserService,
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group(
      {
        currentPassword: new FormControl<string>('', [
          Validators.required,
          // Minimum eight characters, at least one letter,
          // one number and one special character
          Validators.pattern('^(?=.*[A-Z]).{8,}$'),
        ]),
        password: new FormControl<string>('', [
          Validators.required,
          // Minimum eight characters, at least one letter,
          // one number and one special character
          Validators.pattern('^(?=.*[A-Z]).{8,}$'),
        ]),
        confirmPassword: new FormControl<string>('', [Validators.required]),
      },
      {
        validator: MustMatch('password', 'confirmPassword'),
      } as AbstractControlOptions
    );
  }

  ngOnInit() {
      this.brokerageName = this.settingsService.getSetting('brokerageName');
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
  }

  get f() {
    return this.form.controls;
  }

  onSubmit() {
    // stop here if form is invalid
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.loading = true;

    this.userService
      .changePassword(
        this.f['currentPassword'].value!,
        this.f['password'].value!,
        this.f['confirmPassword'].value!
      )
      .then(() => {
        this.loading = false;
        this.router.navigate(['/main']);
        this.toast.success($localize`Password reset`);
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
  }

  onClose(event: any) {
    event.preventDefault();
    this.router.navigate(['/main']);
  }
}
