import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../services/service-authentication';
import { Router } from '@angular/router';
import { RoutingService } from '../../services/service-routing';

@Component({
  selector: 'user-policies-page',
  templateUrl: './page-user-policies.html',
  styleUrls: ['./page-user-policies.scss'],
  host: { class: 'col pt-0 px-0 w-full' },
  standalone: false,
})
export class UserPoliciesPage implements OnInit {
  loading = false;
  user: any;

  constructor(
    private router: Router,
    public routing: RoutingService,
    private authService: AuthenticationService,
  ) {}

  ngOnInit() {
    this.loading = true;
    this.routing.addRoute($localize`Policies`, true);

    this.user = {
      id: this.authService.userId,
    };
  }

  onViewPOI(policyCard: any) {
    if (policyCard) {
      this.router.navigate(['/user/pink-cards'], {
        queryParams: {
          id: policyCard.id,
        },
      });
    }
  }
}
