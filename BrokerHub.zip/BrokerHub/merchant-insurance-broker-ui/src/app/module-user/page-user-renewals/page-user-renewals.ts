import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
} from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/service-authentication';
import { ToastProvider } from '../../providers/provider-toast';
import { UserService } from '../../services/service-user';

@Component({
    selector: 'user-renewals-page',
    templateUrl: './page-user-renewals.html',
    styleUrls: ['./page-user-renewals.scss'],
    host: { class: 'col pt-0 px-0 w-full' },
    standalone: false
})
export class UserRenewalsPage implements OnInit {
  loading = false;
  user: any;

  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private userService: UserService,
    private formBuilder: FormBuilder,
    private toast: ToastProvider
  ) {
  }

  ngOnInit() {
    this.loading = true;
    this.user = {
      id: this.authService.userId
    };
  }

  openPolicies() {
    this.router.navigate(['/user/policies']);
  }  
}
