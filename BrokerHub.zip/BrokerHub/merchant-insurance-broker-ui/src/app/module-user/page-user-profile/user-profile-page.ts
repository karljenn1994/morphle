import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LayoutService } from '../../layout/service/layout.service';
import { ToastProvider } from '../../providers/provider-toast';
import { UserService } from '../../services/service-user';
import { SettingsService } from '../../services/service-settings';
import { SelectItem } from 'primeng/api';
import { LocaleUtils } from '../../utils/utils_locale';
import { AuthenticationService } from '../../services/service-authentication';

@Component({
  selector: 'user-profile-page',
  templateUrl: './user-profile-page.html',
  styleUrls: ['./user-profile-page.scss'],
  standalone: false,
})
export class UserProfilePage implements OnInit {
  loading = false;
  brokerageName: string | null = null;
  systemPubUrl: string | null = null;
  form: any;

  provinces: SelectItem[] = [
    { label: 'Alberta', value: 'AB' },
    { label: 'British Columbia', value: 'BC' },
    { label: 'Manitoba', value: 'MB' },
    { label: 'New Brunswick', value: 'NB' },
    { label: 'Newfoundland', value: 'NL' },
    { label: 'Nova Scotia', value: 'NS' },
    { label: 'Ontario', value: 'ON' },
    { label: 'Prince Esward Island', value: 'PE' },
    { label: 'Quebec', value: 'QC' },
    { label: 'Saskatchewan', value: 'SK' },
    { label: 'Northwest Territories', value: 'NT' },
    { label: 'Nunavut', value: 'NU' },
    { label: 'Yukon', value: 'YT' },
  ];

  constructor(
    private router: Router,
    private userService: UserService,
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    private toast: ToastProvider,
    public authService: AuthenticationService,
  ) {
    this.form = this.formBuilder.group({
      first: new FormControl<string | null>(null, [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(20),
      ]),
      last: new FormControl<string | null>(null, [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(20),
      ]),
      province: new FormControl<string | null>(null, []),
      postal_code: new FormControl<string | null>(null, []),
      dob: new FormControl<string | null>(null, []),
      locale: new FormControl<string>('en', [Validators.required]),
      notificationPreference: new FormControl<string>('email', [Validators.required]),
    });
  }

  ngOnInit() {
    // load the user's profile information
    this.loading = true;

    this.brokerageName = this.settingsService.getSetting('brokerageName');
    this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');

    this.userService
      .readProfile()
      .then((profile) => {
        this.loading = false;

        if (profile) {
          this.f['first'].setValue(profile.first ?? '');
          this.f['last'].setValue(profile.last ?? '');
          this.f['province'].setValue(profile.province_code ?? '');
          this.f['postal_code'].setValue(profile.postal_code ?? '');
          this.f['dob'].setValue(profile.date_of_birth ?? '');
          this.f['locale'].setValue(profile.locale ?? '');
          this.f['notificationPreference'].setValue(profile.notification_preference ?? '');
        }
      })
      .catch((error) => {
        this.toast.show(error);
        this.loading = false;
      });
  }

  get f() {
    return this.form.controls;
  }

  get languages() {
    return LocaleUtils.languages;
  }

  onSubmit() {
    // stop here if form is invalid
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.loading = true;

    this.userService
      .updateProfile(
        this.f['first'].value!,
        this.f['last'].value!,
        this.f['province'].value!,
        this.f['postal_code'].value!,
        this.f['dob'].value!,
        this.f['locale'].value!,
        this.f['notificationPreference'].value!,
      )
      .then(() => {
        this.loading = false;
        this.router.navigate(['/main']);
        this.toast.success($localize`Saved`);
      })
      .catch((error) => {
        this.loading = false;
        this.toast.show(error);
      });
  }

  onClose() {
    this.router.navigate(['/main']);
  }

  hasError(formControl: FormControl): Boolean {
    return formControl?.invalid && (formControl?.dirty || formControl?.touched);
  }
}
