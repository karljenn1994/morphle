import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { ChartModule } from 'primeng/chart';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ProgressBarModule } from 'primeng/progressbar';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../components/module-components';
import { UserPoliciesPage } from './page-user-policies/page-user-policies';
import { UserPasswordPage } from './page-user-password/page-user-password';
import { UserProfilePage } from './page-user-profile/user-profile-page';
import { UserRenewalsPage } from './page-user-renewals/page-user-renewals';
import { UserRoutingModule } from './user-routing.module';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { FloatLabelModule } from 'primeng/floatlabel';
import { DatePickerModule } from 'primeng/datepicker';
import { UserPinkCardsPage } from './page-user-pink-cards/page-user-pink-cards';
import { CardModule } from 'primeng/card'; 
import { BreadcrumbModule } from 'primeng/breadcrumb';

@NgModule({
  declarations: [UserPoliciesPage, UserRenewalsPage, UserPasswordPage, UserPinkCardsPage, UserProfilePage],
  imports: [
    ButtonModule,
    BreadcrumbModule,
    CardModule,
    ChartModule,
    CheckboxModule,
    CommonModule,
    ComponentsModule,
    DatePickerModule,
    DialogModule,
    FloatLabelModule,
    FormsModule,
    InputTextModule,
    ProgressBarModule,
    ProgressSpinnerModule,
    RadioButtonModule,
    ReactiveFormsModule,
    SelectButtonModule,
    SelectModule,
    TableModule,
    UserRoutingModule,
  ],
})
export class UserModule {}
