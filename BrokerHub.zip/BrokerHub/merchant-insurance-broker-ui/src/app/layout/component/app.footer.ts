import { Component } from '@angular/core';
import { LayoutService } from '../../layout/service/layout.service';
import { ToastProvider } from '../../providers/provider-toast';
import { SettingsService } from '../../services/service-settings';

@Component({
  standalone: true,
  selector: 'app-footer',
  template: `
    <!-- <div class="layout-footer">
    <span class="font-medium ml-2">{{brokerageName}}</span>
    </div> -->
  `,
})
export class AppFooter {
  brokerageName: string | null = null;

  constructor(
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    //this.brokerageName = this.settingsService.getSetting('brokerageName');
  }
}
