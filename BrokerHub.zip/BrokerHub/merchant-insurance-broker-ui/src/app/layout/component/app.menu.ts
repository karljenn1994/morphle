import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AppMenuitem } from './app.menuitem';
import { LayoutService } from '../../layout/service/layout.service';
import { ToastProvider } from '../../providers/provider-toast';
import { AdminService } from '../../services/service-admin';
import { RefreshService } from '../../services/service-refresh';
import { AuthenticationService } from '../../services/service-authentication';
import { UserService } from '../../services/service-user';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule, AppMenuitem, RouterModule],
  template: `
    <ul class="layout-menu">
      <ng-container *ngFor="let item of model; let i = index">
        <li app-menuitem *ngIf="!item.separator" [item]="item" [index]="i" [root]="true"></li>
        <li *ngIf="item.separator" class="menu-separator"></li>
      </ng-container>
    </ul>
  `,
})
export class AppMenu {
  model: MenuItem[] = [];

  constructor(
    public layoutService: LayoutService,
    private authService: AuthenticationService,
    private adminService: AdminService,
    private userService: UserService,
    private refreshService: RefreshService,
    private toast: ToastProvider,
  ) {}

  ngOnInit() {
    this.buildMenu();

    this.refreshService.refreshEmitted$.subscribe((data) => {
      this.buildMenu();
    });
  }

  ngOnDestroy() {}

  async buildMenu() {
    try {
      let counters = 0;

      if (this.authService.role == 'admin') {
        counters = await this.adminService.getCounters();
      } else {
        counters = await this.userService.getCounters();
      }

      this._buildMenu(counters);
    } catch (ex: any) {
      this.toast.show(ex);
    }
  }

  _buildMenu(counters: any) {
    this.model = [];

    if (this.authService.role == 'user') {
      this.model.push({
        label: $localize`:@@MenuItem.Home:Home`,
        items: [
          {
            label: $localize`:@@MenuItem.Policies:Policies`,
            icon: 'pi pi-fw pi-shield',
            routerLink: ['/user/policies'],
          },
          {
            label: $localize`:@@MenuItem.Renewals:Renewals`,
            icon: 'pi pi-fw pi-refresh',
            routerLink: ['/user/renewals'],
            badge: counters?.my_renewals ?? 0,
          },
        ],
      });
    }

    if (this.authService.role == 'admin') {
      this.model.push({
        label: 'Home',
        items: [
          {
            label:  $localize`My Policies`,
            icon: 'pi pi-fw pi-shield',
            routerLink: ['/admin/portfolio/policies-mine'],
          },
          {
            label: $localize`My Renewals`,
            icon: 'pi pi-fw pi-refresh',
            routerLink: ['/admin/portfolio/renewals-mine'],
          },

        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Admin:Portfolio`,
        items: [
          {
            label: $localize`:@@MenuItem.Dashboard:Dashboard`,
            icon: 'pi pi-fw pi-home',
            routerLink: ['/admin/portfolio'],
          },
          {
            label: $localize`:@@MenuItem.Clients:Clients`,
            icon: 'pi pi-fw pi-users',
            routerLink: ['/admin/portfolio/users'],
          },
          {
            label: $localize`:@@MenuItem.Policies:Policies`,
            icon: 'pi pi-fw pi-shield',
            routerLink: ['/admin/portfolio/policies'],
          },
          {
            label: $localize`:@@MenuItem.Renewals:Renewals`,
            icon: 'pi pi-fw pi-refresh',
            routerLink: ['/admin/portfolio/renewals'],
            badge: counters?.total_renewals ?? 0,
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Admin:Claims`,
        items: [
          {
            label: $localize`:@@MenuItem.Notice:Notice`,
            icon: 'pi pi-fw pi-file',
            routerLink: ['/admin/claims'],
            badge: counters?.claims_received ?? 0,
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Admin:Opportunities`,
        items: [
          {
            label: $localize`:@@MenuItem.Leads:Leads`,
            icon: 'pi pi-fw pi-compass',
            routerLink: ['/admin/opportunities/leads'],
            badge: counters?.leads_received ?? 0,
          },
          {
            label: $localize`:@@MenuItem.Quotes:Quotes`,
            icon: 'pi pi-fw pi-dollar',
            routerLink: ['/admin/opportunities/quotes'],
            badge: counters?.quotes_received ?? 0,
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Marketing:Marketing`,
        items: [
          {
            label: $localize`:@@MenuItem.MarketingCampaigns:Campaigns`,
            icon: 'pi pi-fw pi-globe',
            routerLink: ['/admin/campaigns/marketing-campaigns'],
            queryParams: { type: ['policy', 'client'] },
          },
          {
            label: $localize`:@@MenuItem.MarketingTemplates:Templates`,
            icon: 'pi pi-fw pi-file-edit',
            routerLink: ['/admin/campaigns/marketing-templates'],
            queryParams: { type: ['policy', 'client'] },
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Surveys:Surveys`,
        items: [
          {
            label: $localize`:@@MenuItem.SurveyCampaigns:Campaigns`,
            icon: 'pi pi-fw pi-globe',
            routerLink: ['/admin/campaigns/survey-campaigns'],
            queryParams: { type: ['survey'] },
          },
          {
            label: $localize`:@@MenuItem.SurveyTemplates:Templates`,
            icon: 'pi pi-fw pi-file-edit',
            routerLink: ['/admin/campaigns/survey-templates'],
            queryParams: { type: ['survey'] },
          },
          {
            label: $localize`:@@MenuItem.Survey:Survey`,
            icon: 'pi pi-fw pi-check',
            routerLink: ['/admin/campaigns/survey-forms'],
            queryParams: { type: ['survey'] },
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Questionnaires:Questionnaires`,
        items: [
          {
            label: $localize`:@@MenuItem.QuestionnaireCampaigns:Campaigns`,
            icon: 'pi pi-fw pi-globe',
            routerLink: ['/admin/campaigns/questionnaire-campaigns'],
            queryParams: { type: ['questionnaire'] },
          },
          {
            label: $localize`:@@MenuItem.QuestionnaireTemplates:Templates`,
            icon: 'pi pi-fw pi-file-edit',
            routerLink: ['/admin/campaigns/questionnaire-templates'],
            queryParams: { type: ['questionnaire'] },
          },
          {
            label: $localize`:@@MenuItem.Questionnaire:Questionnaire`,
            icon: 'pi pi-fw pi-check',
            routerLink: ['/admin/campaigns/questionnaire-forms'],
            queryParams: { type: ['questionnaire'] },
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Admin:Validations`,
        items: [
          {
            label: $localize`:@@MenuItem.Validation:Validation`,
            icon: 'pi pi-fw pi-check',
            routerLink: ['/admin/validation/validators'],
          },
          {
            label: $localize`:@@MenuItem.Validations:Rules`,
            icon: 'pi pi-fw pi-file-edit',
            routerLink: ['/admin/validation/validations'],
          },
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.Admin:Reports`,
        items: [
          {
            label: $localize`Policies on Hold`,
            icon: 'pi pi-fw pi-clipboard',
            routerLink: ['/admin/reports/report-on-hold'],
            badge: counters?.total_on_hold ?? 0,
          }, 
          {
            label: $localize`Risky Renewals`,
            icon: 'pi pi-fw pi-clipboard',
            routerLink: ['/admin/reports/report-renewals'],
            badge: counters?.total_renewals_over_threshold ?? 0,
          },
          {
            label: $localize`Unassigned Policies`,
            icon: 'pi pi-fw pi-clipboard',
            routerLink: ['/admin/reports/report-unmapped-policies'],
            badge: counters?.total_unmapped_policies ?? 0,
          },          
        ],
      });

      this.model.push({
        label: $localize`:@@MenuItem.System:System`,
        items: [
          {
            label: $localize`:@@MenuItem.Administrators:Administrators`,
            icon: 'pi pi-fw pi-user-edit',
            routerLink: ['/admin/system/administrators'],
          },
          {
            label: $localize`:@@MenuItem.Notifications:Notifications`,
            icon: 'pi pi-fw pi-envelope',
            badge: counters?.drafts ?? 0,
            items: [
              {
                label: $localize`:@@MenuItem.Drafts:Drafts`,
                icon: 'pi pi-fw pi-file-edit',
                routerLink: ['/admin/system/drafts'],
                badge: counters?.drafts ?? 0,
              },
              {
                label: $localize`:@@MenuItem.Outbox:Outbox`,
                icon: 'pi pi-fw pi-send',
                routerLink: ['/admin/system/outbox'],
                badge: counters?.outbox ?? 0,
              },
              {
                label: $localize`:@@MenuItem.Sent:Sent`,
                icon: 'pi pi-fw pi-verified',
                routerLink: ['/admin/system/sent'],
              },
            ],
          },
          { label: $localize`:@@MenuItem.Tasks:Tasks`, icon: 'pi pi-fw pi-cog', routerLink: ['/admin/system/tasks'] },
          {
            label: $localize`:@@MenuItem.Settings:Settings`,
            icon: 'pi pi-fw pi-sliders-v',
            routerLink: ['/admin/system/settings'],
          },
        ],
      });
    }
  }
}
