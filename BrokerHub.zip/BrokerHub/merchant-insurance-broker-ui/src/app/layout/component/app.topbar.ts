import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { StyleClassModule } from 'primeng/styleclass';
import { LayoutService } from '../../layout/service/layout.service';
import { ToastProvider } from '../../providers/provider-toast';
import { AuthenticationService } from '../../services/service-authentication';
import { SettingsService } from '../../services/service-settings';
import { LocaleUtils } from '../../utils/utils_locale';
import { MenuModule } from 'primeng/menu';
import { FormsModule } from '@angular/forms';
import { SelectModule } from 'primeng/select';
import { Menu } from 'primeng/menu';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [RouterModule, CommonModule, StyleClassModule, SelectModule, MenuModule, FormsModule],
  template: `
    <div class="layout-topbar">
      <div class="layout-topbar-logo-container">
        <button class="layout-menu-button layout-topbar-action" (click)="layoutService.onMenuToggle()">
          <i class="pi pi-bars"></i>
        </button>
        <a class="layout-topbar-logo" routerLink="/">
          <img *ngIf="systemPubUrl" src="{{ systemPubUrl }}/logo.png" width="200px" height="100px" class="w-10rem flex-shrink-0" />
        </a>
      </div>

      <div class="layout-topbar-actions">
        <button
          class="layout-topbar-menu-button layout-topbar-action"
          pStyleClass="@next"
          enterFromClass="hidden"
          enterActiveClass="animate-scalein"
          leaveToClass="hidden"
          leaveActiveClass="animate-fadeout"
          [hideOnOutsideClick]="true">
          <i class="pi pi-ellipsis-v"></i>
        </button>

        <div class="layout-topbar-menu hidden lg:block">
          <div class="layout-topbar-menu-content">
            <!-- *ngIf="authService.role === 'admin'" -->
            <p-select 
              [options]="languages" 
              [(ngModel)]="language" 
              (onChange)="switchLanguage($event)">
            </p-select>

            <p-menu #menu [popup]="true" [model]="menuItems" appendTo="body" [baseZIndex]="10000"></p-menu>

            <button type="button" class="layout-topbar-action" (click)="toggleMenu($event, menu)">
              <i class="pi pi-user"></i>
              <span>Account</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AppTopbar implements AfterViewInit, OnDestroy {
  menuItems!: MenuItem[];
  language: string = LocaleUtils.default;
  brokerageName: string | null = null;
  systemPubUrl: string | null = null;

  @ViewChild('menubutton') menuButton!: ElementRef;
  @ViewChild('userButton') userButton!: ElementRef;
  @ViewChild('menu') menu!: Menu;

  private scrollListener!: () => void;

  constructor(
    public layoutService: LayoutService,
    public authService: AuthenticationService,
    private settingsService: SettingsService,
    private router: Router,
    private toast: ToastProvider,
  ) {}

  async ngOnInit() {
    this.language = LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;

    try {
      this.brokerageName = this.settingsService.getSetting('brokerageName');
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
    } catch (error: any) {
      this.toast.show(error);
    }

    this.menuItems = [];
    if (this.authService.status == 'active') {
      this.menuItems.push({ label: $localize`Profile`, icon: 'pi pi-fw pi-user-edit', routerLink: ['/user/profile'] });
      this.menuItems.push({ label: $localize`Password`, icon: 'pi pi-fw pi-lock', routerLink: ['/user/password'] });
      this.menuItems.push({ separator: true });
    }
    this.menuItems.push({ label: $localize`Sign out`, icon: 'pi pi-fw pi-sign-out', command: () => this.signOut() });
  }

  ngAfterViewInit() {
    this.scrollListener = () => {
      if (this.menu && this.menu.visible) {
        this.menu.hide();
      }
    };
    window.addEventListener('scroll', this.scrollListener);
  }

  ngOnDestroy() {
    if (this.scrollListener) {
      window.removeEventListener('scroll', this.scrollListener);
    }
  }

  get languages() {
    return LocaleUtils.languages;
  }

  switchLanguage(event: any) {
    this.language = event.value;
    LocaleUtils.locale = this.language;
    window.location.href = LocaleUtils.localizeHRef(window.location.href);
  }

  toggleMenu(event: Event, menu: Menu) {
    menu.toggle(event);
  }

  signOut() {
    this.authService.logout();
  }
}
