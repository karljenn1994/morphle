export const STATUS_UNCONFIRMED = 0;
export const STATUS_ACTIVE = "active";
export const STATUS_LOCKED = "locked";
export const STATUS_DELETED = "deleted";

export const REASON_UNKNOWN = -1;
export const REASON_ACCOUNT_NOT_CONFIRMED = 1;
export const REASON_TOKEN_MISSING = 2;
export const REASON_TOKEN_EXPIRED = 3;