import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { CampaignsService } from '../../services/service-campaigns';
import { ToastProvider } from '../../providers/provider-toast';
import { SearchSortService } from '../../services/service-search-sort';

@Component({
  selector: 'campaign-dialog',
  templateUrl: './widget-campaign-dialog.html',
  styleUrls: ['./widget-campaign-dialog.scss'],
  standalone: false,
})
export class CampaignDialogWidget implements OnInit, OnDestroy {
  @Input() visible: boolean = false;
  @Output() visibleChange = new EventEmitter<boolean>();
  @Input() type: string = '';
  @Input() user: any = null;
  @Input() policy: any = null;
  @Input() categoryLabel: string = 'Campaign';
  @Output() campaignExecuted = new EventEmitter<string>();

  campaignList: any[] = [];
  totalCampaigns: number = 0;
  loadingCampaigns: boolean = true;
  executingCampaign: boolean = false;

  searchSortCampaigns: SearchSortService = new SearchSortService();
  searchCampaignSubject: Subject<string> = new Subject<string>();
  searchCampaignSubscription: Subscription | null = null;

  constructor(
    private campaignService: CampaignsService,
    private toast: ToastProvider,
  ) {}

  ngOnInit(): void {
    this.searchCampaignSubscription = this.searchCampaignSubject
      .pipe(debounceTime(500))
      .subscribe(() => this.searchCampaign());
  }

  ngOnDestroy(): void {
    this.searchCampaignSubscription?.unsubscribe();
    this.visibleChange.emit(false);
    this.visible = false;
  }

  async initialize(): Promise<void> {
    try {
      this.loadingCampaigns = true;
      this.totalCampaigns = await this.campaignService.totalCampaigns(this.type, true);
      await this.loadCampaigns();
    } catch (err) {
      this.toast.show(err);
    } finally {
      this.loadingCampaigns = false;
    }
  }

  async loadCampaigns(): Promise<void> {
    try {
      this.loadingCampaigns = true;
      this.campaignList =
        (await this.campaignService.listCampaigns(
          this.type,
          this.searchSortCampaigns.rowsPerPage,
          this.searchSortCampaigns.index / this.searchSortCampaigns.rowsPerPage,
          this.searchSortCampaigns.sort,
          this.searchSortCampaigns.sortDirection,
          this.searchSortCampaigns.searchText,
          true,
        )) || [];
    } catch (err) {
      this.toast.show(err);
    } finally {
      this.loadingCampaigns = false;
    }
  }

  onLoadCampaigns(event: any): void {
    if (!this.loadingCampaigns) {
      this.searchSortCampaigns.rowsPerPage = event.rows;
      this.searchSortCampaigns.index = event.first;
      this.searchSortCampaigns.sort = event.sortField ?? this.searchSortCampaigns.sort;
      this.searchSortCampaigns.sortDirection = event.sortOrder;
      this.loadCampaigns();
    }
  }

  searchCampaignChanged(): void {
    if (this.searchSortCampaigns.searchText != null) {
      this.searchCampaignSubject.next(this.searchSortCampaigns.searchText);
    }
  }

  searchCampaign(): void {
    this.searchSortCampaigns.index = 0;
    this.loadCampaigns();
  }

  clearCampaignSearch(): void {
    this.searchSortCampaigns.searchText = '';
    this.searchCampaign();
  }

  async onExecuteCampaign(event: MouseEvent, campaignId: string): Promise<void> {
    event.stopPropagation();

    if ((this.user?.id || this.policy?.id) && campaignId && !this.executingCampaign) {
      try {
        this.executingCampaign = true;
        await this.campaignService.runCampaign(campaignId, this.user?.id, this.policy?.id, false, true);
        this.toast.success($localize`Success`);
        this.campaignExecuted.emit(campaignId);
        this.visible = false;
        this.visibleChange.emit(false);
      } catch (error) {
        this.toast.show(error);
        this.executingCampaign = false;
      } finally {
        this.executingCampaign = false;
      }
    }
  }

  closeDialog(): void {
    this.visible = false;
    this.visibleChange.emit(false);
  }
}
