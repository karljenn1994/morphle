import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastProvider } from '../../providers/provider-toast';

@Component({
    selector: 'wallet',
    templateUrl: './widget-wallet.html',
    styleUrls: ['./widget-wallet.scss'],
    standalone: false
})
export class WalletWidget implements OnInit {
  loading = false;
  vehicles: any;
  properties: any;
  loyaltyCards : any;

  @Input() cards: any;

  constructor(private router: Router, private toast: ToastProvider) {}

  ngOnInit() {
    this.loading = true;
    this.vehicles = this.cards.filter((card: { type: any; }) => card.type=="auto");
    this.properties =  this.cards.filter((card: { type: any; }) => card.type=="property");
    this.loyaltyCards =  this.cards.filter((card: { type: any; }) => card.type=="loyalty");
  }

}
