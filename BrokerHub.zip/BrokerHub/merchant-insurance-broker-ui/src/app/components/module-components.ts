import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccordionModule } from 'primeng/accordion';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { InputTextModule } from 'primeng/inputtext';
import { MenuModule } from 'primeng/menu';
import { PasswordModule } from 'primeng/password';
import { PolicySummaryWidget } from './widget-policy-summary/widget-policy-summary';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { TooltipModule } from 'primeng/tooltip';
import { PoliciesWidget } from './widget-policies/widget-policies';
import { RenewalsWidget } from './widget-renewals/widget-renewals';
import { TextFieldWidget } from './widget-text-field/widget-text-field';
import { UserSummaryWidget } from './widget-user-summary/widget-user-summary';
import { WalletWidget } from './widget-wallet/widget-wallet';
import { CheckboxModule } from 'primeng/checkbox';
import { InputNumberModule } from 'primeng/inputnumber';
import { FloatLabelModule } from 'primeng/floatlabel';
import { ChangeWidget } from './widget-policy-summary/widget-change';
import { IssueWidget } from './widget-policy-summary/widget-issue';
import { FieldsetModule } from 'primeng/fieldset';
import { DatePickerModule } from 'primeng/datepicker';
import { TagModule } from 'primeng/tag';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { RouterModule } from '@angular/router';
import { CampaignDialogWidget } from './widget-campaign-dialog/widget-campaign-dialog';
import { OverlayModule } from 'primeng/overlay';
import { SplitButtonModule } from 'primeng/splitbutton';


@NgModule({
  declarations: [
    CampaignDialogWidget,
    ChangeWidget,
    IssueWidget,
    PoliciesWidget,
    PolicySummaryWidget,
    RenewalsWidget,
    TextFieldWidget,
    UserSummaryWidget,
    WalletWidget,
  ],
  imports: [
    AccordionModule,
    ButtonModule,
    CheckboxModule,
    DatePickerModule,
    FloatLabelModule,
    FieldsetModule,
    FormsModule,
    InputTextModule,
    ReactiveFormsModule,
    CommonModule,
    DialogModule,
    SelectModule,
    InputNumberModule,
    MenuModule,
    OverlayModule,
    PasswordModule,
    ProgressSpinnerModule,
    RouterModule,
    SelectModule,
    SelectButtonModule,
    SplitButtonModule,
    TableModule,
    TagModule,
    TieredMenuModule,
    ToolbarModule,
    TooltipModule,
  ],
  exports: [
    CampaignDialogWidget,
    PoliciesWidget,
    PolicySummaryWidget,
    RenewalsWidget,
    TextFieldWidget,
    UserSummaryWidget,
    WalletWidget,
  ],
})
export class ComponentsModule {}
