import {
  Component,
  EventEmitter,
  HostBinding,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { ToastProvider } from '../../providers/provider-toast';
import { UserService } from '../../services/service-user';
import { SettingsService } from '../../services/service-settings';

@Component({
    selector: 'renewals',
    templateUrl: './widget-renewals.html',
    styleUrls: ['./widget-renewals.scss'],
    host: { class: 'width: 100%' },
    standalone: false
})
export class RenewalsWidget implements OnInit {
  loading = false;
  policyReport: any;
  systemPubUrl: string | null = null;

  constructor(
    private userService: UserService,
    private settingsService: SettingsService,
    private toast: ToastProvider
  ) {}

  @Input({ required: true }) user!: any;
  @Input() showBanner: boolean = true;
  @Input() showClient: boolean = false;
  @Input() showClaimsConvictions: boolean = false;
  @Input() showNotify: boolean = false;

  @Output() onOpenPolicies = new EventEmitter<any>();

  ngOnInit() {
    this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
    this.refresh();
  }

  refresh() {
    this.loading = true;

    this.userService
      .getUserReport(this.user['id'])
      .then((policyReport: any) => {
        this.policyReport = policyReport;
        this.loading = false;
      })
      .catch((error) => {
        this.toast.show(error);
        this.loading = false;
      });
  }

  getAssets(policy: any): Array<any> {
    var assets: Array<any> = new Array<any>();

    for (let asset of policy) {
      if (asset.type == 'vehicle' || asset.type == 'property') {
        assets.push(asset);
      }
    }
    return assets;
  }

  openPolicies() {
    this.onOpenPolicies.emit();
  }
}
