import { Component, EventEmitter, HostListenerDecorator, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ToastProvider } from '../../providers/provider-toast';
import { LeadsService } from '../../services/service-leads';
import { RefreshService } from '../../services/service-refresh';
import { AuthenticationService } from '../../services/service-authentication';
import { MenuItem } from 'primeng/api';
import { SplitButton } from 'primeng/splitbutton';

@Component({
  selector: 'user-summary',
  templateUrl: './widget-user-summary.html',
  styleUrls: ['./widget-user-summary.scss'],
  standalone: false,
})
export class UserSummaryWidget implements OnInit {
  loading = false;

  statuses: any[] = [
    { name: $localize`Received`, value: 'received' },
    { name: $localize`Review`, value: 'reviewing' },
    { name: $localize`Complete`, value: 'completed' },
  ];

  clientActionItems: MenuItem[] = [];

  @Input() user: any;
  @Input() leads: any;
  @Input() showLeads: boolean = false;
  @Input() showNotify: boolean = false;

  @Output() editUser = new EventEmitter<any>();
  @Output() addPolicy = new EventEmitter<any>();
  @Output() notifyUser = new EventEmitter<{ type: string }>();

  @ViewChild('splitButton') splitButton!: SplitButton;

  constructor(
    private authService: AuthenticationService,
    private toast: ToastProvider,
    private leadsService: LeadsService,
    private refreshService: RefreshService,
  ) {}

  ngOnInit() {
    this.loading = true;

    this.clientActionItems = [
      // {
      //   label: $localize`:@@editClient:Edit Client`,
      //   icon: 'pi pi-user-plus',
      //   command: (event) => this.onEditUser(event),
      // },
      {
        label: $localize`:@@addPolicy:Add Policy`,
        icon: 'pi pi-shield',
        command: (event) => this.onAddPolicy(event),
      },
    ];

    if (this.showNotify) {
      this.clientActionItems.push({
        label: $localize`:@@notify:Notify Client`,
        icon: 'pi pi-envelope',
        items: [
          {
            label: 'Marketing',
            command: (event) => this.onNotifyUser(),
          },
          {
            label: 'Survey',
            command: (event) => this.onNotifyUser(),
          },
          {
            label: 'Questionnaire',
            command: (event) => this.onNotifyUser(),
          },
        ],
      });
    }
  }

  isAdmin() {
    return this.authService.role == 'admin';
  }

  onEditUser(event: any) {
    this.editUser.emit();
  }

  onAddPolicy(event: any) {
    this.addPolicy.emit();
  }

  onNotifyUser() {
    this.notifyUser.emit({type: 'client' });
  }

  get_lead_description(lead_type: string, collector_type: string): string {
    switch (lead_type) {
      case 'uninsured':
        switch (collector_type) {
          case 'auto':
            return 'Not insured by us';
          case 'property':
            return 'Not insured by us';
        }
        break;
    }

    return lead_type;
  }

  onStatusChanged(event: any) {
    this.loading = true;
    var status = event.option.value;
    this.leadsService
      .changeStatus(this.user['id'], status)
      .then(() => {
        this.refreshService.emitRefresh();
        this.leads.status = status;
        var dt = new Date();
        var now = dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2) + '-' + ('0' + dt.getDate()).slice(-2);
        this.leads.modified_date = now;
        this.loading = false;
      })
      .catch((error) => {
        this.toast.show(error);
        this.loading = false;
      });
  }
}
