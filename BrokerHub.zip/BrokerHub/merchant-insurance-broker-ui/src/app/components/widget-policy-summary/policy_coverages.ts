import { CoverageDescriptions } from './coverage_descriptions';
import { Issues } from './issues';
import { Coverage } from './policy_coverage';

export class Coverages {
  public totalPremium: number = 0;
  public list: Coverage[] = [];
  public issues: Issues;

  constructor(asset?: any | null, issues?: Issues | null) {
    this.totalPremium = 0;
    this.issues = issues ?? new Issues([]);

    if (!asset) return;

    let coverageList = asset.fields.coverages;
    let coverageCodes: string[] | null = coverageList?.split(',');

    coverageCodes?.forEach((coverageCode) => {
      let description: string | null =
        asset.fields['coverage_' + coverageCode + '_description'];
      let premium: string | number | null =
        asset.fields['coverage_' + coverageCode + '_premium'];
      let annual_premium: string | number | null =
        asset.fields['coverage_' + coverageCode + '_annual_premium'];        
      let limit: string | null =
        asset.fields['coverage_' + coverageCode + '_limit'];
      let deductible: string | null =
        asset.fields['coverage_' + coverageCode + '_deductible'];

      // Initial premium to 0 because we need to know it exists to know
      // if a coverages is added or removed. This is not the same limit and
      // deductible.
      let premiumValue: number | null = null;

      if (typeof premium === 'string') {
        if (premium && premium.length > 0) {
          premiumValue = parseFloat(premium);
        }
      } else if (typeof premium === 'number') {
        premiumValue = premium;
      }

      let limitValue: number | null = null;
      
      if (typeof limit === 'string') {
        limitValue = parseFloat(limit);
      }
      else if (typeof limit === 'number') {
        limitValue = limit;
      }

      let deductibleValue: number | null = null;
      
      if (typeof deductible === 'string') {
        deductibleValue = parseFloat(deductible);
      }
      else if (typeof deductible === 'number') {
        deductibleValue = deductibleValue;
      }

      this.addCoverage(
        asset.id,
        coverageCode.toUpperCase(),
        CoverageDescriptions.getDescription(coverageCode, description),
        premiumValue,
        limitValue,
        deductibleValue,
        null,
        this.issues,
      );
    });
  }

  public addCoverage(
    refId: string,
    coverageCode: string,
    description: string | null,
    premiumValue: number | null,
    limitValue: number | null,
    deductibleValue: number | null,
    coverages: Coverage[] | null,
    issues: Issues | null,
  ) {
    coverageCode = coverageCode == '44R' ? '44' : coverageCode;

    this.list.push(
      new Coverage(
        refId,
        coverageCode,
        description,
        premiumValue,
        limitValue,
        deductibleValue,
        coverages,
        issues
      )
    );

    if (premiumValue != null) {
        this.totalPremium += premiumValue;
    }
  }
}
