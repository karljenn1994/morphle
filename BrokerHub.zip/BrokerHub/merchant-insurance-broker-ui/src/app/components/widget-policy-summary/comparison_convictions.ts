import { Conviction } from './conviction';
import { Asset } from './policy_asset';
import { Individual } from './policy_individual';

export class ConvictionComparison {
  public convictionA: Conviction | null = null;
  public convictionB: Conviction | null = null;

  get hasConvictionA() {
    return this.convictionA != null;
  }

  get hasConvictionB() {
    return this.convictionB != null;
  }

  private getStatus(claim: Conviction | null, individual: Individual | null): boolean | null {
    if (individual == null) return null;
    return claim != null;
  }

  getStatusA(individual: Individual | null): boolean | null {
    return this.getStatus(this.convictionA, individual);
  }

  getStatusB(individual: Individual | null): boolean | null {
    return this.getStatus(this.convictionB, individual);
  }

  get description() {
    return this.convictionA?.getDescription() ?? this.convictionB?.getDescription() ?? 'N/A';
  }

  constructor(claimA: Conviction | null, claimB: Conviction | null) {
    this.convictionA = claimA;
    this.convictionB = claimB;
  }
}
