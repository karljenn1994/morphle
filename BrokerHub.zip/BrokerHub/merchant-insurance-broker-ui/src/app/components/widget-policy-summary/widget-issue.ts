import { Component, Input, OnInit } from '@angular/core';
import { Issue } from './issues';

@Component({
    selector: 'issue',
    templateUrl: './widget-issue.html',
    styleUrls: ['./widget-issue.scss'],
    standalone: false
})
export class IssueWidget implements OnInit {
  @Input() showIssues: boolean = false;
  @Input() issues!: Issue[];

  ngOnInit(): void {}
}
