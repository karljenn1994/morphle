import { ConvictionComparison } from './comparison_convictions';
import { Conviction } from './conviction';
import { Individual } from './policy_individual';

export class IndividualComparison {
  private showA: boolean;
  private showB: boolean;

  public status: string;
  public individualA: Individual | null = null;
  public individualB: Individual | null = null;
  public convictionComparison: ConvictionComparison[] = [];

  get driverName() {
    return this.individualA?.name ?? this.individualB?.name ?? 'N/A';
  }

  get dateOfBirth() {
    return this.individualA?.dateOfBirth ?? this.individualB?.dateOfBirth ?? 'N/A';
  }

  get hasConvictions() {
    return (this.individualA?.convictions?.length ?? 0) + (this.individualB?.convictions?.length ?? 0) > 0;
  }

  get convictions() {
    return this.individualA?.convictions ?? this.individualB?.convictions ?? [];
  }

  constructor(showA: boolean, individualA: Individual | null, showB: boolean, individualB: Individual | null) {
    this.status = '';
    this.showA = showA;
    this.individualA = individualA;
    this.showB = showB;
    this.individualB = individualB;

    if (this.showA && this.showB) {
      if (individualA == null && individualB != null) {
        this.status = 'Added';
      } else if (individualA != null && individualB == null) {
        this.status = 'Removed';
      }
    }

    this.compareConvictions();
  }

  private compareConvictions() {
    this.convictionComparison = [];
    const pairs: { [key: string]: [Conviction | null, Conviction | null] } = {};

    for (const conviction of this.individualA?.convictions ?? []) {
      const key = this.buildConvictionKey(conviction);
      pairs[key] = [conviction, null];
    }

    for (const conviction of this.individualB?.convictions ?? []) {
      const key = this.buildConvictionKey(conviction);
      if (pairs[key]) {
        pairs[key][1] = conviction;
      } else {
        pairs[key] = [null, conviction];
      }
    }

    for (const key of Object.keys(pairs).sort((a, b) => {
      const [claimA1, claimB1] = pairs[a];
      const [claimA2, claimB2] = pairs[b];

      const date1 = claimA1?.date ?? claimB1?.date;
      const date2 = claimA2?.date ?? claimB2?.date;

      const time1 = date1 instanceof Date ? date1.getTime() : Number.NEGATIVE_INFINITY;
      const time2 = date2 instanceof Date ? date2.getTime() : Number.NEGATIVE_INFINITY;

      return time2 - time1; // descending
    })) {
      const [claimA, claimB] = pairs[key];

      if (this.showA && this.showB) {
        this.convictionComparison.push(new ConvictionComparison(claimA, claimB));
      } else if (this.showA) {
        this.convictionComparison.push(new ConvictionComparison(null, claimA));
      } else {
        this.convictionComparison.push(new ConvictionComparison(null, claimB));
      }
    }
  }

  private buildConvictionKey(conviction: Conviction): string {
    const parts = [];

    if (conviction.date instanceof Date && !isNaN(conviction.date.getTime())) {
      const isoDate = conviction.date.toISOString().split('T')[0]; // YYYY-MM-DD
      parts.push(isoDate);
    }

    if (conviction.code?.trim()) {
      parts.push(conviction.code.trim());
    }

    return parts.join('_');
  }
}
