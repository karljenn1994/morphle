import { Claim } from './claim';
import { Issue, Issues } from './issues';
import { Asset } from './policy_asset';
import { Individual } from './policy_individual';
import { Property } from './policy_property';
import { Schedule } from './policy_schedule';
import { Vehicle } from './policy_vehicle';

export class Policy {
  public id: string | null = null;
  public heading: string = '';
  public downloaded: boolean = false;
  public policyNumber: string = '';
  public sequence: number = -1;
  public company: string | null = null;
  public insured: string | null = null;
  public coinsured: string | null = null;
  public companyDescription: string | null = null;
  public lob: string | null = null;
  public transactionEffectiveDate: string | null = null;
  public effectiveDate: string | null = null;
  public expiryDate: string | null = null;
  public premium: number | null = null;
  public annual_premium: number | null = null;
  public coveragesPremium: number | null = null;
  public assets: Asset[] = [];
  public individuals: Individual[] = [];
  public claims: Claim[] = [];
  public pdfs: any[] | null = null;
  public issues: Issues | null = null;
  public purpose: string = 'SYN';

  public get hasConvictions() {
    for (var i of this.individuals) {
      if (i.convictions) {
        return true;
      }
    }

    return false;
  }

  public get cancelled() {
    return this.purpose == 'XLN';
  }

  constructor(heading?: string, policy?: any) {
    // Copy constructor.
    if (policy == null) return;

    this.heading = heading ?? '';
    var card = policy?.find((card: any) => card.type == 'policy') ?? null;
    this.id = card?.id;
    this.downloaded = card?.downloaded;
    this.sequence = parseInt(card?.fields?.sequence ?? -1);
    this.policyNumber = card?.fields.policy_number;
    this.company = card?.fields.company_code;
    this.purpose = card?.fields.purpose;
    this.insured = card?.fields.insured;
    this.coinsured = card?.fields.coinsured;
    this.companyDescription = card?.fields.company_name?.toUpperCase();
    this.lob = card?.fields.lob;
    this.transactionEffectiveDate = card?.fields.transaction_effective_date;
    this.effectiveDate = card?.fields.effective_date;
    this.expiryDate = card?.fields.expiry_date;
    this.pdfs = card?.pdfs;
    this.issues = new Issues(
      card?.validations?.issues?.map((i: any) => new Issue(i))
    );

    if (card?.fields.premium) {
       this.premium = parseFloat(card?.fields.premium);
    }

    if (card?.fields.annual_premium) {
       this.annual_premium = parseFloat(card?.fields.annual_premium);
    }

    if (card.claims) {
      card.claims.forEach((claim: any) => {
        // find the driver based on id and get their name.
        var driver = policy?.find((card: any) => card.type == 'individual' && card.id == claim.fields.driver_id) ?? null;

        this.claims.push(
          new Claim(
            new Date(claim.fields.date),
            claim.fields.code,
            driver?.fields?.name,
            claim.fields.driver_id,
            claim.fields.vehicle_id,
            claim.fields.percent_responsible,
            claim.fields.description,
          )
        );
      });
    }

    this.individuals =
      policy
        ?.filter((card: any) => card.type == 'individual')
        .map((card: any) => {
          return new Individual(card);
        }) ?? [];

    this.assets =
      policy
        ?.filter(
          (card: any) =>
            card.type == 'vehicle' ||
            card.type == 'property' ||
            card.type == 'schedule'
        )
        .map((card: any) => {
          var assetIssues: Issues = new Issues(
            this.issues?.findIssues(card.id, null, null) ?? []
          );

          switch (card.type) {
            case 'vehicle':
              return new Vehicle(card, assetIssues);
            case 'property':
              return new Property(card, assetIssues);
            case 'schedule':
              return new Schedule(card, assetIssues);
            default:
              return null;
          }
        }) ?? [];

    for (let asset of this.assets) {
      if (!asset.isScheduledItem && asset.coverages?.list) {
        for (let coverage of asset.coverages?.list) {
          if (this.coveragesPremium == null) {
            this.coveragesPremium = 0;
          }

          if (coverage.premium) {
              this.coveragesPremium += coverage.premium;
          }
        }
      }
    }
  }

  public getIndividualName(id: string | undefined | null) {
    if (id) {
      for (var i of this.individuals) {
        if (i.id == id) {
          return i.name;
        }
      }
    }
    return null;
  }

  public getAssetName(id: string | undefined | null) {
    if (id) {
      for (var i of this.assets) {
        if (i.id == id) {
          return i.description;
        }
      }
    }
    return null;
  }


  public get policyStatus() {
    var status: string = '';

    if (this.purpose == 'XLN') {
      status = $localize`cancelled`;
    } else if (!this.downloaded || this.purpose == 'SYN') {
      status = $localize`unknown`;
    } else if (this.expired) {
      status = $localize`expired`;
    } else {
      status = $localize`active`;
    }

    return status;
  }

  public get expired() {
    if (this.expiryDate != null) {
      var now = new Date();
      now.setHours(0, 0, 0, 0);
      var expiry_date: Date = new Date(this.expiryDate);
      expiry_date.setHours(0, 0, 0, 0);
      return expiry_date < now;
    }

    return false;
  }

  public copy(
    heading: string,
    company: string,
    companyDescription: string,
    premium: number
  ): Policy {
    var copy: Policy = new Policy();
    copy.id = this.id;
    copy.heading = heading;
    copy.company = company;
    copy.companyDescription = companyDescription;
    copy.premium = premium;
    copy.policyNumber = this.policyNumber;
    copy.lob = this.lob;
    copy.downloaded = true;

    for (let asset of this.assets) {
      var c = asset.copy();
      copy.assets.push(c);
    }

    return copy;
  }
}
