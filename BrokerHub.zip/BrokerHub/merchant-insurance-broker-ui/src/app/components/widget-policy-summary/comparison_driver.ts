import { Issue } from './issues';
import { Driver } from './policy_driver';
import { Individual } from './policy_individual';
import { Report } from './report';

export class DriverComparison {
  public assetStatus: string;

  public name: string;
  public status: string;
  public refIdA: string | null = null;
  public refIdB: string | null = null;
  public percentA: number | null = null;
  public percentB: number | null = null;
  public roleA: string | null = null;
  public roleB: string | null = null;
  public percentChange: number | null = null;
  public percentIssues: Issue[] = [];

  private individualA: Individual | null = null;
  private individualB: Individual | null = null;

  get driverName() {
    return this.individualA?.name ?? this.individualB?.name ?? 'N/A';
  }

  get dateOfBirth() {
    return this.individualA?.dateOfBirth ?? this.individualB?.dateOfBirth ?? 'N/A';
  }

  constructor(
    assetStatus: string,
    driverA: Driver | null,
    individualA: Individual | null,
    driverB: Driver | null,
    individualB: Individual | null,
  ) {
    this.assetStatus = assetStatus;
    this.status = '';
    this.individualA = individualA;
    this.individualB = individualB;

    if (this.assetStatus != 'removed') {
      if (driverA == null && driverB != null) {
        this.status = 'Added';
      } else if (driverA != null && driverB == null) {
        this.status = 'Removed';
      }
    }

    this.name = (driverA?.refId ?? driverB?.refId)!;
    this.refIdA = driverA?.refId ?? null;
    this.percentA = driverA?.percent ?? null;
    this.refIdB = driverB?.refId ?? null;
    this.percentB = driverB?.percent ?? null;

    if (driverA == null) {
      this.roleA = "";
    } else if (driverA.principal) {
      this.roleA = $localize`Principal`;
    } else {
      this.roleA = $localize`Occasional`;
    }

    if (this.percentA != null) {
      this.roleA += ' (' + this.percentA + '%)';
    }

    if (driverB == null) {
      this.roleB = "";
    } else if (driverB.principal) {
      this.roleB = $localize`Principal`;
    } else {
      this.roleB = $localize`Occasional`;
    }

    if (this.percentB != null) {
      this.roleB += ' (' + this.percentB + '%)';
    }

    if (driverA?.percent != null && driverB?.percent != null) {
      this.percentChange = Report.calculateChange(driverA.percent, driverB.percent);
    }
  }
}
