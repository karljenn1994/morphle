import { Claim } from './claim';
import { Asset } from './policy_asset';

export class ClaimComparison {
  public claimA: Claim | null = null;
  public claimB: Claim | null = null;

  get hasClaimA() {
    return this.claimA != null;
  }

  get hasClaimB() {
    return this.claimB != null;
  }

  private getStatus(claim: Claim | null, asset: Asset | null): boolean | null {
    if (asset == null) return null;
    return claim != null;
  }

  getStatusA(asset: Asset | null): boolean | null {
    return this.getStatus(this.claimA, asset);
  }

  getStatusB(asset: Asset | null): boolean | null {
    return this.getStatus(this.claimB, asset);
  }

  get description() {
    return this.claimA?.getDescription() ?? this.claimB?.getDescription() ?? 'N/A';
  }

  constructor(claimA: Claim | null, claimB: Claim | null) {
    this.claimA = claimA;
    this.claimB = claimB;
  }
}
