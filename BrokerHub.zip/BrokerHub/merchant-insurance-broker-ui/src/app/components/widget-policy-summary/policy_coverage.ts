import { Issues } from './issues';

export class Coverage {
  public refId: string;
  public code: string;
  public description: string | null = null;
  public premium: number | null = null;
  public limit: number | null = null;
  public deductible: number | null = null;
  public coverages: Coverage[] | null = null;
  public issues: Issues | null = null;

  get isPak(): boolean {
    return this.coverages != null && this.coverages.length > 0;
  }

  constructor(
    refId: string,
    code: string,
    description: string | null,
    premium: number | null,
    limit: number | null,
    deductible: number | null,
    coverages: Coverage[] | null,
    issues: Issues | null
  ) {
    this.refId = refId;
    this.code = code;
    this.description = description;
    this.premium = premium;
    this.limit = limit;
    this.deductible = deductible;
    this.coverages = coverages;
    this.issues = issues;
  }

  copy() {
    var coveragesCopy: Coverage[] | null = null;

    if (this.coverages != null) {
      for (let coverage of this.coverages) {
        if (coveragesCopy == null) coveragesCopy = [];
        coveragesCopy.push(coverage.copy());
      }
    }

    return new Coverage(
      this.refId,
      this.code,
      this.description,
      this.premium,
      this.limit,
      this.deductible,
      coveragesCopy,
      this.issues
    );
  }
}
