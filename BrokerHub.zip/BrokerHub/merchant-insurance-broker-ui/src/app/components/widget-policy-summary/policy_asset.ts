import { Issues } from './issues';
import { Coverages } from './policy_coverages';

export abstract class Asset {
  public id: string | null = null;
  public purchasePrice: number | null = null;
  public coverages: Coverages;
  public issues: Issues;
  public isScheduledItem: boolean;
  public isSchedule: boolean;

  public abstract get description(): string;

  constructor(asset?: any | null, issues?: Issues | null) {
    this.issues = issues ?? new Issues([]);
    this.isScheduledItem = asset?.fields['schedule'] != null;
    this.isSchedule = asset?.type == 'schedule';
    this.coverages = new Coverages(asset, this.issues);

    if (asset) this.id = asset.id;
  }

  public abstract copy(): Asset;
}
