export class Driver {
  public refId: string;
  public percent: number | null = null;
  public principal: boolean | null = null;

  constructor(refId: string, percent: number | null, principal: boolean | null) {
    this.refId = refId;

    if (typeof percent === 'string') {
      this.percent = parseFloat(percent);
    }
    else if (typeof percent === 'number') {
      this.percent = percent;
    }

    this.principal = principal;

  }

  copy() {
    return new Driver(this.refId, this.percent, this.principal);
  }
}
