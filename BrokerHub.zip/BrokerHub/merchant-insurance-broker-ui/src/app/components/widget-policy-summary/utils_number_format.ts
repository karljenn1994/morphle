import { NumberUtils } from '../../utils/utils_number';
import { AssetComparison } from './comparison_asset';
import { CoverageComparison } from './comparison_coverage';

export class NumberFormatUtils {
  static formatPremiumChange(assetComp: AssetComparison, coverageComp: CoverageComparison) {
    if (coverageComp.status.length > 0) {
      return coverageComp.status;
    }

    if (coverageComp.premiumA === coverageComp.premiumB) return '';
    else if (coverageComp.premiumA != null && coverageComp.premiumB == null) {
      if (!assetComp.isRemoved) {
        return 'Removed';
      }
      return '';
    } else if (coverageComp.premiumA == null && coverageComp.premiumB != null) {
      if (!assetComp.isAdded) {
        return 'Added';
      }
      return '';
    }

    return NumberFormatUtils.formatDollarAmount(coverageComp.premiumChange);
  }

  static formatLimitChange(assetComp: AssetComparison, coverageComp: CoverageComparison) {
    if (coverageComp.limitA == coverageComp.limitB) return '';
    else if (coverageComp.limitA && !coverageComp.limitB) {
      if (!assetComp.isRemoved) {
        return 'Removed';
      }
      return '';
    } else if (!coverageComp.limitA && coverageComp.limitB) {
      if (!assetComp.isAdded) {
        return 'Added';
      }
      return '';
    }
    return NumberFormatUtils.formatDollarAmount(coverageComp.limitChange);
  }

  static formatDeductibleChange(assetComp: AssetComparison, coverageComp: CoverageComparison) {
    if (coverageComp.deductibleA == coverageComp.deductibleB) return '';
    else if (coverageComp.deductibleA && !coverageComp.deductibleB) {
      if (!assetComp.isRemoved) {
        return 'Removed';
      }
      return '';
    } else if (!coverageComp.deductibleA && coverageComp.deductibleB) {
      if (!assetComp.isAdded) {
        return 'Added';
      }
      return '';
    }

    return NumberFormatUtils.formatDollarAmount(coverageComp.deductibleChange);
  }

  static formatDollarAmount(amount: any | null): string {
    if (amount == null || amount == 0) {
      return '';
    }
    return NumberUtils.formatDollarAmount(amount);
  }

  static formatPercent(percentage: number, showSign: boolean = true, showZero: boolean = true) {
    return NumberUtils.formatPercent(percentage, showSign, showZero);
  }

  static formatPercentDriverChange(percentage: number, showSign: boolean = true) {
    return NumberUtils.formatPercent(percentage, showSign);
  }
}
