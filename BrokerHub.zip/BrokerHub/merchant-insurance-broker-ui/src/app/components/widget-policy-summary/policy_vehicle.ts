import { NumberUtils } from '../../utils/utils_number';
import { Issues } from './issues';
import { Asset } from './policy_asset';
import { Driver } from './policy_driver';

export class Vehicle extends Asset {
  public year: string | null = null;
  public make: string | null = null;
  public model: string | null = null;
  public vin: string | null = null;
  public type: string | null = null;
  public drivers: Driver[] = [];

  public get description() {
    let base = '';

    if (this.year != null) {
      base += `${this.year} `;
    }

    if (this.make || this.model) {
      base += [this.make, this.model].filter(Boolean).join(' ');
    } else if (this.type) {
      base += this.type?.toUpperCase();
    } else {
      base += $localize`Vehicle`;
    }

    if (this.purchasePrice != null) {
      base += ` (${NumberUtils.formatDollarAmount(this.purchasePrice)})`;
    }

    return base;
  }

  constructor(vehicle?: any | null, issues?: Issues) {
    super(vehicle, issues);
    if (!vehicle) return;

    this.year = vehicle.fields.year;
    this.make = vehicle.fields.make;
    this.model = vehicle.fields.model ?? '';
    this.vin = vehicle.fields.vin;
    this.type = vehicle.fields.type;

    if (vehicle.fields.purchase_price) {
      this.purchasePrice = parseFloat(vehicle.fields.purchase_price);
    }

    if (vehicle.drivers)
      for (var driver of vehicle.drivers) {
        this.drivers.push(new Driver(driver.id, driver.use, driver.principal));
      }
  }

  public copy(): Vehicle {
    var vehicle: Vehicle = new Vehicle();
    vehicle.id = this.id;
    vehicle.year = this.year;
    vehicle.make = this.make;
    vehicle.model = this.model;
    vehicle.vin = this.vin;

    for (var driver of this.drivers) {
      vehicle.drivers.push(new Driver(driver.refId, driver.percent, driver.principal));
    }

    return vehicle;
  }
}
