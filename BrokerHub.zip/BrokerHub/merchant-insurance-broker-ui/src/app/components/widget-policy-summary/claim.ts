import { NgPlural } from '@angular/common';
import { ClaimsDescriptions } from './claims_descriptions';

export class Claim {
  public date: Date;
  public code: string | null = null;
  public driverName: string | null = null;
  public driverId: string | null = null;
  public vehicleId: string | null = null;
  public percentResponsible: number | null = null;
  public description: string | null = null;

  constructor(
    date: Date,
    code: string | null,
    driverName: string | null,
    driverId: string | null,
    vehicleId: string | null,
    percentResponsible: number | null,
    description: string | null,
  ) {
    this.date = date;
    this.code = code;
    this.driverName = driverName;
    this.driverId = driverId;
    this.vehicleId = vehicleId;
    this.percentResponsible = percentResponsible;
    this.description = description;
  }

  get dateString() {
    return this.date.toISOString().split('T')[0];
  }

  getDescription(): string {
    const name = typeof this.driverName === 'string' && this.driverName.trim();
    const hasCode = typeof this.code === 'string' && this.code.trim().length > 0;
    const hasCustomDescription = typeof this.description === 'string' && this.description.trim().length > 0;

    let descriptionText = '';

    if (hasCode || hasCustomDescription) {
      descriptionText = ClaimsDescriptions.getDescription('AUTO', hasCode ? this.code!.trim() : null, this.description);
    } else if (hasCode) {
      descriptionText = this.code!.trim();
    }

    if (name && descriptionText) {
      return `${name} (${descriptionText})`;
    } else if (name) {
      return name;
    } else if (descriptionText) {
      return descriptionText;
    }

    return '';
  }

  copy() {
    return new Claim(
      this.date,
      this.code,
      this.driverName,
      this.driverId,
      this.vehicleId,
      this.percentResponsible,
      this.description,
    );
  }
}
