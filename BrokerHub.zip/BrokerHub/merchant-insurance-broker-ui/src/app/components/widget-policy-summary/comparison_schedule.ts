import { AssetComparison } from './comparison_asset';
import { Asset } from './policy_asset';

export class ScheduleComparison extends AssetComparison {
  constructor(assetA: Asset | null, assetB: Asset | null) {
    super(assetA, assetB);
  }
}
