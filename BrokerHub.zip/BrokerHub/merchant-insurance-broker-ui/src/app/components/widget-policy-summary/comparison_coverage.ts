import { Issue } from './issues';
import { Coverage } from './policy_coverage';
import { Report } from './report';

export class CoverageComparison {
  public assetStatus: string;

  public code: string;
  public status: string;
  public description: string | null;
  public refIdA: string | null = null;
  public refIdB: string | null = null;
  public premiumA: number | null = null;
  public premiumB: number | null = null;
  public premiumChange: number | null = null;
  public premiumChangePercent: number | null = null;
  public limitA: number | null = null;
  public limitB: number | null = null;
  public limitChange: number | null = null;
  public limitChangePercent: number | null = null;
  public deductibleA: number | null = null;
  public deductibleB: number | null = null;
  public deductibleChange: number | null = null;
  public deductibleChangePercent: number | null = null;
  public pakComparisons: CoverageComparison[] | null = null;

  public premiumIssues: Issue[] = [];
  public limitIssues: Issue[] = [];
  public deductibleIssues: Issue[] = [];

  public coverageA: Coverage | null = null;
  public coverageB: Coverage | null = null;

  get isIncludedA(): boolean {
    return this.coverageA != null && this.premiumA == null && this.limitA == null && this.deductibleA == null
  }

  get isRemovedA(): boolean {
    return this.coverageA == null
  }
  
  get isIncludedB(): boolean {
    return this.coverageB != null && this.premiumB == null && this.limitB == null && this.deductibleB == null
  }

  get isRemovedB(): boolean {
    return this.coverageB == null
  }

  get isPak(): boolean {
    return this.pakComparisons != null && this.pakComparisons.length > 0;
  }

  constructor(
    assetStatus: string,
    coverageA: Coverage | null,
    coverageB: Coverage | null
  ) {
    this.assetStatus = assetStatus;
    this.coverageA = coverageA;
    this.coverageB = coverageB;
    this.status = '';

    if (this.assetStatus != 'removed') {
      if (coverageA == null && coverageB != null) this.status = 'Added';
      else if (coverageA != null && coverageB == null) this.status = 'Removed';
    }

    this.code = (coverageA?.code ?? coverageB?.code)!;
    this.description = coverageA?.description ?? coverageB?.description ?? null;

    this.refIdA = coverageA?.refId ?? null;
    this.premiumA = coverageA?.premium ?? null;
    this.limitA = coverageA?.limit ?? null;
    this.deductibleA = coverageA?.deductible ?? null;

    this.refIdB = coverageB?.refId ?? null;
    this.premiumB = coverageB?.premium ?? null;
    this.limitB = coverageB?.limit ?? null;
    this.deductibleB = coverageB?.deductible ?? null;

    if (coverageA && coverageB) {
      this.premiumChange = Report.calculateChange(this.premiumA, this.premiumB);
      this.premiumChangePercent = Report.calculateChangePercent(
        this.premiumA,
        this.premiumB
      );
      this.limitChange = Report.calculateChange(this.limitA, this.limitB);
      this.limitChangePercent = Report.calculateChangePercent(
        this.limitA,
        this.limitB
      );
      this.deductibleChange = Report.calculateChange(
        this.deductibleA,
        this.deductibleB
      );
      this.deductibleChangePercent = Report.calculateChangePercent(
        this.deductibleA,
        this.deductibleB
      );
    }

    // Organize PAKS
    if (coverageA?.coverages != null || coverageB?.coverages != null) {
      this.pakComparisons = [];
      var pairs: { [key: string]: [Coverage | null, Coverage | null] } = {};

      if (coverageA?.coverages != null) {
        for (let coverage of coverageA.coverages)
          pairs[coverage.code] = [coverage, null];
      }

      if (coverageB?.coverages != null) {
        for (let coverage of coverageB.coverages) {
          if (coverage.code in pairs) pairs[coverage.code][1] = coverage;
          else pairs[coverage.code] = [null, coverage];
        }
      }

      for (let coverageCode in pairs) {
        let pair = pairs[coverageCode];
        this.pakComparisons?.push(
          new CoverageComparison(this.assetStatus, pair[0], pair[1])
        );
      }
    }

    this.premiumIssues.push(
      ...(this.coverageA?.issues?.findIssues(
        this.refIdA,
        'premium',
        this.code
      ) ?? [])
    );
    this.premiumIssues.push(
      ...(this?.coverageB?.issues?.findIssues(
        this.refIdB,
        'premium',
        this.code
      ) ?? [])
    );
    this.limitIssues.push(
      ...(this.coverageA?.issues?.findIssues(this.refIdA, 'limit', this.code) ??
        [])
    );
    this.limitIssues.push(
      ...(this?.coverageB?.issues?.findIssues(
        this.refIdB,
        'limit',
        this.code
      ) ?? [])
    );
    this.deductibleIssues.push(
      ...(this.coverageA?.issues?.findIssues(
        this.refIdA,
        'deductible',
        this.code
      ) ?? [])
    );
    this.deductibleIssues.push(
      ...(this?.coverageB?.issues?.findIssues(
        this.refIdB,
        'deductible',
        this.code
      ) ?? [])
    );
  }
}
