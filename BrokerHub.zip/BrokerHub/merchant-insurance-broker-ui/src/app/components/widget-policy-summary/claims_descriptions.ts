export class ClaimsDescriptions {
  public static getDescription(
    lob: string | undefined | null,
    code: string | undefined | null,
    description: string | undefined | null
  ): string {
    var newDescription: string | null = null;
    var upperCode = null;

    if (code) {
      upperCode = code?.toUpperCase().replace(/^0+/, '');

      if (lob) {
        if (lob == 'AUTO')
          newDescription =
            ClaimsDescriptions.vehicleDescriptions.get(upperCode) ?? null;
        else
          newDescription =
            ClaimsDescriptions.propertyDescriptions.get(upperCode) ?? null;
      }
    }

    if (!newDescription && description) newDescription = description;
    if (!newDescription && upperCode) newDescription = upperCode;
    if (!newDescription) newDescription = "";
    return newDescription;
  }

  static vehicleDescriptions: Map<string, string> = new Map<string, string>([
    ['1', $localize`Backed Into Car`],
    ['3', $localize`Collision with Animal`],
    ['4', $localize`Collision - Head-on`],
    ['5', $localize`Collision - Rear-ended`],
    ['6', $localize`Collision - Multi-vehicle`],
    ['7', $localize`Collision - Other`],
    ['8', $localize`Disobeyed Stop Sign/Red Light`],
    ['16', $localize`Fire`],
    ['17', $localize`Flood`],
    ['18', $localize`Glass/Windshield`],
    ['19', $localize`Hit & Run`],
    ['20', $localize`Hit Pedestrian`],
    ['21', $localize`Lightning`],
    ['22', $localize`Parking Lot`],
    ['31', $localize`Theft`],
    ['34', $localize`Vandalism`],
    ['36', $localize`Windstorm/Hail`],
  ]);

  static propertyDescriptions: Map<string, string> = new Map<string, string>([
    ['503', $localize`Burglary`],
    ['547', $localize`Fire`],
    ['502', $localize`Liability`],
    ['588', $localize`Property Damage`],
    ['591', $localize`Sewer Backup`],
    ['627', $localize`Water Damage`],
    ['641', $localize`Wind/Hail Damage`],
    ['999', $localize`Other`],
  ]);
}
