import { ClaimComparison } from './comparison_claims';
import { CoverageComparison } from './comparison_coverage';
import { CoverageDescriptions } from './coverage_descriptions';
import { Issue } from './issues';
import { Asset } from './policy_asset';
import { Coverage } from './policy_coverage';
import { Vehicle } from './policy_vehicle';
import { Report } from './report';

export abstract class AssetComparison {
  public assetA: Asset | null;
  public assetB: Asset | null;
  public claimComparison: ClaimComparison[] = [];
  public premiumChange: number | null = null;
  public premiumChangePercent: number | null = null;
  public coverageComparison: CoverageComparison[] = [];
  public totalPremiumIssues: Issue[] = [];

  get isScheduledItem() {
    return this.assetA?.isScheduledItem || this.assetB?.isScheduledItem;
  }

  get isSchedule() {
    return this.assetA?.isSchedule || this.assetB?.isSchedule;
  }

  get isAdded() {
    return this.assetA == null && this.assetB != null;
  }

  get isRemoved() {
    return this.assetA != null && this.assetB == null;
  }

  get description() {
    return this.assetA?.description ?? this.assetB?.description ?? '';
  }

  get purchasePrice() {
    return this.assetA?.purchasePrice ?? this.assetB?.purchasePrice ?? '';
  }

  get status() {
    if (this.assetA != null && this.assetB == null) return 'removed';
    if (this.assetA == null && this.assetB != null) return 'added';
    return '';
  }

  get lob() {
    if (this.assetA instanceof Vehicle || this.assetB instanceof Vehicle)
      return 'AUTO';
    return 'HABL';
  }

  get totalIssues() {
    return (
      (this.assetA?.issues?.totalIssues ?? 0) +
      (this.assetB?.issues?.totalIssues ?? 0)
    );
  }

  get issues() {
    var i: Issue[] = [];
    i.push(...(this.assetA?.issues?.list ?? []));
    i.push(...(this.assetB?.issues?.list ?? []));
    return i;
  }

  constructor(assetA: Asset | null, assetB: Asset | null) {
    this.assetA = assetA;
    this.assetB = assetB;

    this.calculatePremiumChange();
    this.compareCoverages();
  }

  private calculatePremiumChange() {
    if (this.assetA && this.assetB) {
      this.premiumChange = Report.calculateChange(
        this.assetA.coverages?.totalPremium,
        this.assetB.coverages?.totalPremium
      );

      this.premiumChangePercent = Report.calculateChangePercent(
        this.assetA.coverages?.totalPremium,
        this.assetB.coverages?.totalPremium
      );
    }
  }

  private compareCoverages() {
    // Make a copy of all A and B coverages so we don't change the originals. The originals
    // will be needed when the user changes their comparison. Also, make a list of a paks and
    // map what pak each coverage belongs to.
    var coveragesA: { [key: string]: Coverage } = {};
    var coveragesB: { [key: string]: Coverage } = {};
    var paks: string[] = [];
    var coveragePaks: { [key: string]: string } = {};
    this.assetA?.coverages?.list.forEach((coverage: Coverage) => {
      let copy = coverage.copy();
      coveragesA[coverage.code] = copy;
      if (copy.isPak && copy.coverages != null) {
        if (!(copy.code in paks)) paks.push(copy.code);
        for (let cov of copy.coverages) {
          cov.description = CoverageDescriptions.getDescription(cov.code, null);
          coveragePaks[cov.code] = copy.code;
          if (cov.limit == -1) cov.limit = null;
          if (cov.deductible == -1) cov.deductible = null;
        }
      }
    });
    this.assetB?.coverages?.list.forEach((coverage: Coverage) => {
      let copy = coverage.copy();
      coveragesB[coverage.code] = copy;
      if (copy.isPak && copy.coverages != null) {
        if (!(copy.code in paks)) paks.push(copy.code);
        for (let cov of copy.coverages) {
          cov.description = CoverageDescriptions.getDescription(cov.code, null);
          coveragePaks[cov.code] = copy.code;
          if (cov.limit == -1) cov.limit = null;
          if (cov.deductible == -1) cov.deductible = null;
        }
      }
    });

    // Build Paks
    for (let pakCode of paks) {
      if (!(pakCode in coveragesA)) {
        // A side doesn't have the pak, so we need to build one.
        let pak_coverages: Coverage[] = [];
        let premium: number | null = null;

        for (let code in coveragePaks) {
          if (coveragePaks[code] == pakCode && code in coveragesA) {
            let c: Coverage = coveragesA[code];

            if (c.premium != null) {
              if (premium == null) premium = 0;
              premium += c.premium ?? 0;
            }

            pak_coverages.push(coveragesA[code]);
            delete coveragesA[code];
          }
        }

        coveragesA[pakCode] = new Coverage(
          this.assetA?.id!,
          pakCode,
          CoverageDescriptions.getDescription(pakCode, null),
          premium,
          -1,
          -1,
          pak_coverages,
          null
        );
      }

      if (!(pakCode in coveragesB)) {
        // B side doesn't have the pak, so we need to build one.
        let pak_coverages: Coverage[] = [];
        let premium: number | null = null;

        for (let code in coveragePaks) {
          if (coveragePaks[code] == pakCode && code in coveragesB) {
            let c: Coverage = coveragesB[code];

            if (c.premium != null) {
              if (premium == null) premium = 0;
              premium += c.premium ?? 0;
            }

            pak_coverages.push(coveragesB[code]);
            delete coveragesB[code];
          }
        }

        coveragesB[pakCode] = new Coverage(
          this.assetB?.id!,
          pakCode,
          CoverageDescriptions.getDescription(pakCode, null),
          premium,
          -1,
          -1,
          pak_coverages,
          null
        );
      }
    }

    var coveragePairsMap: {
      [key: string]: [Coverage | null, Coverage | null];
    } = {};

    for (let coverageCode in coveragesA)
      coveragePairsMap[coverageCode] = [coveragesA[coverageCode], null];

    for (let coverageCode in coveragesB) {
      var existingPair = null;

      if (Object.keys(coveragePairsMap).includes(coverageCode))
        existingPair = coveragePairsMap[coverageCode];

      if (existingPair) existingPair[1] = coveragesB[coverageCode];
      else coveragePairsMap[coverageCode] = [null, coveragesB[coverageCode]];
    }

    // Sort the coverages
    let coverageCodes = Object.keys(coveragePairsMap);

    let sorting: string[] = ['AP', 'APOD', 'CMP', 'COL', 'COLOD', 'SP'];

    if (this.lob == 'HABL') {
      sorting = ['DWELL'];
    }

    coverageCodes?.sort((a, b) => {
      if (sorting.includes(a)) return -1;
      if (sorting.includes(b)) return 1;
      if (a.startsWith('TP')) return -1;
      if (b.startsWith('TP')) return 1;
      if (a.startsWith('DIS')) return 1;
      if (b.startsWith('DIS')) return -1;
      return 0;
    });

    for (let code of coverageCodes) {
      let pair: [Coverage | null, Coverage | null] = coveragePairsMap[code];
      this.coverageComparison.push(
        new CoverageComparison(this.status, pair[0], pair[1])
      );
    }
  }
}
