import { Vehicle } from './policy_vehicle';
import { Property } from './policy_property';
import { Policy } from './policy';
import { AssetComparison } from './comparison_asset';
import { Issues } from './issues';
import { Asset } from './policy_asset';
import { VehicleComparison } from './comparison_vehicle';
import { PropertyComparison } from './comparison_property';
import { Schedule } from './policy_schedule';
import { ScheduleComparison } from './comparison_schedule';

export class Comparison {
  public assetComparisons: AssetComparison[] = [];
  public policyA: Policy | null = null;
  public policyB: Policy | null = null;

  get isComparing() {
    return this.hasA && this.hasB;
  }

  get hasA() {
    return this.policyA != null && this.policyA.downloaded == true;
  }

  get hasB() {
    return this.policyB != null && this.policyB.downloaded == true;
  }

  get hasActiveA() {
    return this.policyA != null && this.policyA.downloaded && this.policyA.purpose != 'XLN';
  }

  get hasActiveB() {
    return this.policyB != null && this.policyB.downloaded && this.policyB.purpose != 'XLN';
  }

  constructor(
    policyA: Policy | null,
    policyB: Policy | null,
  ) {
    this.policyA = policyA;
    this.policyB = policyB;

    if (this.policyB == null) {
      // If there is nothing in column B then we should use the second column for A.
      // This will space things out nicer.
      this.policyB = this.policyA;
      this.policyA = null;
    }

    // If there are no coverages on A then it must have been removed, so remove it.
    if (this.policyA != null)
      this.policyA.assets = this.policyA?.assets.filter(
        (asset) => asset.coverages !== null && !asset.isScheduledItem
      );

    // If there are no coverages on B then it must have been removed, so remove it.
    if (this.policyB != null)
      this.policyB.assets = this.policyB?.assets.filter(
        (asset) => asset.coverages !== null
      );

    var pairs: [Asset | null, Asset | null][] = [];

    this.policyA?.assets?.forEach((asset: Asset) => {
      pairs.push([asset, null]);
    });

    this.policyB?.assets.forEach((asset: Asset) => {
      var existingPair = this.lookupAsset(pairs, asset);
      if (existingPair) existingPair[1] = asset;
      else pairs.push([null, asset]);
    });

    for (let pair of pairs) {
      var c = this.makeComparison(this.policyA, pair[0], this.policyB, pair[1]);

      if (c)
        this.assetComparisons.push(c);
    }
  }

  private makeComparison(
    policyA: Policy | null,
    assetA: Asset | null,
    policyB: Policy | null,
    assetB: Asset | null,
  ) {
    if (assetA instanceof Vehicle || assetB instanceof Vehicle)
      return new VehicleComparison(policyA, assetA, policyB, assetB);
    else if (assetA instanceof Property || assetB instanceof Property)
      return new PropertyComparison(assetA, assetB);
    else if (assetA instanceof Schedule || assetB instanceof Schedule)
      return new ScheduleComparison(assetA, assetB);

    return null;
  }

  private lookupAsset(
    assetPairs: [Asset | null, Asset | null][],
    assetB: Asset
  ): [Asset | null, Asset | null] | null {
    if (assetB == null) return null;

    if (assetB instanceof Vehicle) {
      for (let assetPair of assetPairs) {
        var assetA = assetPair[0];

        if (assetA instanceof Vehicle) {
          if (assetB?.vin && assetB?.vin === assetA?.vin) return assetPair;

          if (
            assetB?.year === assetA?.year &&
            assetB?.make === assetA?.make &&
            assetB?.model === assetA?.model
          )
            return assetPair;
        }
      }
    } else if (assetB instanceof Property) {
      for (let assetPair of assetPairs) {
        var assetA = assetPair[0];

        if (assetA instanceof Property) {
          // As per conversation with Karl we have decided to only compare on street address becasue
          // Northbridge sometimes messes up city and province in the EDI. Street should be
          // enough.
          if (assetB?.address === assetA?.address)
            return assetPair;          
        }
      }
    } else if (assetB instanceof Schedule) {
      for (let assetPair of assetPairs) {
        var assetA = assetPair[0];

        if (assetA instanceof Property) {
          if (assetB?.id === assetA?.id)
            return assetPair;
        }
      }
    }

    return null;
  }
}
