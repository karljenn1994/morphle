import { Claim } from './claim';
import { AssetComparison } from './comparison_asset';
import { ClaimComparison } from './comparison_claims';
import { DriverComparison } from './comparison_driver';
import { Policy } from './policy';
import { Asset } from './policy_asset';
import { Driver } from './policy_driver';
import { Vehicle } from './policy_vehicle';

export class VehicleComparison extends AssetComparison {
  public driverComparison: DriverComparison[] = [];
  private policyA: Policy | null = null;
  private policyB: Policy | null = null;

  constructor(policyA: Policy | null, assetA: Asset | null, policyB: Policy | null, assetB: Asset | null) {
    super(assetA, assetB);
    this.policyA = policyA;
    this.policyB = policyB;
    this.compareDrivers();
    this.compareClaims();
  }

  private compareDrivers() {
    var pairs: { [key: string]: [Driver | null, Driver | null] } = {};

    if (this.assetA instanceof Vehicle) {
      var vehicleA: Vehicle = this.assetA as Vehicle;

      for (let driver of vehicleA.drivers) {
        pairs[driver.refId] = [driver, null];
      }
    }

    if (this.assetB instanceof Vehicle) {
      var vehicleB: Vehicle = this.assetB as Vehicle;

      for (let driver of vehicleB.drivers) {
        var existingPair = null;

        if (Object.keys(pairs).includes(driver.refId)) {
          existingPair = pairs[driver.refId];
        }

        if (existingPair) {
          existingPair[1] = driver;
        } else {
          pairs[driver.refId] = [null, driver];
        }
      }
    }

    for (let key in pairs) {
      var pair = pairs[key];
      var dA = this.lookupDriver(pair[0]);
      var dB = this.lookupDriver(pair[1]);
      this.driverComparison.push(new DriverComparison(this.status, pair[0], dA, pair[1], dB));
    }
  }

  private lookupDriver(driver: Driver | null) {
    if (this.policyA != null && driver != null)
      for (var i of this.policyA?.individuals) if (i.id == driver.refId) return i;

    if (this.policyB != null && driver != null)
      for (var i of this.policyB?.individuals) if (i.id == driver.refId) return i;

    return null;
  }

  private compareClaims() {
    const pairs: { [key: string]: [Claim | null, Claim | null] } = {};

    if (this.assetA instanceof Vehicle) {
      const vehicleA = this.assetA as Vehicle;

      for (const claim of this.policyA?.claims ?? []) {
        if (claim.vehicleId === vehicleA.id) {
          const key = this.buildClaimKey(claim);
          pairs[key] = [claim, null];
        }
      }
    }

    if (this.assetB instanceof Vehicle) {
      const vehicleB = this.assetB as Vehicle;

      for (const claim of this.policyB?.claims ?? []) {
        if (claim.vehicleId === vehicleB.id) {
          const key = this.buildClaimKey(claim);
          if (pairs[key]) {
            pairs[key][1] = claim;
          } else {
            pairs[key] = [null, claim];
          }
        }
      }
    }

    for (const key of Object.keys(pairs).sort((a, b) => {
      const [claimA1, claimB1] = pairs[a];
      const [claimA2, claimB2] = pairs[b];

      const date1 = claimA1?.date ?? claimB1?.date;
      const date2 = claimA2?.date ?? claimB2?.date;

      const time1 = date1 instanceof Date ? date1.getTime() : Number.NEGATIVE_INFINITY;
      const time2 = date2 instanceof Date ? date2.getTime() : Number.NEGATIVE_INFINITY;

      return time2 - time1; // descending
    })) {
      const [claimA, claimB] = pairs[key];
      this.claimComparison.push(new ClaimComparison(claimA, claimB));
    }
  }

  private buildClaimKey(claim: Claim): string {
    const parts = [claim.vehicleId];

    if (claim.driverId?.trim()) {
      parts.push(claim.driverId.trim());
    }

    if (claim.date instanceof Date && !isNaN(claim.date.getTime())) {
      const isoDate = claim.date.toISOString().split('T')[0]; // YYYY-MM-DD
      parts.push(isoDate);
    }

    if (claim.code?.trim()) {
      parts.push(claim.code.trim());
    }

    return parts.join('_');
  }
}
