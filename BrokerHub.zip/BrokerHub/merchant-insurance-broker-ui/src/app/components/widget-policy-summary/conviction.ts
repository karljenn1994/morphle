import { ConvictionDescriptions } from './convictions_descriptions';

export class Conviction {
  public date: Date;
  public code: string | null = null;
  public name: string | null = null;

  constructor(date: Date, code: string | null, name: string | null) {
    this.date = date;
    this.code = code;
    this.name = name;
  }

  get dateString() {
    return this.date.toISOString().split('T')[0];
  }

  getDescription(): string {
    const name = typeof this.name === 'string' && this.name.trim();
    const hasCode = typeof this.code === 'string' && this.code.trim().length > 0;

    let descriptionText = '';

    if (hasCode) {
      descriptionText = ConvictionDescriptions.getDescription('AUTO', this.code!.trim(), null);
    }

    if (name && descriptionText) {
      return `${name} (${descriptionText})`;
    } else if (name) {
      return name;
    } else if (descriptionText) {
      return descriptionText;
    }

    return '';
  }

  copy() {
    return new Conviction(this.date, this.code, this.name);
  }
}
