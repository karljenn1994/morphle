export class ConvictionDescriptions {
  public static getDescription(
    lob: string,
    code: string | null,
    description: string | null
  ): string {
    var newDescription: string | null = null;
    var upperCode = null;

    if (code) {
      upperCode = code?.toUpperCase().replace(/^0+/, '');

      if (lob) {
        if (lob == 'AUTO')
          newDescription =
            ConvictionDescriptions.descriptions.get(upperCode) ?? null;
      }
    }

    if (!newDescription && description) newDescription = description;
    if (!newDescription && upperCode) newDescription = upperCode;
    if (!newDescription) newDescription = '';
    return newDescription;
  }

  static descriptions: Map<string, string> = new Map<string, string>([
    ['CD', $localize`Careless Driving`],
    ['CN', $localize`Criminal negligence`],
    ['DD', $localize`Dangerous driving`],
    ['DUS', $localize`Driving while under suspension`],
    ['FPBT', $localize`Failure to pass breath or blood test`],
    ['FPEI', $localize`Failure to produce evidence of insurance`],
    ['FTR', $localize`Failure to remain`],
    ['FTS', $localize`Failure to stop`],
    ['HL', $localize`Headlight offense`],
    ['ILC', $localize`Improper lane change`],
    ['PSB', $localize`School bus - improper passing or fail to stop`],
    ['RAC', $localize`Racing`],
    ['MAJOR', $localize`Major`],
  ]);
}
