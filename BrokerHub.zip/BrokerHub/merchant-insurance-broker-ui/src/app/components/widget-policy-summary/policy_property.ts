import { Issues } from './issues';
import { Asset } from './policy_asset';

export class Property extends Asset {
  public address: string | null = null;
  public city: string | null = null;
  public provinceCode: string | null = null;
  public postalCode: string | null = null;

  public get description() {
    const parts: string[] = [];

    if (this.address) {
      parts.push(this.address);
    }

    if (this.city) {
      parts.push(this.city);
    }

    if (this.provinceCode) {
      parts.push(this.provinceCode);
    }

    return parts.join(', ');
  }

  constructor(property?: any | null, issues?: Issues) {
    if (!property) return;
    super(property, issues);
    this.address = property.fields.address;
    this.city = property.fields.city;
    this.provinceCode = property.fields.province_code;

    if (property.fields.coverage_dwell_limit) this.purchasePrice = parseFloat(property.fields.coverage_dwell_limit);
  }

  public copy(): Property {
    var property: Property = new Property();
    property.id = this.id;
    property.address = this.address;
    property.city = this.city;
    property.provinceCode = this.provinceCode;
    property.postalCode = this.postalCode;
    property.purchasePrice = this.purchasePrice;
    return property;
  }
}
