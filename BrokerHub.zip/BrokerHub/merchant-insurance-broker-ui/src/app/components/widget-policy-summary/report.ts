import { NumberUtils } from '../../utils/utils_number';
import { Comparison } from './comparison';
import { IndividualComparison } from './comparison_individual';
import { Policy } from './policy';
import { Individual } from './policy_individual';

export class PolicyOption {
  label: string;
  premium: string;
  purpose: string;
  policy: Policy;
  effectiveDate: Date | null = null;
  sequence: Number | null = null;

  constructor(label: string, premium: string, purpose: string, policy: Policy) {
    this.label = label;
    this.premium = premium;
    this.purpose = purpose;
    this.policy = policy;

    if (policy.effectiveDate != null) this.effectiveDate = new Date(policy.effectiveDate!);

    if (policy.sequence != null) this.sequence = policy.sequence;
  }
}

export class Report {
  public policy: Policy | null;
  public renewal: Policy | null;
  public history: Policy[] | null;

  public comparison!: Comparison;
  public individualComparison: IndividualComparison[] = [];
  public changePercent: number | null = null;
  public policyOptions: PolicyOption[] = [];
  public hasOptions = false;

  private _policyA: Policy | null = null;
  private _policyB: Policy | null = null;

  public policyName(policy: Policy): string {
    const option = this.policyOptions.find((opt) => opt.policy === policy);
    return option?.label ?? '';
  }

  get hasConvictions() {
    for (var i of this.individualComparison) {
      if (i.hasConvictions) return true;
    }

    return false;
  }

  get hasClaims() {
    return (this._policyA?.claims?.length ?? 0) + (this._policyB?.claims?.length ?? 0) > 0;
  }

  get isDownloaded() {
    return this.policy?.downloaded || this.renewal;
  }

  get policyA() {
    return this._policyA;
  }

  set policyA(policy: Policy | null) {
    this._policyA = policy;
  }

  get hasPolicyA() {
    return this._policyA != null && this._policyA.downloaded;
  }

  get policyB() {
    return this._policyB;
  }

  set policyB(policy: Policy | null) {
    this._policyB = policy;
  }

  get hasPolicyB() {
    return this._policyB != null && this._policyB.downloaded;
  }

  get pdfs() {
    if ((this.policy?.pdfs?.length ?? 0) > 0) { 
      return this.policy?.pdfs;
    }

    if ((this.renewal?.pdfs?.length ?? 0) > 0) {
      return this.renewal?.pdfs;
    }

    return null;
  }

  constructor(policy: Policy | null, renewal: Policy | null, history: Policy[] | null) {
    this.policy = policy;
    this.renewal = renewal;
    this.history = history;

    if (this.policy && this.renewal) {
      this.changePercent = Report.calculateChangePercent(this.policy.premium, this.renewal.premium);
    }

    this.clearPolicies();
  }

  public compare(policyA: Policy, policyB: Policy | null) {
    // A might be a placeholder. If we have a B (i.e. renewal), we should
    // show that by itself.
    if (policyA?.downloaded != true && this.policyB?.downloaded == true) {
      this.policyA = policyB;
    } else {
      this._policyA = policyA;
      this._policyB = policyB;
    }

    this.comparison = new Comparison(this._policyA, this._policyB);
    this.compare_individuals(this._policyA, this._policyB);

    this.changePercent = null;

    const a_premium = this._policyA?.premium;
    const b_premium = this._policyB?.premium;

    if (a_premium != null && b_premium != null) {
      this.changePercent = Report.calculateChangePercent(a_premium, b_premium);
    }
  }

  private compare_individuals(policyA: Policy | null, policyB: Policy | null) {
    this.individualComparison = [];

    var individualPairsMap: {
      [key: string]: [Individual | null, Individual | null];
    } = {};

    for (let individual of policyA?.individuals ?? []) {
      individualPairsMap[individual.id!] = [individual, null];
    }

    for (let individual of policyB?.individuals ?? []) {
      var existingPair = null;

      if (Object.keys(individualPairsMap).includes(individual.id!)) {
        existingPair = individualPairsMap[individual.id!];
      }

      if (existingPair) {
        existingPair[1] = individual;
      } else {
        individualPairsMap[individual.id!] = [null, individual];
      }
    }

    for (const pair of Object.values(individualPairsMap)) {
      const hasPolicyA = !!this._policyA;
      const hasPolicyB = !!this._policyB;

      // If there is nothing in column B then we should use the second column for A.
      // This will space things out nicer.
      if (hasPolicyA && hasPolicyB) {
        this.individualComparison.push(new IndividualComparison(true, pair[0], true, pair[1]));
      } else {
        const value = hasPolicyA ? pair[0] : pair[1];
        this.individualComparison.push(new IndividualComparison(false, null, true, value));
      }
    }
  }

  public purposeString(purpose: string): string {
    var p = purpose;

    switch (p) {
      case 'NBS':
        p = 'New Business';
        break;
      case 'PCH':
        p = 'Policy Change';
        break;
      case 'RWL':
        p = 'Renewal';
        break;
      case 'RII':
        p = 'Reissue';
        break;
      case 'XLN':
        p = 'Cancellation';
        break;
    }

    return p;
  }

  public policyStatusString(status: string): string {
    var s = status;

    switch (s) {
      case 'cancelled':
        s = 'Cancelled';
        break;
    }

    return s;
  }

  public clearPolicies() {
    this.policyOptions = [];

    if (this.policy && this.policy.downloaded) {
      this.addPolicy(
        $localize`Current`,
        this.policy.premium ?? 0,
        this.purposeString(this.policy.purpose),
        this.policy,
      );
    }

    if (this.renewal) {
      this.addPolicy(
        $localize`Renewal`,
        this.renewal.premium ?? 0,
        this.purposeString(this.renewal.purpose),
        this.renewal,
      );
    }

    if (this.history) {
      for (var h of this.history) {
        this.addPolicy(h.heading, h.premium ?? 0, this.purposeString(h.purpose), h);
      }
    }
  }

  public addPolicy(label: string, premium: number, type: string, policy: Policy): PolicyOption {
    var pOption = new PolicyOption(label, NumberUtils.formatDollarAmount(premium), type, policy);
    this.policyOptions.push(pOption);
    this.policyOptions.sort((a, b) => {
      const aDate = a.effectiveDate;
      const bDate = b.effectiveDate;

      // Both dates missing → sort by premium (ascending), null premiums first
      if (aDate == null && bDate == null) {
        if (a.policy.premium == null && b.policy.premium == null) return 0;
        if (a.policy.premium == null) return -1;
        if (b.policy.premium == null) return 1;
        if (a.policy.premium > b.policy.premium) return 1;
        if (a.policy.premium < b.policy.premium) return -1;
        return 0;
      }

      // One date missing → missing goes last
      if (aDate == null) return 1;
      if (bDate == null) return -1;

      // Both dates present → newer first (descending by date)
      if (aDate < bDate) return 1;
      if (aDate > bDate) return -1;

      // Dates equal → tie-break on sequence if both present (higher first).
      const aSeq = a.sequence;
      const bSeq = b.sequence;
      if (aSeq != null && bSeq != null) {
        // higher seq should come first.
        if (aSeq > bSeq) return -1;
        if (aSeq < bSeq) return 1;
      }

      // Final fallback → premium (ascending).
      const ap = a.policy.premium;
      const bp = b.policy.premium;
      if (ap == null && bp == null) return 0;
      if (ap == null) return -1;
      if (bp == null) return 1;
      if (ap > bp) return 1;
      if (ap < bp) return -1;
      return 0;
    });
    this.hasOptions = true;
    return pOption;
  }

  static calculateChange(currentValue: any, renewalValue: any) {
    if (currentValue != null && renewalValue != null) {
      // Both should be floats. Here we want to return a negative value for a decrease,
      // and a positive value for an increase.
      var v1 = +currentValue;
      var v2 = +renewalValue;
      return -v1 + v2;
    }

    return null;
  }

  static calculateChangePercent(currentValue: any, renewalValue: any) {
    if (currentValue && renewalValue) {
      var v1 = +currentValue;
      var v2 = +renewalValue;

      if (v2 > v1) {
        return ((v2 - v1) / v1) * 100;
      } else if (v2 < v1) {
        return -(((v1 - v2) / v1) * 100);
      }

      return 0;
    }

    return null;
  }
}
