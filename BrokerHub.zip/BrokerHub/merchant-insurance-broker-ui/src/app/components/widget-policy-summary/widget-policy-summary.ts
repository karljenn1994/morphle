import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ToastProvider } from '../../providers/provider-toast';
import { Cancellable, QuotesService } from '../../services/service-quotes';
import { PolicyOption, Report } from './report';
import { Policy } from './policy';
import { Coverage } from './policy_coverage';
import { Accordion } from 'primeng/accordion';
import { Issues } from './issues';
import { NumberFormatUtils } from './utils_number_format';
import { AssetComparison } from './comparison_asset';
import { VehicleComparison } from './comparison_vehicle';
import { PropertyComparison } from './comparison_property';
import { DomSanitizer } from '@angular/platform-browser';
import { AuthenticationService } from '../../services/service-authentication';
import { MenuItem } from 'primeng/api';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'policy-summary',
  templateUrl: './widget-policy-summary.html',
  styleUrls: ['./widget-policy-summary.scss'],
  standalone: false,
})
export class PolicySummaryWidget implements OnInit {
  @Input() user: any = null;
  @Input() policy!: Array<any>;
  @Input() history: Array<Array<any>> | null = null;
  @Input() renewal: Array<any> | null = null;

  @Input() showHistory: boolean = false;
  @Input() showQuote: boolean = false;
  @Input() showRenewal: boolean = false;
  @Input() showRenewalWhenNoPolicy: boolean = false;
  @Input() showDelete: boolean = false;
  @Input() showIssues: boolean = false;
  @Input() showCompare: boolean = false;
  @Input() showClaimsConvictions: boolean = false;
  @Input() showPinkCards: boolean = false;
  @Input() showNotify: boolean = false;
  @Input() showPolicyLink: boolean = false;

  @Output() viewPolicy = new EventEmitter<any>();
  @Output() viewPOI = new EventEmitter<any>();
  @Output() delete = new EventEmitter<void>();
  @Output() notifyUser = new EventEmitter<{ type: string; policy: any }>();

  @ViewChild('accordion') accordion!: Accordion;

  loading = false;

  showHeadings = true;
  activeTabs: boolean[] = [true, false];

  report!: Report;
  policyObj: Policy | null = null;
  renewalObj: Policy | null = null;

  cancellableQuote: Cancellable<any> | null = null;
  quoteInProgress = false;
  showQuoteDialog = false;

  showPolicyPicker: boolean = false;
  policiesBeingCompared: PolicyOption[] = [];
  tempPoliciesBeingCompared: PolicyOption[] = [];

  formatDollarAmount: any;
  formatPercent: any;
  formatPremiumChange: any;
  formatLimitChange: any;
  formatDeductibleChange: any;

  actionItems: MenuItem[] = [];
  primaryCommand: null | (() => void) = null;
  primaryLabel: string | null = null;
  primaryIcon: string | null = null;

  constructor(
    private authService: AuthenticationService,
    private quoteService: QuotesService,
    private toast: ToastProvider,
    private sanitizer: DomSanitizer,
    private http: HttpClient,
  ) {}

  isAdmin() {
    return this.authService.role == 'admin';
  }

  get hasHistory() {
    return this.history != null && this.history.length > 0;
  }

  get totalNewDocuments() {
    return this.report?.pdfs?.filter((p) => p.current).length ?? 0;
  }

  get totalDocuments() {
    return this.report?.pdfs?.length ?? 0;
  }

  get totalIssues() {
    return (this.policyObj?.issues?.policyIssues?.length ?? 0) + (this.renewalObj?.issues?.policyIssues?.length ?? 0);
  }

  getTotalAssetIssues(assetComparison: AssetComparison) {
    var aIssues = assetComparison.assetA?.issues?.getAssetIssues(assetComparison.assetA?.id)?.length ?? 0;
    var bIssues = assetComparison.assetB?.issues?.getAssetIssues(assetComparison.assetB?.id)?.length ?? 0;
    return aIssues + bIssues;
  }

  get totalPolicyErrors() {
    return this.policyObj?.issues?.totalErrors ?? 0;
  }

  get totalPolicyWarnings() {
    return this.policyObj?.issues?.totalWarnings ?? 0;
  }

  get totalRenewalErrors() {
    return this.renewalObj?.issues?.totalErrors ?? 0;
  }

  get totalRenewalWarnings() {
    return this.renewalObj?.issues?.totalWarnings ?? 0;
  }

  get vehiclePropertyLegend(): string {
    return this.report.policyA?.lob === 'AUTO' ? $localize`:@@vehicles:Vehicles` : $localize`:@@properties:Properties`;
  }

  get quoteLabel(): string {
    return this.quoteInProgress ? $localize`Cancel` : $localize`Quote`;
  }

  get isMobile() {
    const userAgent = navigator.userAgent.toLowerCase();

    const isAndroid = /android/.test(userAgent);
    const isIPhone = /iphone|ipod/.test(userAgent);
    const isIPad = /ipad/.test(userAgent);
    const isMobile = /mobile/.test(userAgent);

    // Android tablets: 'android' but NOT 'mobile'
    if (isAndroid && !isMobile) {
      return true;
    }

    return isAndroid || isIPhone || isIPad;
  }

  ngOnInit() {
    this.formatDollarAmount = NumberFormatUtils.formatDollarAmount;
    this.formatPercent = NumberFormatUtils.formatPercent;
    this.formatPremiumChange = NumberFormatUtils.formatPremiumChange;
    this.formatLimitChange = NumberFormatUtils.formatLimitChange;
    this.formatDeductibleChange = NumberFormatUtils.formatDeductibleChange;

    if (this.history == null) {
      this.history = null;
    }

    if (this.renewal == null) {
      this.renewal = null;
    }

    if (!this.showRenewal && !this.showRenewalWhenNoPolicy) {
      this.renewal = null;
    }

    if (this.renewal) {
      this.renewalObj = new Policy($localize`Renewal`, this.renewal);
    }

    if (this.policy) {
      this.policyObj = new Policy($localize`Current`, this.policy);
    }

    var historicalPolicies: Policy[] | null = null;

    if (this.showHistory && this.history != null) {
      historicalPolicies = [];
      for (var h of this.history) {
        var p: Policy = new Policy('', h);
        p.heading = p.transactionEffectiveDate ?? '';
        historicalPolicies.push(p);
      }
    }

    this.report = new Report(this.policyObj, this.renewalObj, historicalPolicies);

    this._compareDefaults();
    this._setupActions();
  }

  _setupActions() {
    const items: MenuItem[] = [];

    // Compare
    if (this.showCompare && this.report.policyOptions.length > 1) {
      items.push({
        label: $localize`:@@compare:Compare`,
        icon: 'pi pi-arrow-right-arrow-left',
        command: () => this.onShowOptionPicker(),
      });
    }

    // Quote
    if (this.showQuote && this.policyObj?.downloaded == true) {
      items.push({
        label: this.quoteLabel,
        icon: this.quoteInProgress ? 'pi pi-spin pi-spinner' : 'pi pi-shield',
        command: () => this.onQuote(),
      });
    }

    // Proof of Insurance
    if (this.showPinkCards && this.isMobile && this.policyObj?.downloaded == true) {
      items.push({
        label: $localize`:@@proofOfInsurance:Proof of Insurance`,
        icon: 'pi pi-file',
        command: () => this.onViewPOI(),
      });
    }

    // Notify
    if (this.isAdmin() && this.showNotify && this.policyObj?.downloaded == true) {
      items.push({
        label: $localize`:@@notify:Notify`,
        icon: 'pi pi-envelope',
        items: [
          {
            label: 'Marketing',
            command: (event) => this.onNotifyUser('policy'),
          },
          {
            label: 'Survey',
            command: (event) => this.onNotifyUser('survey'),
          },
          {
            label: 'Questionnaire',
            command: (event) => this.onNotifyUser('questionnaire'),
          },
        ],
      });
    }

    // Remove
    if (this.showDelete && this.report.policy) {
      items.push({
        label: $localize`:@@remove:Remove`,
        icon: 'pi pi-trash',
        command: () => this.onDelete(),
      });
    }

    this.actionItems = items;

    if (items.length > 0) {
      const [primary, ...rest] = items;
      this.primaryLabel = primary.label!;
      this.primaryIcon = primary.icon!;
      this.primaryCommand = () => primary.command!({ originalEvent: undefined, item: primary });

      this.actionItems = rest;
    } else {
      this.primaryLabel = null;
      this.primaryIcon = null;
      this.primaryCommand = null;
    }
  }

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  castToVehicleComparison(assetComparison: AssetComparison) {
    return assetComparison as VehicleComparison;
  }

  castToPropertyComparison(assetComparison: AssetComparison) {
    return assetComparison as PropertyComparison;
  }

  getPDFLink(pdf: any) {
    return this.sanitizer.bypassSecurityTrustUrl(environment.apiURL + '/' + pdf.download_link);
  }

  onViewPOI() {
    this.viewPOI.emit();
  }

  onDelete() {
    this.delete.emit();
  }

  onOpenPolicy() {
    if (this.showPolicyLink) {
      this.viewPolicy?.emit();
    }
  }

  onQuote() {
    if (this.quoteInProgress) this.onCancelQuote();
    this.quoteInProgress = true;
    this.cancellableQuote = this.quoteService.performQuote(this.renewal ?? this.policy);
    var quotes: any = [];

    this.cancellableQuote?.promise
      ?.then((quoteResults: any) => {
        if (this.cancellableQuote?.isCancelled == true) {
          return;
        }
        if (quoteResults) {
          for (var provider of quoteResults) {
            console.log(provider.provider.toUpperCase());
            console.log('QUOTE REQUEST XML');
            console.log(provider.quote_request_xml);
            console.log('QUOTE RESPONSE XML');
            console.log(provider.quote_response_xml);

            if (provider.status !== 'success') {
              continue;
            }

            for (var result of provider.quote_results) {
              if (provider.status !== 'success') {
                continue;
              }
              if (result.total_premium > 0) {
                quotes.push(result);
              }
            }
          }
        }

        this.report.clearPolicies();

        if (quotes.length > 0) {
          quotes.forEach((quote: any) => {
            var policy: Policy | null = this._buildPolicy(quote);
            if (policy !== null && policy.company != null) {
              this.report.addPolicy(policy.company, policy.premium ?? 0, 'Quote', policy);
            }
          });

          this._compareFirstQuote();
        } else {
          this.toast.success($localize`No quotes could be found`);
        }
      })
      .catch((error) => {
        this.report.clearPolicies();

        if (error.hasOwnProperty('message')) {
          this.toast.show(error);
        } else if (error.hasOwnProperty('error')) {
          this.toast.error(error.error);
        } else this.toast.error($localize`An error occurred`);
      })
      .finally(() => {
        this.quoteInProgress = false;
        this.cancellableQuote = null;
      });
  }

  onCancelQuote() {
    if (this.cancellableQuote) {
      this.cancellableQuote.cancelRequest();
    }
    this.showQuoteDialog = false;
  }

  onShowOptionPicker() {
    this.showPolicyPicker = true;
    this.tempPoliciesBeingCompared = this.policiesBeingCompared;
  }

  onSelectOption(option: PolicyOption) {
    this.showPolicyPicker = false;
  }

  gotoPolicyIssues() {
    window.location.hash = '';
    window.location.hash = 'policy-issues';
  }

  gotoRenewalIssues() {
    window.location.hash = '';
    window.location.hash = 'renewal-issues';
  }

  choosePolicy(event: any, option: PolicyOption) {
    if (this.tempPoliciesBeingCompared.length > 2) {
      this.tempPoliciesBeingCompared.shift();
    }
  }

  onChangeCompare() {
    this.policiesBeingCompared = this.tempPoliciesBeingCompared;
    this.showPolicyPicker = false;
    this._compare();
  }

  onNotifyUser(type: any) {
    this.notifyUser.emit({ type: type, policy: this.report.policyA });
  }

  _buildPolicy(quote: any): Policy | null {
    var policyToCopy: Policy | null = null;
    if (this.report.renewal != null) {
      policyToCopy = this.report.renewal;
    }
    if (policyToCopy == null) {
      policyToCopy = this.report.policy;
    }
    if (policyToCopy == null) {
      return null;
    }

    var quotePolicy: Policy = policyToCopy.copy('Quote', quote.insurer, quote.insurer_description, quote.total_premium);

    for (var asset of quotePolicy.assets) {
      if (quote.discounts) {
        for (var discount of quote.discounts) {
          if (discount.item_id == asset.id) {
            asset.coverages?.addCoverage(discount.code, discount.description, null, null, null, null, null, null);
          }
        }
      }

      for (var coverage of quote.coverages) {
        if (coverage.item_id == asset.id) {
          if (coverage.premium != -1) {
            if (quotePolicy.coveragesPremium == null) {
              quotePolicy.coveragesPremium = 0;
            }

            quotePolicy.coveragesPremium += coverage.premium;
          }

          let pak_coverages: Coverage[] | null = null;

          if ('coverages' in coverage) {
            pak_coverages = [];

            for (let pack_coverage of coverage['coverages']) {
              pak_coverages.push(
                new Coverage(
                  asset.id!,
                  pack_coverage['code'],
                  pack_coverage['description'],
                  null,
                  pack_coverage['limit'],
                  pack_coverage['deductible'],
                  null,
                  null,
                ),
              );
            }
          }

          asset?.coverages?.addCoverage(
            asset?.id!,
            coverage.code,
            coverage.description,
            coverage.premium != -1 ? coverage.premium : null,
            coverage.limit != -1 ? coverage.limit : null,
            coverage.deductible != -1 ? coverage.deductible : null,
            pak_coverages,
            null,
          );
        }
      }
    }

    return quotePolicy;
  }

  _isRenewalComparison(a: PolicyOption, b: PolicyOption) {
    if (this.showIssues && this.showRenewal && a != null && b != null) {
      if (
        (a.policy == this.policyObj && b.policy == this.renewalObj) ||
        (a.policy == this.renewalObj && b.policy == this.policyObj)
      ) {
        return true;
      }
    }

    return false;
  }

  _compare() {
    if (this.policiesBeingCompared.length == 2) {
      var p1Option = this.policiesBeingCompared[0];
      var p2Option = this.policiesBeingCompared[1];
      var policies: [p1: Policy, p2: Policy] = this._sortCompare(p1Option.policy, p2Option.policy);
      var issues: Issues | null = null;

      if (this._isRenewalComparison(p1Option, p2Option)) {
        issues = this.renewalObj?.issues ?? null;
      }

      this.report.compare(policies[0], policies[1]);
    } else if (this.policiesBeingCompared.length == 1) {
      var p1Option = this.policiesBeingCompared[0];
      this.report.compare(p1Option.policy, null);
    } else this._compareDefaults();
  }

  _compareDefaults() {
    this.policiesBeingCompared = [];
    var indices: number[] = [1, 0];

    var hasRenewal = this.renewalObj?.downloaded == true;
    var hasPolicy = this.policyObj?.downloaded == true;

    if (hasRenewal) {
      this.policiesBeingCompared.push(this.report.policyOptions[indices.pop()!]);
    }

    if (hasPolicy) {
      this.policiesBeingCompared.push(this.report.policyOptions[indices.pop()!]);
    }

    if (hasRenewal && hasPolicy) {
      this.report.compare(this.policyObj!, this.renewalObj);
    } else if (hasPolicy || !hasRenewal) {
      this.report.compare(this.policyObj!, null);
    } else if (hasRenewal) {
      this.report.compare(this.renewalObj!, null);
    }
  }

  _compareFirstQuote() {
    for (var option of this.report.policyOptions) {
      // First quote wont have an effective date.
      if (option.effectiveDate == null) {
        this.policiesBeingCompared = [this.report.policyOptions[0], option];
        this.tempPoliciesBeingCompared = this.policiesBeingCompared;
        this._compare();
        break;
      }
    }
  }

  _sortCompare(p1: Policy, p2: Policy): [p1: Policy, p2: Policy] {
    if (p1.effectiveDate == null && p2.effectiveDate == null) {
      return [p1, p2];
    } else if (p1.effectiveDate == null) {
      return [p2, p1];
    } else if (p2.effectiveDate == null) {
      return [p1, p2];
    } else if (p1.effectiveDate < p2.effectiveDate) {
      return [p1, p2];
    } else if (p1.effectiveDate > p2.effectiveDate) {
      return [p2, p1];
    } else {
      return [p1, p2];
    }
  }
}
