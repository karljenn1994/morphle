import { Issues } from './issues';
import { Asset } from './policy_asset';

export class Schedule extends Asset {
  public name: string | null = null;

  public get description() {
    if (this.name != null) {
      return this.name.split("|").join(", ");
    }

    return "Schedule " + this.id;
  }

  constructor(schedule?: any | null, issues?: Issues) {
    if (!schedule) return;
    super(schedule, issues);

    this.name = schedule.fields.name;
  }

  public copy(): Schedule {
    var schedule: Schedule = new Schedule();
    schedule.id = this.id;
    schedule.id = this.name;
    return schedule;
  }
}
