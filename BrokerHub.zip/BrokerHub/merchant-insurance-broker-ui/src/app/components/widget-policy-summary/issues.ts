export class Issues {
  public list: Issue[] = [];

  constructor(issues: Issue[]) {
    this.list = issues;
  }

  get totalIssues() {
    return this.list?.length ?? 0;
  }

  get totalErrors() {
    return this.list?.filter((i: any) => i.severity == 'error').length ?? 0;
  }

  get totalWarnings() {
    return this.list?.filter((i: any) => i.severity == 'warn').length ?? 0;
  }

  get policyIssues() {
      return this.list?.filter((i: any) => i.type == 'policy');
  } 

  getAssetIssues(refId: string | null | undefined) {
    if (refId == null) {
      return null;
    }
    
    return this.list?.filter((i: any) => i.refId == refId);
  } 


  findIssues(
    refId: string | null,
    type: string | null,
    coverage_code: string | null
  ) {
    var issues: Issue[] | null = null;

    if (refId == null) return null;

    if (type == null && coverage_code == null) {
      issues = this.list?.filter(
        (i: any) => i.refId != null && i.refId == refId
      );
    } else if (coverage_code == null) {
      issues = this.list?.filter(
        (i: any) => i.refId == refId && i.type != null && i.type == type
      );
    } else if (type == null) {
      issues = this.list?.filter(
        (i: any) =>
          i.refId == refId &&
          i.coverage_code != null &&
          i.coverage_code.toUpperCase() == coverage_code.toUpperCase()
      );
    } else {
      issues = this.list?.filter(
        (i: any) =>
          i.refId == refId &&
          i.type != null &&
          i.type == type &&
          i.coverage_code != null &&
          i.coverage_code.toUpperCase() == coverage_code.toUpperCase()
      );
    }

    return issues;
  }
}

export class Issue {
  public type: string;
  public code: string;
  public refId: string;
  public severity: string;
  public message: string;
  public coverage_code: string | null;

  constructor(issue: any) {
    this.type = issue.type;
    this.code = issue.code;
    this.refId = issue.ref_id;
    this.severity = issue.severity;
    this.message = issue.message;
    this.coverage_code = issue.ctx;
  }
}
