import { Conviction } from "./conviction";

export class Individual {
  public id: string | null = null;
  public name: string | null = null;
  public provinceCode: string | null = null;
  public postalCode: string | null = null;
  public dateOfBirth: string | null = null;
  public convictions: Conviction[] = [];

  constructor(individual?: any | null) {
    if (!individual) return;
    this.id = individual.id;
    this.name = individual.fields.name;
    this.provinceCode = individual.fields.province_code;
    this.postalCode = individual.fields.postal_code;
    this.dateOfBirth = individual.fields.date_of_birth;


    if (individual.convictions) {
      for (var conviction of individual.convictions) {
        this.convictions.push(new Conviction(new Date(conviction.fields.date), conviction.fields.code, this.name));
      }
    }
  }

  copy() {
    var i = new Individual();
    i.id = this.id;
    i.name = this.name;
    i.provinceCode = this.provinceCode;
    i.postalCode = this.postalCode;
    i.dateOfBirth = this.dateOfBirth;
    return i;
  }
}
