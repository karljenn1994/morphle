import { Component, Input, OnInit } from '@angular/core';
import { Issue } from './issues';
import { AssetComparison } from './comparison_asset';
import { CoverageComparison } from './comparison_coverage';
import { NumberUtils } from '../../utils/utils_number';
import { NumberFormatUtils } from './utils_number_format';

@Component({
    selector: 'change',
    templateUrl: './widget-change.html',
    styleUrls: ['./widget-change.scss'],
    standalone: false
})
export class ChangeWidget implements OnInit {
  @Input() showIssues: boolean = false;
  @Input() issues!: Issue[];
  @Input() changePercent: number | null = null;
  @Input() changeAmount: number | null = null;

  formatDollarAmount: any;
  formatPercent: any;

  ngOnInit(): void {
    this.formatDollarAmount = NumberFormatUtils.formatDollarAmount;
    this.formatPercent = NumberFormatUtils.formatPercent;
  }
}
