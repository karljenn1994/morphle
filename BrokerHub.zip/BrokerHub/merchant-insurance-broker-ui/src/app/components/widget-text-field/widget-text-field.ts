import { Component, ElementRef, Input, ViewChild, forwardRef } from '@angular/core';
import { FormGroup, ControlContainer, FormControl, ValidationErrors } from '@angular/forms';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
    selector: 'text-field',
    templateUrl: './widget-text-field.html',
    styleUrls: ['./widget-text-field.scss'],
    styles: [
        `
      :host ::ng-deep .pi-eye,
      :host ::ng-deep .pi-eye-slash {
        transform: scale(1.6);
        margin-right: 1rem;
        color: var(--primary-color) !important;
      }
    `,
    ],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TextFieldWidget),
            multi: true
        }
    ],
    standalone: false
})
export class TextFieldWidget implements ControlValueAccessor {
  @Input() id!: string;
  @Input() floatLabel: boolean = true;
  @Input() readonly: boolean = false;
  @Input() class: string | undefined;
  @Input() details: string | undefined;
  @Input() type: string = "text";
  @Input() placeholder!: string;
  @Input() formControl!: FormControl;
  @Input() requiredError!: string;
  @Input() minlength!: number;
  @Input() maxlength!: number;
  @Input() minLengthError: string | undefined;
  @Input() patternError: string | undefined;
  @Input() mismatchError: string | undefined;
  @Input() emailError: string | undefined;
  @Input() showStrength: boolean = false;

  @ViewChild('input') input!: ElementRef;
  @ViewChild('reveal') reveal!: ElementRef;
  
  form: FormGroup | undefined;
  val: string = ""
  originalType: string = "text";

  constructor(private controlContainer: ControlContainer) { }

  ngOnInit() {
    this.form = <FormGroup>this.controlContainer.control;
    this.originalType = this.type;
  }

  get f() {
    return this.form?.controls;
  }

  get inputClass() {
    var clazz = this.class
    if (this.readonly) return clazz + " form-control-plaintext p-inputtext w-full"
    return clazz + " form-control p-inputtext w-full"
  }

  hasError(): Boolean {
    return this.formControl?.invalid && (this.formControl?.dirty || this.formControl?.touched)
  }

  get error(): string | null {
    var err = null;
    var controlErrors: ValidationErrors | undefined | null = this.formControl?.errors;

    if (controlErrors) {
      Object.keys(controlErrors).forEach(keyError => {
        if (controlErrors![keyError]) {
          switch (keyError) {
            case 'required':
              err = this.requiredError;
              break;
            case 'minlength':
              err = this.minLengthError;
              break;
            case 'pattern':
              err = this.patternError;
              break;
            case 'mismatch':
              err = this.mismatchError;
              break;
            case 'email':
              err = this.emailError;
              break;
            default:
              err = "Invalid"
              break;
          }
        }
      });
    }

    return err;
  }

  onChange: any = () => { }

  onTouch: any = () => { }

  set value(val: string | undefined | null) {
    if (val && this.val !== val) {
      this.val = val
      this.onChange(val)
      this.onTouch(val)
    }
  }

  writeValue(value: any) {
    this.value = value
  }

  registerOnChange(fn: any) {
    this.onChange = fn
  }

  registerOnTouched(fn: any) {
    this.onTouch = fn
  }

  hideShowPassword(event: any) {
    event.preventDefault()
    this.type = (this.type =='text') ? 'password' : 'text'
    this.reveal.nativeElement.blur()
    this.input.nativeElement.focus()
  }
}
