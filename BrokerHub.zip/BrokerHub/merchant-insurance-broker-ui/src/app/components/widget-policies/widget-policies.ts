import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { ToastProvider } from '../../providers/provider-toast';
import { UserService } from '../../services/service-user';
import { SettingsService } from '../../services/service-settings';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { SelectItem } from 'primeng/api';
import { REASON_TOKEN_EXPIRED } from '../../constants';

@Component({
  selector: 'policies',
  templateUrl: './widget-policies.html',
  styleUrls: ['./widget-policies.scss'],
  host: { class: 'width: 100%' },
  standalone: false,
})
export class PoliciesWidget implements OnInit {
  loading = false;
  showAddDialog = false;
  showSearchDialog = false;
  policyReport: any;
  systemPubUrl: string | null = null;

  @Input({ required: true }) user!: any;
  @Input() showBanner: boolean = true;
  @Input() showClient: boolean = false;
  @Input() showHistory: boolean = false;
  @Input() showLeads: boolean = false;
  @Input() showLoyalty: boolean = false;
  @Input() showDelete: boolean = false;
  @Input() showRenewal: boolean = false;
  @Input() showRenewalWhenNoPolicy: boolean = false;
  @Input() showQuote: boolean = false;
  @Input() showIssues: boolean = false;
  @Input() showCompare: boolean = false;
  @Input() showAddPolicy: boolean = false;
  @Input() showClaimsConvictions: boolean = false;
  @Input() showPinkCards: boolean = false;
  @Input() showNotify: boolean = false;
  @Input() showPolicyLink: boolean = false;

  @Output() viewPolicy = new EventEmitter<any>();
  @Output() viewPOI = new EventEmitter<any>();
  @Output() delete = new EventEmitter<any>();

  @Output() editUser = new EventEmitter<any>();
  @Output() addPolicy = new EventEmitter<any>();
  @Output() notifyUser = new EventEmitter<any>();

  provinces: SelectItem[] = [
    { label: 'Alberta', value: 'AB' },
    { label: 'British Columbia', value: 'BC' },
    { label: 'Manitoba', value: 'MB' },
    { label: 'New Brunswick', value: 'NB' },
    { label: 'Newfoundland', value: 'NL' },
    { label: 'Nova Scotia', value: 'NS' },
    { label: 'Ontario', value: 'ON' },
    { label: 'Prince Esward Island', value: 'PE' },
    { label: 'Quebec', value: 'QC' },
    { label: 'Saskatchewan', value: 'SK' },
    { label: 'Northwest Territories', value: 'NT' },
    { label: 'Nunavut', value: 'NU' },
    { label: 'Yukon', value: 'YT' },
  ];

  policySearchForm: any;

  policyNumberForm: any;

  showPinkCard(policy: any) {
    const policyCard = policy?.find((card: any) => card.type === 'policy');
    return policyCard?.downloaded ?? false;
  }

  constructor(
    private userService: UserService,
    private settingsService: SettingsService,
    private formBuilder: FormBuilder,
    private toast: ToastProvider,
  ) {
    this.policySearchForm = this.formBuilder.group({
      first: new FormControl<string>('', [Validators.required]),
      last: new FormControl<string>('', [Validators.required]),
      province: new FormControl<string>('', [Validators.required]),
      postal_code: new FormControl<string>('', [Validators.required]),
      dob: new FormControl<string>('', [Validators.required]),
    });

    this.policyNumberForm = this.formBuilder.group({
      policyNumber: new FormControl<string>('', [Validators.required]),
    });

    var dt = new Date();
    dt.setFullYear(dt.getFullYear() - 25);
    this.policySearchForm.controls['dob'].setValue(this.formatDate(dt));
  }

  ngOnInit() {
    this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
    this.refresh();
  }

  async refresh() {
    try {
      this.loading = true;
      this.policyReport = await this.userService.getUserReport(this.user['id']);
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  getAssets(policy: any): Array<any> {
    var assets: Array<any> = new Array<any>();

    for (let asset of policy) {
      if (asset.type == 'vehicle' || asset.type == 'property') {
        assets.push(asset);
      }
    }
    return assets;
  }

  getPolicyCard(policy: any) {
    var policyCard: any;

    for (let card of policy) {
      if (card.type == 'policy') {
        policyCard = card;
      }
    }
    return policyCard;
  }

  lookupRenewal(policy: any) {
    if (!this.showRenewal) return null;

    var policy_card = this.getPolicyCard(policy);

    if (policy_card == null) return null;

    // We might want to show a renewal when we have one but we haven't received any
    // downloads for the policy yet. In this case we may generally not want to show
    // renewals, but when there is no policy to show we can show the renewal instead.
    // This gives the user something to look at.

    // We don't have a policy and don't want to show renewals under any circumstance.
    if (!this.showRenewal && !(this.showRenewalWhenNoPolicy && (policy == null || !policy.downloaded))) return null;

    var policyNumber = policy_card?.fields?.policy_number;
    var policyCompany = policy_card?.fields?.company_code;
    var policyLob = policy_card?.fields?.lob;

    var renewals = this.policyReport['renewals'];

    for (var renewal of renewals) {
      var renewalPolicyCard = this.getPolicyCard(renewal);
      var renewalPolicyNumber = renewalPolicyCard?.fields?.policy_number;
      var renewalCompany = renewalPolicyCard?.fields?.company_code;
      var renewalLob = renewalPolicyCard?.fields?.lob;

      if (renewalPolicyNumber == policyNumber && renewalLob == policyLob && renewalCompany == policyCompany) {
        return renewal;
      }
    }

    return null;
  }

  onViewPolicy(policy: any) {
    var policyCard = this.getPolicyCard(policy);

    if (policyCard?.id != null) {
      this.viewPolicy.emit(policyCard.id);
    }
  }

  onViewPOI(policy: any) {
    var policyCard = this.getPolicyCard(policy);

    if (policyCard) {
      this.viewPOI.emit(policyCard);
    }
  }

  onDelete(policy: any) {
    var policyCard = this.getPolicyCard(policy);
    if (policyCard) this.delete.emit(policyCard);
  }

  lookupHistory(policy: any) {
    if (!this.showHistory) return null;
    var policy_card = this.getPolicyCard(policy);
    if (policy_card == null) return null;
    return policy_card['history'];
  }

  hasError(formControl: FormControl): Boolean {
    return formControl?.invalid && (formControl?.dirty || formControl?.touched);
  }
}
