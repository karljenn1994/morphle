import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError, Subject, from } from 'rxjs';
import { catchError, switchMap, first } from 'rxjs/operators';
import { AuthenticationService } from '../services/service-authentication';
import * as constants from '../constants';
import { LocaleUtils } from '../utils/utils_locale';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private isRefreshing = false;
  private refreshSubject = new Subject<boolean>();
  private hasLoggedOut = false;

  constructor(private authService: AuthenticationService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const isRefreshRequest = req.url.endsWith('/refresh');
    const requestWithCsrf = this.addHeaders(req, isRefreshRequest);

    return next.handle(requestWithCsrf).pipe(
      catchError((err: HttpErrorResponse) => {
        if ((err.status === 401 || err.status === 419) && !isRefreshRequest) {
          if (!this.isRefreshing) {
            this.isRefreshing = true;
            this.hasLoggedOut = false;
            this.refreshSubject = new Subject<boolean>();

            return from(this.authService.refreshToken()).pipe(
              switchMap(() => {
                this.refreshSubject.next(true);
                this.isRefreshing = false;
                this.refreshSubject.complete();
                return next.handle(this.addHeaders(req, false));
              }),
              catchError((refreshError) => {
                this.refreshSubject.next(false);
                this.isRefreshing = false;
                this.refreshSubject.complete();
                if (!this.hasLoggedOut) {
                  this.hasLoggedOut = true;
                  this.authService.logout();
                }
                return throwError(() => ({
                  code: constants.REASON_TOKEN_EXPIRED,
                  message: 'You have been logged out due to inactivity',
                  severity: 'info',
                }));
              }),
            );
          } else {
            return this.refreshSubject.pipe(
              first((success) => success === true),
              switchMap(() => next.handle(this.addHeaders(req, false))),
              catchError(() => {
                if (!this.hasLoggedOut) {
                  this.hasLoggedOut = true;
                  this.authService.logout();
                }
                return throwError(() => ({
                  code: constants.REASON_TOKEN_EXPIRED,
                  message: 'You have been logged out due to inactivity',
                  severity: 'info',
                }));
              }),
            );
          }
        }
        return throwError(() => err);
      }),
    );
  }

  private addHeaders(request: HttpRequest<any>, isRefreshRequest: boolean): HttpRequest<any> {
    const token = this.getCsrfFromCookie(isRefreshRequest ? 'csrf_refresh_token' : 'csrf_access_token');

    const headers: Record<string, string> = {
      'Accept-Language': this.getAppLocale(), // 👈 use your app's locale
    };

    if (token) {
      headers['X-CSRF-TOKEN'] = token;
    }

    return request.clone({
      withCredentials: true,
      setHeaders: headers,
    });
  }

  private getCsrfFromCookie(name: string): string | null {
    const match = document.cookie.match(new RegExp(`${name}=([^;]+)`));
    return match ? match[1] : null;
  }

  private getAppLocale(): string {
    return LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;
  }
}
