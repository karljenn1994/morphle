import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LayoutService } from '../../layout/service/layout.service';
import { SettingsService } from '../../services/service-settings';
import { ToastProvider } from '../../providers/provider-toast';
import { LocaleUtils } from '../../utils/utils_locale';

@Component({
    selector: 'app-landing',
    templateUrl: './page-landing.html',
    standalone: false
})
export class LandingComponent {
  brokerageName: string | null = null;
  systemPubUrl: string | null = null;
  language: string = LocaleUtils.default;
  
  constructor(
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    public router: Router,
    private toast: ToastProvider
  ) {}

  async ngOnInit() {
    try {    
      this.language = LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;
      this.brokerageName = this.settingsService.getSetting('brokerageName');
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
    }
    catch(error: any) {
      this.toast.show(error);
    }
  }

  get languages() {
    return LocaleUtils.languages;
  }

  switchLanguage(event: any) {
    this.language = event.value;
    LocaleUtils.locale = this.language;
    window.location.href = LocaleUtils.localizeHRef(window.location.href);
  }  
}
