import { Injectable } from '@angular/core'
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate, Router } from '@angular/router'
import { Observable } from 'rxjs'
import { AuthenticationService } from '../services/service-authentication'

@Injectable({
  providedIn: 'root'
})
export class LandingGuard implements CanActivate {
  constructor(private router: Router, private authService: AuthenticationService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    if (this.authService.role == "admin") {
      this.router.navigate(['/admin/portfolio'])
    }
    else if (this.authService.role == "user") {
      this.router.navigate(['/user'])
    }
    else if (this.authService.role == "pending") {
      this.router.navigate(['/auth/pending'])
    }

    return false
  }
}
