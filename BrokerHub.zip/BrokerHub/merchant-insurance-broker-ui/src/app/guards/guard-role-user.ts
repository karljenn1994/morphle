import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { ToastProvider } from '../providers/provider-toast';
import { AuthenticationService } from '../services/service-authentication';

@Injectable({ providedIn: 'root' })
export class UserRoleGuard implements CanActivate {
  constructor(
    private authService: AuthenticationService,
    private toast: ToastProvider,
  ) {}

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree> {
    // If the role is already set, check it immediately
    if (this.authService.role) {
      return this.checkUserRole();
    }

    try {
      // Fetch user details and update role
      await this.authService.updateClaims();
      return this.checkUserRole();
    } catch (error) {
      this.toast.error($localize`:@@Error.PermissionDenied:Permission denied`);
      this.authService.logout();
      return false;
    }
  }

  private checkUserRole(): boolean {
    if (this.authService.role !== 'user' &&this.authService.role !== 'admin') {
      this.toast.error($localize`:@@Error.PermissionDenied:Permission denied`);
      this.authService.logout();
      return false;
    }
    return true;
  }
}
