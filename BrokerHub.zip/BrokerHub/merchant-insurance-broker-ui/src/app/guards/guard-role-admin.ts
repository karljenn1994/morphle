import { Injectable } from '@angular/core';
import { UrlTree, CanActivate } from '@angular/router';
import { AuthenticationService } from '../services/service-authentication';
import { ToastProvider } from '../providers/provider-toast';

@Injectable({ providedIn: 'root' })
export class AdminRoleGuard implements CanActivate {
  constructor(
    private authService: AuthenticationService,
    private toast: ToastProvider,
  ) {}

  async canActivate(): Promise<boolean | UrlTree> {
    // If the role is already set, check it immediately
    if (this.authService.role) {
      return this.checkAdminRole();
    }

    try {
      // Fetch user details and update role
      await this.authService.updateClaims();
      return this.checkAdminRole();
    } catch (error) {
      this.toast.error($localize`:@@Error.PermissionDenied:Permission denied`);
      this.authService.logout();
      return false;
    }
  }

  private checkAdminRole(): boolean {
    if (this.authService.role !== 'admin') {
      this.toast.error($localize`:@@Error.PermissionDenied:Permission denied`);
      this.authService.logout();
      return false;
    }
    return true;
  }
}
