import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, AbstractControlOptions, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../services/service-authentication';
import { MustMatch } from '../../validators/validator-must-match';
import { ToastProvider } from '../../providers/provider-toast';
import { LayoutService } from '../../layout/service/layout.service';
import { SettingsService } from '../../services/service-settings';
import { LocaleUtils } from '../../utils/utils_locale';

@Component({
    selector: 'user-set-password-page',
    templateUrl: './page-user-set-password.html',
    styleUrls: ['./page-user-set-password.scss'],
    standalone: false
})
export class UserSetPasswordPage implements OnInit {
  loading = false;
  resetCode: string | null = null;
  brokerageName: string | null = null;
  systemPubUrl: string | null = null;
  language: string = LocaleUtils.default;
  form: any;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthenticationService,
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group(
      {
        password: new FormControl<string>('', [
          Validators.required,
          // Minimum eight characters, at least one letter,
          // one number and one special character
          Validators.pattern('^(?=.*[A-Z]).{8,}$'),
        ]),
        confirmPassword: new FormControl<string>('', [Validators.required]),
      },
      {
        validator: MustMatch('password', 'confirmPassword'),
      } as AbstractControlOptions
    );    
  }

  async ngOnInit() {
    try {
      this.loading = true;
      this.language = LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;
      this.brokerageName = this.settingsService.getSetting('brokerageName');
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
      this.resetCode = this.route.snapshot.paramMap.get('reset_code');

      if (this.resetCode == null) {
        this.router.navigate(['/auth/login']);
      }

      let valid = await this.authService.validateResetCode(this?.resetCode!);

      if (!valid) {
        this.router.navigate(['/auth/login']);
      }
    } catch (error: any) {
      this.router.navigate(['/auth/login']);
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  get f() {
    return this.form?.controls;
  }

  get languages() {
    return LocaleUtils.languages;
  }

  async onSubmit() {
    try {
      this.loading = true;

      // stop here if form is invalid
      if (this.form?.invalid) {
        return;
      }

      var password: string | null = this.f?.['password'].value;

      if (password && this.resetCode != null) {
        await this.authService.reset(this?.resetCode, password);
        this.router.navigate(['/main']);
        this.toast.success($localize`Password reset`);
      }
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  onClose() {
    this.router.navigate(['/main']);
  }

  switchLanguage(event: any) {
    this.language = event.value;
    LocaleUtils.locale = this.language;
    window.location.href = LocaleUtils.localizeHRef(window.location.href);
  }
}
