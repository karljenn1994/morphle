import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ComponentsModule } from '../components/module-components';
import { ToastProvider } from '../providers/provider-toast';
import { AuthRoutingModule } from './auth-routing.module';
import { ForgotPage } from './page-forgot/page-forgot';
import { UserLoginPage } from './page-user-login/page-user-login';
import { UserSetPasswordPage } from './page-user-set-password/page-user-set-password';
import { UserAccessPage } from './page-user-access/page-user-access';
import { SelectModule } from 'primeng/select';

@NgModule({
  declarations: [
    UserAccessPage,
    UserSetPasswordPage,
    UserLoginPage,
    ForgotPage,
  ],
  imports: [
    CommonModule,
    ComponentsModule,
    SelectModule,
    AuthRoutingModule,
    FormsModule,
    ProgressSpinnerModule,
    ReactiveFormsModule,
    PasswordModule,
    InputTextModule,
    ButtonModule,
  ],
  providers: [ToastProvider],
})
export class AuthModule {}
