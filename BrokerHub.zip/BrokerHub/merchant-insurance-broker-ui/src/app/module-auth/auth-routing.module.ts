import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserLoginPage } from './page-user-login/page-user-login';
import { UserSetPasswordPage } from './page-user-set-password/page-user-set-password';
import { ForgotPage } from './page-forgot/page-forgot';
import { UserAccessPage } from './page-user-access/page-user-access';

const routes: Routes = [
  {
    path: '',
    component: UserLoginPage,
  },  
  {
    path: 'access',
    component: UserAccessPage,
  },     
  {
    path: 'access/token/:token',
    component: UserAccessPage,
  },    
  {
    path: 'access/reset_code/:reset_code',
    component: UserAccessPage,
  },    
  {
    path: 'access/token/:token/reset_code/:reset_code',
    component: UserAccessPage,
  },  
  {
    path: 'login',
    component: UserLoginPage,
  },
  {
    path: 'forgot',
    component: ForgotPage,
  },  
  {
    path: 'set-password/:reset_code',
    component: UserSetPasswordPage,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
