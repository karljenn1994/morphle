import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/service-authentication';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { ToastProvider } from '../../providers/provider-toast';
import { LayoutService } from '../../layout/service/layout.service';
import { SettingsService } from '../../services/service-settings';
import { LocaleUtils } from '../../utils/utils_locale';

@Component({
    selector: 'user-login-page',
    templateUrl: './page-user-login.html',
    styleUrls: ['./page-user-login.scss'],
    standalone: false
})
export class UserLoginPage implements OnInit {
  loading = false;
  form: any;
  brokerageName: string | null = null;
  systemPubUrl: string | null = null;
  language: string = LocaleUtils.default;

  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group({
      email: new FormControl<string>(localStorage.getItem('email') ?? '', [
        Validators.required,
        Validators.email,
        Validators.minLength(5),
        Validators.maxLength(255),
      ]),
      password: new FormControl<string>('', [
        Validators.required,
        // Minimum eight characters, at least one letter,
        // one number and one special character
        Validators.pattern('^(?=.*[A-Z]).{8,}$'),
      ]),
    });
  }

  async ngOnInit() {
    try {
      this.loading = true;
      this.language = LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;
      this.brokerageName = this.settingsService.getSetting('brokerageName');
      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
    } catch (error: any) {
      this.toast.show(error);
    } finally {
      this.loading = false;
    }
  }

  get f() {
    return this.form?.controls;
  }

  get languages() {
    return LocaleUtils.languages;
  }

  openRegistration(event: any) {
    event.preventDefault();
    this.router.navigate(['/auth/register']);
  }

  openForgot(event: any) {
    event.preventDefault();
    this.router.navigate(['/auth/forgot']);
  }

  onSubmit() {
    // stop here if form is invalid
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.login();
  }

  async login() {
    try {
      this.loading = true;
      var email: string | undefined | null = this.form.get('email')?.value;
      var password: string | undefined | null = this.form.get('password')?.value;

      if (email && password) {
        await this.authService.authenticate(email, password);
        this.router.navigate(['/main']);
      }
    } catch (error: any) {
      this.toast.show(error);
      this.toast.error("Testing 1");
      this.toast.error("Testing 2");
      this.toast.error("Testing 3");
      this.toast.error("Testing 4");
    } finally {
      this.loading = false;
    }
  }

  switchLanguage(event: any) {
    this.language = event.value;
    LocaleUtils.locale = this.language;
    window.location.href = LocaleUtils.localizeHRef(window.location.href);
  }
}
