import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  AbstractControlOptions,
  FormControl,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../services/service-authentication';
import { MustMatch } from '../../validators/validator-must-match';
import { ToastProvider } from '../../providers/provider-toast';
import { LayoutService } from '../../layout/service/layout.service';
import { SettingsService } from '../../services/service-settings';
import { LocaleUtils } from '../../utils/utils_locale';
import { RoutingService } from '../../services/service-routing';

@Component({
    selector: 'user-access',
    templateUrl: './page-user-access.html',
    styleUrls: ['./page-user-access.scss'],
    standalone: false
})
export class UserAccessPage implements OnInit {
  loading = false;
  createForm: any;
  loginForm: any;
  systemPubUrl: string | null = null;
  brokerageName: string | null = null;
  language: string = LocaleUtils.default;

  token: string | null = null;
  resetCode: string | null = null;
  triggerEvent: string | null = null;
  tokenValid: boolean = false;
  resetCodeValid: boolean = false;


  constructor(
    public routing: RoutingService,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthenticationService,
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private settingsService: SettingsService,
    private toast: ToastProvider
  ) {
    this.createForm = this.formBuilder.group(
      {
        password: new FormControl<string>('', [
          Validators.required,
          // Minimum eight characters, at least one letter,
          // one number and one special character
          Validators.pattern('^(?=.*[A-Z]).{8,}$'),
        ]),
        confirmPassword: new FormControl<string>('', [Validators.required]),
      },
      {
        validator: MustMatch('password', 'confirmPassword'),
      } as AbstractControlOptions
    );
  
    this.loginForm = this.formBuilder.group({
      email: new FormControl<string>(localStorage.getItem('email') ?? '', [
        Validators.required,
        Validators.email,
        Validators.minLength(5),
        Validators.maxLength(255),
      ]),
      password: new FormControl<string>('', [
        Validators.required,
        // Minimum eight characters, at least one letter,
        // one number and one special character
        Validators.pattern('^(?=.*[A-Z]).{8,}$'),
      ]),
    });
  }

  get languages() {
    return LocaleUtils.languages;
  }

  async ngOnInit() {
    try {
      this.language =
        LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;

      this.loading = true;
      this.token = this.route.snapshot.paramMap.get('token');
      this.resetCode = this.route.snapshot.paramMap.get('reset_code');
      this.triggerEvent = this.routing.getQueryParameters()?.get('trigger_event') ?? null;

      this.systemPubUrl = this.settingsService.getSetting('systemPubUrl');
      this.brokerageName = this.settingsService.getSetting('brokerageName');

      if (this.token || this.resetCode) {
        var result = await this.authService.validateIdentityTokenAndResetCode(
          this.token!,
          this.resetCode!
        );

        this.tokenValid = result.token_valid;
        this.resetCodeValid = result.reset_code_valid;
      }
    } catch (error: any) {
      this.toast.error(error.message ?? $localize`An error occurred`);
      this.router.navigate(['/auth/login']);
    } finally {
      this.loading = false;
    }
  }

  async onCreate() {
    try {
      this.loading = true;

      if (this.createForm.invalid) {
        Object.keys(this.createForm.controls).forEach((field) => {
          const control = this.createForm.get(field);
          control?.markAsTouched({ onlySelf: true });
        });
      } else {
        var password: string | null =
          this.createForm.controls?.['password'].value;

        if (password && this.resetCode != null) {
          await this.authService.reset(this?.resetCode, password);
          this.router.navigate(['/main']);
          this.toast.success($localize`Success`);
        }
      }
    } catch (error: any) {
      this.toast.error(error.message ?? $localize`An error occurred`);
    } finally {
      this.loading = false;
    }
  }

  async onLogin() {
    try {
      this.loading = true;

      if (this.loginForm.invalid) {
        Object.keys(this.loginForm.controls).forEach((field) => {
          const control = this.loginForm.get(field);
          control?.markAsTouched({ onlySelf: true });
        });
      } else {
        var email: string | null = this.loginForm.controls?.['email'].value;
        var password: string | null =
          this.loginForm.controls?.['password'].value;

        if (email && password) {
          await this.authService.authenticate(email, password);

          if (this.triggerEvent) {
            this.router.navigate([
              '/' + this.authService.role + '/' + this.triggerEvent,
            ]);
          } else {
            this.router.navigate(['/main']);
          }
        }
      }
    } catch (error: any) {
      this.toast.error(error.message ?? $localize`An error occurred`);
    } finally {
      this.loading = false;
    }
  }

  async onContinue() {
    try {
      this.loading = true;
      await this.authService.authenticateAsGuest(this?.token!);
      this.router.navigate(['/main']);
    } catch (error: any) {
      this.toast.error(error.message ?? $localize`An error occurred`);
    } finally {
      this.loading = false;
    }
  }

  async onResend() {
    try {
      this.loading = true;
      await this.authService.resendIdentityToken(this?.token!);
      this.toast.success($localize`Check your email for the new link`);
    } catch (error: any) {
      this.toast.error(error.message ?? $localize`An error occurred`);
    } finally {
      this.loading = false;
    }
  }

  switchLanguage(event: any) {
    this.language = event.value;
    LocaleUtils.locale = this.language;
    window.location.href = LocaleUtils.localizeHRef(window.location.href);
  }
}
