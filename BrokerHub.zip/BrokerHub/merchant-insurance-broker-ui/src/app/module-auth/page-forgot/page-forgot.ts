import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {
  Validators,
  FormBuilder,
  FormControl,
} from '@angular/forms';
import { AuthenticationService } from '../../services/service-authentication';
import { Router } from '@angular/router';
import { ToastProvider } from '../../providers/provider-toast';
import { LayoutService } from '../../layout/service/layout.service';
import { SettingsService } from '../../services/service-settings';
import { LocaleUtils } from '../../utils/utils_locale';

@Component({
    selector: 'forgot-page',
    templateUrl: './page-forgot.html',
    styleUrls: ['./page-forgot.scss'],
    standalone: false
})
export class ForgotPage implements OnInit {
  loading = false;
  brokerageName: string | null = null;
  systemPubUrl: string | null = null;
  language: string = LocaleUtils.default;
  form: any = null;

  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private formBuilder: FormBuilder,
    public layoutService: LayoutService,
    private settingsService: SettingsService,   
    private toast: ToastProvider
  ) {
    this.form = this.formBuilder.group({
      email: new FormControl<string>('', [
        Validators.required,
        Validators.email,
        Validators.minLength(5),
        Validators.maxLength(255),
      ]),
    });    
  }

  async ngOnInit() {
    try {
      this.language = LocaleUtils.localeFromHRef(window.location.href) ?? LocaleUtils.default;
      this.brokerageName = this.settingsService.getSetting("brokerageName");
      this.systemPubUrl = this.settingsService.getSetting("systemPubUrl");      
    }
    catch(error: any) {
      this.toast.show(error);
    }
  }

  get f() {
    return this.form?.controls;
  }

  get languages() {
    return LocaleUtils.languages;
  }
  
  onSubmit() {
    // stop here if form is invalid
    if (this.form.invalid) {
      Object.keys(this.form.controls).forEach((field) => {
        const control = this.form.get(field);
        control?.markAsTouched({ onlySelf: true });
      });

      return;
    }

    this.forgot();
  }

  async forgot() {
    try {
      this.loading = true;
      var email: string | undefined | null = this.form?.get('email')?.value;

      if (email) {
        await this.authService.forgot(email);
        this.toast.success($localize`Please check your email to set your password`);
        this.router.navigate(['/auth/login']);
      }
    }
    catch(error: any) {
      this.toast.show(error);
    }
    finally {
      this.loading = false;
    }
  }

  onClose() {
    this.router.navigate(['auth/login']);
  }

  switchLanguage(event: any) {
    this.language = event.value;
    LocaleUtils.locale = this.language;
    window.location.href = LocaleUtils.localizeHRef(window.location.href);
  }  
}
