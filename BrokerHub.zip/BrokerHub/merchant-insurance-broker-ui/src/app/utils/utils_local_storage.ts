import { LocaleUtils } from "./utils_locale";

export class LocalStorageUtils {
    static clear() {
        var locale = LocaleUtils.locale
        localStorage.clear();
        LocaleUtils.locale = locale;
    }
}