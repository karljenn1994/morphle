import { environment } from '../../environments/environment';

export class LocaleUtils {
  static default: string = 'en';
  static supportedLocales: string[] = ['en'];
  static languages: { label: string; value: string }[] = [
    { label: 'English', value: 'en' }, // fallback
  ];

  private static readonly languageLabels: Record<string, string> = {
    'en': 'English',
    'fr': 'Français',
    'es': 'Español',
    'zh-CN': '简体中文', // Simplified Chinese
    'zh-TW': '繁體中文', // Traditional Chinese
  };
  
  static get locale(): string {
    return localStorage.getItem('locale') || LocaleUtils.default;
  }

  static set locale(l: string) {
    localStorage.setItem('locale', l);
  }

  static setSupportedLocales(locales: string[]): void {
    this.supportedLocales = locales;

    this.languages = locales.map((value) => ({
      value,
      label: this.languageLabels[value] || value,
    }));
  }

  static localizeHRef(href: string): string {
    if (!environment.production) return href;

    const url = new URL(href);
    const preferredLocale = LocaleUtils.locale;
    const path = url.pathname;

    // 🛑 Prevent recursion: if path already starts with locale, leave it alone
    if (path === `/${preferredLocale}` || path.startsWith(`/${preferredLocale}/`)) {
      return href;
    }

    // Otherwise, prepend preferred locale and return
    const pathName = LocaleUtils.pathNameFromHRef(href);
    const query = url.search;

    return `${url.origin}/${preferredLocale}/${pathName}${query}`;
  }

  static hostNameFromHRef(href: string): string {
    const u = new URL(href);
    return `${u.protocol}//${u.host}`;
  }

  static localeFromHRef(href: string): string | null {
    if (!environment.production) return LocaleUtils.default;

    const pathLocale = new URL(href).pathname.split('/')[1];
    return this.supportedLocales.includes(pathLocale) ? pathLocale : null;
  }

  static pathNameFromHRef(href: string): string {
    const url = new URL(href);
    let pathName = url.pathname;
    const currentLocale = pathName.split('/')[1];

    if (this.supportedLocales.includes(currentLocale)) {
      pathName = pathName.split('/').slice(2).join('/');
    }

    return pathName.startsWith('/') ? pathName.substring(1) : pathName;
  }
}
