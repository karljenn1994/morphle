export class StringUtils {
  static capitalize(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  /**
   * Converts a string to Title Case (capitalizes first letter of each word).
   * Examples:
   *   "first name" → "First Name"
   *   "user_id"    → "User Id"
   *   "USER NAME"  → "User Name"
   */
  static toTitleCase(str: string): string {
    if (!str) return '';

    return str
      .toLowerCase()
      .replace(/[_\s]+/g, ' ') // Normalize separators to space
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }  
}
