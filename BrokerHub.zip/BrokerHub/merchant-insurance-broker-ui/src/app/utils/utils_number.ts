export class NumberUtils {
  static formatPercent(percentage: number | null, showSign = true, showZero = false) {
    if (!percentage && percentage != 0) return '';

    if (percentage > 0 || showZero) {
      var p = percentage.toFixed(2);
      if (showSign && percentage > 0) p = '+' + p;

      p += '%';
      return p;
    }

    return percentage.toFixed(2) + '%';
  }

  static formatDollarAmount(amount: any | null): string {
    let formattedAmount: string = '';

    if (amount != null) {
      if (typeof amount == 'string') {
        const premiumAmount: number = parseFloat(amount);

        if (premiumAmount != null) {
          let numFormat: Intl.NumberFormat;

          if (amount.includes('.') && !amount.endsWith('00') && !amount.endsWith('0')) {
            numFormat = new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
              minimumFractionDigits: 2,
            });
          } else {
            numFormat = new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
              minimumFractionDigits: 0,
            });
          }

          // In the case of debit/credit we might have a -/+ on the end of the value. Save it for later.
          const sign: string = amount[amount.length - 1];
          formattedAmount = numFormat.format(premiumAmount);

          // Only want to show the sign if it is a minus.
          if (sign === '-') {
            formattedAmount = '(' + formattedAmount + ')';
          }
        }
      } else {
        let numFormat: Intl.NumberFormat;
        numFormat = new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 0,
        });

        if (amount < 0) {
          formattedAmount = `(${numFormat.format(Math.abs(amount))})`;
        } else {
          formattedAmount = numFormat.format(amount);
        }
      }
    }

    return formattedAmount;
  }
}
