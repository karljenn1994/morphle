import { ApplicationConfig, importProvidersFrom, provideAppInitializer, inject } from '@angular/core';
import { HTTP_INTERCEPTORS, provideHttpClient, withFetch, withInterceptorsFromDi } from '@angular/common/http';
import { provideRouter, withEnabledBlockingInitialNavigation, withInMemoryScrolling } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations';

import { DatePipe } from '@angular/common';
import { MessageService } from 'primeng/api';
import { providePrimeNG } from 'primeng/config';
import Lara from '@primeng/themes/lara';
import { definePreset } from '@primeng/themes';

import { ToastProvider } from './providers/provider-toast';
import { RefreshService } from './services/service-refresh';
import { AuthInterceptor } from './interceptors/interceptor-auth';
import { SettingsService } from './services/service-settings';
import { environment } from '../environments/environment';
import { LocaleUtils } from './utils/utils_locale';
import { appRoutes } from './app.routes';

// PrimeNG theme customization
const CustomLaraBlue = definePreset(Lara, {
  semantic: {
    primary: {
      50: '{blue.50}',
      100: '{blue.100}',
      200: '{blue.200}',
      300: '{blue.300}',
      400: '{blue.400}',
      500: '{blue.500}',
      600: '{blue.600}',
      700: '{blue.700}',
      800: '{blue.800}',
      900: '{blue.900}',
      950: '{blue.950}',
    },
    colorScheme: {
      light: {
        primary: { color: '{blue.500}', hoverColor: '{blue.600}', activeColor: '{blue.700}' },
      },
      dark: {
        primary: { color: '{blue.400}', hoverColor: '{blue.300}', activeColor: '{blue.200}' },
      },
    },
  },
});

export const appConfig: ApplicationConfig = {
  providers: [
    // Router
    provideRouter(
      appRoutes,
      withInMemoryScrolling({ anchorScrolling: 'enabled', scrollPositionRestoration: 'enabled' }),
      withEnabledBlockingInitialNavigation(),
    ),

    // HTTP
    provideHttpClient(withFetch(), withInterceptorsFromDi()),

    // Animations (needed by PrimeNG toast, etc.)
    provideAnimations(),

    // PrimeNG config
    providePrimeNG({
      theme: {
        preset: CustomLaraBlue,
        options: { darkModeSelector: '.app-dark' },
      },
    }),

    // Core Angular services
    DatePipe,

    // App services
    MessageService,
    RefreshService,
    ToastProvider,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },

    // Initializer: load settings before app renders
    provideAppInitializer(async () => {
      const settings = inject(SettingsService);
      await settings.loadSettings(null, true);

      const raw = settings.getSetting('systemSupportedLocales');
      const supported = raw?.split(',').map((l: string) => l.trim()) ?? ['en'];
      LocaleUtils.setSupportedLocales(supported);

      if (environment.production) {
        const preferred = LocaleUtils.locale;
        const current = LocaleUtils.localeFromHRef(window.location.href);
        const redirectUrl = LocaleUtils.localizeHRef(window.location.href);

        if (preferred !== current && redirectUrl !== window.location.href) {
          window.location.href = redirectUrl;
        }
      }
    }),
  ],
};
