import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class TasksService {
  private static API_PATH = '/broker-api/web/v1/ui/tasks';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async runNow(taskName: string): Promise<void> {
    await this.handleRequest(
      this.http.put<void>(
        `${environment.apiURL}${TasksService.API_PATH}/run`,
        { name: taskName },
        { withCredentials: true }
      )
    );
  }

  async update(
    taskName: string,
    status: string,
    minute: string,
    hour: string,
    daysOfWeek: string[],
    monthsOfYear: string[]
  ): Promise<void> {
    await this.handleRequest(
      this.http.put<void>(
        `${environment.apiURL}${TasksService.API_PATH}`,
        {
          name: taskName,
          status: status,
          minute: minute,
          hour: hour,
          days_of_week: daysOfWeek.join(','),
          months_of_year: monthsOfYear.join(','),
        },
        { withCredentials: true }
      )
    );
  }

  async getTask(taskName: string): Promise<Map<string, string | string[]>> {
    const response = await this.handleRequest<any>(
      this.http.get(`${environment.apiURL}${TasksService.API_PATH}/${taskName}`, { withCredentials: true })
    );
    return new Map<string, string | string[]>(Object.entries(response ?? {}));
  }
}
