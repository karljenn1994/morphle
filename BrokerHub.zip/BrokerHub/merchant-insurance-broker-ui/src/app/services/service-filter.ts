import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FilterService {
  private _context: string | null = null;
  index: number = 0;
  rowsPerPage: number = 10;
  values: any[] | null = null;

  clear() {
    this.index = 0;
    this.values = null;
  }

  set context(c : string | null) {
    if (c != this._context) {
      this.clear();
    }
    
    this._context = c;
  }

  get page() : number { 
      return Math.floor(this.index / this.rowsPerPage);
  }
}
