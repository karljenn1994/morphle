import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as constants from '../constants';
import { environment } from '../../environments/environment';
import { firstValueFrom } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ApplePassService {
  private static API_PATH = '/broker-api/web/v1/ui/pass';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    try {
      return await firstValueFrom(observable.pipe(catchError(this.handleError)));
    } catch (error) {
      throw this.handleError(error);
    }
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getPinkCard(vehicle: any): Promise<Blob> {
    return this.handleRequest(
      this.http.post(`${environment.apiURL}${ApplePassService.API_PATH}/apple/liability/create`, vehicle, {
        withCredentials: true,
        responseType: 'blob',
      }),
    );
  }
}
