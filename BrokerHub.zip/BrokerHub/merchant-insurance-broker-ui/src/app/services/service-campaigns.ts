import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CampaignsService {
  private static API_PATH = '/broker-api/web/v1/ui/campaigns';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, error: $localize`An unknown error occurred` };
  }

  async listTemplates(templateTypes: string[] | string | null): Promise<any> {
    let url = `${environment.apiURL}${CampaignsService.API_PATH}/templates`;

    if (templateTypes) {
      if (Array.isArray(templateTypes) && templateTypes.length > 0) {
        url += '?type=' + templateTypes.map(encodeURIComponent).join('&type=');
      } else {
        url += '?type=' + templateTypes;
      }
    }

    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async loadTemplate(templateId: string): Promise<any> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/template/${encodeURIComponent(templateId)}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async upsertTemplate(
    id: string,
    name: string,
    description: string,
    templateType: string,
    contents: any,
  ): Promise<any> {
    // this.handleAuth();
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/template/${encodeURIComponent(id)}`;
    return this.handleRequest(
      this.http.post(url, { name, description, template_type: templateType, contents }, { withCredentials: true }),
    );
  }

  async deleteTemplate(templateId: string): Promise<void> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/template/${encodeURIComponent(templateId)}`;
    await this.handleRequest(this.http.delete(url, { withCredentials: true }));
  }

  async totalRecipients(campaign_id: string): Promise<any> {
    // this.handleAuth();
    let url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${campaign_id}/recipients/total`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async listRecipients(
    campaign_id: string,
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
  ): Promise<any[]> {
    let url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${campaign_id}/recipients`;

    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    url += `?${params.toString()}`;

    return this.handleRequest(
      this.http.get<any[]>(url, {
        withCredentials: true,
      }),
    );
  }

  async totalCampaigns(campaignTypes: string[] | string | null, active?: boolean): Promise<any> {
    let url = `${environment.apiURL}${CampaignsService.API_PATH}/total`;
    const params: string[] = [];

    if (campaignTypes) {
      if (Array.isArray(campaignTypes)) {
        params.push(...campaignTypes.map((type) => `type=${encodeURIComponent(type)}`));
      } else {
        params.push(`type=${encodeURIComponent(campaignTypes)}`);
      }
    }

    if (active !== undefined) {
      params.push(`active=${active}`);
    }

    if (params.length > 0) {
      url += '?' + params.join('&');
    }

    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async listCampaigns(
    campaignTypes: string[] | string | null,
    rowsPerPage: number | null,
    page: number | null,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
    active?: boolean,
  ): Promise<any> {
    let url = `${environment.apiURL}${CampaignsService.API_PATH}`;
    const queryParams = new URLSearchParams();

    if (campaignTypes) {
      if (Array.isArray(campaignTypes)) {
        campaignTypes.forEach((type) => queryParams.append('type', encodeURIComponent(type)));
      } else {
        queryParams.append('type', encodeURIComponent(campaignTypes));
      }
    }

    if (rowsPerPage !== null && rowsPerPage !== undefined) {
      queryParams.append('rows_per_page', rowsPerPage.toString());
    }

    if (page !== null && page !== undefined) {
      queryParams.append('page', page.toString());
    }

    if (sort && sortDirection) {
      queryParams.append('sort', sort);
      queryParams.append('sort_direction', sortDirection === '1' ? 'desc' : 'asc');
    }

    if (search) {
      queryParams.append('search', search);
    }

    if (active !== undefined) {
      queryParams.append('active', String(active));
    }

    url += `?${queryParams.toString()}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async loadCampaign(campaignId: string): Promise<any> {
    // this.handleAuth();
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async loadCampaignResults(campaignId: string): Promise<any> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}/results`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async lists(campaignType: string | null): Promise<any> {
    let url = `${environment.apiURL}${CampaignsService.API_PATH}/lists`;
    if (campaignType) url += `?type=${encodeURIComponent(campaignType)}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async updateCampaignTemplate(campaignId: string, templateId: string): Promise<any> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}/template`;
    return this.handleRequest(this.http.patch(url, { message_id: templateId }, { withCredentials: true }));
  }

  async activateCampaign(campaignId: string, active: boolean): Promise<any> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}/activate`;
    return this.handleRequest(this.http.patch(url, { active }, { withCredentials: true }));
  }

  async upsertCampaign(
    campaignId: string,
    active: boolean,
    approval: boolean,
    marketing: boolean,
    campaignType: string,
    templateId: string,
    formId: string,
    name: string,
    description: string,
    replyTo: string,
    scheduled: boolean,
    trigger: string | null,
    rules: any,
  ): Promise<any> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}`;
    return this.handleRequest(
      this.http.post(
        url,
        {
          active,
          approval,
          marketing,
          campaign_type: campaignType,
          template_id: templateId,
          form_id: formId,
          name,
          description,
          reply_to: replyTo,
          scheduled,
          trigger,
          rules,
        },
        { withCredentials: true },
      ),
    );
  }

  async runCampaign(
    campaignId: string,
    userId: string | null,
    policyId: string | null,
    dryrun: boolean,
    notifyNow: boolean = false,
  ): Promise<any> {
    let url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}`;
    if (policyId) url += `/policy_id/${encodeURIComponent(policyId)}`;
    if (userId) url += `/user_id/${encodeURIComponent(userId)}`;
    url += `/run?dryrun=${dryrun}&notify_now=${notifyNow}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async sendTestEmail(type: string, email: string, subject: string, body: string): Promise<any> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/send-test-email/${encodeURIComponent(email)}`;
    return this.handleRequest(this.http.put(url, { type, subject, body }, { withCredentials: true }));
  }

  async deleteCampaign(campaignId: string): Promise<void> {
    const url = `${environment.apiURL}${CampaignsService.API_PATH}/campaign/${encodeURIComponent(campaignId)}`;
    await this.handleRequest(this.http.delete(url, { withCredentials: true }));
  }
}
