import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as constants from '../constants';
import { environment } from '../../environments/environment';
import { firstValueFrom } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private static API_PATH = '/broker-api/web/v1/ui/admin';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    try {
      return await firstValueFrom(observable.pipe(catchError(this.handleError)));
    } catch (error) {
      throw this.handleError(error);
    }
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getCounters(): Promise<any> {
    return this.handleRequest(
      this.http.get(`${environment.apiURL}${AdminService.API_PATH}/counters`, { withCredentials: true })
    );
  }

  async totalUsers(role: string | null = null): Promise<number> {
    const url = new URL(`${environment.apiURL}${AdminService.API_PATH}/users/total`);
    if (role) url.searchParams.append('role', role);

    return this.handleRequest(this.http.get<number>(url.toString(), { withCredentials: true }));
  }

  async readUser(user_id: string): Promise<any> {
    return this.handleRequest(
      this.http.get(`${environment.apiURL}${AdminService.API_PATH}/user_id/${user_id}`, { withCredentials: true })
    );
  }

  async listUsers(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
    role: string | null,
    status: string | null
  ): Promise<any[]> {

    const queryParams = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      sort: sort ?? 'leads',
      sort_direction: sortDirection == '1' ? 'desc' : 'asc',
      ...(search && { search }),
      ...(role && { role }),
      ...(status && { status }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${AdminService.API_PATH}/users?${queryParams}`, {
        withCredentials: true,
      })
    );
  }

  async addUser(
    email: string,
    account_name: string | null,
    first: string | null,
    last: string | null,
    is_admin: boolean,
    policy_id: string | null,
  ): Promise<void> {
    
    return this.handleRequest(
      this.http.post<void>(
        `${environment.apiURL}${AdminService.API_PATH}/user/notify/false`,
        {
          email,
          account_name,
          first,
          last,
          is_admin,
          policy_id,
        },
        { withCredentials: true }
      )
    );
  }

  async updateUser(
    user_id: string,
    email: string,
    account_name: string | null,
    first: string | null,
    last: string | null,
    is_admin: boolean
  ): Promise<any> {
    return this.handleRequest(
      this.http.put(
        `${environment.apiURL}${AdminService.API_PATH}/user`,
        {
          user_id,
          email,
          account_name,
          first,
          last,
          is_admin,
        },
        { withCredentials: true }
      )
    );
  }

  async inviteUser(id: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${AdminService.API_PATH}/invite/${id}`, { withCredentials: true })
    );
  }

  async resendNotification(notifier_recipient_id: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${AdminService.API_PATH}/resend_notification/${notifier_recipient_id}`, { withCredentials: true })
    );
  }

  async deleteUser(id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${AdminService.API_PATH}/user/${id}`, { withCredentials: true })
    );
  }

  async updateStatus(id: string, status: string): Promise<void> {
    return this.handleRequest(
      this.http.put<void>(`${environment.apiURL}/v1/users/${id}/status`, { status }, { withCredentials: true })
    );
  }

  async updateRole(id: string, role: string): Promise<void> {
    return this.handleRequest(
      this.http.put<void>(`${environment.apiURL}/v1/users/${id}/role`, { role }, { withCredentials: true })
    );
  }

  async updateTask(taskName: string, status: string, time: Date): Promise<any> {
    return this.handleRequest(
      this.http.put(
        `${environment.apiURL}${AdminService.API_PATH}/task`,
        { name: taskName, status, time },
        { withCredentials: true }
      )
    );
  }

  async listCompanies(): Promise<any[]> {
    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${AdminService.API_PATH}/companies`, { withCredentials: true })
    );
  }
}
