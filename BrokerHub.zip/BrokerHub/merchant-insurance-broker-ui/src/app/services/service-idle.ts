import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, interval, Subscription } from 'rxjs';
import { AuthenticationService } from './service-authentication';
import { SettingsService } from './service-settings';

@Injectable({
  providedIn: 'root',
})
export class IdleService {
  private idleTimeout = 900000; // 15 minutes default
  private timeoutId: any;
  private countdownSubscription: Subscription | null = null;
  private lastActivityTime = Date.now();

  public idleTimeRemaining$ = new BehaviorSubject<number>(0);

  constructor(
    private authService: AuthenticationService,
    private settingsService: SettingsService,
    private router: Router,
    private ngZone: NgZone,
  ) {
    const idleStr = this.settingsService.getSetting('systemIdleTimeout');
    if (idleStr) {
      const parsed = parseInt(idleStr, 10);
      if (!isNaN(parsed) && parsed > 0) {
        this.idleTimeout = parsed * 1000;
      }
    }
    this.startWatching();
  }

  /**
   * Starts watching for user activity.
   */
  startWatching(): void {
    this.resetTimer();
    this.addEventListeners();
  }

  /**
   * Adds event listeners for user activity.
   */
  private addEventListeners(): void {
    ['mousemove', 'keydown', 'click', 'scroll'].forEach((event) => {
      document.addEventListener(event, () => this.resetTimer());
    });
  }

  /**
   * Resets the logout timer and starts countdown.
   */
  private resetTimer(): void {
    clearTimeout(this.timeoutId);
    this.lastActivityTime = Date.now();
    this.timeoutId = setTimeout(() => this.handleLogout(), this.idleTimeout);
    this.startCountdown();
  }

  /**
   * Starts the countdown observable that emits remaining time in seconds.
   */
  private startCountdown(): void {
    if (this.countdownSubscription) {
      this.countdownSubscription.unsubscribe();
    }

    this.countdownSubscription = interval(1000).subscribe(() => {
      const elapsed = Date.now() - this.lastActivityTime;
      const remaining = Math.max(0, this.idleTimeout - elapsed);
      this.idleTimeRemaining$.next(Math.floor(remaining / 1000));
    });
  }

  /**
   * Logs the user out after inactivity.
   */
  private handleLogout(): void {
    this.idleTimeRemaining$.next(0);

    if (this.countdownSubscription) {
      this.countdownSubscription.unsubscribe();
      this.countdownSubscription = null;
    }

    this.ngZone.run(() => {
      this.authService.logout();
    });
  }
}
