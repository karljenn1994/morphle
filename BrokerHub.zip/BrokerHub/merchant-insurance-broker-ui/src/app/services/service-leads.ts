import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class LeadsService {
  private static API_PATH = '/broker-api/web/v1/ui/leads';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getLeadReport(leadId: string): Promise<Map<string, string | Array<Map<string, string>>>> {
    return this.handleRequest(
      this.http.get<Map<string, string | Array<Map<string, string>>>>(
        `${environment.apiURL}${LeadsService.API_PATH}/lead/${leadId}`,
        { withCredentials: true }
      )
    );
  }

  async totalLeads(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${LeadsService.API_PATH}/total`, { withCredentials: true })
    );
  }

  async listLeads(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${LeadsService.API_PATH}?${params.toString()}`, {
        withCredentials: true,
      })
    );
  }

  async changeStatus(id: string, status: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${LeadsService.API_PATH}/${status}/${id}`, { withCredentials: true })
    );
  }

  async deleteLead(id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${LeadsService.API_PATH}/${id}`, { withCredentials: true })
    );
  }
}
