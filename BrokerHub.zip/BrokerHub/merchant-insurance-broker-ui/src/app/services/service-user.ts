import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private static API_PATH = '/broker-api/web/v1/ui/user';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getCounters(): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${UserService.API_PATH}/counters`, { withCredentials: true })
    );
  }

  async changePassword(currentPassword: string, password: string, confirmPassword: string): Promise<void> {
    await this.handleRequest(
      this.http.put<void>(
        `${environment.apiURL}${UserService.API_PATH}/change-password`,
        { currentPassword, password, confirmPassword },
        { withCredentials: true }
      )
    );
  }

  async readProfile(): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${UserService.API_PATH}`, { withCredentials: true })
    );
  }

  async updateProfile(
    first: string,
    last: string,
    province?: string,
    postal_code?: string,
    date_of_birth?: string,
    locale?: string,
    notificationPreference?: string
  ): Promise<void> {
    const params: Record<string, string> = {
      first_name: first,
      last_name: last,
    };

    if (province) params['province_code'] = province;
    if (postal_code) params['postal_code'] = postal_code;
    if (date_of_birth) params['date_of_birth'] = date_of_birth;
    if (locale) params['locale'] = locale;
    if (notificationPreference) params['notification_preference'] = notificationPreference;

    await this.handleRequest(
      this.http.put<void>(`${environment.apiURL}${UserService.API_PATH}`, JSON.stringify(params), {
        withCredentials: true,
        headers: { 'Content-Type': 'application/json' },
      })
    );
  }

  async getUserReport(userId: string): Promise<any> {
    const response = await this.handleRequest<any>(
      this.http.get(`${environment.apiURL}${UserService.API_PATH}/report/${userId}`, { withCredentials: true })
    );
    return response;
  }

  async getPolicy(userId: string, policyId: string): Promise<any> {
    let url = `${environment.apiURL}${UserService.API_PATH}/user/${userId}/policy/${policyId}`;
    return this.handleRequest(this.http.get<any>(url, { withCredentials: true }));
  }  

  async addPolicy(userId: string, policyId: string, notify: boolean): Promise<void> {
    await this.handleRequest(
      this.http.put<void>(`${environment.apiURL}${UserService.API_PATH}/${userId}/policy/${policyId}/notify/${notify}`, null, {
        withCredentials: true,
      })
    );
  }

  async searchAddPolicy(policyNumber: string, notify: boolean): Promise<[boolean, boolean]> {
    return this.handleRequest<[boolean, boolean]>(
      this.http.put(`${environment.apiURL}${UserService.API_PATH}/add/policy_number/${policyNumber}/notify/${notify}`, null, {
        withCredentials: true,
      })
    );
  }

  async removePolicy(userId: string, policyId: string): Promise<void> {
    await this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${UserService.API_PATH}/${userId}/policy/${policyId}`, {
        withCredentials: true,
      })
    );
  }
}
