import { Injectable } from '@angular/core';
import { ParamMap, Router, UrlTree } from '@angular/router';
import { Location } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class RoutingService {
  constructor(
    private router: Router,
    private location: Location,
  ) {}

  public trail: {
    label: string;
    routerLink: (string | null)[];
    queryParams?: Record<string, any>;
  }[] = [];

  public clear() {
    this.trail = [];
  }

  replaceState() {
    this.location.replaceState(this.router.url ?? '');
  }

  public setLabel(label: string) {
    // Change the label.
    if (this.trail.length > 0) {
      this.trail[this.trail.length - 1].label = label;
    }

    // Rebuild the entire trail so that Angular will detect the changes and
    // update the display.
    let oldTrail = this.trail;
    this.trail = [];

    for (let i of oldTrail) {
      this.trail.push(i);
    }
  }

  public navigate(): void {
    if (this.trail.length > 0) {
      const top = this.trail[this.trail.length - 1];
      this.router.navigate(top.routerLink, { queryParams: top.queryParams || {} });
    } else {
      this.router.navigate(['/']);
    }
  }

  public addRoute(name: string, clear: boolean) {
    this.replaceState();

    if (clear) {
      this.clear();
    }

    const path = this.router.url;
    if (!path) return;

    const urlTree = this.router.parseUrl(path);
    const newRouterLink = ['/' + urlTree.root.children['primary']?.segments.map((s) => s.path).join('/')];
    const newQueryParams = urlTree.queryParams;

    const existingIndex = this.trail.findIndex(
      (route) =>
        JSON.stringify(route.routerLink) === JSON.stringify(newRouterLink) &&
        JSON.stringify(route.queryParams || {}) === JSON.stringify(newQueryParams || {}),
    );

    if (existingIndex !== -1) {
      // Found an existing match — trim back to it
      this.trail = this.trail.slice(0, existingIndex + 1);
    } else {
      // Not found — push new route
      this.trail.push({
        label: name,
        routerLink: newRouterLink,
        queryParams: newQueryParams,
      });
    }
  }

  public pushRoute(name: string, path: string | null) {
    if (!path) return;

    const urlTree = this.router.parseUrl(path);
    this.trail.push({
      label: name,
      routerLink: ['/' + urlTree.root.children['primary']?.segments.map((s) => s.path).join('/')],
      queryParams: urlTree.queryParams,
    });
  }

  public popRoute(event: any | null) {
    var popped: any = null;

    if (event == null) {
      this.trail.pop();
    } else {
      do {
        popped = this.trail.pop();
      } while (popped['label'] != event.item['label'] && this.trail.length > 0);

      this.trail.push(popped);
    }

    return this;
  }

  public get _route() {
    if (this.trail.length > 0) {
      return this.trail[this.trail.length - 1]['routerLink'];
    }
    return ['/'];
  }

  public getQueryParameters(): ParamMap | null {
    if (this.router.url != null) {
      const urlTree: UrlTree = this.router.parseUrl(this.router.url);
      const queryParams: ParamMap = urlTree.queryParamMap;
      return queryParams;
    }

    return null;
  }

  private getPathWithoutQuery(path: string | null) {
    if (path != null) {
      return path.split('?')[0];
    }

    return null;
  }
}
