import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { LocalStorageUtils } from '../utils/utils_local_storage';
import { BehaviorSubject, firstValueFrom } from 'rxjs';
import { Router } from '@angular/router';
import { SettingsService } from './service-settings';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private static API_PATH = '/broker-api/web/v1/ui/auth';

  public firstName?: string | null = null;
  public lastName?: string | null = null;

  private _currentUserId: string | null = null;
  private _status: string | null = null;
  private _role: string | null = null;
  public role$ = new BehaviorSubject<string | null>(null);

  private _accessTokenExp: number | null = null;

  constructor(
    private http: HttpClient,
    private router: Router,
    private settingsService: SettingsService,
  ) {}

  get userId() {
    return this._currentUserId;
  }

  set userId(id) {
    this._currentUserId = id;
  }

  get status() {
    return this._status;
  }

  set status(status) {
    this._status = status;
  }

  get role() {
    return this._role;
  }

  set role(role) {
    this._role = role;
    this.role$.next(role);
  }

  get accessTokenRemainingSeconds(): number | null {
    if (!this._accessTokenExp) return null;
    const remaining = Math.floor((this._accessTokenExp - Date.now()) / 1000);
    return remaining > 0 ? remaining : 0;
  }

  get refreshTokenRemainingSeconds(): number | null {
    const stored = localStorage.getItem('refreshExpires');
    if (!stored) return null;
    const exp = Date.parse(stored);
    const remaining = Math.floor((exp - Date.now()) / 1000);
    return remaining > 0 ? remaining : 0;
  }

  private async handleRequest<T>(observable: any, userErrorMessage: string): Promise<T> {
    try {
      return await firstValueFrom(observable);
    } catch (error) {
      throw this.handleError(userErrorMessage);
    }
  }

  private handleError(error: any): never {
    if (error) {
      throw { code: constants.REASON_UNKNOWN, message: error };
    }
    throw { code: constants.REASON_UNKNOWN, message: $localize`Authentication failed.` };
  }

  async authenticate(email: string, password: string): Promise<void> {
    const response = await this.handleRequest(
      this.http.post<any>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/sign-in`,
        { email, password },
        { withCredentials: true },
      ),
      $localize`Authentication failed.`,
    );

    this.processTokenResponse(response);
  }

  async updateClaims(): Promise<void> {
    const response = await this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${AuthenticationService.API_PATH}/claims`, { withCredentials: true }),
      $localize`We were unable to process your request. Please try again later.`,
    );

    this.processTokenResponse(response);
  }

  private getCSRFRefreshTokenFromCookies(): string | null {
    const cookies = document.cookie.split('; ');
    for (let cookie of cookies) {
      if (cookie.startsWith('csrf_refresh_token=')) {
        return cookie.split('=')[1];
      }
    }
    return null;
  }

  async refreshToken(): Promise<void> {
    const csrfRefreshToken = this.getCSRFRefreshTokenFromCookies();

    const response = await this.handleRequest(
      this.http.post<any>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/refresh`,
        {},
        {
          withCredentials: true,
          ...(csrfRefreshToken ? { headers: { 'X-CSRF-TOKEN': csrfRefreshToken } } : {}),
        },
      ),
      $localize`Authentication failed.`,
    );

    this.processTokenResponse(response);
  }

  async authenticateAsGuest(token: string): Promise<void> {
    LocalStorageUtils.clear();

    const response = await this.handleRequest(
      this.http.post<any>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/sign-in-using-token`,
        { token },
        { withCredentials: true },
      ),
      $localize`We were unable to process your request. Please try again.`,
    );

    this.processTokenResponse(response, false);
  }

  async resendIdentityToken(identity_token: string): Promise<void> {
    LocalStorageUtils.clear();

    await this.handleRequest(
      this.http.post<void>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/resend-identity-token`,
        { identity_token },
        { withCredentials: true },
      ),
      $localize`We were unable to process your request. Please try again.`,
    );
  }

  async logout() {
    this.role = null;
    LocalStorageUtils.clear();
    this.settingsService.clearSettings();

    await this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${AuthenticationService.API_PATH}/sign-out`, { withCredentials: true }),
      $localize`We were unable to process your request. Please try again.`,
    );

    await this.settingsService.loadSettings(this.role, true); 
    this.router.navigate(['/auth/login']);
  }

  async forgot(email: string): Promise<void> {
    await this.handleRequest(
      this.http.put<void>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/forgot`,
        { email },
        { withCredentials: true },
      ),
      $localize`We were unable to process your request. Please try again later.`,
    );
  }

  async reset(resetCode: string, password: string): Promise<void> {
    const response = await this.handleRequest(
      this.http.put<any>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/reset`,
        {
          reset_code: resetCode,
          password,
        },
        { withCredentials: true },
      ),
      $localize`We were unable to process your request. Please try again later.`,
    );

    await this.processTokenResponse(response);
  }

  async validateIdentityTokenAndResetCode(token: string, resetCode: string): Promise<any> {
    return await this.handleRequest(
      this.http.get<any>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/validate/identity_token/${token}/reset_code/${resetCode}`,
        { withCredentials: true },
      ),
      $localize`Authentication failed.`,
    );
  }

  async validateResetCode(resetCode: string): Promise<boolean> {
    return await this.handleRequest(
      this.http.get<boolean>(
        `${environment.apiURL}${AuthenticationService.API_PATH}/validate/reset_code/${resetCode}`,
        { withCredentials: true },
      ),
      $localize`Authentication failed.`,
    );
  }

  private async processTokenResponse(res: any, store: boolean = true) {
    if (store) {
      localStorage.setItem('userId', res['user_id']);
      localStorage.setItem('status', res['status']);
      localStorage.setItem('role', res['role']);
      localStorage.setItem('email', res['email']);
      localStorage.setItem('firstName', res['first_name']);
      localStorage.setItem('lastName', res['last_name']);
    }

    this._currentUserId = res['user_id'];
    this._accessTokenExp = new Date(res['expires']).getTime();

    this.status = res['status'] ?? '';
    this.role = res['role'];
    this.firstName = res['first_name'] ?? '';
    this.lastName = res['last_name'] ?? '';


    if ('refresh_expires' in res) {
      localStorage.setItem('refreshExpires', res['refresh_expires']);
    }

    await this.settingsService.loadSettings(this.role, true); 
  }
}
