import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject, firstValueFrom, throwError } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';
import { v4 as uuidv4 } from 'uuid';
import { environment } from '../../environments/environment';
import * as constants from '../constants';

@Injectable({
  providedIn: 'root',
})
export class QuotesService {
  private static API_PATH = '/broker-api/web/v1/ui/quotes';
  private static QUOTE_PATH = '/broker-api/mobile/v1/quote';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getQuoteReport(quoteId: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${QuotesService.API_PATH}/quote/${quoteId}`, { withCredentials: true })
    );
  }

  async totalQuotes(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${QuotesService.API_PATH}/total`, { withCredentials: true })
    );
  }

  async listQuotes(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${QuotesService.API_PATH}?${params.toString()}`, {
        withCredentials: true,
      })
    );
  }

  async changeStatus(id: string, status: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${QuotesService.API_PATH}/${status}/${id}`, { withCredentials: true })
    );
  }

  async deleteQuote(id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${QuotesService.API_PATH}/${id}`, { withCredentials: true })
    );
  }

  performQuote(policy: any): Cancellable<any> | null {
    let payload: any = {};
    let lob: string | null = null;
    let province_code: string | null = null;

    for (let card of policy) {
      let id = uuidv4();

      if (card.type === 'policy') {
        lob = card.fields.lob === 'AUTO' ? 'AUTO' : 'HAB';
        province_code = card.fields.province_code;
      }

      payload[id] = card;
    }

    if (!lob || !province_code) {
      return null;
    }

    let cancellable = new Cancellable();
    cancellable.promise = firstValueFrom(
      this.http
        .post(`${environment.apiURL}${QuotesService.QUOTE_PATH}/${province_code}/${lob}/false`, payload, {
          withCredentials: true,
        })
        .pipe(takeUntil(cancellable.cancelRequest$), catchError(this.handleError))
    );

    return cancellable;
  }
}

export class Cancellable<T> {
  public promise: Promise<T> | null = null;
  public cancelRequest$: Subject<void> = new Subject<void>();
  public isCancelled: boolean = false;

  cancelRequest(): void {
    this.isCancelled = true;
    this.cancelRequest$.next();
  }
}
