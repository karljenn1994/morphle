import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class PoliciesService {
  private static API_PATH = '/broker-api/web/v1/ui/policies';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getPolicyReport(
    policyId: string | null,
    policyNumber: string | null,
    company: string | null,
    lob: string | null,
  ): Promise<any> {
    if (!policyId && !policyNumber) {
      throw { message: 'Missing policy number and id' };
    }

    let url = `${environment.apiURL}${PoliciesService.API_PATH}`;
    if (policyId) {
      url += `/policy/${policyId}`;
    } else if (policyNumber && lob && company) {
      url += `/policy_number/${policyNumber}/company/${company}/lob/${lob}`;
    } else if (policyNumber && lob) {
      url += `/policy_number/${policyNumber}/lob/${lob}`;
    } else {
      url += `/policy_number/${policyNumber}`;
    }

    return this.handleRequest(this.http.get<any>(url, { withCredentials: true }));
  }

  async totalPolicies(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${PoliciesService.API_PATH}/total`, { withCredentials: true }),
    );
  }

  async listPolicies(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${PoliciesService.API_PATH}?${params.toString()}`, {
        withCredentials: true,
      }),
    );
  }

  async addPolicy(policy_number: string, company: string, lob: string): Promise<void> {
    return this.handleRequest(
      this.http.post<void>(
        `${environment.apiURL}${PoliciesService.API_PATH}/policy`,
        { policy_number, company, lob },
        { withCredentials: true },
      ),
    );
  }

  async addUser(policy_id: string, user_id: string, notify: boolean): Promise<void> {
    return this.handleRequest(
      this.http.put<void>(`${environment.apiURL}${PoliciesService.API_PATH}/${policy_id}/user/${user_id}/notify/${notify}`, null, {
        withCredentials: true,
      }),
    );
  }

  async removeUser(policy_id: string, user_id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${PoliciesService.API_PATH}/${policy_id}/user/${user_id}`, {
        withCredentials: true,
      }),
    );
  }

  async deletePolicy(id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${PoliciesService.API_PATH}/policy/${id}`, {
        withCredentials: true,
      }),
    );
  }

  async totalUnmappedPolicies(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${PoliciesService.API_PATH}/unmapped/total`, { withCredentials: true }),
    );
  }

  async listUnmappedPolicies(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${PoliciesService.API_PATH}/unmapped?${params.toString()}`, {
        withCredentials: true,
      }),
    );
  }


  async releaseOnHold(policy_id: string): Promise<number> {
    return this.handleRequest(
      this.http.put<void>(`${environment.apiURL}${PoliciesService.API_PATH}/release/${policy_id}`, null, {
        withCredentials: true,
      }),
    );
  }

  async totalOnHold(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${PoliciesService.API_PATH}/onhold/total`, { withCredentials: true }),
    );
  }

  async listOnHold(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${PoliciesService.API_PATH}/onhold?${params.toString()}`, {
        withCredentials: true,
      }),
    );
  }
}
