import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Model } from 'survey-core';
import { SurveyCreatorModel } from 'survey-creator-core';

@Injectable()
export class FormService {
  private static API_PATH = '/broker-api/web/v1/ui/forms';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async totalForms(formType: string): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${FormService.API_PATH}/${formType}/total`, { withCredentials: true })
    );
  }

  async listForms(
    formType: string,
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${FormService.API_PATH}/${formType}?${params}`, {
        withCredentials: true,
      })
    );
  }

  async loadForm(formId: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}`, { withCredentials: true })
    );
  }

  async saveForm(
    formId: string,
    formType: string,
    name: string,
    description: string,
    form: SurveyCreatorModel
  ): Promise<any> {
    const payload = { type: formType, name, description, form: form.JSON };
    return this.handleRequest(
      this.http.post(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}`, payload, {
        withCredentials: true,
      })
    );
  }

  async deleteForm(formId: string): Promise<void> {
    await this.handleRequest(
      this.http.delete(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}`, { withCredentials: true })
    );
  }

  async loadFormInstanceByToken(token: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${FormService.API_PATH}/token/${token}`, { withCredentials: true })
    );
  }

  async loadFormInstanceById(userId: string, formId: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}/user_id/${userId}`, {
        withCredentials: true,
      })
    );
  }

  async loadResult(formId: string, userId: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}/user_id/${userId}`, {
        withCredentials: true,
      })
    );
  }

  async saveResult(token: string, formData: Model): Promise<any> {
    return this.handleRequest(
      this.http.post(`${environment.apiURL}${FormService.API_PATH}/token/${token}`, formData, { withCredentials: true })
    );
  }

  async totalResults(formId: string): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}/total`, {
        withCredentials: true,
      })
    );
  }

  async listResults(
    formId: string,
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${FormService.API_PATH}/results/form_id/${formId}?${params}`, {
        withCredentials: true,
      })
    );
  }

  async deleteResult(formId: string, userId: string): Promise<void> {
    await this.handleRequest(
      this.http.delete(`${environment.apiURL}${FormService.API_PATH}/form_id/${formId}/user_id/${userId}`, {
        withCredentials: true,
      })
    );
  }
}
