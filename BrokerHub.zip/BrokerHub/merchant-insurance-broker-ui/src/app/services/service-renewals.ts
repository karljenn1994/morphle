import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class RenewalsService {
  private static API_PATH = '/broker-api/web/v1/ui/renewals';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, error: $localize`An unknown error occurred` };
  }


  async getPolicyReport(
    policyId: string | null,
    policyNumber: string | null,
    company: string | null,
    lob: string | null,
  ): Promise<any> {
    if (!policyId && !policyNumber) {
      throw { message: 'Missing policy number and id' };
    }

    let url = `${environment.apiURL}${RenewalsService.API_PATH}`;
    if (policyId) {
      url += `/policy/${policyId}`;
    } else if (policyNumber && lob && company) {
      url += `/policy_number/${policyNumber}/company/${company}/lob/${lob}`;
    } else if (policyNumber && lob) {
      url += `/policy_number/${policyNumber}/lob/${lob}`;
    } else {
      url += `/policy_number/${policyNumber}`;
    }

    return this.handleRequest(this.http.get<any>(url, { withCredentials: true }));
  }

  async totalRenewals(changePercent?: number | null): Promise<number> {
    const params = new URLSearchParams()

    if (changePercent !== undefined && changePercent !== null) {
      params.append('change_percent', changePercent.toString());
    }

    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${RenewalsService.API_PATH}/total?${params.toString()}`, { withCredentials: true })
    );
  }

  async listRenewals(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
    issues?: number[] | null,
    changePercent?: number | null,
  ): Promise<any[]> {

    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    if (issues !== undefined && issues !== null) {
      issues.forEach((issue) => params.append('issue', issue.toString()));
    }

    if (changePercent !== undefined && changePercent !== null) {
      params.append('change_percent', changePercent.toString());
    }

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${RenewalsService.API_PATH}?${params.toString()}`, {
        withCredentials: true,
      })
    );
  }

  async totalValidationRules(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${RenewalsService.API_PATH}/rules/total`, { withCredentials: true })
    );
  }

  async listValidationRules(
    rowsPerPage: number | null,
    page: number | null,
    sort: string | null,
    sortDirection: string | null,
    search: string | null
  ): Promise<any[]> {
    const params = new URLSearchParams();
    if (rowsPerPage) params.append('rows_per_page', rowsPerPage.toString());
    if (page) params.append('page', page.toString());
    if (sort && sortDirection) {
      params.append('sort', sort);
      params.append('sort_direction', sortDirection === '1' ? 'desc' : 'asc');
    }
    if (search) params.append('search', search);

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${RenewalsService.API_PATH}/rules?${params.toString()}`, {
        withCredentials: true,
      })
    );
  }
}
