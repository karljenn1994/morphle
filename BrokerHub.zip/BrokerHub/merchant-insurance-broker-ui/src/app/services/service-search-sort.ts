import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SearchSortService {
  private _context: string | null = null;
  searchText: string | null = null;
  sort: string | null = null;
  sortDirection: string | null = null;
  index: number = 0;
  rowsPerPage: number = 50;

  clear() {
    this.searchText = null;
    this.sort = null;
    this.sortDirection = null;
    this.index = 0;
  }

  set context(c: string | null) {
    if (c != this._context) {
      this.clear();
    }

    this._context = c;
  }

  get page(): number {
    return Math.floor(this.index / this.rowsPerPage);
  }
}
