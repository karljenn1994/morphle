import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom, Subject, throwError } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';
import { v4 as uuidv4 } from 'uuid';
import { environment } from '../../environments/environment';
import * as constants from '../constants';

@Injectable({
  providedIn: 'root',
})
export class ClaimsService {
  private static API_PATH = '/broker-api/web/v1/ui/claims';
  private static CLAIM_PATH = '/broker-api/mobile/v1/claim';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async getClaimReport(claimId: string): Promise<Map<string, string | Array<Map<string, string>>>> {
    return this.handleRequest(
      this.http.get<Map<string, string | Array<Map<string, string>>>>(
        `${environment.apiURL}${ClaimsService.API_PATH}/claim/${claimId}`,
        { withCredentials: true }
      )
    );
  }

  async totalClaims(): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${ClaimsService.API_PATH}/total`, { withCredentials: true })
    );
  }

  async listClaims(
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null
  ): Promise<any[]> {
    const queryParams = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${ClaimsService.API_PATH}?${queryParams}`, { withCredentials: true })
    );
  }

  async changeStatus(id: string, status: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${ClaimsService.API_PATH}/${status}/${id}`, { withCredentials: true })
    );
  }

  async deleteClaim(id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${ClaimsService.API_PATH}/${id}`, { withCredentials: true })
    );
  }

  performClaim(policy: any): Cancellable<any> | null {
    let payload: any = {};
    let lob: string | null = null;
    let province_code: string | null = null;

    for (let card of policy) {
      if (!card.id) card.id = uuidv4();

      if (card.type == 'policy') {
        lob = card.fields.lob == 'AUTO' ? 'AUTO' : 'HAB';
        province_code = card.fields.province_code;
      }

      payload[card.id] = card;
    }

    if (!lob || !province_code) {
      return null;
    }

    let cancellable = new Cancellable();
    cancellable.promise = firstValueFrom(
      this.http
        .post(`${environment.apiURL}${ClaimsService.CLAIM_PATH}/${province_code}/${lob}/false`, payload, {
          withCredentials: true,
        })
        .pipe(takeUntil(cancellable.cancelRequest$), catchError(this.handleError))
    );

    return cancellable;
  }
}

export class Cancellable<T> {
  public promise: Promise<T> | null = null;
  public cancelRequest$: Subject<void> = new Subject<void>();
  public isCancelled: boolean = false;

  cancelRequest(): void {
    this.isCancelled = true;
    this.cancelRequest$.next();
  }
}
