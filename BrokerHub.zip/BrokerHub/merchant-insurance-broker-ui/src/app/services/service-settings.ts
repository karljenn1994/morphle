import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SettingsService {
  private static API_PATH = '/broker-api/web/v1/ui/settings';

  public settings: Map<string, string> | null = null;
  private lastRole: string | null = null;

  private loadingPromise: Promise<void> | null = null;

  constructor(
    private http: HttpClient,
  ) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async updateSettings(settings: Map<string, string>): Promise<void> {
    await this.handleRequest(
      this.http.put<void>(`${environment.apiURL}${SettingsService.API_PATH}`, Object.fromEntries(settings), {
        withCredentials: true,
        headers: { 'Content-Type': 'application/json' },
      }),
    );

    this.settings = new Map<string, string>(Object.entries(settings));
  }

  clearSettings(): void {
    this.settings = null;
    this.lastRole = null;
    this.loadingPromise = null;
  }

  async loadSettings(role?: string | null, force?: boolean): Promise<void> {
    if (this.settings && !force && role === this.lastRole) {
      return; // already loaded for this role
    }

    // If already loading, return the same promise
    if (this.loadingPromise) {
      return this.loadingPromise;
    }

    this.lastRole = role ?? null;
    this.loadingPromise = (async () => {
      try {
        const response = await this.handleRequest<any>(
          this.http.get(`${environment.apiURL}${SettingsService.API_PATH}`, { withCredentials: true }),
        );
        this.settings = new Map<string, string>(Object.entries(response ?? {}));
      } finally {
        // clear the loading promise so subsequent calls can refresh if needed
        this.loadingPromise = null;
      }
    })();

    return this.loadingPromise;
  }

  getSetting(name: string): string | null {
    return this.settings?.get(name) ?? null;
  }
}
