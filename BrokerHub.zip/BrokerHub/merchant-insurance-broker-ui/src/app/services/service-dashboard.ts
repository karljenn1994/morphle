import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  private static API_PATH = '/broker-api/web/v1/ui/metrics';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async loadMetrics(): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${DashboardService.API_PATH}/dashboard`, { withCredentials: true })
    );
  }
}
