import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class RefreshService {
  constructor() {}

  private refreshChangeSource = new Subject<any>();

  refreshEmitted$ = this.refreshChangeSource.asObservable();

  emitRefresh() {
    this.refreshChangeSource.next(null);
  }
}
