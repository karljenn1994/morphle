import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ValidatorService {
  private static API_PATH = '/broker-api/web/v1/ui/validators';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, error: $localize`An unknown error occurred` };
  }

  async listValidationRules(validationId: string): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validation/${validationId}/rules`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async listValidationRuleTemplates(validationType: string): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validation/${validationType}/rule_templates`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async listValidations(validationType: string | null): Promise<any> {
    let url = `${environment.apiURL}${ValidatorService.API_PATH}/validations`;
    if (validationType) url += `?type=${encodeURIComponent(validationType)}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async loadValidation(validationId: string): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validation/${validationId}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async upsertValidation(
    id: string,
    name: string,
    description: string,
    validationType: string,
    rules: any[]
  ): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validation/${id}`;
    return this.handleRequest(
      this.http.post(url, { name, description, validation_type: validationType, rules }, { withCredentials: true })
    );
  }

  async deleteValidation(validationId: string): Promise<void> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validation/${validationId}`;
    await this.handleRequest(this.http.delete(url, { withCredentials: true }));
  }

  async listValidators(): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async loadValidator(validatorId: string): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validator/${validatorId}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async lists(validatorType: string | null): Promise<any> {
    let url = `${environment.apiURL}${ValidatorService.API_PATH}/lists`;
    if (validatorType) url += `?type=${encodeURIComponent(validatorType)}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async updateValidatorValidations(validatorId: string, validationId: string): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validator/${validatorId}/validation`;
    return this.handleRequest(this.http.patch(url, { validation_id: validationId }, { withCredentials: true }));
  }

  async activateValidator(validatorId: string, active: boolean): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validator/${validatorId}/activate`;
    return this.handleRequest(this.http.patch(url, { active }, { withCredentials: true }));
  }

  async upsertValidator(
    validatorId: string,
    active: boolean,
    validatorType: string,
    validationId: string,
    name: string,
    description: string,
    trigger: string | null,
    rules: any
  ): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validator/${validatorId}`;
    return this.handleRequest(
      this.http.post(
        url,
        {
          active,
          validator_type: validatorType,
          validation_id: validationId,
          name,
          description,
          trigger,
          rules,
        },
        { withCredentials: true }
      )
    );
  }

  async runValidator(validatorId: string, dryrun: boolean): Promise<any> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validator/${validatorId}/run?dryrun=${dryrun}`;
    return this.handleRequest(this.http.get(url, { withCredentials: true }));
  }

  async deleteValidator(validatorId: string): Promise<void> {
    const url = `${environment.apiURL}${ValidatorService.API_PATH}/validator/${validatorId}`;
    await this.handleRequest(this.http.delete(url, { withCredentials: true }));
  }
}
