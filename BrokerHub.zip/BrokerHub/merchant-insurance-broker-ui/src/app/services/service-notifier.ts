import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import * as constants from '../constants';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class NotifierService {
  private static API_PATH = '/broker-api/web/v1/ui/notifier';

  constructor(private http: HttpClient) {}

  private async handleRequest<T>(observable: any): Promise<T> {
    return await firstValueFrom(observable.pipe(catchError((error) => throwError(() => this.handleError(error)))));
  }

  private handleError(error: any): never {
    throw error ?? { code: constants.REASON_UNKNOWN, message: $localize`An unknown error occurred` };
  }

  async totalRecipients(notifierId: string): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${NotifierService.API_PATH}/recipients/total/${notifierId}`, {
        withCredentials: true,
      }),
    );
  }

  async listRecipients(
    notifierId: string,
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      sort: sort ?? 'account_name',
      sort_direction: sortDirection == '1' ? 'desc' : 'asc',
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(
        `${environment.apiURL}${NotifierService.API_PATH}/recipients/${notifierId}?${params.toString()}`,
        { withCredentials: true },
      ),
    );
  }

  async deleteRecipient(recipientId: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${NotifierService.API_PATH}/recipient/${recipientId}`, {
        withCredentials: true,
      }),
    );
  }

  async totalNotifications(mailBox: string): Promise<number> {
    return this.handleRequest(
      this.http.get<number>(`${environment.apiURL}${NotifierService.API_PATH}/${mailBox}/total`, {
        withCredentials: true,
      }),
    );
  }

  async toggleNotifications(userId: string, policyId: string, enabled: boolean): Promise<void> {
    return this.handleRequest(
      this.http.put<void>(`${environment.apiURL}${NotifierService.API_PATH}/notify/${enabled}/user/${userId}/policy/${policyId}`, {
        withCredentials: true,
      }),
    );
  }

  async listNotifications(
    mailbox: string,
    rowsPerPage: number,
    page: number,
    sort: string | null,
    sortDirection: string | null,
    search: string | null,
  ): Promise<any[]> {
    const params = new URLSearchParams({
      rows_per_page: rowsPerPage.toString(),
      page: page.toString(),
      ...(sort && sortDirection && { sort, sort_direction: sortDirection == '1' ? 'desc' : 'asc' }),
      ...(search && { search }),
    });

    return this.handleRequest(
      this.http.get<any[]>(`${environment.apiURL}${NotifierService.API_PATH}/${mailbox}?${params.toString()}`, {
        withCredentials: true,
      }),
    );
  }

  async loadNotification(notificationId: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(
        `${environment.apiURL}${NotifierService.API_PATH}/notification/${encodeURIComponent(notificationId)}`,
        { withCredentials: true },
      ),
    );
  }

  async deleteNotification(id: string): Promise<void> {
    return this.handleRequest(
      this.http.delete<void>(`${environment.apiURL}${NotifierService.API_PATH}/${id}`, { withCredentials: true }),
    );
  }

  async approve(id: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${NotifierService.API_PATH}/approve/${id}`, { withCredentials: true }),
    );
  }

  async draft(id: string): Promise<void> {
    return this.handleRequest(
      this.http.get<void>(`${environment.apiURL}${NotifierService.API_PATH}/draft/${id}`, { withCredentials: true }),
    );
  }

  async testNotification(notifierId: string, notifierRecipientId: string): Promise<any> {
    return this.handleRequest(
      this.http.get<any>(
        `${environment.apiURL}${NotifierService.API_PATH}/test/notifier/${encodeURIComponent(notifierId)}/notifier_recipient/${encodeURIComponent(notifierRecipientId)}`,
        { withCredentials: true },
      ),
    );
  }

  async getNotificationReport(policyId?: string, userId?: string): Promise<any> {
    const params = new URLSearchParams();

    if (policyId) {
      params.set('policy_id', policyId);
    }

    if (userId) {
      params.set('user_id', userId);
    }

    return this.handleRequest(
      this.http.get<any>(`${environment.apiURL}${NotifierService.API_PATH}/report?${params.toString()}`, {
        withCredentials: true,
      }),
    );
  }
}
