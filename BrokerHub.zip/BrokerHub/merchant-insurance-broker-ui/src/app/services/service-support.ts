import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from './service-authentication';

@Injectable({
  providedIn: 'root',
})
export class NavigationService {
  constructor(private router: Router, private authService: AuthenticationService) {}

  redirectToLogin(): void {
    this.authService.logout();
    this.router.navigate(['/main']);
  }
}
