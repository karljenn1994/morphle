import { Component, OnInit } from '@angular/core';
import { environment } from '../environments/environment';
import { IdleService } from './services/service-idle';
import { SettingsService } from './services/service-settings';
import { LocaleUtils } from './utils/utils_locale';

// PrimeNG
import { ToastModule } from 'primeng/toast';
import { MessageModule } from 'primeng/message';
import { RouterOutlet } from '@angular/router';
import { SessionDebugComponent } from './session-debug.component';
import { AuthenticationService } from './services/service-authentication';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [
    RouterOutlet,
    ToastModule,
    MessageModule,
    SessionDebugComponent,
  ],
})
export class AppComponent implements OnInit {
  constructor(
    private idleService: IdleService,
    private authService: AuthenticationService,
    private settingsService: SettingsService,
  ) {}

  async ngOnInit(): Promise<void> {
    // Ensure settings are loaded and locales are set up here, once for the app
    const raw = this.settingsService.getSetting('systemSupportedLocales');
    const supportedLocales = raw?.split(',').map((l) => l.trim()) ?? ['en'];
    LocaleUtils.setSupportedLocales(supportedLocales);

    if (environment.production) {
      const preferredLocale = LocaleUtils.locale;
      const currentLocale = LocaleUtils.localeFromHRef(window.location.href);
      const redirectUrl = LocaleUtils.localizeHRef(window.location.href);

      // Only redirect if it will actually change the URL
      if (preferredLocale !== currentLocale && redirectUrl !== window.location.href) {
        window.location.href = redirectUrl;
      }
    }
  }
}
