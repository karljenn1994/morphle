import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-router',
    templateUrl: './app-router.html',
    styleUrls: ['./app-router.scss'],
    standalone: false
})
export class AppRouter implements OnInit {
  constructor() { }

  ngOnInit() {
  }
}
