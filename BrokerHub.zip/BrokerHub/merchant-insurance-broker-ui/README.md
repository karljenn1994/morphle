# 📦 Changelog

## [1.0.2] - 2025-07-11
### ⚠️ Breaking Changes
### 🚧 New
### 🐛 Fixed

## [1.0.1] - 2025-06-04
### ⚠️ Breaking Changes
- 
### 🚧 New
- Enabled language drop downs for customers
- Added reply-to email address
- Preview emails
- Removed unecessary columns from draft and outbox mailbox recipient lists
- Added a password complexity hint
### 🐛 Fixed
- Change "New Campaign" to "New Template" on templates screen
- Added required validation messages to subject and body on the template screen
- Properly stripped all HTML and entities from template subject line before testing and saving
- Made subject and body required for all supported languages
- Test button only available when template is saved
- Fixed insured being shown on policy summary
- Added transaction_effective_date, policy_effective_date, and policy_expiry_date to template toolbar 
- Comparison of property assets only by street now to handle missing city and province
- Fixed asset description to better handle missing parts like city, province, make, and model
- Driver comparison now shows "Principal" and "Occasional" instead of percentages
- Added RII trigger for reissue
- Added zh-TW locale for traditional chinese
- Refactored admin module into sub-modules according to the menu headings
- Hide proof of insurance when not on a phone
- Validation configuration now opens properly