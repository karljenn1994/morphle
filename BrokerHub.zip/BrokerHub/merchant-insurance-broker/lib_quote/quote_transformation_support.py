import re
from typing import Iterable

from suds.sax.text import Text


class QuoteTransformationSupport(object):
    def __init__(self, log):
        self._transformation_log = log

    @property
    def transformation_log(self):
        return self._transformation_log

    def _value(self, obj, name, default=None, data_type=None, level="error", tag=None):
        object_type = None

        if obj is None:
            return default

        if not isinstance(obj, Iterable):
            return default

        if "type" in obj:
            object_type = obj["type"]

        val = None

        if name in obj:
            val = obj[name]

        if val == "None":
            val = None

        elif type(val) == str and len(val) <= 0:
            val = None

        if data_type is not None:
            val = self._convert_to_type(val, data_type)

        if val is None and default is not None:
            self._transformation_log.log_missing_value(object_type, name, level=level, tag=tag)
            self._transformation_log.log(level, "Using default value " + str(default) + " for " + name)
            val = default

        if val is None:
            self._transformation_log.log_missing_value(object_type, name, level=level, tag=tag)

        return val

    def value(self, obj, name, default=None, data_type=None, level="error", tag=None):
        if type(name) == list:
            for i, n in enumerate(name):
                if i < len(name) - 1:
                    obj = self._value(obj, n, default=default, level=level, tag=tag)
                else:
                    obj = self._value(obj, n, default=default, data_type=data_type, level=level, tag=tag)

                if obj is None:
                    break

            return obj
        else:
            return self._value(obj, name, default=default, data_type=data_type, level=level, tag=tag)

    def field(self, obj, name, default=None, data_type=None, level="error", tag=None):
        object_type = None
        val = None

        if "type" in obj:
            object_type = obj["type"]

        if "fields" in obj:
            if name in obj["fields"]:
                val = obj["fields"][name]

        if "fields" not in obj:
            self._transformation_log.log_missing_value(object_type, "fields", level=level, tag=tag)
            return None

        if val is not None and data_type is not None:
            val = self._convert_to_type(val, data_type)

        if val is None and default is not None:
            self._transformation_log.log_missing_value(object_type, name, level=level, tag=tag)
            self._transformation_log.log(level, "Using default value " + str(default) + " for " + name)
            val = default

        if val is None:
            self._transformation_log.log_missing_value(object_type, name, level=level, tag=tag)

        return val

    def _convert_to_type(self, val, data_type):
        if type(val) == Text:
            val = str(val)

        if type(val) == str:
            return self._convert_str_to(val, data_type)

        if type(val) == float:
            return self._convert_float_to(val, data_type)

        if type(val) == int:
            return self._convert_int_to(val, data_type)

        if type(val) == bool:
            return self._convert_bool_to(val, data_type)

    def _convert_str_to(self, val, data_type):
        if data_type == float:
            return self._convert_str_to_float(val)

        if data_type == int:
            return self._convert_str_to_int(val)

        if data_type == bool:
            return self._convert_str_to_bool(val)

        return val

    def _convert_bool_to(self, val, data_type):
        if data_type == str:
            return str(val)

        return False

    def _convert_float_to(self, val, data_type):
        if data_type == str:
            return self._convert_float_to_str(val)

        if data_type == int:
            return self._convert_float_to_int(val)

        if data_type == bool:
            return self._convert_str_to_bool(val)

        return val

    def _convert_int_to(self, val, data_type):
        if data_type == str:
            return self._convert_float_to_str(val)

        if data_type == float:
            return self._convert_int_to_float(val)

        if data_type == bool:
            return self._convert_str_to_bool(val)

        return val

    def _convert_str_to_float(self, val):
        if val is None or len(val) == 0:
            return None

        # Remove spaces.
        new_val = val.replace(" ", "")

        was_neg = False

        if new_val[0] == "-":
            was_neg = True

        # cleanup whole number and fraction part.
        parts = new_val.split(".")

        # Remove all non digits.
        for i, p in enumerate(parts):
            parts[i] = re.sub(r'\D', '', p)

        new_val = ".".join(parts)

        if was_neg:
            new_val = "-" + new_val

        return float(new_val)

    def _convert_str_to_int(self, val):
        if val is None or len(val) == 0:
            return None

        # Remove spaces.
        new_val = val.replace(" ", "")

        # Remove all non digits.
        new_val = re.sub(r'\D', '', new_val)
        return int(new_val)

    def _convert_str_to_bool(self, val):
        if val is None or len(val) == 0:
            return False

        # Remove spaces.
        new_val = val.replace(" ", "")
        new_val = new_val.lower()

        if new_val in ["y", "true", "1", "on"]:
            return True

        if new_val in ["n", "false", "0", "-1", "off"]:
            return False

        return False

    def _convert_float_to_str(self, val):
        if val is None:
            return val

        return str(val)

    def _convert_float_to_int(self, val):
        if val is None:
            return val

        return int(round(val, 0))

    def _convert_float_to_bool(self, val):
        if val is None:
            return False

        if val > 0:
            return True

        return False

    def _convert_int_to_str(self, val):
        if val is None:
            return val

        return str(val)

    def _convert_int_to_float(self, val):
        if val is None:
            return val

        return float(val)

    def _convert_int_to_bool(self, val):
        if val is None:
            return False

        if val > 0:
            return True

        return False
