import datetime
import logging
import uuid
from abc import ABC
from datetime import datetime

import moment
from dateutil.relativedelta import relativedelta

from lib_common import constants
from lib_common.constants import LOGGER
from lib_persistence import location as persist_loc, vehicle as persist_veh
from lib_quote.card_to_cq import CardToCQ

log = logging.getLogger(LOGGER)

ACORD_VERSION = 1180
DEFAULT_LICENCE_CLASS = "G"
DEFAULT_FIRE_HYDRANT_DISTANCE = 10
DEFAULT_REPLACEMENT_COSE = 300000
DEFAULT_ANNUAL_DISTANCE = 25000
DEFAULT_DAILY_DISTANCE = 3


class CardToCQAuto(CardToCQ, ABC):
    def __init__(self, config, quick_quote, quote_support, credit_score):
        CardToCQ.__init__(self, config, quick_quote, quote_support)
        self._credit_score = credit_score

    def to_cq_json(self, quoting_province, card_json):
        acord_output = self.map_auto_request(quoting_province, card_json)
        return acord_output

    def get_primary_driver(self, card_json, vehicle_obj):
        primary_driver = None

        # Find the primary driver
        primary_driver_id = self._value(vehicle_obj, "primary_driver", data_type=str)

        # When might have a driver's element.
        if not primary_driver and not primary_driver_id and "drivers" in vehicle_obj:
            for driver in vehicle_obj["drivers"]:
                if driver['principal']:
                    primary_driver_id = driver["id"]
                    break

        if primary_driver_id:
            for entry in card_json.values():
                if entry["type"] == "individual" and entry["id"] == primary_driver_id:
                    primary_driver = entry
                    break

        # # TODO: This should only be done for quick quoting
        # if not primary_driver:  # and self._quick_quote:
        #     for entry in card_json.values():
        #         if entry["type"] == "individual":
        #             primary_driver = entry
        #             break

        if primary_driver is None:
            self._error("Missing primary driver for vehicle.")

        return primary_driver

    def map_auto_request(self, quoting_province, card_json):
        carrier_config = self._config["carriers"]

        if carrier_config is None:
            self._error("No carriers for " + quoting_province + " have been configured")
            return

        # Rating web service will have a single carrier. Rate bridge will have a map
        # of possibly many carriers.
        if type(carrier_config) is str:
            carriers = [carrier_config]
        elif type(carrier_config) is list:
            carriers = carrier_config
        else:
            carriers = list(carrier_config.keys())

        individuals = [item for item in card_json.values() if self._value(item, "type", data_type=str) == "individual"]

        if len(individuals) == 0:
            self._error("No individuals in request")
            return

        insured = individuals[0]
        vehicle_items = [item for item in card_json.values() if self._value(item, "type", data_type=str) == "vehicle"]

        if len(vehicle_items) == 0:
            self._error("No vehicles in request")
            return

        driver_profile = []

        for individual in individuals:
            if self._value(individual, "drivers_licence") is not None or self._quick_quote:
                driver_profile.append(self.map_driver_node(individual))

        id_offset = 0
        claims = [self.map_auto_claim(claim, self._value(individual, "cqID", data_type=str), i + id_offset) for
                  i, individual in enumerate(individuals) for i, claim in
                  enumerate(self._value(individual, ["history", "claims"], level="info", default=[]))]

        id_offset += len(claims)
        tickets = [self.map_conviction(ticket, self._value(individual, "cqID", data_type=str), i + id_offset) for
                   i, individual in enumerate(individuals) for i, ticket in
                   enumerate(self._value(individual, ["history", "tickets"], level="info", default=[]))]

        id_offset += len(tickets)
        convictions = [self.map_conviction(conviction, self._value(individual, "cqID", data_type=str), i + id_offset)
                       for i, individual in enumerate(individuals) for i, conviction in
                       enumerate(self._value(individual, ["history", "convictions"], level="info", default=[])) if
                       self._value(conviction, "type", data_type=str) != "Driving without insurance"]

        id_offset += len(convictions)

        # TODO: We don't seem to have "Driving without insurance" and it should be a value not a description.
        incidents = [self.map_incident(conviction, self._value(individual, "cqID", data_type=str), i + id_offset) for
                     i, individual in enumerate(individuals) for i, conviction in
                     enumerate(self._value(individual, ["history", "convictions"], level="info", default=[])) if
                     self._value(conviction, "type", data_type=str) == "Driving without insurance"]

        convictions = tickets + convictions
        vehicles = []
        vehicle_links = []

        for vehicle in vehicle_items:
            self.map_vehicle_link_node(card_json, vehicle, individuals, vehicle_links)
            veh = self.map_vehicle_node(card_json, vehicle)

            if veh is not None:
                vehicles.append(veh)

        client_prov = self.get_province_code(insured)
        addr = self.get_address(insured)
        consent = "Y" if self._field(insured, "consent_to_credit_check", data_type=bool, level="none") else "N"

        drivers_licence = self._value(insured, "drivers_licence", default=None)

        policy = None
        for item in card_json.values():
            if self._value(item, "type", data_type=str) == "policy":
                policy = item

        first_name = self._field(insured, "first_name", data_type=str)
        last_name = self._field(insured, "last_name", data_type=str)
        province_code = self.get_province_code(insured)
        city = self.get_city(insured)
        postal_code = self.get_postal_code(insured)

        renewal = {
            '#text': "NO"
            }

        if drivers_licence is not None:
            first_name = first_name if first_name is not None else self._field(drivers_licence, "first_name",
                                                                               data_type=str)
            last_name = last_name if last_name is not None else self._field(drivers_licence, "last_name", data_type=str)
            province_code = province_code if province_code is not None else self._field(drivers_licence,
                                                                                        "province_code",
                                                                                        data_type=str)
            postal_code = postal_code if postal_code is not None else self._field(drivers_licence, "postal_code",
                                                                                  data_type=str)
            city = city if city is not None else self._field(drivers_licence, "city", data_type=str)

        if policy is not None:
            first_name = first_name if first_name is not None else self._field(policy, "first_name", data_type=str)
            last_name = last_name if last_name is not None else self._field(policy, "last_name", data_type=str)
            province_code = province_code if province_code is not None else self._field(policy, "province_code",
                                                                                        data_type=str)
            city = city if city is not None else self._field(policy, "city", data_type=str)
            postal_code = postal_code if postal_code is not None else self._field(policy, "postal_code", data_type=str)

            company_code = self._field(policy, "company_code", default=None)
            if company_code is not None:
                renewal["@vor" + company_code.upper()] = "YES"

        return {
            "QuoteGUID": str(uuid.uuid1()),
            "QuoteIterationGUID": str(uuid.uuid1()),
            "xmlparam_FortusTransaction": {
                "FortusTransaction": {
                    "@xmlns": "",
                    "@Type": "Automobile",
                    "Carriers": {
                        "Carrier": carriers
                        },
                    "EffDate": datetime.now().strftime("%Y%m%d"),
                    "Province": quoting_province,
                    "Renewal": renewal,
                    "CodeNames": {
                        "Auto": {
                            "QuoteInfo": {
                                "Language": "English",
                                "DriverProfile": driver_profile,
                                "Claim": claims,
                                "Conviction": convictions,
                                "Incident": incidents,
                                "ID": "QuoteInfo1",
                                "Origin": "",
                                "Vehicle": vehicles,
                                "VehLink": vehicle_links,
                                **(self._credit_score if self._credit_score is not None else {})
                                }
                            }
                        }
                    }
                },
            "xmlparam_ExtendedInput": {
                "FortusTransaction": {
                    "@xmlns": "",
                    "@Type": "Automobile",
                    "Province": quoting_province,
                    "Renewal": renewal,
                    "CodeNames": {
                        "Auto": {
                            "QuoteInfo": {
                                "ContractNumber": self.get_contract(carrier_config),
                                "Client": {
                                    "Classification": "Client",
                                    "ID": "Client1",
                                    "Address1": addr.replace(",", "") if addr is not None else "",
                                    "Province": client_prov,
                                    "PostalCode": postal_code,
                                    "City": city,
                                    "Address": {
                                        "ID": "ClientAddress1",
                                        "Address1": addr,
                                        "Province": province_code,
                                        "PostalCode": postal_code,
                                        "City": city,
                                        },
                                    "Name": {
                                        "Classification": "Client",
                                        "FirstName": first_name,
                                        "LastName": last_name,
                                        "ID": "Client1",
                                        },
                                    },
                                "Telephone": {
                                    # TODO add telephone (retrieved from web view if needed)
                                    },
                                "Origin": "",
                                "ID": "QuoteInfo1",
                                }
                            }
                        }
                    }
                },
            "xmlparam_CarrierInfo": self.map_carrier_info(carrier_config, consent)
            }

    def map_auto_claim(self, claim, cq_id, claim_number):
        claim_type = self.map_claim_type(claim["type"])
        claim_node = {
            "DriverID": cq_id,
            "ID": f"{cq_id}-{claim_number}",
            "ClaimDate": moment.date(self._value(claim, "date", data_type=str), "YYYY-MM").format("YYYYMMDD"),
            "ClaimType": claim_type,
            }

        return claim_node

    def map_claim_type(self, claim_type):
        switch_dict = {
            "1": "Collision",
            "3": "Collision",
            "4": "Collision",
            "5": "Collision",
            "6": "Collision",
            "7": "Collision",
            "8": "Other non-responsible Comp/SP",
            "16": "Fire",
            "17": "Other non-responsible Comp/SP",
            "18": "Glass Breakage",
            "19": "Liability & Collision",
            "20": "Liability & Collision",
            "21": "Other non-responsible Comp/SP",
            "22": "Collision",
            "31": "Theft",
            "34": "Vandalism",
            "36": "Hail"
            }

        return switch_dict.get(claim_type, "")

    def map_conviction(self, conviction, cq_id, counter):
        in_type = self.map_conviction_type(conviction["type"])
        conviction_node = {
            "DriverID": cq_id,
            "ID": f"{cq_id}-{counter}",
            "ConvictionDate": moment.date(conviction["date"], "YYYY-MM").format("YYYYMMDD"),
            "OffenceCode": in_type[0],
            "Severity": in_type[1],
            }
        return conviction_node

    def map_conviction_type(self, ticket_type):
        return_code = ""
        return_severity = ""

        # Mapping logic
        if ticket_type == "BACK":
            return_code = "FTS"
            return_severity = "Minor"
        elif ticket_type == "BIKE":
            return_code = "MINOR"
            return_severity = "Minor"
        elif ticket_type == "CPV":
            return_code = "CPV"
            return_severity = "Minor"
        elif ticket_type == "FCIC":
            return_code = "FCIC"
            return_severity = "Minor"
        elif ticket_type == "FTC":
            return_code = "FTC"
            return_severity = "Minor"
        elif ticket_type == "FTS":
            return_code = "FTS"
            return_severity = "Minor"
        elif ticket_type == "MINOR":
            return_code = "MINOR"
            return_severity = "Minor"
        elif ticket_type == "SP":
            return_code = "SP"
            return_severity = "Minor"
        elif ticket_type == "SS":
            return_code = "SS"
            return_severity = "Minor"
        elif ticket_type == "SB":
            return_code = "SB"
            return_severity = "Minor"
        elif ticket_type == "CD":
            return_code = "CD"
            return_severity = "Major"
        elif ticket_type == "CN":
            return_code = "CN"
            return_severity = "Criminal"
        elif ticket_type == "DD":
            return_code = "DD"
            return_severity = "Criminal"
        elif ticket_type == "DUS":
            return_code = "DUS"
            return_severity = "Criminal"
        elif ticket_type == "FPBT":
            return_code = "ALC"
            return_severity = "Criminal"
        elif ticket_type == "FPEI":
            return_code = "FPEI"
            return_severity = "Minor"
        elif ticket_type == "FTR":
            return_code = "FTR"
            return_severity = "Criminal"
        elif ticket_type == "FTS":
            return_code = "FTS"
            return_severity = "Minor"
        elif ticket_type == "HL":
            return_code = "HL"
            return_severity = "Minor"
        elif ticket_type == "ILC":
            return_code = "ILC"
            return_severity = "Minor"
        elif ticket_type == "MAJOR":
            return_code = "MAJOR"
            return_severity = "Major"
        elif ticket_type == "PSB":
            return_code = "PSB"
            return_severity = "Major"
        elif ticket_type == "RAC":
            return_code = "RAC"
            return_severity = "Major"

        return return_code, return_severity

    def map_driver_node(self, ind_node):
        # TODO: we need to correct birth_date/date_of_birth.
        birth_date = self._field(ind_node, "birth_date", data_type=str)

        if birth_date is not None:
            birth_date = datetime.strptime(birth_date, "%B %d, %Y")
            birth_date_str = birth_date.strftime("%Y%m%d")
        else:
            birth_date = self._field(ind_node, "date_of_birth", data_type=str)
            birth_date = datetime.strptime(birth_date, "%Y-%m-%d")
            birth_date_str = birth_date.strftime("%Y%m%d")

        drivers_licence = self._value(ind_node, "drivers_licence")
        format_lic_date = None
        lic_date_raw = self._field(drivers_licence, "first_licence_date", data_type=str, level="none")

        if lic_date_raw is not None:
            # TODO: this could be done better.
            if len(lic_date_raw) == 10:
                format_lic_date = datetime.strptime(lic_date_raw, "%Y-%m-%d").strftime("%Y%m%d")
            else:
                format_lic_date = lic_date_raw

        if format_lic_date is None:
            format_lic_date = birth_date + relativedelta(years=18)
            format_lic_date = format_lic_date.strftime("%Y%m%d")

        lic_class = self._field(drivers_licence, "class", data_type=str)
        lic_prov = self._field(drivers_licence, "province_code", default="", data_type=str)
        lic_num = self._field(drivers_licence, "number", data_type=str)

        if self._quick_quote:
            if lic_prov is None:
                lic_prov = ""

            # TODO: this need to be default per province.
            if lic_class is None:
                lic_class = DEFAULT_LICENCE_CLASS

            # String for unique licence ID.
            if lic_num is None:
                lic_num = self._field(drivers_licence, "number", data_type=str)

                if lic_num is None:
                    lic_num = self._field(ind_node, "first_name", default="", data_type=str) + "001"

        # TODO: what to do if no province?
        # if lic_prov.upper() == "NB" or lic_prov.upper() == "NEW BRUNSWICK":
        lic_class = self.map_license_class(lic_class)

        # TODO: what to do about g1?
        lic_class = "G"

        # Default the date with the company to 10 years
        date_with_company = moment.now().subtract("years", 10).format("YYYYMMDD")

        gender = self._field(ind_node, "gender", level="info", data_type=str)
        gender = gender[0] if gender is not None else "f"

        driver_node = {
            "Birthdate": birth_date_str,
            "DateContinuousInsurance": format_lic_date,
            "DriverLicense": {
                "ID": lic_num,
                "LicenseClass": lic_class.upper(),
                "LicenseDate": format_lic_date,
                "ProvinceState": lic_prov.upper(),
                },
            "Gender": gender.upper(),
            "ID": self._value(ind_node, "cqID", data_type=str),
            "MaritalStatus": "M",
            "OccupationCode": "998",
            "RelationshipToApplicant": "Applicant",
            "DateWithCompany": date_with_company,
            "Retired": "N",
            }

        return driver_node

    def map_incident_type(self, ticket_type):
        return_code = ''
        return_type = ''

        if ticket_type == 'Driving without insurance':
            return_type = 'Ins Lapse'
            return_code = 'DWOI'

        return [return_code, return_type]

    def map_incident(self, incident, cq_id, conviction_count):
        incident_type = self.map_incident_type(incident["type"])

        incident_node = {
            "DriverID": cq_id,
            "ID": f"{cq_id}-{conviction_count}",
            "IncidentDate": datetime.strptime(incident["date"], "%Y-%m").strftime("%Y%m%d"),
            "IncidentType": incident_type[1],
            "Reason": incident_type[0],
            }

        return incident_node

    def map_license_class(self, lic_class):
        return_val = lic_class

        if lic_class is not None:
            # Convert license class based on the provided mappings
            mappings = {
                "5": "G",
                "05": "G",
                "5L": "G2",
                "5R": "G",
                "9": "M",
                "09": "M",
                "7": "G1",
                "07": "G1",
                "6": "M",
                "06": "M",
                }

            return_val = mappings.get(lic_class, return_val)

        return return_val

    def map_vehicle_link_node(self, card_json, veh_node, ind_array, veh_link):
        # Find the primary driver - For a quick quote, we use the first individual
        primary_driver = self.get_primary_driver(card_json, veh_node)

        coverages = self._field(veh_node, "coverages", default=None)
        discount_array = []

        if coverages is not None:
            coverage_codes = coverages.split(",")

            for idx, discount_code in enumerate(coverage_codes):
                if discount_code.lower().startswith("dis") or discount_code.lower().startswith("z"):
                    discount_array.append({
                        "ID": "D" + str(idx),
                        "DiscountCode": discount_code.upper(),
                        })

        # if "drivers" in veh_node:
        #     for driver in veh_node["drivers"]:
        #         idd = None
        #         for ind in ind_array:
        #             if ind["id"] == driver["id"]:
        #                 idd = "VehLink" + str(ind_array.index(ind))
        #                 break
        #
        #         veh_link_node = {
        #             "DriverID": driver["id"],
        #             # "Link": "Prn" if driver["principal"] else "Occ",
        #             "Link": "Prn",
        #             "ID": idd,
        #             "PrincipalOwner": "Y",
        #             "VehicleID": veh_node["cqID"],
        #             "Discount": discount_array,
        #         }
        #         veh_link.append(veh_link_node)
        #

        if primary_driver is not None:
            # Look for this driver in the list of drivers
            for ind in ind_array:
                if ind["id"] == primary_driver["id"]:
                    veh_link_node = {
                        "DriverID": ind["cqID"],
                        "Link": "Prn",  # TODO owner?
                        "ID": "VehLink" + str(ind_array.index(ind)),
                        "PrincipalOwner": "Y",
                        "VehicleID": veh_node["cqID"],
                        "Discount": discount_array,
                        }
                    veh_link.append(veh_link_node)

    def map_vehicle_node(self, card_json, veh_node):
        # Find the primary driver - For a quick quote, we use the first individual
        primary_driver = self.get_primary_driver(card_json, veh_node)

        if primary_driver is None:
            return

        # Perform all VICC lookups
        vicc = persist_veh.lookup_vehicle_by_vin(self._field(veh_node, "vin", data_type=str))

        if vicc is None:
            year = self._field(veh_node, "year", default=None, data_type=str)
            make = self._field(veh_node, "make", default=None, data_type=str)
            model = self._field(veh_node, "model", default=None, data_type=str)

            if year is not None and make is not None and model is not None:
                vicc = persist_veh.lookup_vehicle_by_year_make_model(year, make, model)

        if vicc is None:
            return None

        # Distance Annually
        dis_annual = self._field(veh_node, "annual_km", default=DEFAULT_ANNUAL_DISTANCE, data_type=int)

        # Distance daily
        dist_daily = self._field(veh_node, "commute_distance", default=DEFAULT_DAILY_DISTANCE, data_type=int)

        # TODO - Need to figure this out.
        usage = "Pleasure"
        # if (veh_node.fields.vehicle_business_usage != "0") {
        #    usage = "Business"
        # }

        # CQ only accepts 20 characters
        veh_id = veh_node["cqID"]

        # See if the vehicle has coverages that we should use.
        coverages = self._field(veh_node, "coverages", default=None)
        coverage_array = []

        if coverages is not None:
            coverage_codes = coverages.split(",")

            for idx, coverage_code in enumerate(coverage_codes):
                if not coverage_code.startswith("dis") and not coverage_code.startswith("zd"):
                    mapped_cov_code = coverage_code
                    mapped_cov_code = mapped_cov_code.upper()

                    if mapped_cov_code == '44R':
                        mapped_cov_code = '44'

                    cov = {
                        "CSIOCode": mapped_cov_code,
                        "ID": "Coverage" + str(idx),
                        }

                    limit = self._field(veh_node, "coverage_" + coverage_code + "_limit", default=None)
                    if limit is not None and limit != '-1':
                        if coverage_code == '20' or coverage_code == '20A':
                            cov["Limit2"] = limit
                        else:
                            cov["Limit1"] = limit

                    deductible = self._field(veh_node, "coverage_" + coverage_code + "_deductible", default=None)
                    if deductible is not None and limit != '-1':
                        cov["Deductible"] = deductible

                    coverage_array.append(cov)

            # TODO - We need to get this from discount.
            winter_tires = "Y"

        else:
            winter_tires = self._field(veh_node, "winter_tires", data_type=bool)
            winter_tires = "Y" if winter_tires is not None else "N"

            # Check the package requested (Recommended vs Economical)
            coverage_package_type = self._field(veh_node, "quote_coverage_type", default="recommended", data_type=str)

            if coverage_package_type.lower() == constants.QUOTING_LEVEL_RECOMMENDED:
                cov_limit = 2000000
                col_deductible = 500
                cmp_deductible = 500
            elif coverage_package_type.lower() == constants.QUOTING_LEVEL_ECONOMICAL:
                cov_limit = 1000000
                col_deductible = 1000
                cmp_deductible = 1000
            else:
                cov_limit = 2000000
                col_deductible = 500
                cmp_deductible = 500

            cov_44 = {
                "CSIOCode": "44",
                "ID": "Coverage1",
                "Limit1": cov_limit,
                }
            cov_ab = {
                "CSIOCode": "AB",
                "ID": "Coverage2",
                }

            cov_tpbi = {
                "CSIOCode": "TPBI",
                "ID": "Coverage3",
                "Limit1": cov_limit,
                }

            cov_tpdc = {
                "CSIOCode": "TPDC",
                "ID": "Coverage4",
                "Deductible": "0",
                }

            cov_tppd = {
                "CSIOCode": "TPPD",
                "ID": "Coverage5",
                "Limit1": cov_limit,
                }
            cov_ua = {
                "CSIOCode": "UA",
                "ID": "Coverage6",
                }

            cov_cmp = {
                "CSIOCode": "CMP",
                "ID": "Coverage7",
                "Deductible": cmp_deductible,
                }

            cov_col = {
                "CSIOCode": "COL",
                "ID": "Coverage8",
                "Deductible": col_deductible,
                }

            coverage_array.extend([cov_44, cov_ab, cov_tpbi, cov_tpdc, cov_tppd, cov_ua, cov_cmp, cov_col, ])

        # Purchased Date
        purchase_date = datetime.now().strftime("%Y%m%d")

        # Perform a location lookup
        location_index = persist_loc.lookup_location(self.get_postal_code(primary_driver))

        purchase_price = self._field(veh_node, "purchase_price", default=10000, data_type=float)
        postal_code = self.get_postal_code(primary_driver)

        vehicle_node = {
            "Coverage": coverage_array,
            "DistanceDaily": dist_daily,
            "DistanceYearly": dis_annual,
            "ID": veh_id,
            "Location": location_index[0] if location_index is not None else "",
            "LocationIndex": location_index[1] if location_index is not None else "",
            "MakeAndModel": vicc[1],
            "Manufacturer": vicc[0],
            "Owned": "Y",
            "PostalCode": postal_code,
            "ProductLine": "Personal",
            "VehType": "Private Passenger",
            "VehUse": usage,
            "VICCCode": vicc[3],
            "VICCCodeExt": vicc[4],
            "Year": vicc[2],
            "PurchasePrice": purchase_price,
            "WinterTires": winter_tires,
            "PurchaseDate": purchase_date,  # TODO: Need to get this from somewhere.
            "PurchaseCondition": "N",
            "NightParking": "Driveway",
            "ABS": vicc[5],
            "FuelType": vicc[6],
            "BodyType": vicc[7],
            }

        return vehicle_node
