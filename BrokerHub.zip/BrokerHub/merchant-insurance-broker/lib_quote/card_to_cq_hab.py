import datetime
import logging
import math
import uuid
from abc import ABC
from datetime import datetime

import moment

from lib_common import constants
from lib_common.constants import LOGGER
from lib_persistence import location as persist_loc
from lib_quote.card_to_cq import CardToCQ

log = logging.getLogger(LOGGER)

ACORD_VERSION = 1180
DEFAULT_NUM_BATHROOMS = 1
DEFAULT_YEAR_BUILT = "20000101"
DEFAULT_FIREHALL_DIST = 5
DEFAULT_HYDRANT_DIST = 150
DEFAULT_TOTAL_FLOOR_AREA = 1200
DEFAULT_HOME_VALUE = 350000
DEFAULT_YEARS_INSURED = 10


class CardToCQHab(CardToCQ, ABC):
    def __init__(self, config, quick_quote, quote_support):
        CardToCQ.__init__(self, config, quick_quote, quote_support)

    def to_cq_json(self, quoting_province, card_json):
        acord_output = self.map_hab_request(quoting_province, card_json)
        return acord_output

    def map_hab_request(self, quoting_province, card_json):
        carrier_config = self._config["carriers"]

        if carrier_config is None:
            self._error("No carriers for " + quoting_province + " have been configured")
            return

        # Rating web service will have a single carrier. Rate bridge will have a map
        # of possibly many carriers.
        if type(carrier_config) is str:
            carriers = [carrier_config]
        elif type(carrier_config) is list:
            carriers = carrier_config
        else:
            carriers = list(carrier_config.keys())

        individuals = [item for item in card_json.values() if self._value(item, "type", data_type=str) == "individual"]

        if len(individuals) == 0:
            self._error("No individuals in request")
            return

        properties = [item for item in card_json.values() if self._value(item, "type", data_type=str) == "property"]

        if len(properties) == 0:
            self._error("No properties in request")
            return

        insured = individuals[0]
        consent = "Y" if self._field(insured, "consent_to_credit_check", data_type=bool, level="none") else "Y"
        claims = [
            self.map_hab_claim(claim, i)
            for prop in properties
            for i, claim in enumerate(self._value(prop, ["history", "claims"], default=[], level="none"))
        ]
        dwellings = [self.map_property_node(dwell, i, claims) for i, dwell in enumerate(properties)]

        return {
            "QuoteGUID": str(uuid.uuid1()), "QuoteIterationGUID": str(uuid.uuid1()),
            "xmlparam_FortusTransaction": {
                "FortusTransaction": {
                    "@Type": "Property2",
                    "@xmlns": "",
                    "Carriers": {"Carrier": carriers},
                    "EffDate": moment.now().format("YYYYMMDD"),
                    "Province": quoting_province,
                    "Renewal": "NO",
                    "CodeNames": {
                        "Property": {
                            "QuoteInfo": {
                                "ContractNumber": self.get_contract(carrier_config),
                                "ID": "QuoteInfo1",
                                "Origin": "",
                                "Business": "N",
                                "Dwelling": dwellings,
                                "Insured": insured,
                                "Discount": [
                                    {"Applied": "Y", "DiscountType": "MatureHomeowner", "ID": "DIS-1"},
                                    {"Applied": "Y", "DiscountType": "ClaimsFree", "ID": "DIS-2"},
                                ],
                            },
                        },
                    },
                },
            },
            "xmlparam_ExtendedInput": {
                "FortusTransaction": {
                    "@Type": "Property2",
                    "@xmlns": "",
                    "Province": quoting_province,
                    "Renewal": "NO",
                    "CodeNames": {
                        "Property": {
                            "QuoteInfo": dwellings,
                        },
                    },
                },
            },
            "xmlparam_CarrierInfo": self.map_carrier_info(carrier_config, consent)
        }

    def map_hab_claim(self, claim, counter):
        claim_type = self.map_claim_type_hab(self._value(claim, "type", data_type=str))

        claim_node = {
            "ID": counter,
            "ClaimDate": moment.date(claim["date"], "YYYY-MM").format("YYYYMMDD"),
            "ClaimType": claim_type,
        }

        return claim_node

    def map_claim_type_hab(self, claim_type):
        return {
            "502": "BI",
            "503": "BURG",
            "505": "PD",
            "506": "PD",
            "534": "CREDITCARD",
            "521": "ERQK",
            "526": "EXPLOSION",
            "547": "FIRE",
            "549": "FOOD",
            "564": "WIND",
            "571": "PD",
            "588": "PD",
            "591": "SEWER",
            "594": "FIRE",
            "595": "OTHER",
            "611": "VAND",
            "627": "WATERDAM",
            "641": "WIND",
            "999": "OTHER",
        }.get(claim_type, "OTHER")

    def map_insured_node(self, individual, iterator):
        years_insured = int(
            self._field(individual, "years_continuously_insured", default="0", data_type=int, level="none"))
        years_insured = DEFAULT_YEARS_INSURED if years_insured is None and self._quick_quote else years_insured

        if years_insured is None:
            self._error("Missing field years_continuously_insured on individual")

        insured_since_date = moment.now().subtract("years", years_insured).format("YYYYMMDD")
        insured = {
            "InsSince": insured_since_date,
            "WithBroker": insured_since_date,
            "HabCo": "HAL",
            "HabCoDate": insured_since_date,
            "ID": f"SNAPIND-{iterator}",
            "NonSmoker": "N",
            "OccupFullTime": "N",
            "Retired": "N",
            "DateOfBirth": datetime.strptime(individual["fields"]["birth_date"], "%B %d,%Y").strftime("%Y%m%d")
        }

        return insured

    def map_property_node(self, prop_node, iterator, claim):
        # Perform a location lookup
        postal_code = self._field(prop_node, "postal_code", data_type=str)
        postal_code = postal_code.replace(" ", "") if postal_code is not None else None

        if postal_code is None:
            self._error("Province could not be determined")
            return

        location_index = persist_loc.lookup_location(postal_code)

        if location_index is None:
            self._error("Location index could not be found for postal code " + postal_code)
            return

        # "InCoverage": 0,
        sewer_backup = {
            "Applied": "Y",
            "CoverageType": "SewerBackup",
            "ID": "SewerBackup1",
            "InDeduct": "-1",
            "InCoverage": "-2",
        }

        overland_water = {
            "Applied": "Y",
            "CoverageType": "OverlandWater",
            "ID": "OverlandWater1",
            "InDeduct": "-1",
            "InCoverage": "-2",
        }

        ground_water = {
            "Applied": "Y",
            "CoverageType": "GroundWater",
            "ID": "GroundWater1",
            "InDeduct": "-1",
            "InCoverage": "-2",
        }

        by_laws = {
            "Applied": "Y",
            "CoverageType": "ByLaws",
            "ID": "ByLaws1",
            "InCoverage": "30000",
        }

        water_damage = {
            "Applied": "Y",
            "CoverageType": "WaterDamage",
            "ID": "WaterDamage1",
            "InDeduct": "-1",
            "InCoverage": "-2",
        }

        id_theft = {
            "Applied": "Y",
            "CoverageType": "IdentityTheft",
            "ID": "IdentityTheft1",
            "InCoverage": "-1",
        }

        fire_charges = {
            "Applied": "Y",
            "CoverageType": "FireDeptCharges",
            "ID": "FireDeptCharges1",
            "InCoverage": "-1",
        }

        claim_free = {
            "Applied": "Y",
            "CoverageType": "ClaimFreeProtection",
            "ID": "ClaimFreeProtection1",
        }

        coverage_array = [
            sewer_backup,
            overland_water,
            ground_water,
            by_laws,
            fire_charges,
            claim_free,
            id_theft,
            water_damage,
        ]

        # Check the package requested (Recommended vs Economical)
        coverage_package_type = self._field(prop_node, "quote_coverage_type",
                                            default=constants.QUOTING_LEVEL_RECOMMENDED, data_type=str, level="info")

        if coverage_package_type.lower() == constants.QUOTING_LEVEL_ECONOMICAL:
            policy_deductible = 1000
            liability = 1000000
        else:
            policy_deductible = 1000
            liability = 2000000

        province_code = self._field(prop_node, "province_code", data_type=str)
        dwell_type = self.map_dwelling_type(self._field(prop_node, "building_type", data_type=str))
        prop_id = self._value(prop_node, "cqID", data_type=str)
        num_beds = self._field(prop_node, "number_bedrooms", default=2, data_type=int)
        pri_res = self._field(prop_node, "primary_residence", default=True, data_type=bool, level="info")
        pri_res = "Y" if pri_res is None or pri_res is True else "N"
        year = moment.now().subtract("years", 10).format("YYYY")
        occupied_date = self._field(prop_node, "occupied_since", default=year, data_type=int)
        occupied_date = str(occupied_date)[0:4] + "0101"
        replacement_cost = self._field(prop_node, "value", default=DEFAULT_HOME_VALUE, data_type=float)
        struct_type = self._field(prop_node, "building_type", data_type=str)
        form_type = 0 if struct_type == "Apartment" or struct_type == "Condo" else 2
        year_built = self._field(prop_node, "year_built", data_type=int)
        year_built = str(year_built)[0:4] + "0101" if year_built is not None else DEFAULT_YEAR_BUILT
        num_mortgage = self._field(prop_node, "number_of_mortgages", default=1, data_type=int)
        num_stories = self._field(prop_node, "num_stories", default=1, data_type=float)
        square_footage = self._field(prop_node, "square_footage", default=DEFAULT_TOTAL_FLOOR_AREA, data_type=int)
        res_value = self._field(prop_node, "value", default=DEFAULT_HOME_VALUE, data_type=float)
        num_bathrooms = self._field(prop_node, "number_bathrooms", DEFAULT_NUM_BATHROOMS, data_type=float)
        half_baths, full_baths = math.modf(num_bathrooms)
        temp_up_date = moment.now().subtract("years", 10).format("YYYYMMDD")
        hydrant_distance = self._field(prop_node, "distance_to_hydrant", default=DEFAULT_HYDRANT_DIST, data_type=int)
        firehall_dist = self._field(prop_node, "fire_station_distance", default=DEFAULT_FIREHALL_DIST, data_type=int)

        property_node = {
            "CityName": location_index[0],
            "Claim": claim,
            "Coverage": self.map_coverage(dwell_type, res_value),
            "Deduct": policy_deductible,
            "DwellingDate": year_built,
            "DwellingType": dwell_type,
            "FHDist": firehall_dist,
            "GBRC": "Y",
            "ID": prop_id,
            "Liab": liability,
            "NumFam": "1",
            "NumMortgage": num_mortgage,
            "NumStoreys": num_stories,
            "NumUnits": 1,
            "OB": -1,
            "PostalCode": postal_code.upper(),
            "PP": -1,  # cova_limit,
            "ProtectionClass": self.map_protection_class(firehall_dist, hydrant_distance),
            "Value": replacement_cost,
            "RoofDate": temp_up_date,
            "RoofType": self.map_roof_type(self._field(prop_node, "roof_type", data_type=str)),
            "RoofRenoPerc": 100,
            "EvalTool": 21,
            "LastHomeEvaluation": "20210507",
            "ElectDate": temp_up_date,
            "ElectType": "COPPER",
            "ElectServ": "200 AMP",
            "ElectRenoPerc": 100,
            "WaterHeaterDate": "20150101",
            "ElectPanelType": "BREAKERS",
            "PlumbDate": temp_up_date,
            "PlumbType": "COPPER_PVC",
            "PlumbRenoPerc": 100,
            "BsmtApt": "N",
            "BlockWatch": "N",
            "WalledCom": "N",
            "WindowBars": "N",
            "Dog": "N",
            "DeadBolt": "N",
            "SumpPumpAlarmed": "N",
            "SumpPumpPit": "N",
            "BackflowValve": "NONE",
            "Inlaw": "N",
            "SepticSystem": "N",
            "Sprinkler": "NONE",
            "FireExt": 1,
            "InsuredOcc": pri_res,
            "Structure": self.map_structure(struct_type),
            "LivingAreaMeasure": "F",
            "TotalLivingArea": square_footage,
            "Construction": self.map_construction(self._field(prop_node, "exterior", data_type=str)),
            "ExteriorFinish": self.map_exterior_finish(self._field(prop_node, "exterior", data_type=str)),
            "SmokeDetectors": int(num_stories),
            "OccSince": occupied_date,
            "NumFullBaths": full_baths,
            "NumBedrooms": num_beds,
            "NumHalfBaths": half_baths,
            "Garage": self.map_garage_type(self._field(prop_node, "garage", data_type=str)),
            "GarageCars": 2,
            "PoolType": self.map_pool_type(self._field(prop_node, "pool", data_type=str)),
            "FormType": form_type,
            "LocationIndex": location_index[1],
            "HydDist": hydrant_distance,
            "SglLimit": "Y",
            "HailDeduct": -1,
            "WaterDeduct": -1,
            "WindDeduct": -1,
            "Prov": province_code,
            # Street Address is required by Intact
            "StreetAddress": self._field(prop_node, "address", data_type=str),

            "Heating": {
                "Approved": "Y",
                "HeatingType": self.map_heating_type(self._field(prop_node, "heat_type", data_type=str)),
                "ID": f"HeatingTypePrimary-{iterator}",
                "Primary": "Y",
                "HeatingDate": temp_up_date,
            },

            "ExtCov": coverage_array,

            # "BurgAlarm" : "",
            # "FireAlarm": "",
            # "FireExt": "",
            # "Sprinkler": "",
            # "DeadBolt" : "",
            # "WalledCom" : "",
            # "BsmtFinishPerc": "100",
            # "TotalBsmtArea": "1400",
        }

        return property_node

    def map_dwelling_type(self, building_type):
        return_string = "H"

        # If it's the first building we'll consider it primary
        if building_type is not None:
            building_type_lower = building_type.lower()

            if building_type_lower in ["house", "duplex", "triplex", "row/townhouse", "semi/duplex"]:
                return_string = "H"
            elif building_type_lower in ["apartment", "condo"]:
                return_string = "C"

        return return_string

    def map_heating_type(self, heat_type):
        return_string = "ELECTRIC"

        if heat_type is not None:
            heat_type_lower = heat_type.lower()
            if heat_type_lower == "none":
                return_string = "NONE"
            elif heat_type_lower == "gas":
                return_string = "CENTRAL FURNACE - GAS"
            elif heat_type_lower == "propane":
                return_string = "CENTRAL FURNACE - PROPANE"
            elif heat_type_lower == "electric":
                return_string = "ELECTRIC"
            elif heat_type_lower == "wood":
                return_string = "WOOD BURNING STOVE"
            elif heat_type_lower == "pellets":
                return_string = "SF_P"
            elif heat_type_lower == "solar":
                return_string = "SOLAR"
            elif heat_type_lower == "radiant":
                return_string = "SPACE HEATER - ELECTRIC"
            elif heat_type_lower == "oil":
                return_string = "CENTRAL FURNACE - OIL"
            elif heat_type_lower == "other":
                return_string = "OTHER"

        return return_string

    def map_protection_class(self, firehall_distance, hydrant_distance):
        # If either field is missing, return Unprotected
        if firehall_distance is None or hydrant_distance is None:
            return "U"

        if firehall_distance < 10 and hydrant_distance <= 300:
            return "P"
        elif firehall_distance < 20 and hydrant_distance <= 600:
            return "S"

        return "U"

    def map_roof_type(self, roof_type):
        return_string = "ASPHALT SHINGLES"

        if roof_type is not None:
            if roof_type == "Asphalt":
                return_string = "ASPHALT SHINGLES"
            elif roof_type == "Clay Tile":
                return_string = "CLAY TILE"
            elif roof_type == "Concrete":
                return_string = "CONCRETE TILE"
            elif roof_type == "Copper":
                return_string = "METAL TILE"
            elif roof_type == "Slate Tile":
                return_string = "SLATE TILE"
            elif roof_type == "Steel":
                return_string = "CORRUGATED STEEL"
            elif roof_type == "Tar and Gravel":
                return_string = "TAR AND GRAVEL"
            elif roof_type == "Wood Shingles":
                return_string = "WOOD SHINGLES"

        return return_string

    def map_structure(self, struct):
        return_string = "DETACHED"

        if struct is not None:
            if struct == "House":
                return_string = "DETACHED"
            elif struct == "Duplex":
                return_string = "SEMI DETACHED"
            elif struct == "Triplex":
                return_string = "TRIPLEX"
            elif struct == "Row/Townhouse":
                return_string = "TOWNHOUSE"

        return return_string

    def map_construction(self, ext_code):
        return_string = "FRAME"

        if ext_code is not None:
            if ext_code == "Brick Veneer" or ext_code == "Brick":
                return_string = "FRAME"
            elif ext_code == "Concrete":
                return_string = "CBLOCK"
            elif ext_code == "Logs":
                return_string = "LOG"
            elif ext_code == "Stone" or ext_code == "Stucco" or ext_code == "Vinyl" or ext_code == "Wood" \
                    or ext_code == "Wood Siding":
                return_string = "FRAME"

        return return_string

    def map_exterior_finish(self, ext_code):
        return_string = "VNYL"

        if ext_code is not None:
            if ext_code == "Brick Veneer":
                return_string = "BRVN"
            elif ext_code == "Brick":
                return_string = "BRIC"
            elif ext_code == "Concrete":
                return_string = "CONC"
            elif ext_code == "Logs":
                return_string = "LGSD"
            elif ext_code == "Stone":
                return_string = "STON"
            elif ext_code == "Stucco":
                return_string = "STUCCO"
            elif ext_code == "Vinyl":
                return_string = "VNYL"
            elif ext_code == "Wood" or ext_code == "Wood Siding":
                return_string = "WOOD"

        return return_string

    def map_garage_type(self, garage):
        return_string = "0"

        if garage is not None:
            if garage == "Attached":
                return_string = 4
            elif garage == "Detached":
                return_string = 6
            elif garage == "Carport":
                return_string = 3
            elif garage == "Built-in":
                return_string = 1

        return return_string

    def map_pool_type(self, pool):
        return_string = "None"

        if pool is not None:
            if pool == "Above Ground":
                return_string = "AG_F"
            elif pool == "In-Ground":
                return_string = "IG_F"

        return return_string

    def map_coverage(self, dwell_type, value):
        if value is None:
            value = ""

        return value
