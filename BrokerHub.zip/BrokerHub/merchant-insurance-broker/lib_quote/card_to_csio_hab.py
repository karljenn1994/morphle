import logging
import math
import uuid
from abc import ABC
from datetime import datetime, timezone

import moment
import xmltodict

from lib_common import constants
from lib_common.constants import LOGGER
from lib_quote.card_to_csio import CardToCSIO

log = logging.getLogger(LOGGER)

ACORD_VERSION = 1180
DEFAULT_NUM_BATHROOMS = 1
DEFAULT_DISTANCE_TO_HYDRANT = 150
DEFAULT_FIREHALL_DISTANCE = 5
DEFAULT_TOTAL_FLOOR_AREA = 2000
DEFAULT_YEAR_BUILT = 2000
DEFAULT_HOME_VALUE = 350000


class CardToCSIOHab(CardToCSIO, ABC):
    def __init__(self, config, quick_quote, quote_support):
        CardToCSIO.__init__(self, config, quick_quote, quote_support)

    def to_csio_xml(self, card_json):
        acord_output = {
            "@xmlns": "http://www.ACORD.org/standards/PC_Surety/ACORD1/xml/",
            "@xmlns:csio": "http://www.CSIO.org/standards/PC_Surety/CSIO1/xml/",
            "SignonRq": {
                "SignonPswd": {
                    "CustId": {
                        "SPName": "wawanesa.com",
                        "CustLoginId": self._config["api_username"],
                    },
                    "CustPswd": {
                        "EncryptionTypeCd": "NONE",
                        "Pswd": self._config["api_password"],
                    },
                },
                "ClientDt": moment.now().format("YYYY-MM-DDTHH:mm:ssZ"),
                "CustLangPref": "en",
                "ClientApp": {
                    "Org": "Brunvalley",
                    "Name": "Snapably",
                    "Version": 1,
                },
            },
            "InsuranceSvcRq": {
                "RqUID": str(uuid.uuid1()),
            },
        }

        acord_output["InsuranceSvcRq"]["HomePolicyQuoteInqRq"] = self.map_hab_request(card_json)
        return xmltodict.unparse({"ACORD": acord_output}, full_document=False)

    def get_dwell(self, card_json):
        for item in card_json.values():
            if self._value(item, "type") == "property":
                return item

    def map_garage_type_cd(self, garage_type):
        return {
            "None": "0",
            "Attached": "4",
            "Detached": "6",
            "Carport": "3",
            "Built-in": "1",
        }.get(garage_type, "")

    def map_hab_request(self, card_json):
        contract_number = self.get_contract_number(card_json)
        insured_or_principals = []
        individuals = [item for item in card_json.values() if self._value(item, "type", data_type=str) == "individual"]

        for i, individual in enumerate(individuals):
            relation_to_insured = "csio:S"

            # If this is the first individual, use csio:5 otherwise csio:13
            if i == 0:
                relation_to_insured = "csio:I"

            insured_or_principals.append(
                self.map_insured_or_principal(card_json, individual, relation_to_insured, "habl"))

        home_policy_quote_inq_rq = {
            "RqUID": str(uuid.uuid1()), "BusinessPurposeTypeCd": "csio:NBQ",
            "TransactionRequestDt": self.format_acord_datetime(datetime.now(timezone.utc)) or "",
            "TransactionEffectiveDt": self.format_acord_datetime(moment.utcnow().add("years", 1).date) or "",
            "CurCd": "CAD",
            "ACORDStandardVersionCd": ACORD_VERSION, "Producer": {
                "ProducerInfo": {
                    "ContractNumber": contract_number,
                },
            },
            "InsuredOrPrincipal": insured_or_principals,
            "PersPolicy": self.map_pers_policy(card_json),
            "Location": self.map_location_hab(card_json),
            "HomeLineBusiness": self.map_home_line_business(card_json)
        }

        return home_policy_quote_inq_rq

    def map_pers_policy(self, card_json):
        primary_individual = self.get_primary_individual(card_json)

        try:
            years_insured = self._field(primary_individual, "years_continuously_insured", data_type=int)
            years_insured = int(years_insured) if years_insured is not None else -1
            years_insured += years_insured if years_insured > -1 else 0
        except ValueError:
            years_insured = 0
            self._warn("Coverage years_continuously_insured is not a float")

        if years_insured is None:
            years_insured = 0

        policy_start_date = moment.now().subtract("years", years_insured)
        losses = self.get_all_losses(card_json)
        loss_conviction_array = [*losses] if losses is not None else []

        pers_policy = {
            "LOBCd": f"csio:HABL",
            "ContractTerm": {
                "EffectiveDt": moment.now().format("YYYY-MM-DD"),
                "ExpirationDt": moment.now().add("years", 1).format("YYYY-MM-DD"),
            },
            "BillingMethodCd": "csio:A",
            "RateEffectiveDt": moment.now().format("YYYY-MM-DD"),
            "OtherOrPriorPolicy": {
                "InsurerName": "No Previous Insurance",
                "LOBCd": f"csio:HABL",
                "csio:CompanyCd": "NONE",
            },
            "PolicyTermCd": "annual",
            "OriginalPolicyInceptionDt": self.format_acord_datetime(moment.date(policy_start_date).date) or "",
            "csio:CompanyCd": "WAWA",
            "PersApplicationInfo": {
                "KnownSinceDt": moment.now().subtract("years", 10).format("YYYY-MM-DD"),
                "csio:PrincipalDriverKnownByAgentBroker": {
                    "EffectiveDt": moment.now().subtract("years", 10).format("YYYY-MM-DD"),
                },
            },
            "AccidentViolation": loss_conviction_array,
        }

        return pers_policy

    def map_location_hab(self, card_json):
        primary_individual = self.get_primary_individual(card_json)
        dwell = self.get_dwell(card_json)

        location = {
            "@id": "LOC-1",
            "ItemIdInfo": {
                "ItemIdInfo": {
                    "AgencyId": self._field(primary_individual, "last_name", default="", data_type=str) + "-01",
                },
            },
            "Addr": {
                "AddrTypeCd": "csio:10",
                "Addr1": self._field(dwell, "address", default="", data_type=str),
                "City": self._field(dwell, "city", default="", data_type=str),
                "StateProvCd": self._field(dwell, "province_code", default="", data_type=str),
                "PostalCode": self._field(dwell, "postal_code", default="", data_type=str),
                "CountryCd": "CA",
            },
        }

        return location

    def map_dwell(self, card_json):
        dwell = self.get_dwell(card_json)
        year_built = str(self._field(dwell, "year_built", default=DEFAULT_YEAR_BUILT, data_type=int))[0:4] + "-01-01"

        primary_heat = self.map_heating_unit_info(self._field(dwell, "heat_type", data_type=str), "csio:PRI")
        secondary_heat = self._field(dwell, "secondary_heat_type", data_type=str, level="none")

        if secondary_heat is not None and secondary_heat != "" and secondary_heat != "None":
            secondary_heat = self.map_heating_unit_info(self._field(dwell, "secondary_heat_type", data_type=str),
                                                        "csio:AUX")

        if primary_heat is not None and secondary_heat is not None:
            heating_info = [primary_heat, secondary_heat]
        else:
            heating_info = primary_heat

        # Check the package requested (Recommended vs Economical)
        coverage_package_type = self._field(dwell, "quote_coverage_type", default=constants.QUOTING_LEVEL_RECOMMENDED,
                                            data_type=str, level="info")

        if coverage_package_type.lower() == constants.QUOTING_LEVEL_ECONOMICAL:
            policy_deductible = 1000
            liability = 1000000
        else:
            policy_deductible = 1000
            liability = 2000000

        cov_hsl = {
            "CoverageCd": "csio:HSL",
            "CoverageDesc": "Single Inclusive Limit",
        }

        cov_guarr = {
            "CoverageCd": "csio:GUARR",
            "CoverageDesc": "Guaranteed Replacement Cost",
        }

        cov_pp = {
            "CoverageCd": "csio:PP",
            "CoverageDesc": "Personal Property (C)",
        }

        home_value = self._field(dwell, "value", default=DEFAULT_HOME_VALUE, data_type=float, level="warn")

        cov_dwell = {
            "CoverageCd": "csio:DWELL",
            "CoverageDesc": "Dwelling (A)",
            "Limit": {
                "FormatCurrencyAmt": {
                    "Amt": home_value,
                    "CurCd": "CAD",
                },
            },
        }

        cov_pl = {
            "CoverageCd": "csio:PL",
            "CoverageDesc": "Liability (E)",
            "Limit": {
                "FormatCurrencyAmt": {
                    "Amt": liability,
                    "CurCd": "CAD",
                },
            },
        }

        sewer_backup = {
            "CoverageCd": "csio:SEWER",
            "CoverageDesc": "Sewer Back-up Coverage",
            "Limit": {
                "FormatCurrencyAmt": {
                    "Amt": "-1",
                    "CurCd": "CAD",
                },
            },
        }

        overland_water = {
            "CoverageCd": "csio:FLOOD",
            "CoverageDesc": "Flood Damage (Surface Water)",
        }

        ground_water = {
            "CoverageCd": "csio:WATER",
            "CoverageDesc": "Water Damage Endorsement",
        }

        bylaws = {
            "CoverageCd": "csio:ByLaws",
            "CoverageDesc": "Bylaws Endorsement",
        }

        # TODO: What's up here?
        # water_damage = {
        #     "CoverageCd": "csio:SEWER",
        #     "CoverageDesc": "Sewer Back-up Coverage",
        # }

        claim_free = {
            "CoverageCd": "csio:CLFRE",
            "CoverageDesc": "Claim Free Protection",
        }

        homeowners_package_wawanesa = {
            "csio:PackageCoverageName": "HO_PackageCov",
            "csio:PackageCoverageCompanyCd": "HO_PackageCov",
            "CoverageDesc": "Package",
            "Deductible": {
                "FormatCurrencyAmt": {
                    "Amt": policy_deductible,
                    "CurCd": "CAD",
                },
            },
        }

        coverage_array = [
            cov_hsl,
            cov_guarr,
            cov_pp,
            cov_dwell,
            cov_pl,
            sewer_backup,
            overland_water,
            bylaws,
            claim_free,
            ground_water,
            homeowners_package_wawanesa,
        ]

        exterior_wall = self.map_exterior_wall_material_cd(self._field(dwell, "exterior", data_type=str))
        exterior_wall = exterior_wall.replace("csio:", "")

        num_bathrooms = self._field(dwell, "number_bathrooms", DEFAULT_NUM_BATHROOMS, data_type=float)
        half_baths, full_baths = math.modf(num_bathrooms)

        # TODO: Why is this not used.
        # full_bath_json = {
        #     "BathroomInfo": {
        #         "NumBathrooms": full_baths,
        #         "BathroomTypeCd": "Full",
        #     },
        # }
        #
        # half_bath_json = {
        #     "BathroomInfo": {
        #         "NumBathrooms": half_baths,
        #         "BathroomTypeCd": "Half",
        #     },
        # }

        dwell_value = self._field(dwell, "value", data_type=float, level="warn")
        foundation_type = self.map_foundation_type_cd(self._field(dwell, "foundation_type", data_type=str))
        improvement_year = moment.now().subtract("years", 10).format("YYYY-MM-DD")

        if year_built > improvement_year:
            improvement_year = year_built

        hydrant_dist = self._field(dwell, "distance_to_hydrant", default=DEFAULT_DISTANCE_TO_HYDRANT, data_type=int)
        fire_hall_dist = self._field(dwell, "fire_station_distance", default=DEFAULT_FIREHALL_DISTANCE, data_type=int)
        square_footage = self._field(dwell, "square_footage", default=DEFAULT_TOTAL_FLOOR_AREA, data_type=int)
        yr_occupied = str(self._field(dwell, "occupied_since", default=moment.now().format("YYYY"),
                                      data_type="int"))[0:4] + "-01-01"

        home_line_business = {
            "@id": "DWL-1",
            "@LocationRef": "LOC-1",
            "PrincipalUnitAtRiskInd": "1",
            "PolicyTypeCd": "csio:4",
            "PurchasePriceAmt": dwell_value,
            "Construction": {
                "ConstructionCd": self.map_construction_cd(self._field(dwell, "exterior")),
                "YearBuilt": year_built,
                "FoundationCd": "csio:" + str(foundation_type),
                "BldgArea": {
                    "NumUnits": square_footage,
                    "UnitMeasurementCd": "sqft",
                },
                "NumStories": self._field(dwell, "num_stories"),
                "RoofingMaterial": {
                    "RoofMaterialCd": "csio:" + self.map_roof_material_cd(self._field(dwell, "roof_type")),
                    "RoofMaterialPct": "100",
                },
                "ExteriorWallMaterialInfo": {
                    "ExteriorWallMaterialCd": exterior_wall,
                    "ExteriorWallMaterialPct": "100",
                },
            },
            "DwellOccupancy": {
                "YearOccupancy": yr_occupied,
                "NumApartments": "1",
                "ResidenceTypeCd": "csio:" + self.map_residence_type_cd(self._field(dwell, "building_type")),
                "DwellUseCd": "csio:1",
                "OccupancyTypeCd": "csio:1",
            },
            "DwellRating": {},
            "BldgProtection": {
                "DistanceToFireStation": {
                    "NumUnits": fire_hall_dist,
                    "UnitMeasurementCd": "KMT",
                },
                "DistanceToHydrant": {
                    "NumUnits": hydrant_dist,
                    "UnitMeasurementCd": "MTR",
                },
            },
            "BldgImprovements": {
                "HeatingImprovementCd": "C",
                "HeatingImprovementYear": improvement_year,
                "PlumbingImprovementCd": "C",
                "PlumbingImprovementYear": improvement_year,
                "RoofingImprovementCd": "C",
                "RoofingImprovementYear": improvement_year,
                "WiringImprovementCd": "C",
                "WiringImprovementYear": improvement_year,
            },
            "DwellInspectionValuation": {
                "DwellStyleCd": "BASIC",
                "EstimatedReplCostAmt": {
                    "Amt": dwell_value,
                    "CurCd": "CAD",
                },
                "NumFamilies": 1,
                "BathroomInfo": {
                    "NumBathrooms": full_baths,
                    "BathroomTypeCd": "Full",
                },
                "TotalLivingArea": {
                    "NumUnits": square_footage,
                    "UnitMeasurementCd": "FTK",
                },
                "SubstructureInfo": {
                    "FinishedBasementInfo": {
                        "FinishedBasementPct": self._field(dwell, "basement_finished"),
                    },
                },
            },
            "Coverage": coverage_array,
            "HeatingUnitInfo": heating_info
        }

        # Pool details
        pool = self._field(dwell, "pool", level="info")

        if pool is not None and pool.upper() != "NONE":
            home_line_business["SwimmingPool"] = {
                "AboveGroundInd": "1" if pool == "Above Ground" else "0",
                "ApprovedFenceInd": "Y",
                "IndoorCd": "N",
            }

        # Garage Details
        garage_doors = self._field(dwell, "number_garage_doors", level="info")
        garage = self._field(dwell, "garage", level="info")

        if garage_doors is not None and garage_doors != "" and garage is not None and garage != "":
            home_line_business["GarageInfo"] = {
                "GarageTypeCd": self.map_garage_type_cd(garage),
                "NumGarages": garage_doors,
            }

        return home_line_business

    def map_home_line_business(self, card_json):
        dwell = self.map_dwell(card_json)

        # These coverages need to be applied at the HomeLineBusiness level
        id_theft = {
            "CoverageCd": "csio:IDTFT",
            "CoverageDesc": "Identity Theft",
        }

        fire_charges = {
            "CoverageCd": "csio:FDC",
            "CoverageDesc": "Fire Department Service Charges",
        }

        coverage_array = [id_theft, fire_charges]

        home_line_business = {
            "LOBCd": "csio:HABL",
            "Dwell": dwell,
            "Coverage": coverage_array,
        }

        return home_line_business

    def map_heating_unit_info(self, heating_field, heating_use_type):
        fuel_type_cd = None
        heating_unit_cd = None

        if heating_field is not None:
            heating_field_lower = heating_field.lower()

            if heating_field_lower in ["natural gas", "gas"]:
                heating_unit_cd = "csio:F"
                fuel_type_cd = "csio:N"
            elif heating_field_lower == "propane":
                heating_unit_cd = "csio:F"
                fuel_type_cd = "csio:P"
            elif heating_field_lower == "electric":
                heating_unit_cd = "csio:K"
                fuel_type_cd = "csio:Y"
            elif heating_field_lower == "wood":
                heating_unit_cd = "csio:F"
                fuel_type_cd = "csio:W"
            elif heating_field_lower == "wood pellets":
                heating_unit_cd = "csio:2"
                fuel_type_cd = "csio:T"
            elif heating_field_lower == "solar":
                heating_unit_cd = "csio:K"
                fuel_type_cd = "csio:R"
            elif heating_field_lower == "radiant heat":
                heating_unit_cd = "csio:8"
                fuel_type_cd = "csio:Y"
            elif heating_field_lower == "oil":
                heating_unit_cd = "csio:F"
                fuel_type_cd = "csio:I"
            elif heating_field_lower == "other":
                heating_unit_cd = "csio:O"
                fuel_type_cd = "csio:O"

        heating_unit_info = {
            "FuelTypeCd": fuel_type_cd,
            "HeatingUnitCd": heating_unit_cd,
            "UseCd": heating_use_type,
        }

        return heating_unit_info

    def map_exterior_wall_material_cd(self, value_cd):
        return_string = ""

        if value_cd is not None:
            value_lower = value_cd.lower()

            if value_lower in ["brick veneer", "brick"]:
                return_string = "csio:B"
            elif value_lower == "concrete":
                return_string = "csio:D"
            elif value_lower == "fiber cement":
                return_string = "csio:C"
            elif value_lower == "log":
                return_string = "csio:1"
            elif value_lower == "stone":
                return_string = "csio:S"
            elif value_lower == "stucco":
                return_string = "csio:O"
            elif value_lower in ["vinyl siding", "vinyl"]:
                return_string = "csio:Y"
            elif value_lower == "wood siding":
                return_string = "csio:U"

        return return_string

    def map_foundation_type_cd(self, foundation_type):
        return_value = 1

        if foundation_type is not None:
            foundation_type_lower = foundation_type.lower()

            if foundation_type_lower == "basement":
                return_value = 1
            elif foundation_type_lower == "crawlspace":
                return_value = 7
            elif foundation_type_lower == "pier":
                return_value = 5
            elif foundation_type_lower == "slab on grade":
                return_value = 8
            elif foundation_type_lower == "walkout basement":
                return_value = 1

        return return_value

    def map_construction_cd(self, value_cd):
        return_string = ""

        if value_cd is not None:
            value_lower = value_cd.lower()

            if value_lower == "brick veneer":
                return_string = "csio:F"
            elif value_lower == "brick":
                return_string = "csio:B"
            elif value_lower == "concrete":
                return_string = "csio:D"
            elif value_lower == "fiber cement":
                return_string = "csio:F"
            elif value_lower == "log":
                return_string = "csio:1"
            elif value_lower == "stone":
                return_string = "csio:F"
            elif value_lower == "stucco":
                return_string = "csio:F"
            elif value_lower in ["vinyl siding", "vinyl"]:
                return_string = "csio:F"
            elif value_lower == "wood siding":
                return_string = "csio:F"

        return return_string

    def map_residence_type_cd(self, residence_type):
        return {
            "House": "DT",
            "Duplex": "DX",
            "Triplex": "TX",
            "Row/Townhouse": "RH",
            "Apartment": "AP",
            "Condo": "AP",
        }.get(residence_type, "")

    def map_roof_material_cd(self, roof_material):
        return {
            "Asphalt": "A",
            "Clay Tile": "C",
            "Concrete": "N",
            "Copper": "O",
            "Slate Tile": "S",
            "Steel": "L",
            "Tar and Gravel": "T",
            "Tin": "O",
            "Wood": "X",
        }.get(roof_material, "")
