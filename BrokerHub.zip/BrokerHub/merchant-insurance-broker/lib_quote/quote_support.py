from lib_quote.quote_log import QuoteLog
from lib_quote.quote_result import QuoteStatus
from lib_quote.quote_transformation_support import QuoteTransformationSupport


class QuoteSupport(object):
    def __init__(self):
        self._quote_result = {
            "status": QuoteStatus.NONE,
            "messages": [],
        }

        self._tracking_number = None
        self._quote_log = QuoteLog()
        self._transformation_support = QuoteTransformationSupport(self._quote_log)
        self.value = self._transformation_support.value
        self.field = self._transformation_support.field
        self.error = self._quote_log.log_error
        self.info = self._quote_log.log_info
        self.warn = self._quote_log.log_warn
        self.log = self._quote_log.log

    def append_quote(self, quote_result):
        if "quote_results" not in self._quote_result:
            self._quote_result["quote_results"] = []

        self.quote_result["quote_results"].append(quote_result)

    @property
    def provider(self):
        return self._quote_result["provider"]

    @provider.setter
    def provider(self, provider):
        self._quote_result["provider"] = provider

    @property
    def transformation_support(self):
        return self._transformation_support

    @property
    def quote_log(self):
        return self._quote_log

    @property
    def insurer(self):
        return self._quote_result["insurer"]

    @insurer.setter
    def insurer(self, insurer):
        self._quote_result["insurer"] = insurer

    @insurer.setter
    def insurer_description(self, insurer):
        self._quote_result["insurer_description"] = insurer

    @property
    def total_premium(self):
        return self._quote_result["total_premium"]

    @total_premium.setter
    def total_premium(self, total_premium):
        self._quote_result["total_premium"] = total_premium

    @property
    def tracking_number(self):
        return self._quote_result["tracking_number"]

    @tracking_number.setter
    def tracking_number(self, number):
        self._quote_result["tracking_number"] = number

    @property
    def status(self):
        return self._quote_result["status"]

    @status.setter
    def status(self, status):
        self._quote_result["status"] = status

    @property
    def messages(self):
        return self._quote_result["messages"]

    @messages.setter
    def messages(self, messages):
        self._quote_result["messages"] = messages

    def append_message(self, message):
        if "messages" not in self._quote_result:
            self._quote_result["messages"] = []

        self._quote_result["messages"].append(message)

    @property
    def coverages(self):
        return self._quote_result["coverages"]

    @coverages.setter
    def coverages(self, coverages):
        self._quote_result["coverages"] = coverages

    def append_coverage(self, coverage):
        if "coverages" not in self._quote_result:
            self._quote_result["coverages"] = []

        self._quote_result["coverages"].append(coverage)

    @property
    def discounts(self):
        return self._quote_result["discounts"]

    @discounts.setter
    def discounts(self, discounts):
        self._quote_result["discounts"] = discounts

    def append_discount(self, discount):
        if "discounts" not in self._quote_result:
            self._quote_result["discounts"] = []

        self._quote_result["discounts"].append(discount)

    @property
    def insured_items(self):
        return self._quote_result["insured_items"]

    @insured_items.setter
    def insured_items(self, insured_items):
        self._quote_result["insured_items"] = insured_items

    def add_insured_item(self, iid, insured_item):
        if "insured_items" not in self._quote_result:
            self._quote_result["insured_items"] = {}

        self._quote_result["insured_items"][iid] = insured_item

    @property
    def quote_result(self):
        return self._quote_result
