import logging
import uuid
from abc import ABC
from datetime import datetime, timezone

import moment
import xmltodict

from lib_common.constants import LOGGER
from lib_quote.quote_result import QuoteStatus
from lib_policy_dom.JSON import JSON
from lib_quote.card_to_csio import CardToCSIO
from dateutil.relativedelta import relativedelta

log = logging.getLogger(LOGGER)

ACORD_VERSION = 1180
DEFAULT_LICENCE_CLASS = "5"


class CardToCSIOAuto(CardToCSIO, ABC):
    def __init__(self, config, quick_quote, quote_support):
        CardToCSIO.__init__(self, config, quick_quote, quote_support)

    def to_csio_xml(self, card_json):
        acord_output = {
            "@xmlns": "http://www.ACORD.org/standards/PC_Surety/ACORD1/xml/",
            "@xmlns:csio": "http://www.CSIO.org/standards/PC_Surety/CSIO1/xml/",
            "SignonRq": {
                "SignonPswd": {
                    "CustId": {
                        "SPName": "wawanesa.com",
                        "CustLoginId": self._config["api_username"],
                        },
                    "CustPswd": {
                        "EncryptionTypeCd": "NONE",
                        "Pswd": self._config["api_password"],
                        },
                    },
                "ClientDt": moment.now().format("YYYY-MM-DDTHH:mm:ssZ"),
                "CustLangPref": "en",
                "ClientApp": {
                    "Org": "Brunvalley",
                    "Name": "Snapably",
                    "Version": 1,
                    },
                },
            "InsuranceSvcRq": {
                "RqUID": str(uuid.uuid1()),
                },
            }

        acord_output["InsuranceSvcRq"]["PersAutoPolicyQuoteInqRq"] = self.map_auto_request(card_json)
        return xmltodict.unparse({
            "ACORD": acord_output
            }, full_document=False)

    def get_primary_driver(self, card_json, vehicle):
        # Find the primary driver - For a quick quote, we use the first individual
        primary_driver_id = self._value(vehicle, "primary_driver", data_type=str)
        primary_driver = None

        if primary_driver_id is not None:
            primary_driver = card_json[primary_driver_id]

        # TODO: This should only be done for quick quoting
        if primary_driver is None:
            for entry in card_json.values():
                if entry["type"] == "individual":
                    primary_driver = entry
                    self._error("Defaulting primary driver to first individual")
                    break

        if primary_driver is None:
            self._error("Missing primary driver for vehicle.")
            self._quote_support.status = QuoteStatus.FAILED

        return primary_driver

    def get_accident_violations(self, card_json):
        accidents = []

        for item in card_json.values():
            if self._value(item, "type") != "individual":
                continue

            if item.get("history") is None:
                continue

            if item["history"].get("tickets") is not None:
                for ticket in item["history"]["tickets"]:
                    accidents.append({
                        "ConvictionDt": f'{self._value(ticket, "date", tag="AccidentViolation")}-01',
                        "AccidentViolationCd": f'csio:{self._value(ticket, "type", tag="AccidentViolation")}',
                        })

            if item["history"].get("convictions") is not None:
                for conviction in item["history"]["convictions"]:
                    accidents.append({
                        "AccidentViolation": {
                            "ConvictionDt": f'{self._value(conviction, "date", tag="AccidentViolation")}-01',
                            "AccidentViolationCd": f'csio:{self._value(conviction, "type")}',
                            },
                        })

        return accidents

    def get_drivers(self, card_json):
        return [item for item in card_json.values() if
                self._value(item, "type") == "individual" and self._value(item, "drivers_licence") is not None]

    def get_vehicles(self, card_json):
        return [item for item in card_json.values() if self._value(item, "type") == "vehicle"]

    def map_auto_request(self, card_json):
        contract_number = self.get_contract_number(card_json)

        pers_auto_policy_quote_inq_rq = {
            "RqUID": str(uuid.uuid1()),
            "BusinessPurposeTypeCd": "csio:NBQ",
            "TransactionRequestDt": self.format_acord_datetime(datetime.now(timezone.utc)) or "",
            "TransactionEffectiveDt": self.format_acord_datetime(moment.utcnow().add("years", 1).date) or "",
            "CurCd": "CAD",
            "ACORDStandardVersionCd": ACORD_VERSION,
            "Producer": {
                "ProducerInfo": {
                    "ContractNumber": contract_number,
                    },
                },
            }

        lob = "AUTO"

        # This named_insured is used to register the vehicles, as each vehicle must be registered to at
        # least one insured.
        named_insured = None

        first_individual = True
        pers_auto_policy_quote_inq_rq["InsuredOrPrincipal"] = []

        for card in card_json.values():
            if self._value(card, "type") != "individual":
                continue

            relation_to_insured = "csio:S"

            # If this is the first individual, use csio:5; otherwise, csio:13.
            if first_individual:
                first_individual = False
                relation_to_insured = "csio:I"
                named_insured = card

            pers_auto_policy_quote_inq_rq["InsuredOrPrincipal"].append(
                self.map_insured_or_principal(card_json, card, relation_to_insured, lob))

        pers_auto_policy_quote_inq_rq["PersPolicy"] = self.map_pers_policy(card_json, lob)
        pers_auto_policy_quote_inq_rq["Location"] = self.map_location(card_json)
        pers_auto_policy_quote_inq_rq["PersAutoLineBusiness"] = self.map_pers_auto_line_business(card_json,
                                                                                                 named_insured)

        return pers_auto_policy_quote_inq_rq

    def map_driver_veh(self, card_json):
        driver_veh_array = []
        drivers = self.get_drivers(card_json)
        vehicles = self.get_vehicles(card_json)

        for i, driver in enumerate(drivers):
            for j, vehicle in enumerate(vehicles):
                # Vehicle Ownership.
                veh_owned = "1"
                ownership = self._field(vehicle, "ownership", data_type=str, level="none")

                if ownership is not None and ownership.upper() != "OWN":
                    veh_owned = "0"

                # Primary or Secondary driver.
                driver_type = "csio:S"

                # Find the primary driver - For a quick quote, we use the first individual
                primary_driver = self.get_primary_driver(card_json, vehicle)

                if primary_driver is not None and self._value(primary_driver, "id", data_type=str) == self._value(
                        driver, "id", data_type=str):
                    driver_type = "csio:P"

                driver_veh = {
                    "@DriverRef": f"DRV-{i}",
                    "@VehRef": f"VEH-{j}",
                    "OwnedVehInd": veh_owned,
                    "UsePct": "100",  # TODO: Should UsePct be 100?
                    "DriverTypeCd": driver_type,
                    }

                driver_veh_array.append(driver_veh)

        return driver_veh_array

    def map_location(self, card_json):
        primary_individual = self.get_primary_individual(card_json)
        policy = self.get_policy(card_json)

        city = self._field(primary_individual, "city", data_type=str)
        city = self._value(primary_individual, ["drivers_licence", "fields", "city"]) if city is None else city
        city = self._value(policy, ["fields", "city"]) if city is None and policy is not None else city

        street = self._field(primary_individual, "street", data_type=str)
        street = self._value(primary_individual, ["drivers_licence", "fields",
                                                  "street"]) if street is None and self._quick_quote else street
        street = self._value(policy, ["fields", "street"]) if street is None and policy is not None else street

        location = {
            "@id": "LOC-1",
            "ItemIdInfo": {
                "ItemIdInfo": {
                    "AgencyId": f'{self._field(primary_individual, "last_name", default="", data_type=str)}-01',
                    },
                },
            "Addr": {
                "AddrTypeCd": "csio:10",
                "Addr1": street,
                "City": city,
                "StateProvCd": self.get_individual_prov_code(primary_individual),
                "PostalCode": self.get_individual_postal(primary_individual, card_json),
                "CountryCd": "CA",
                },
            }

        return location

    def map_pers_auto_line_business(self, card_json, named_insured):
        vehicles = self.get_vehicles(card_json)
        drivers = self.get_drivers(card_json)
        pers_driver = [self.map_pers_driver(card_json, driver, i) for i, driver in enumerate(drivers)]
        pers_veh = [self.map_pers_veh(card_json, vehicle, j, named_insured) for j, vehicle in enumerate(vehicles)]

        pers_auto_line_business = {
            "LOBCd": "csio:AUTO",
            "PersDriver": pers_driver,
            "PersVeh": pers_veh,
            }

        return pers_auto_line_business

    def map_pers_driver(self, card_json, driver, driver_index):
        general_party_info = self.map_general_party_info(card_json, driver, "auto")

        birth_date = self._field(driver, "birth_date", data_type=str)

        if birth_date is not None:
            birth_date = datetime.strptime(birth_date, "%B %d, %Y")
        else:
            birth_date = self._field(driver, "date_of_birth", data_type=str)
            birth_date = datetime.strptime(birth_date, "%Y-%m-%d")

        # Formatting for license date.
        drivers_licence = self._value(driver, "drivers_licence")
        format_lic_date = None

        if drivers_licence is not None:
            lic_date_raw = self._field(drivers_licence, "first_licence_date", data_type=str, level="none")

            if lic_date_raw is not None:
                # TODO: this could be done better.
                if len(lic_date_raw) == 10:
                    format_lic_date = datetime.strptime(lic_date_raw, "%Y-%m-%d").strftime("%Y-%m-%d")
                else:
                    format_lic_date = lic_date_raw

        if format_lic_date is None:
            format_lic_date = birth_date + relativedelta(years=18)
            format_lic_date = format_lic_date.strftime("%Y-%m-%d")
            self._error("Using default birth date minus 16 years for first_licence_date")

        # DriverRelationshipToApplicantCd.
        primary_individual = self.get_primary_individual(card_json)

        # Default DriverRelationshipToApplicantCd to Spouse unless they are the insured.
        relationship_to_applicant = "csio:S"

        if primary_individual is not None and self._value(primary_individual, "id") == driver["id"]:
            relationship_to_applicant = "csio:I"

        gender = self._field(driver, "gender", data_type=str, level="info")
        gender = gender[0] if gender is not None else "F"

        birth_date = self._field(driver, "birth_date", data_type=str)

        if birth_date is not None:
            birth_date = datetime.strptime(birth_date, "%B %d, %Y")
            birth_date_str = birth_date.strftime("%Y-%m-%d")
        else:
            birth_date = self._field(driver, "date_of_birth", data_type=str)
            birth_date = datetime.strptime(birth_date, "%Y-%m-%d")
            birth_date_str = birth_date.strftime("%Y-%m-%d")

        pers_driver = {
            "@id": f"DRV-{driver_index}",
            "GeneralPartyInfo": general_party_info,
            "DriverInfo": {
                "PersonInfo": {
                    "GenderCd": gender,
                    "BirthDt": birth_date_str,
                    "MaritalStatusCd": "csio:S",
                    "LanguageCd": "en",
                    "OccupationClassCd": "csio:S05",
                    # TODO csio:SuspensionRevocationReasonDesc can be added here.
                    },
                "License": {
                    "LicensedDt": format_lic_date,
                    "LicensePermitNumber": self._field(drivers_licence, "number", data_type=str),
                    "LicenseClassCd": self._field(drivers_licence, "class", default=DEFAULT_LICENCE_CLASS,
                                                  data_type=str).upper(),
                    "StateProvCd": self._field(drivers_licence, "province_code", default="", data_type=str).upper(),
                    "CountryCd": "CA",
                    },  # TODO - Driver QuestionAnswer go here.
                "DriverRelationshipToApplicantCd": relationship_to_applicant,
                "ExcludedFromUMInd": 0,
                },  # TODO - PersDriverInfo can go here (mostly training info). It appears to be required.
            "PersDriverInfo": {},
            }
        return pers_driver

    def map_pers_policy(self, card_json, lob):
        driver_veh = self.map_driver_veh(card_json)
        primary_individual = self.get_primary_individual(card_json)
        policy_start_date = moment.now().format("YYYYMMDD")

        drivers_licence = self._value(primary_individual, "drivers_licence")
        format_lic_date = None

        if drivers_licence is not None:
            format_lic_date = self._field(drivers_licence, "first_licence_date", data_type=str, level="none")

        if format_lic_date is not None and len(format_lic_date) > 0:
            if len(format_lic_date) > 7:
                format_lic_date = moment.date(format_lic_date, "MMMM,YYYY").format("YYYY-MM-DD")
            else:
                format_lic_date = moment.date(format_lic_date, "YYYY-MM").format("YYYY-MM-DD")
            policy_start_date = format_lic_date

        convictions = self.get_accident_violations(card_json)
        loss_conviction_array = convictions

        other_or_prior_policy = []
        drivers = self.get_drivers(card_json)

        policy = self.get_policy(card_json)
        company_code = JSON.get_company_code(policy) if policy is not None else "NONE"
        company = JSON.get_company_code(policy) if policy is not None else "No Previous Insurance"
        effective_date = JSON.get_effective_date(policy) if policy is not None else ""

        for i, driver in enumerate(drivers):
            other_or_prior_policy.append(
                {
                    "@DriverRef": f"DRV-{i}",
                    "InsurerName": company,
                    "LOBCd": f"csio:{lob}",
                    "csio:CompanyCd": company_code,
                    "ContractTerm": {
                        "EffectiveDt": effective_date,
                        }
                    },
                )

        pers_policy = {
            "LOBCd": f"csio:{lob}",
            "ContractTerm": {
                "EffectiveDt": moment.now().format("YYYY-MM-DD"),
                "ExpirationDt": moment.now().add("years", 1).format("YYYY-MM-DD"),
                },
            "BillingMethodCd": "csio:A",
            "DriverVeh": driver_veh,
            "RateEffectiveDt": moment.now().format("YYYY-MM-DD"),
            "OtherOrPriorPolicy": other_or_prior_policy,
            "PolicyTermCd": "annual",
            "OriginalPolicyInceptionDt": self.format_acord_datetime(moment.date(policy_start_date).date) or "",
            "csio:CompanyCd": "WAWA",
            "PersApplicationInfo": {
                "KnownSinceDt": moment.now().subtract("years", 10).format("YYYY-MM-DD"),
                "csio:PrincipalDriverKnownByAgentBroker": {
                    "EffectiveDt": moment.now().subtract("years", 10).format("YYYY-MM-DD"),
                    },
                },
            "AccidentViolation": loss_conviction_array,
            }

        return pers_policy

    def map_pers_veh(self, card_json, vehicle, vehicle_index, named_insured):
        # Formatting for purchase date. Default to 5 years ago for quick quote.
        purchased = self._field(vehicle, "purchased", data_type=str)
        purchase_date = moment.date(purchased, "MMMM,YYYY").format("YYYY-MM-DD") if purchased is not None and len(
            purchased) > 0 else moment.now().subtract("years", 5).format("YYYY-MM-DD")

        # Distance Annually.
        dis_annual = self._field(vehicle, "annual_km", default=10000, data_type=int)

        # Leased Indicator.
        ownership = self._field(vehicle, "ownership", data_type=str, level="warn")
        leased = 1 if ownership is not None and ownership.upper() != "OWN" else 0

        # Registration Province.
        primary_driver_id = self._value(vehicle, "primary_driver", data_type=str)

        # TODO: This should only be done for quick quoting
        if primary_driver_id is None:  # and self._quick_quote:
            for entry in card_json.values():
                if entry["type"] == "individual":
                    primary_driver_id = entry["id"]
                    break

        primary_driver = None

        if primary_driver_id is not None:
            primary_driver = card_json[primary_driver_id]

        reg_prov = self.get_individual_prov_code(primary_driver)

        # reg_prov = self._field(primary_driver, "province_code",
        #                        data_type=str) if primary_driver is not None else self.get_individual_prov_code(
        #     self.get_primary_individual(card_json))

        # Winter tires.
        winter_tires = self._field(vehicle, "winter_tires", data_type=bool)
        winters = winter_tires if winter_tires is not None else False

        # Named insured.
        additional_interest = {
            "GeneralPartyInfo ": self.map_general_party_info(card_json, named_insured, "auto"),
            }

        additional_interest_info = {
            "NatureInterestCd": "csio:RO",
            }
        additional_interest["AdditionalInterestInfo"] = additional_interest_info

        # Check the package requested (Recommended vs Economical).
        coverage_package_type = self._field(vehicle, "quote_coverage_type", default="recommended", data_type=str)

        # Purchase Price.
        purchase_price = self._field(vehicle, "purchase_price", default=10000, data_type=float)

        # Vehicle Value.
        veh_value = self._field(vehicle, "value", default=10000, data_type=float)

        # See if the vehicle has coverages that we should use.
        coverages = self._field(vehicle, "coverages", default=None)
        coverage_array = []

        if coverages is not None:
            coverage_codes = coverages.split(",")

            for idx, coverage_code in enumerate(coverage_codes):
                cov = {
                    "CSIOCode": coverage_code.upper(),
                    "ID": "Coverage" + str(idx),
                    }

                limit = self._field(vehicle, "coverage_" + coverage_code + "_limit", default=None)
                if limit is not None:
                    cov["Limit1"] = limit

                deductible = self._field(vehicle, "coverage_" + coverage_code + "_deductible", default=None)
                if deductible is not None:
                    cov["Deductible"] = deductible

                coverage_array.append(cov)
        else:
            if coverage_package_type.lower() == "recommended":
                cov_limit = 2000000
                col_deductible = 500
                cmp_deductible = 500
            elif coverage_package_type.lower() == "economical":
                cov_limit = 1000000
                col_deductible = 1000
                cmp_deductible = 1000
            else:
                cov_limit = 2000000
                col_deductible = 500
                cmp_deductible = 500

            cov_tppd = {
                "CoverageCd": "csio:TPPD",
                "CoverageDesc": "Property Damage Liability",
                "Limit": {
                    "FormatCurrencyAmt": {
                        "Amt": cov_limit,
                        "CurCd": "CAD",
                        },
                    },
                }

            cov_ab = {
                "CoverageCd": "csio:AB",
                "CoverageDesc": "Accident Benefits",
                }

            cov_tpbi = {
                "CoverageCd": "csio:TPBI",
                "CoverageDesc": "Bodily Injury Liability",
                "Limit": {
                    "FormatCurrencyAmt": {
                        "Amt": cov_limit,
                        "CurCd": "CAD",
                        },
                    },
                }

            cov_tpdc = {
                "CoverageCd": "csio:TPDC",
                "CoverageDesc": "Direct Compensation Property Damage",
                "Deductible": {
                    "FormatCurrencyAmt": {
                        "Amt": "0",
                        "CurCd": "CAD",
                        },
                    },
                }

            cov_cmp = {
                "CoverageCd": "csio:CMP",
                "CoverageDesc": "Comprehensive",
                "Deductible": {
                    "FormatCurrencyAmt": {
                        "Amt": cmp_deductible,
                        "CurCd": "CAD",
                        },
                    },
                }

            cov_col = {
                "CSIOCode": "COL",
                "ID": "Coverage8",
                "Deductible": col_deductible,
                }

            cov_ua = {
                "CoverageCd": "csio:UM",
                "CoverageDesc": "Uninsured Automobile",
                }

            cov_44 = {
                "CoverageCd": "csio:44",
                "CoverageDesc": "44 - Family Protection",
                "Limit": {
                    "FormatCurrencyAmt": {
                        "Amt": cov_limit,
                        "CurCd": "CAD",
                        },
                    },
                }

            # TODO cov_44 should only be added for Ontario.
            coverage_array.extend([cov_44, cov_ab, cov_tpbi, cov_tpdc, cov_tppd, cov_ua, cov_cmp, cov_col, ])

        agency_id = vehicle["id"]

        pers_veh = {
            "@id": f"VEH-{vehicle_index}",
            "@LocationRef": "LOC-1",
            "@RegisteredOwnerRef": "DRV-0",
            "csio:PCVEH": {
                "@xmlns:csio": "http://www.CSIO.org/standards/PC_Surety/CSIO1/xml/",
                "ItemIdInfo": {
                    "AgencyId": agency_id,
                    "InsurerId": agency_id,
                    },
                "Manufacturer": self._field(vehicle, "make", data_type=str),
                "Model": self._field(vehicle, "model", data_type=str),
                "ModelYear": self._field(vehicle, "year", data_type=int),
                # TODO is this acceptable to default? Get from vicc tables.
                "VehBodyTypeCd": "csio:P4",
                "EstimatedAnnualDistance": {
                    "NumUnits": dis_annual,
                    "UnitMeasurementCd": "KMT",
                    },
                "Displacement": {
                    "NumUnits": self._field(vehicle, "engine_size", data_type=float),
                    },
                "LeasedVehInd": leased,
                "NumCylinders": self._field(vehicle, "cylinders", data_type=int),
                "PurchaseDt": purchase_date,
                "RegistrationStateProvCd": reg_prov,
                "VehIdentificationNumber": self._field(vehicle, "vin", data_type=str),
                "AdditionalInterest": additional_interest,
                "DistanceOneWay": self._field(vehicle, "commute_distance", default=0, data_type=int),
                "VehUseCd": "csio:P",
                "csio:WinterTiresInd": winters,
                "PresentValueAmt": {
                    "Amt": veh_value,
                    "CurCd": "CAD",
                    },
                "PurchasePriceAmt": {
                    "Amt": purchase_price,
                    "CurCd": "CAD",
                    },

                },  # TODO QuestionAnswers go here.
            "Coverage": coverage_array,
            # TODO csio:BusinessUsePct goes here.
            }

        return pers_veh
