from enum import Enum


class QuoteStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    NONE = "none"

    def __str__(self) -> str:
        return self.value
