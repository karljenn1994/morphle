from abc import ABC

import moment


class CardToCSIO(ABC):
    def __init__(self, config, quick_quote, quote_support):
        self._config = config
        self._quick_quote = quick_quote
        self._quote_support = quote_support
        self._value = self._quote_support.transformation_support.value
        self._field = self._quote_support.transformation_support.field
        self._error = self._quote_support.transformation_support.transformation_log.log_error
        self._warn = self._quote_support.transformation_support.transformation_log.log_warn
        self._info = self._quote_support.transformation_support.transformation_log.log_info

    @property
    def transformation_log(self):
        return self._quote_support.transformation_support.transformation_log

    def format_acord_datetime(self, dt):
        if dt is None:
            return None

        formatted_dt = dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        milliseconds = int(dt.microsecond / 1000)
        return formatted_dt[:-6] + "{:03d}".format(milliseconds) + formatted_dt[-3:]

    def get_primary_individual(self, card_json):
        primary_individual = None

        for item in card_json.values():
            if self._value(item, "type", data_type=str) == "individual":
                primary_individual = item
                break

        if primary_individual is None:
            self._error("No primary individual could be found")

        return primary_individual

    def get_policy(self, card_json):
        policy = None

        for item in card_json.values():
            if self._value(item, "type", data_type=str) == "policy":
                policy = item
                break

        return policy

    def get_contract_number(self, card_json):
        primary_individual = self.get_primary_individual(card_json)

        if primary_individual is None:
            self._error("No primary individual was found so no contract number could be found")
            return None

        prov = self.get_individual_prov_code(primary_individual)

        if prov is None:
            self._error("Primary individual is missing province_code so no contract number could be found")
            return None

        prov = prov.upper()

        # Switch case equivalent in Python using a dictionary.
        contract_number_dict = {
            "ON": "0701507",
            "NS": "0001505",
            "NB": "0001504",
            "PE": "0001506",
            "NF": "0001500",
        }

        # Default to Ontario?
        # contract_number = contract_number_dict.get(prov, "0701507")

        if prov not in contract_number_dict.keys():
            self._error("Could not find a contract number for province " + prov)
            return None

        return contract_number_dict.get(prov)

    def get_individual_city(self, card_json, individual, lob):
        city = self._field(individual, "city", data_type=str, level="none")
        policy = self.get_policy(card_json)

        if lob.lower() == "auto":
            city = self._value(individual, ["drivers_licence", "fields", "city"]) \
                if city is None and self._quick_quote \
                else city
        else:
            if city is None and self._quick_quote:
                properties = [p for p in card_json.values() if p["type"] == "property"]
                city = self._field(properties[0], "city") \
                    if len(properties) > 0 else None

        city = self._value(policy, ["fields", "city"]) \
            if city is None and policy is not None \
            else city

        if city is None:
            self._error("Missing field city on individual")

        return city

    def get_individual_postal(self, insured, card_json):
        policy = self.get_policy(card_json)
        postal = self._field(insured, "postal_code", data_type=str)

        postal = self._value(policy, ["fields", "postal_code"]) \
            if postal is None \
            else postal

        if postal is not None:
            postal = postal.upper().replace("-", "").replace(" ", "")[:6]
            postal = f"{postal[:3]} {postal[3:]}"

        return postal

    def get_individual_prov_code(self, insured):
        prov = self._field(insured, "province_code", data_type=str)

        prov = self._value(insured, ["drivers_licence", "fields", "province_code"]) \
            if prov is None \
            else prov

        if prov is not None:
            prov = prov.upper()

        return prov

    def get_individual_street(self, card_json, individual, lob):
        street = self._field(individual, "street", data_type=str, level="none")
        policy = self.get_policy(card_json)

        if lob.lower() == "auto":
            street = self._value(individual, ["drivers_licence", "fields", "street"]) \
                if street is None and self._quick_quote \
                else street

        else:
            if street is None and self._quick_quote:
                properties = [p for p in card_json.values() if p["type"] == "property"]
                street = self._field(properties[0], "address") \
                    if len(properties) > 0 else ""

        street = self._value(policy, ["fields", "address"]) \
            if street is None and policy is not None\
            else street

        if street is None:
            self._error("Missing field street on individual")

        return street

    def map_insured_or_principal(self, card_json, individual, relation_to_insured, lob):
        general_party_info = self.map_general_party_info(card_json, individual, lob)
        gender = self._field(individual, "gender", data_type=str, level="none")
        gender = gender[0] if gender is not None else "f"
        birth_date = self._field(individual, "birth_date", data_type=str, default=moment.now().format("MMMM DD,YYYY"))

        insured_or_principal = {
            "GeneralPartyInfo": general_party_info,
            "InsuredOrPrincipalInfo": {
                "InsuredOrPrincipalRoleCd": "csio:5",
                "PersonInfo": {
                    "GenderCd": gender,
                    "BirthDt": moment.date(birth_date, "MMMM DD,YYYY").format("YYYY-MM-DD"),
                    "MaritalStatusCd": "csio:S",
                    # Self Employed
                    "OccupationClassCd": "csio:S05",
                    "LanguageCd": "en",
                    "RelationshipToInsuredCd": relation_to_insured,
                },
            },
        }

        # TODO Credit Info should not be static.
        if lob.upper() == "HAB" or lob.upper() == "HABL":
            insured_or_principal["InsuredOrPrincipalInfo"]["csio:CreditInfoConsentCd"] = "D"

        return insured_or_principal

    def map_general_party_info(self, card_json, individual, lob):
        city = self.get_individual_city(card_json, individual, lob)
        street = self.get_individual_street(card_json, individual, lob)
        email = self._field(individual, "email", default="info@brunvalley.com", data_type=str)

        return {
            "NameInfo": {
                "PersonName": {
                    "Surname": self._field(individual, "last_name", data_type=str),
                    "GivenName": self._field(individual, "first_name", data_type=str),
                },
            },
            "Addr": {
                "AddrTypeCd": "csio:10",
                "Addr1": street,
                "City": city,
                "StateProvCd": self.get_individual_prov_code(individual),
                "PostalCode": self.get_individual_postal(individual, card_json),
                "CountryCd": "CA",
            },
            "Communications": {
                "PhoneInfo": {
                    "PhoneTypeCd": "Phone",
                    "CommunicationUseCd": "Home",
                    "PhoneNumber": self._field(individual, "phone", data_type=str),
                },
                "EmailInfo": {
                    "EmailAddr": email,
                },
                "LanguageCd": "en",
            },
        }

    def get_all_losses(self, card_json):
        losses = []

        for item in card_json.values():
            if self._value(item, "type", data_type=str) != "individual":
                continue

            if self._value(item, "history") is None or item["history"].get("claims") is None:
                continue

            losses = [{"Loss": {
                "LossDt": f'{self._value(claim, "date", tag="Loss", data_type=str)}-01',
                "csio:CompanyCd": "OT3",
                "ResponsiblePct": "50",
                "InsurerName": "Other",
                "LossCauseCd": f'csio:{self._value(claim, "type", data_type=str)}',
            }} for claim in item["history"]["claims"]]
        return losses
