from abc import ABC


class CardToCQ(ABC):
    def __init__(self, config, quick_quote, quote_support):
        self._config = config
        self._quick_quote = quick_quote
        self._quote_support = quote_support
        self._transformation_support = self._quote_support.transformation_support
        self._value = self._transformation_support.value
        self._field = self._transformation_support.field
        self._error = self._transformation_support.transformation_log.log_error
        self._warn = self._transformation_support.transformation_log.log_warn
        self._info = self._transformation_support.transformation_log.log_info

    @property
    def transformation_log(self):
        return self._transformation_support.transformation_log

    def get_postal_code(self, insured):
        postal_code = self._field(insured, "postal_code", data_type=str)

        if postal_code is not None:
            postal_code = postal_code.replace(" ", "").upper()

        return postal_code

    def get_address(self, insured):
        address = self._field(insured, "address", data_type=str)

        if address is not None:
            comma = address.find(",")
            address = address[:comma] if comma != -1 else address

        return address

    def get_province_code(self, insured):
        prov = self._field(insured, "province_code", data_type=str)
        return prov.upper() if prov is not None else None

    def get_city(self, insured):
        return self._field(insured, "city", data_type=str)

    def get_contract(self, carrier_config):
        if type(carrier_config) == str:
            return None
        if type(carrier_config) == list:
            return None

        contract_number = {}

        for carrier in carrier_config:
            cfg = carrier_config[carrier]

            if cfg is not None:
                contract_code = cfg["contract"] if "contract" in cfg else None

                if contract_code is not None:
                    element_name = "@vor" + carrier
                    contract_number[element_name] = contract_code

        return contract_number

    def map_carrier_info(self, carrier_config, consent):
        group_array = []

        additional = {
            "CorrespondLanguage": "E",
            "Consent": consent,
        }

        for carrier_name in carrier_config:
            cfg = None

            if type(carrier_config) == dict:
                cfg = carrier_config[carrier_name]

            group = {
                "Carriers": {
                    carrier_name: ""
                },
                "Additional": additional
            }

            if type(cfg) == dict:
                group["Credentials"] = \
                    {
                        "UserName": cfg["username"] if "username" in cfg else "",
                        "Password": cfg["password"] if "password" in cfg else "",
                        "ContractCode": cfg["contract"] if "contract" in cfg else ""
                    },

            group_array.append(group)

        return {
            "RBCarrierInfo": {
                "@xmlns": "",
                "Group": group_array,
            }
        }
