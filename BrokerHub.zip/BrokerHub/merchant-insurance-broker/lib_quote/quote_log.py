import logging

from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class QuoteLog(object):
    def __init__(self):
        self._messages = {"error": [], "warn": [], "info": [], }

    def dump_log(self):
        for error in self._messages["error"]:
            log.error(error)

        for warn in self._messages["warn"]:
            log.warning("WARN: " + warn)

        for info in self._messages["info"]:
            log.info("INFO: " + info)

    def clear(self):
        self._messages = {"error": [], "warn": [], "info": [], }

    def log(self, level, msg):
        if level != "none":
            self._messages[level].append(msg)

    def get_messages(self):
        return self._messages

    def get_errors(self):
        return self._messages["error"]

    def log_error(self, msg):
        self._messages["error"].append(msg)

    def get_warnings(self):
        return self._messages["warn"]

    def log_warn(self, msg):
        self._messages["warn"].append(msg)

    def get_infos(self):
        return self._messages["info"]

    def log_info(self, msg):
        self._messages["info"].append(msg)

    def log_missing_value(self, object_type, name, level="error", tag=None):
        if level != "none":
            if object_type is not None:
                self._messages[level].append("Missing field " + name + " on " + object_type)
            elif tag is not None:
                self._messages[level].append("Missing field " + name + " on " + tag)
            else:
                self._messages[level].append("Missing field " + name)
