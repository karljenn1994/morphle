from typing import Optional


class CoverageModel:
    def __init__(self, parent: "_CoverageMixin", code: str):
        self._parent = parent
        self.code = code.lower()

    def _k(self, suffix: str) -> str:
        return f"coverage_{self.code}_{suffix}"

    @property
    def premium(self) -> Optional[float]:
        v = self._parent.raw.get("fields", {}).get(self._k("premium"))
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    @premium.setter
    def premium(self, value: Optional[float]) -> None:
        self._parent.raw.setdefault("fields", {})[self._k("premium")] = value

    @property
    def limit(self) -> Optional[float]:
        v = self._parent.raw.get("fields", {}).get(self._k("limit"))
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    @limit.setter
    def limit(self, value: Optional[float]) -> None:
        self._parent.raw.setdefault("fields", {})[self._k("limit")] = value

    @property
    def deductible(self) -> Optional[float]:
        v = self._parent.raw.get("fields", {}).get(self._k("deductible"))
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    @deductible.setter
    def deductible(self, value: Optional[float]) -> None:
        self._parent.raw.setdefault("fields", {})[self._k("deductible")] = value

    @property
    def description(self) -> Optional[str]:
        return self._parent.raw.get("fields", {}).get(self._k("description"))

    @description.setter
    def description(self, value: Optional[str]) -> None:
        self._parent.raw.setdefault("fields", {})[self._k("description")] = value
