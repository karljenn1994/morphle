import logging
from typing import Optional

from lib_policy_dom.individual_model import IndividualModel
from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class _DriverAssignmentModel:
    def __init__(self, driver_id: str, use: Optional[float], principal: bool, resolver):
        self.driver_id = driver_id
        self.use = use
        self.principal = bool(principal)
        self._resolver = resolver  # id -> Individual|None

    @property
    def individual(self) -> Optional[IndividualModel]:
        return self._resolver(self.driver_id)
