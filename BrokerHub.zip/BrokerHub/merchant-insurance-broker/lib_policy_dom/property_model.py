import logging

from lib_policy_dom.base_model import _BaseModel
from lib_policy_dom.coverage_mixin import _CoverageMixin
from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class PropertyModel(_BaseModel, _CoverageMixin):
    @property
    def address(self): return self._field("address")

    @property
    def city(self): return self._field("city")

    @property
    def province_code(self): return self._field("province_code")

    @property
    def postal_code(self): return self._field("postal_code")

    @property
    def year_built(self): return self._field("year_built", int)
