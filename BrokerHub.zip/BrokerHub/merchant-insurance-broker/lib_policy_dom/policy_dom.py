import json
import logging
import uuid
from typing import List, Optional

from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import (
    find_group_by_group_name,
    find_groups_by_group_name,
    find_groups_by_group_name_as_map,
    fix_policy_number,
    group_val,
    remove_spaces,
    val
)
from lib_common import constants
from lib_common.constants import LOGGER
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_helpers import (
    date_from_edi_date,
    date_to_string,
    parse_first_name,
    parse_last_name,
    to_dollars,
    to_dollars_and_cents,
    to_first_name,
    to_float,
    to_full_name,
    to_last_name
)
from lib_persistence import policy
from lib_policy_dom.individual_model import IndividualModel
from lib_policy_dom.policy_model import PolicyModel
from lib_policy_dom.property_model import PropertyModel
from lib_policy_dom.vehicle_model import VehicleModel
from lib_transform.mapping_utils import MappingUtils as Map

log = logging.getLogger(LOGGER)


class PolicyDOM(object):
    extensions = (".json",)

    valid_codes = [
        "NBS",
        "NBQ",
        "REI",
        "RNC",
        "RNI",
        "RWL",
        "SYR",
        "XLN",
        "REW",
        "PCH",
        "PCQ",
        "RII",
        "SYN",
        "SYR",
    ]

    def __init__(self):
        self.json = {}  # instance variable
        self._effective_date = None
        self._expiry_date = None

    def save(self, file_path):
        card_str = json.dumps(self.json, indent=4, sort_keys=False, ensure_ascii=False)
        FileManagerFactory.create_file_manager().write_string(file_path, card_str)

    @staticmethod
    def load(json_file):
        card_json_str = FileManagerFactory.create_file_manager().read_string(json_file)
        j = json.loads(card_json_str)

        if j is list or "version" not in j or j["version"] < constants.CARD_JSON_VERSION:
            # Need to upgrade.
            al3_json_file = json_file.replace(".JSON", ".AL3")
            txt = AL3ToJSON.load(al3_json_file)
            al3_object = AL3ToJSON.to_json(txt)
            policy_dom = PolicyDOM.from_al3_json(al3_object)
            policy_dom.save(json_file)
        else:
            policy_dom = PolicyDOM()
            policy_dom.json = j
            policy_dom._build_dom()

        return policy_dom

    @staticmethod
    def from_json(j):
        policy_dom = PolicyDOM()
        policy_dom.json = j
        policy_dom._build_dom()
        return policy_dom

    @staticmethod
    def from_al3_json(al3_json):
        policy_dom = PolicyDOM()
        policy_dom.json = policy_dom._transform_al3_json(al3_json)
        policy_dom._build_dom()
        return policy_dom

    def to_cards_json(self) -> list[dict]:
        """
        Return a copy of the 'cards' portion of self.json with all values
        converted to strings (booleans left alone).

        HOW IT WORKS
        ------------
        - Recursively walks self.json["cards"].
        - Converts scalars (int, float, None, etc.) into strings.
        - Leaves booleans untouched.
        - Returns a new list of cards; self.json is NOT mutated.
        """
        def stringify(obj):
            if isinstance(obj, dict):
                return {str(k): stringify(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [stringify(v) for v in obj]
            elif isinstance(obj, bool):
                return obj
            else:
                return "" if obj is None else str(obj)

        return stringify(self.json.get("cards", []))

    def to_cards_json_str(self, indent: int = 2) -> str:
        """
        Return the stringified 'cards' portion of self.json as a formatted JSON string.
        """
        return json.dumps(self.to_cards_json(), indent=indent, ensure_ascii=False)

    def _build_dom(self):
        """
        Build typed objects from self.json (after _to_card).
        """
        cards = (self.json or {}).get("cards", [])
        self.policy: Optional[PolicyModel] = None
        self.individuals: List[IndividualModel] = []
        self.vehicles: List[VehicleModel] = []
        self.properties: List[PropertyModel] = []

        # pass 1: create objects and index individuals by id
        id_to_ind: dict[str, IndividualModel] = {}
        for c in cards:
            t = c.get("type")
            if t == "policy":
                try:
                    policy.update_company_name(c)
                except Exception:
                    log.exception("update_company_name failed for policy card id=%s", c.get("id"))

                self.policy = PolicyModel(c)
                self.policy = PolicyModel(c)
            elif t == "individual":
                ind = IndividualModel(c)
                self.individuals.append(ind)
                if ind.id:
                    id_to_ind[ind.id] = ind
            elif t == "vehicle":
                self.vehicles.append(VehicleModel(c))
            elif t == "property":
                self.properties.append(PropertyModel(c))

        # pass 2: bind driver relationships on vehicles
        def resolve(ind_id: str) -> Optional[IndividualModel]:
            return id_to_ind.get(ind_id)

        for v in self.vehicles:
            v._bind_drivers(resolve)

    def _transform_al3_json(self, al3_json):
        cards = []
        policy_type = group_val(al3_json, "2TRG", "07", None)
        transaction_type = group_val(al3_json, "2TRG", "25", None)

        if transaction_type not in PolicyDOM.valid_codes:
            return cards

        two_trg = find_group_by_group_name(al3_json, "2TRG")
        nine_bis = find_group_by_group_name(al3_json, "9BIS")
        five_bis = find_group_by_group_name(al3_json, "5BIS")
        five_bpis = find_groups_by_group_name(al3_json, "5BPI")

        for five_bpi in five_bpis:
            # Make sure there is a policy number.
            if val(five_bpi, "01", None) is None:
                continue

            self._effective_date = date_from_edi_date(val(five_bpi, "06", None))
            self._expiry_date = date_from_edi_date(val(five_bpi, "07", None))

            if policy_type == "AUTO":
                five_bpi_children = five_bpi.get("children", {})
                six_sads_map = find_groups_by_group_name_as_map(five_bpi_children, "6SAD")

                for six_sad_key in six_sads_map.keys():
                    six_sad = six_sads_map[six_sad_key]
                    nine_sad_id = "9SAD" + six_sad_key[4:]
                    nine_sad = None

                    if nine_sad_id in five_bpi_children:
                        nine_sad = five_bpi_children[nine_sad_id]

                    self._map_auto_individuals(six_sad, nine_sad, nine_bis, cards)

                five_lags = find_groups_by_group_name(five_bpi.get("children", {}), "5LAG")

                for five_lag in five_lags:
                    six_savs = find_groups_by_group_name(five_lag.get("children", {}), "6SAV")

                    for six_sav in six_savs:
                        self._map_auto(five_lag, six_sav, cards)

            elif policy_type == "HABL":
                five_isi = find_group_by_group_name(five_bis.get("children", {}), "5ISI")
                self._map_property_individuals(five_bis, nine_bis, five_isi, cards)

                five_lags = find_groups_by_group_name(five_bpi.get("children", {}), "5LAG")

                for five_lag in five_lags:
                    property_card = self._map_property(five_lag, cards)
                    six_wsgs = find_groups_by_group_name(five_lag.get("children", {}), "6WSG")

                    for six_wsg in six_wsgs:
                        self._map_scheduled_group(six_wsg, cards)

                    if property_card:
                        self._map_scheduled_personal_article_coverages(five_lag, property_card['fields'])

            self._map_policy(
                two_trg,
                five_bpi,
                five_bis,
                nine_bis,
                self._policy_has_claims(five_bpi),
                self._policy_has_convictions(five_bpi),
                cards)

        return {
            "version": constants.CARD_JSON_VERSION,
            "cards": cards
        }

    def _map_scheduled_personal_article_coverages(self, five_lag, fields):
        coverages = []

        if "coverages" in fields:
            coverages = fields["coverages"].split(",")

        six_ppss = find_groups_by_group_name(five_lag.get("children", {}), "6PPS")

        for six_pps in six_ppss:
            class_code = val(six_pps, "02", default=None)

            if class_code:
                six_cvhs = find_groups_by_group_name(six_pps.get("children", {}), "6CVH")

                for six_cvh in six_cvhs:
                    coverage_code = val(six_cvh, "01", default=None)

                    if coverage_code:
                        coverage_code = class_code.lower() + "_" + coverage_code.lower()
                        coverages.append(coverage_code)
                        pfx = "coverage_" + coverage_code
                        self._set(fields, pfx + "_premium", to_dollars_and_cents(val(six_cvh, "06", None)))
                        self._set(fields, pfx + "_limit", to_dollars(val(six_cvh, "11", None)))
                        self._set(fields, pfx + "_deductible", to_dollars(val(six_cvh, "12", None)))

                        description = val(six_cvh, "24", None)

                        if description:
                            self._set(fields, pfx + "_description", description + " - " + class_code)

        fields["coverages"] = ",".join(coverages)

    def _set(self, target, key, value):
        if value is None:
            return
        elif isinstance(value, str):
            if value is not None and len(value) > 0:
                target[key] = value
        else:
            target[key] = value

    def _get_individual(self, fixed_id, cards):
        for card in cards:
            if card["id"] == fixed_id:
                return card
        return None

    def _map_claims(self, policy_obj, five_bpi, cards):
        six_achs = find_groups_by_group_name_as_map(five_bpi.get("children", {}), "6ACH")
        nine_achs = find_groups_by_group_name_as_map(five_bpi.get("children", {}), "9ACH")

        for six_ach_key in six_achs.keys():
            six_ach = six_achs[six_ach_key]
            nine_ach_key = six_ach_key.replace("6ACH", "9ACH")
            nine_ach = None

            if nine_ach_key in nine_achs:
                nine_ach = nine_achs[six_ach_key.replace("6ACH", "9ACH")]

            driver_id = val(six_ach, "03", None)

            if driver_id is not None:
                individual = self._get_individual(driver_id, cards)

                if individual is not None:
                    if "claims" not in policy_obj:
                        policy_obj["claims"] = []
                    policy_obj["claims"].append(
                        {
                            "type": "claim",
                            "category": "individual",
                            "fields": {
                                "driver_id": val(six_ach, "03", ""),
                                "vehicle_id": val(six_ach, "01", ""),
                                "date": date_to_string(date_from_edi_date(val(six_ach, "18", None))),
                                "code": val(nine_ach, "67", "") if nine_ach is not None else "",
                                "description": val(six_ach, "05", ""),
                                "percent_responsible": float(val(six_ach, "02", 0)),
                            }
                        }
                    )

    def _map_conviction(self, six_sah):
        conviction = {
            "type": "conviction",
            "category": "individual",
            "fields": {
                "date": date_to_string(date_from_edi_date(val(six_sah, "01", None))),
                "code": val(six_sah, "02", None),
            },
        }

        return conviction

    def _policy_has_convictions(self, five_bpi):
        six_sahs = find_groups_by_group_name(five_bpi.get("children", {}), "6SAH")
        return len(six_sahs) > 0

    def _policy_has_claims(self, five_bpi):
        six_achs = find_groups_by_group_name(five_bpi.get("children", {}), "6ACH")
        return len(six_achs) > 0

    def _map_policy(self,
                    two_trg,
                    five_bpi,
                    five_bis,
                    nine_bis,
                    policy_has_claims,
                    policy_has_convictions,
                    cards):
        fields = {}
        policy_obj = {
            "id": uuid.uuid4().hex,
            "type": "policy",
            "category": "folio",
            "fields": fields
        }
        cards.append(policy_obj)

        policy_number = fix_policy_number(val(five_bpi, "01", None))
        self._set(fields, "policy_number", policy_number)

        original_company_code = val(five_bpi, "03", None)
        company_code, company_name = policy.map_company_code(original_company_code)

        self._set(fields, "original_company_code", original_company_code)
        self._set(fields, "company_code", company_code)
        self._set(fields, "company_name", company_name)

        five_pph = find_group_by_group_name(five_bpi.get("children", {}), "5PPH")
        if five_pph is not None:
            self._set(fields, "prior_policy_number", val(five_pph, "03", None))
            original_prior_company_code = val(five_pph, "01", None)
            original_prior_company_code = original_prior_company_code \
                if original_prior_company_code is not None and len(original_prior_company_code) > 0 else None
            original_prior_company_name = val(five_pph, "02", None)
            original_prior_company_name = original_prior_company_name \
                if original_prior_company_name is not None and len(original_prior_company_name) > 0 else None
            prior_company_code, prior_company_description = \
                policy.map_company_code(original_prior_company_code, allow_none=True)
            self._set(fields, "original_prior_company_code", original_prior_company_code)
            self._set(fields, "original_prior_company_name", original_prior_company_name)
            self._set(fields, "prior_company_code", prior_company_code)
            self._set(fields, "prior_company_name", prior_company_description)

        self._set(fields, "purpose", val(two_trg, "25", None))
        self._set(fields, "lob", val(five_bpi, "04", None))
        self._set(fields, "renewal_term", val(five_bpi, "10", None))
        self._set(fields, "names", to_full_name(val(five_bis, "01", None)))
        self._set(fields, "insured", to_full_name(val(five_bis, "01", None)))
        self._set(fields, "coinsured", to_full_name(val(five_sngs[0], "03", None))) if (
            five_sngs := find_groups_by_group_name(five_bis.get("children", {}), "5SNG")) else None
        self._set(fields, "address", val(nine_bis, "51", None))
        self._set(fields, "city", val(nine_bis, "53", None))
        self._set(fields, "postal_code", remove_spaces(val(nine_bis, "55", None)))
        self._set(fields, "province_code", val(nine_bis, "54", None))
        self._set(fields, "sequence", val(two_trg, "19", "0"))
        self._set(fields, "claims", policy_has_claims)
        self._set(fields, "convictions", policy_has_convictions)
        self._set(fields, "effective_date", date_to_string(self._effective_date))
        self._set(fields, "expiry_date", date_to_string(self._expiry_date))

        transaction_date = date_from_edi_date(val(two_trg, "20", None))
        transaction_effective_date = date_from_edi_date(val(two_trg, "23", None))

        self._set(fields, "transaction_date", date_to_string(transaction_date))
        self._set(fields, "transaction_effective_date", date_to_string(transaction_effective_date))

        premium = to_dollars_and_cents(val(five_bpi, "11", None))
        self._set(fields, "premium", premium)
        self._set(fields, "annual_premium", premium)

        five_pay = find_group_by_group_name(five_bpi.get("children", {}), "5PAY")

        if five_pay is not None:
            self._set(fields, "withdrawal_amount", to_dollars_and_cents(val(five_pay, "17", None)))
            self._set(fields, "day_of_month_due", val(five_pay, "02", None))

        self._map_claims(policy_obj, five_bpi, cards)
        return policy_obj

    def _map_auto(self, five_lag, six_sav, cards):
        fields = {}
        fixed_id = val(six_sav, "02", uuid.uuid4().hex)
        veh = {
            "id": fixed_id,
            "type": "vehicle",
            "category": "folio",
            "fields": fields,
        }
        cards.append(veh)

        self._set(fields, "code", val(six_sav, "03", None))
        self._set(fields, "year", val(six_sav, "04", None))
        self._set(fields, "make", val(six_sav, "5A", None))
        self._set(fields, "model", val(six_sav, "5B", None))
        self._set(fields, "vin", val(six_sav, "07", None))
        self._set(fields, "cylinders", val(six_sav, "08", None))
        self._set(fields, "engine_size", val(six_sav, "09", None))
        self._set(fields, "purchased", date_to_string(date_from_edi_date(val(six_sav, "10", None))))

        # There might be no price. We have also seen $1 price, which could be a value they use
        # to get past some validation. Don't accept $0 or $1. Choose the largest between purchase
        # and list price.
        purchase_price = to_float(to_dollars(val(six_sav, "12", None)))
        list_price = to_float(to_dollars(val(six_sav, "13", None)))
        price = max([i for i in [0, purchase_price, list_price] if i is not None])

        price = str(price) if price > 1 else ""
        self._set(fields, "purchase_price", price)

        self._set(fields, "commute_distance", val(six_sav, "38", None))
        self._set(fields, "annual_km", val(six_sav, "39", None))

        self._set(fields, "address", val(five_lag, "02", None))
        self._set(fields, "city", val(five_lag, "04", None))
        self._set(fields, "province_code", val(five_lag, "05", None))
        self._set(fields, "postal_code", remove_spaces(val(five_lag, "06", None)))
        self._set(fields, "country", val(five_lag, "11", None))

        drivers = []
        self._map_driver(drivers, val(six_sav, "27", None), val(six_sav, "28", None), True)
        self._map_driver(drivers, val(six_sav, "29", None), val(six_sav, "30", None), False)
        self._map_driver(drivers, val(six_sav, "31", None), val(six_sav, "32", None), False)
        self._map_driver(drivers, val(six_sav, "33", None), val(six_sav, "34", None), False)
        self._map_driver(drivers, val(six_sav, "35", None), val(six_sav, "36", None), False)

        if drivers:
            veh["drivers"] = drivers

        six_sacs = find_groups_by_group_name(six_sav.get("children", {}), "6SAC")
        self._map_auto_coverages(six_sacs, fields)

    def _map_driver(self, drivers, driver_id, use, principal):
        if driver_id is not None:
            driver = {"id": driver_id}
            if use is not None:
                driver['use'] = float(use)
            driver['principal'] = principal
            drivers.append(driver)

    def _map_auto_individuals(self, six_sad, nine_sad, nine_bis, cards):
        fields = {}
        drivers_licence_fields = {}
        fixed_id = val(six_sad, "01", uuid.uuid4().hex)
        ind = {
            "id": fixed_id,
            "type": "individual",
            "category": "folio",
            "fields": fields,
            "drivers_licence": {
                "type": "drivers_licence_card",
                "category": "individual",
                "fields": drivers_licence_fields,
            },
        }
        cards.append(ind)

        first_name = to_first_name(val(six_sad, "03", None))
        last_name = to_last_name(val(six_sad, "03", None))

        if first_name is None:
            first_name = parse_first_name(val(six_sad, "03", None))

        if last_name is None:
            last_name = parse_last_name(val(six_sad, "03", None))

        if last_name is not None and first_name is not None:
            full_name = " ".join([first_name, last_name])
        else:
            full_name = val(six_sad, "03", None)
            full_name = " ".join(full_name.split())

        self._set(fields, "name", full_name)
        self._set(fields, "first_name", first_name)
        self._set(fields, "last_name", last_name)
        self._set(fields, "date_of_birth", date_to_string(date_from_edi_date(val(six_sad, "06", None))))
        self._set(fields, "city", val(nine_sad, "52", None))
        self._set(fields, "province_code", val(nine_sad, "54", None))
        self._set(fields, "postal_code", remove_spaces(val(nine_sad, "55", None)))

        self._set(drivers_licence_fields, "number", val(six_sad, "04", None))
        self._set(drivers_licence_fields, "first_name", first_name)
        self._set(drivers_licence_fields, "last_name", last_name)
        self._set(drivers_licence_fields, "date_of_birth", date_to_string(date_from_edi_date(val(six_sad, "06", None))))
        self._set(drivers_licence_fields, "postal_code", remove_spaces(val(nine_sad, "55", None)))
        self._set(drivers_licence_fields, "class", val(nine_sad, "58", None))
        self._set(drivers_licence_fields,
                  "first_licence_date",
                  date_to_string(date_from_edi_date(val(nine_sad, "57", None))))

        prov = val(six_sad, "05", None)
        if prov is None:
            prov = val(nine_sad, "54", None)
        if prov is None:
            prov = val(nine_bis, "54", None)

        self._set(drivers_licence_fields, "province_code", prov)

        six_sahs = find_groups_by_group_name(six_sad.get("children", {}), "6SAH")
        convictions = []
        for six_sah in six_sahs:
            convictions.append(self._map_conviction(six_sah))
        if len(convictions) > 0:
            ind["convictions"] = convictions

    def _map_property(self, five_lag, cards):
        fields = {}
        fixed_id = val(five_lag, "01", uuid.uuid4().hex)
        prop = {
            "id": fixed_id,
            "type": "property",
            "category": "folio",
            "fields": fields
        }

        self._set(fields, "address", val(five_lag, "02", None))
        self._set(fields, "city", val(five_lag, "04", None))
        self._set(fields, "province_code", val(five_lag, "05", None))
        self._set(fields, "postal_code", remove_spaces(val(five_lag, "06", None)))
        self._set(fields, "country", val(five_lag, "11", None))

        # Property Details -> 5LAG/6HRU
        six_hru = find_group_by_group_name(five_lag.get("children", {}), "6HRU")

        # Don't want to add the property if it doesn't have coverages. This happens when we
        # have a home policy not insuring a home but rather things like boats and
        # trailers.
        if six_hru is not None:
            policy_type_cd = val(six_hru, "01", None)

            if policy_type_cd == "84":
                # This is a trailer.
                prop["type"] = "vehicle"
                self._set(fields, "type", "trailer")
                self._set(fields, "year", val(six_hru, "03", None))

                five_moh = find_group_by_group_name(five_lag.get("children", {}), "5MOH")

                if five_moh is not None:
                    self._set(fields, "make", val(five_moh, "02", None))
                    self._set(fields, "model", val(five_moh, "03", None))
                    self._set(fields, "vin", val(five_moh, "04", None))
                    self._set(fields, "length", val(five_moh, "10", None))

            # Coverages -> 5LAG/6HRU/6CVH
            six_cvhs = find_groups_by_group_name(six_hru.get("children", {}), "6CVH")

            # Same as above. No coverage means that this property is not being insured.
            if len(six_cvhs) == 0:
                return None

            self._map_hab_coverages(six_cvhs, fields)

            self._set(fields, "distance_to_hydrant", Map.hydrant_distance_cd(val(six_hru, "12A", None)))
            self._set(fields, "building_type", Map.property_type(val(six_hru, "07", None)))
            self._set(fields, "fire_station_distance", Map.fire_station_distance(val(six_hru, "14A", None)))
            self._set(fields, "heat_type", Map.fuel_type_cd(val(six_hru, "30", None)))
            self._set(fields, "secondary_heat_type", Map.fuel_type_cd(val(six_hru, "37", None)))
            self._set(fields, "exterior", Map.construction_cd(val(six_hru, "02", val(six_hru, "43", None))))
            self._set(fields, "year_built", val(six_hru, "03", None))
            self._set(fields, "number_bedrooms", val(six_hru, "05", None))
            self._set(fields, "contains_business", "true" if val(six_hru, "34", None) == "Y" else "false")
            self._set(fields, "value", to_dollars(val(six_hru, "06", None)))

            # Construction -> 5LAG/6HRU/6IIG/6IVC
            const = find_group_by_group_name(five_lag.get("children", {}), "6IVC")

            if const is not None:
                basement = val(const, "07", None)

                if basement:
                    self._set(fields, "square_footage", val(const, "02", None))
                    self._set(fields, "num_stories", Map.stories_and_building_type(val(const, "01", None))[1])
                    self._set(
                        fields, "number_bathrooms", Map.bathrooms(val(const, "03", None), val(const, "04", None))
                    )
                    self._set(fields, "garage", Map.garage_type_cd(val(const, "17", None)))
                    self._set(fields, "roof_type", Map.roof_cd(val(const, "18", None)))
                    self._set(fields, "pool", Map.pool_cd(val(const, "21", None)))
                    self._set(fields, "number_garage_doors", Map.num_garage_doors(val(const, "16", None)))
                    self._set(fields, "number_kitchens", val(const, "64", ""))
                    self._set(fields, "foundation_type", Map.foundation_type_cd(val(const, "38", None)))
                else:
                    fields["basement_finished"] = Map.edi_to_snap_basement_finished(basement)

            cards.append(prop)
            return prop

        return None

    def _map_property_individuals(self, five_bis, nine_bis, five_isi, cards):
        fields = {}
        fixed_id = val(five_bis, "02", uuid.uuid4().hex)
        ind = {
            "id": fixed_id,
            "type": "individual",
            "category": "folio",
            "fields": fields,
        }
        cards.append(ind)

        self._set(fields, "name", to_full_name(val(five_bis, "01", None)))
        self._set(fields, "date_of_birth", date_to_string(date_from_edi_date(val(five_isi, "01", None))))
        self._set(fields, "province_code", val(nine_bis, "54", None))
        self._set(fields, "postal_code", remove_spaces(val(nine_bis, "55", None)))

        co_insured_dob = val(five_isi, "05", None)

        five_sngs = find_groups_by_group_name(five_bis.get("children", {}), "5SNG")

        for five_sng in five_sngs:
            name = val(five_sng, "03", None)
            dob = val(five_sng, "06", co_insured_dob)

            if name is not None and dob is not None:
                fields = {}
                fixed_id = val(five_sng, "01", uuid.uuid4().hex)
                ind = {
                    "id": fixed_id,
                    "type": "individual",
                    "category": "folio",
                    "fields": fields,
                }
                cards.append(ind)
                self._set(fields, "name", to_full_name(name))
                self._set(fields, "date_of_birth", date_to_string(date_from_edi_date(dob)))
                self._set(fields, "province_code", val(nine_bis, "54", None))
                self._set(fields, "postal_code", remove_spaces(val(nine_bis, "55", None)))

    def _map_scheduled_group(self, six_wsg, cards):
        fields = {}
        fixed_id = val(six_wsg, "01", uuid.uuid4().hex)
        schedule = {
            "id": fixed_id,
            "type": "schedule",
            "category": "folio",
            "fields": fields,
        }
        cards.append(schedule)

        schedule_name = None

        # Watercraft and trailers - scheduled items.
        six_wais = find_groups_by_group_name(six_wsg.get("children", {}), "6WAI")

        # Make a schedule name from the risks. The name will be separated by pipes, so we have some
        # ability to format it on the UI.
        for six_wai in six_wais:
            schedule_name = "|".join(filter(
                None, [schedule_name, " ".join(filter(None, [
                    val(six_wai, "03", None),
                    val(six_wai, "04", None),
                    val(six_wai, "29", None)])).strip()])).strip()

        self._set(fields, "name", schedule_name)

        # Map the schedule coverages into the schedule fields.
        six_cvhs = find_groups_by_group_name(six_wsg.get("children", {}), "6CVH")
        self._map_hab_coverages(six_cvhs, fields)

        # Now we will create a separate vehicle for each watercraft and trailer. To remain compatible,
        # we need to put all the schedule coverage onto each risk. This will eventually be phased out
        # in favor of the schedule we created above.
        for six_wai in six_wais:
            self._map_watercraft_and_trailers(fixed_id,
                                              six_wai,
                                              six_cvhs,
                                              cards)

    def _map_watercraft_and_trailers(self,
                                     schedule,
                                     six_wai,
                                     six_cvhs,
                                     cards):
        vin = val(six_wai, "05", None)
        veh = None
        fields = None

        for card in cards:
            if "vin" in card["fields"] and card["fields"]["vin"] == vin:
                veh = card
                fields = veh["fields"]
                break

        if veh is None:
            fields = {}
            veh = {
                "id": uuid.uuid4().hex,
                "type": "vehicle",
                "category": "folio",
                "fields": fields
            }
            cards.append(veh)

            self._set(fields, "schedule", schedule)

            veh_type = val(six_wai, "02", None)
            length = val(six_wai, "08", None)

            if veh_type == "7":
                type_str = "trailer"
            elif veh_type != "7" and length is None:
                type_str = "engine"
            else:
                type_str = "boat"

            self._set(fields, "type", type_str)
            self._set(fields, "year", val(six_wai, "03", None))
            self._set(fields, "make", val(six_wai, "04", None))
            self._set(fields, "model", val(six_wai, "29", None))
            self._set(fields, "vin", val(six_wai, "05", None))
            self._set(fields, "engine_size", val(six_wai, "06", None))
            self._set(fields, "purchased", date_to_string(date_from_edi_date(val(six_wai, "30", None))))
            self._set(fields, "purchase_price", to_dollars(val(six_wai, "17", val(six_wai, "16", None))))

        self._map_hab_coverages(six_cvhs, fields)

    def _map_hab_coverages(self, coverage_groups, fields):
        if coverage_groups is not None:
            coverages = []

            if "coverages" in fields:
                coverages = fields["coverages"].split(",")

            for coverage_group in coverage_groups:
                cov_code = val(coverage_group, "01", None)

                if cov_code is not None and len(cov_code) > 0:
                    coverages.append(cov_code.lower())

            # Remove any duplicates.
            coverages = list(set(coverages))
            fields["coverages"] = ",".join(coverages)

            for coverage_group in coverage_groups:
                cov_code = val(coverage_group, "01", None)

                if cov_code is not None and len(cov_code) > 0:
                    pfx = "coverage_" + cov_code.lower()
                    premium = to_dollars_and_cents(val(coverage_group, "06", None))
                    self._set(fields, pfx + "_premium", premium)
                    self._set(fields, pfx + "_annual_premium", premium)
                    self._set(fields, pfx + "_limit", to_dollars(val(coverage_group, "11", None)))
                    self._set(fields, pfx + "_deductible", to_dollars(val(coverage_group, "12", None)))
                    self._set(fields, pfx + "_description", val(coverage_group, "24", None))

    def _map_auto_coverages(self, coverage_groups, fields):
        if coverage_groups is not None:
            coverages = []

            for coverage_group in coverage_groups:
                cov_code = val(coverage_group, "01", None)

                if cov_code is not None and len(cov_code) > 0:
                    coverages.append(cov_code.lower())

            # Remove any duplicates.
            coverages = list(set(coverages))
            fields["coverages"] = ",".join(coverages)

            for coverage_group in coverage_groups:
                cov_code = val(coverage_group, "01", None)

                if cov_code is not None and len(cov_code) > 0:
                    pfx = "coverage_" + cov_code.lower()

                    premium = to_dollars_and_cents(val(coverage_group, "06", None))
                    self._set(fields, pfx + "_premium", premium)
                    self._set(fields, pfx + "_annual_premium", premium)
                    self._set(fields, pfx + "_limit", to_dollars(val(coverage_group, "11", None)))
                    self._set(fields, pfx + "_deductible", to_dollars(val(coverage_group, "13", None)))
                    self._set(fields, pfx + "_description", val(coverage_group, "16", None))
