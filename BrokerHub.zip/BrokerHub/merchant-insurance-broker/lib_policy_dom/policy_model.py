import datetime
import logging
from datetime import datetime
from typing import Optional

from lib_common.constants import LOGGER
from lib_policy_dom.base_model import _BaseModel
from lib_policy_dom.coverage_mixin import _CoverageMixin

log = logging.getLogger(LOGGER)


class PolicyModel(_BaseModel, _CoverageMixin):
    """
    Domain model for an insurance policy. Provides structured accessors
    for policy fields, metadata, and related assets such as PDFs and EDI.

    Backed by a raw dict (`self.raw`) which typically contains:
      - "id": Unique identifier for the policy.
      - "fields": Dictionary of domain-specific attributes (policy_number, premium, etc.).
      - Other top-level keys (e.g., "pdfs", "validations", "edi", "json").
    """

    @property
    def number(self) -> str | None:
        """Return the policy number."""
        return self._field("policy_number")

    @property
    def company_code(self) -> str | None:
        """Return the issuing company code."""
        return self._field("company_code")

    @property
    def original_company_code(self) -> str | None:
        """Return the original company code (before transfers or rewrites)."""
        return self._field("original_company_code")

    @property
    def prior_policy_number(self) -> str | None:
        """Return the prior policy number (for renewals or rewritten policies)."""
        return self._field("prior_policy_number")

    @property
    def prior_company_code(self) -> str | None:
        """Return the company code associated with the prior policy."""
        return self._field("prior_company_code")

    @property
    def prior_company_name(self) -> str | None:
        """Return the company name associated with the prior policy."""
        return self._field("prior_company_name")

    @property
    def lob(self) -> str | None:
        """
        Return the line of business (LOB).
        Always lowercased if a string, otherwise None.
        """
        s = self._field("lob")
        return s.lower() if isinstance(s, str) else s

    @property
    def premium_total(self) -> float | None:
        """Return the total premium for the policy, if present."""
        return self._field("premium", float)

    @property
    def annual_premium(self) -> float | None:
        """Return the annualized premium for the policy, if present."""
        return self._field("annual_premium", float)

    @property
    def sequence(self) -> int:
        """
        Return the sequence number of this policy in its renewal chain.
        Falls back to 0 if not set or invalid.
        """
        s = self._field("sequence")
        try:
            return int(s)
        except (TypeError, ValueError):
            return 0

    @property
    def purpose(self) -> str | None:
        """Return the purpose code for this policy (e.g., NBS, RWL, PCH)."""
        return self._field("purpose")

    @property
    def transaction_date(self) -> Optional[datetime.date]:
        """Return the transaction date as a `datetime.date`, if present."""
        s = self._field("transaction_date")
        return datetime.date.fromisoformat(s) if s else None

    @property
    def transaction_effective_date(self) -> Optional[datetime.date]:
        """Return the transaction effective date as a `datetime.date`, if present."""
        s = self._field("transaction_effective_date")
        return datetime.date.fromisoformat(s) if s else None

    @property
    def effective_date(self) -> Optional[datetime.date]:
        """Return the policy effective date as a `datetime.date`, if present."""
        s = self._field("effective_date")
        return datetime.date.fromisoformat(s) if s else None

    @property
    def expiry_date(self) -> Optional[datetime.date]:
        """Return the policy expiry date as a `datetime.date`, if present."""
        s = self._field("expiry_date")
        return datetime.date.fromisoformat(s) if s else None
    @property
    def pdfs(self) -> list[str]:
        """
        Return a list of PDFs attached to this policy.
        Defaults to an empty list if none are set.
        """
        return self.raw.get("pdfs", [])

    @pdfs.setter
    def pdfs(self, value: list[str]) -> None:
        """
        Attach or update a list of PDFs for this policy.
        Pass None to remove the PDFs entry.
        """
        if value is None:
            self.raw.pop("pdfs", None)
        else:
            self.raw["pdfs"] = value

    @property
    def downloaded(self) -> bool:
        """
        Return whether this policy has been marked as downloaded.
        Defaults to False if not present.
        """
        return bool(self.raw.get("downloaded", False))

    @downloaded.setter
    def downloaded(self, value: bool) -> None:
        """
        Mark this policy as downloaded (True/False).
        Pass None to remove the flag entirely.
        """
        if value is None:
            self.raw.pop("downloaded", None)
        else:
            self.raw["downloaded"] = bool(value)

    @property
    def validations(self) -> list[dict]:
        """
        Return the list of validation objects for this policy.
        Each validation is typically a dict describing an error or warning.
        Defaults to an empty list if not present.
        """
        return self.raw.get("validations", [])

    @validations.setter
    def validations(self, value: list[dict]) -> None:
        """
        Set or update the list of validation objects for this policy.
        Pass None to remove the entry.
        """
        if value is None:
            self.raw.pop("validations", None)
        else:
            self.raw["validations"] = value

    @property
    def edi(self) -> str | None:
        """
        Get the raw EDI (AL3) content associated with this policy, if available.
        """
        return self.raw.get("edi")

    @edi.setter
    def edi(self, value: str | None) -> None:
        """
        Set or update the raw EDI (AL3) content for this policy.
        Pass None to remove it.
        """
        if value is None:
            self.raw.pop("edi", None)
        else:
            self.raw["edi"] = value

    @property
    def json(self) -> str | None:
        """
        Get the raw JSON string representation of this policy, if available.
        Note: This may shadow the built-in `json` module.
        """
        return self.raw.get("json")

    @json.setter
    def json(self, value: str | None) -> None:
        """
        Set or update the raw JSON string representation for this policy.
        Pass None to remove it.
        """
        if value is None:
            self.raw.pop("json", None)
        else:
            self.raw["json"] = value

    def has_discount(self, code: str) -> bool:
        """
        Check if this policy has a discount with the given code.
        Discounts are represented in the same structure as coverages.

        Args:
            code: The discount code to check.

        Returns:
            True if the discount is present, False otherwise.
        """
        return self.has_coverage(code)
