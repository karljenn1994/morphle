import datetime
import logging
from datetime import datetime
from typing import Optional

from lib_policy_dom.base_model import _BaseModel
from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class IndividualModel(_BaseModel):
    @property
    def first_name(self):
        return self._field("first_name")

    @property
    def last_name(self):
        return self._field("last_name")

    @property
    def name(self):
        full = self._field("name")
        if full:
            return full
        parts = [p for p in [self.first_name, self.last_name] if p]
        return " ".join(parts) if parts else None

    @property
    def date_of_birth(self):
        s = self._field("date_of_birth")
        try:
            return datetime.date.fromisoformat(s) if s else None
        except Exception:
            return None

    # driver’s licence subcard
    @property
    def drivers_licence(self) -> Optional[dict]:
        return self.raw.get("drivers_licence")

    @property
    def drivers_licence_number(self) -> Optional[str]:
        dl = self.drivers_licence or {}
        return dl.get("fields", {}).get("number")
