import logging
from typing import Optional

from lib_policy_dom.base_model import _BaseModel
from lib_policy_dom.coverage_mixin import _CoverageMixin
from lib_policy_dom.driver_assignment_model import _DriverAssignmentModel
from lib_policy_dom.individual_model import IndividualModel
from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class VehicleModel(_BaseModel, _CoverageMixin):
    @property
    def vehicle_year(self) -> Optional[str]:  # raw string, parity with get_vehicle_year
        return self._field("year")

    @property
    def vehicle_year_int(self) -> Optional[int]:  # parity with get_vehicle_year_as_int
        s = self._field("year")
        try:
            return int(s)
        except (TypeError, ValueError):
            return None

    @property
    def make(self):
        return self._field("make")

    @property
    def model(self):
        return self._field("model")

    @property
    def vin(self):
        return self._field("vin")

    @property
    def drivers(self) -> list[_DriverAssignmentModel]:
        return getattr(self, "_drivers", [])

    def _bind_drivers(self, resolver):
        bound = []
        for d in self.raw.get("drivers", []) or []:
            did = d.get("id")
            use = d.get("use")
            try:
                use_f = float(use) if use is not None else None
            except Exception:
                use_f = None
            bound.append(_DriverAssignmentModel(did, use_f, d.get("principal", False), resolver))
        self._drivers = bound

    @property
    def primary_driver(self) -> Optional[IndividualModel]:
        for d in self.drivers:
            if d.principal:
                return d.individual
        return None
