import logging
from typing import Optional

from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class _BaseModel:
    def __init__(self, raw: dict):
        self.raw = raw or {}

    def _field(self, name, cast=None, default=None):
        v = self.raw.get("fields", {}).get(name)
        if v is None:
            return default
        if cast is None:
            return v
        try:
            return cast(v)
        except Exception:
            return default

    @property
    def id(self) -> Optional[str]:
        return self.raw.get("id")

    @id.setter
    def id(self, v: Optional[str]) -> None:
        if v is None:
            self.raw.pop("id", None)
        else:
            self.raw["id"] = v
