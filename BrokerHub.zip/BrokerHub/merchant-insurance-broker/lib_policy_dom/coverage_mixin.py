import logging
from typing import Any, Dict, Optional, TYPE_CHECKING

from lib_common.constants import LOGGER
from lib_policy_dom.coverage_model import CoverageModel

log = logging.getLogger(LOGGER)


class _CoverageMixin:
    """Shared helpers for Policy, Vehicle, Property."""

    # Only visible to the type checker, not at runtime
    if TYPE_CHECKING:
        raw: Dict[str, Any]

        def _fields(self) -> Dict[str, Any]: ...

    @property
    def coverages(self) -> list[CoverageModel]:
        """Return a list of CoverageModel objects bound to this mixin's raw dict."""
        return [CoverageModel(self, c) for c in self._codes()]

    def _codes(self) -> list[str]:
        coverages = self.raw.get("fields", {}).get("coverages")
        if not coverages:
            return []
        return [c.strip().lower() for c in coverages.split(",") if c.strip()]

    def has_coverage(self, code: str) -> bool:
        return code.lower() in self._codes()

    def _k(self, code: str, suffix: str) -> str:
        return f"coverage_{code.lower()}_{suffix}"

    def premium(self, code: str) -> Optional[float]:
        v = self.raw.get("fields", {}).get(self._k(code, "premium"))
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    def limit(self, code: str) -> Optional[float]:
        v = self.raw.get("fields", {}).get(self._k(code, "limit"))
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    def deductible(self, code: str) -> Optional[float]:
        v = self.raw.get("fields", {}).get(self._k(code, "deductible"))
        try:
            return float(v) if v is not None else None
        except Exception:
            return None

    def coverage_snapshot(self) -> dict:
        fields = self.raw.get("fields", {})
        return {
            c: {
                "premium": self.premium(c),
                "limit": self.limit(c),
                "deductible": self.deductible(c),
                "description": fields.get(self._k(c, "description")),
            }
            for c in self._codes()
        }

    def has_limit(self, code: str) -> bool:
        return self.has_coverage(code)

    def has_deductible(self, code: str) -> bool:
        return self.has_coverage(code)

    def limits(self) -> list[tuple[str, float]]:
        out = []
        f = self.raw.get("fields", {})
        for k, v in f.items():
            if k.endswith("_limit"):
                code = k.split("_")[1]
                try:
                    out.append((code, float(v)))
                except (TypeError, ValueError):
                    pass
        return out

    def deductibles(self) -> list[tuple[str, float]]:
        out = []
        f = self.raw.get("fields", {})
        for k, v in f.items():
            if k.endswith("_deductible"):
                code = k.split("_")[1]
                try:
                    out.append((code, float(v)))
                except (TypeError, ValueError):
                    pass
        return out

    def find_limit(self, code: str) -> Optional[float]:
        v = self.raw.get("fields", {}).get(self._k(code, "limit"))
        try:
            return float(v) if v is not None else None
        except (TypeError, ValueError):
            return None

    def find_deductible(self, code: str) -> Optional[float]:
        v = self.raw.get("fields", {}).get(self._k(code, "deductible"))
        try:
            return float(v) if v is not None else None
        except (TypeError, ValueError):
            return None
