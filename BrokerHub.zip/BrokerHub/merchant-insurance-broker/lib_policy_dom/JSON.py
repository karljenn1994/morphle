import datetime
import json

from lib_common import constants
from lib_common.exceptions import (
    CODE_AL3_MISSING_COMPANY,
    CODE_AL3_MISSING_POLICY_NUMBER,
    CODE_UNSUPPORTED_POLICY_TYPE,
    JSONException
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import policy as policy_lib
from lib_policy_dom.policy_dom import PolicyDOM
from lib_al3.al3_to_json import AL3ToJSON


class JSON(object):
    extensions = (".json",)

    def __new__(cls, *args, **kwds):
        it = cls.__dict__.get("__it__")

        if it is not None:
            return it

        cls.__it__ = it = object.__new__(cls)
        it.init(*args, **kwds)
        return it

    def init(self):
        pass

    @staticmethod
    def load_card_json(card_json_file):
        card_json_str = FileManagerFactory.create_file_manager().read_string(card_json_file)
        j = json.loads(card_json_str)

        if j is list or "version" not in j or j["version"] < constants.CARD_JSON_VERSION:
            # Need to upgrade.
            al3_json_file = card_json_file.replace(".JSON", ".AL3")
            txt = AL3ToJSON.load(al3_json_file)
            al3_map = AL3ToJSON.to_json(txt)
            policy_dom = PolicyDOM.from_al3_json(al3_map)
            policy_dom.save(card_json_file)
            j = policy_dom.json

        return j["cards"]

    @staticmethod
    def make_json_folder(card_json):
        fm = FileManagerFactory.create_file_manager()
        policy_card = JSON.get_policy_card(card_json)

        policy_no = JSON.get_policy_number(policy_card)

        if policy_no is None:
            raise JSONException("Missing policy number in 5BPI", error_code=CODE_AL3_MISSING_POLICY_NUMBER)

        company = JSON.get_company_code(policy_card)

        if company is None:
            raise JSONException("Missing company name in 5BPI", error_code=CODE_AL3_MISSING_COMPANY)

        return fm.join(company.upper(), policy_no.upper(), )

    @staticmethod
    def make_json_file_name(card_json):
        err_msg = ""
        policy_card = JSON.get_policy_card(card_json)
        policy_no = JSON.get_policy_number(policy_card)

        if policy_no is None:
            err_msg += " policy,"

        company = JSON.get_company_code(policy_card)

        if company is None:
            err_msg += " company,"

        lob = JSON.get_lob(policy_card)

        if lob.lower() != "auto" and lob.lower() != "cauto" and lob.lower() != "habl":
            raise JSONException("Policy type " + lob + " not supported", error_code=CODE_UNSUPPORTED_POLICY_TYPE)
        elif lob is None:
            err_msg += " lob,"

        tx_date_str = JSON.get_transaction_date_str(policy_card)

        if not tx_date_str:
            err_msg += " transaction date,"

        policy_effective_date_str = JSON.get_effective_date_str(policy_card)

        if not policy_effective_date_str:
            err_msg += " policy effective date,"

        purpose = JSON.get_purpose(policy_card)

        if purpose is None:
            err_msg += " purpose,"

        seq = JSON.get_sequence_str(policy_card)

        if seq is None:
            err_msg += " seq,"

        if len(err_msg) <= 0:
            file_name = (
                    company
                    + "_" + tx_date_str
                    + "_" + policy_effective_date_str
                    + "_" + seq
                    + "_" + policy_no
                    + "_" + lob
                    + "_" + purpose
                    + ".JSON"
            ).upper()

        else:
            file_name = None

        return file_name, err_msg

    @staticmethod
    def _get_card_field(card, field):
        if card is not None:
            if "fields" in card:
                fields = card["fields"]

                if field in fields:
                    return fields[field]
        return None

    @staticmethod
    def get_policy_card(policy):
        for card in policy:
            if "category" in card and "type" in card:
                if card["category"] == "folio" and card["type"] == "policy":
                    policy_lib.update_company_name(card)
                    return card

        return None

    @staticmethod
    def get_property_cards(policy):
        vehicles = []

        for card in policy:
            if "type" in card and card["type"] == "property":
                vehicles.append(card)

        return vehicles

    @staticmethod
    def get_vehicles(policy):
        vehicles = []

        for card in policy:
            if "type" in card and card["type"] == "vehicle":
                vehicles.append(card)

        return vehicles

    @staticmethod
    def get_individuals(policy):
        individuals = []

        for card in policy:
            if "type" in card and card["type"] == "individual":
                individuals.append(card)

        return individuals

    @staticmethod
    def get_drivers_licences(jsn):
        licences = []

        for card in jsn:
            if "drivers_licence" in card:
                licences.append(card["drivers_licence"])

        return licences

    @staticmethod
    def get_policy_card_id(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_id(policy_card)

    @staticmethod
    def get_policy_card_policy_number(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_policy_number(policy_card)

    @staticmethod
    def get_policy_card_lob(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_lob(policy_card)

    @staticmethod
    def get_policy_card_premium(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_premium(policy_card)

    @staticmethod
    def get_policy_card_original_company_code(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_original_company_code(policy_card)

    @staticmethod
    def get_policy_card_company_code(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_company_code(policy_card)

    @staticmethod
    def get_policy_card_purpose(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_purpose(policy_card)

    @staticmethod
    def get_policy_card_transaction_date(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_transaction_date(policy_card)

    @staticmethod
    def get_policy_card_sequence(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_sequence(policy_card)

    @staticmethod
    def get_policy_card_transaction_effective_date(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_transaction_effective_date(policy_card)

    @staticmethod
    def get_policy_card_effective_date(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_effective_date(policy_card)

    @staticmethod
    def get_policy_card_expiry_date(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.get_expiry_date(policy_card)

    @staticmethod
    def has_policy_card_claims(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.has_claims(policy_card)

    @staticmethod
    def has_policy_card_convictions(jsn):
        policy_card = JSON.get_policy_card(jsn)
        return JSON.has_convictions(policy_card)

    @staticmethod
    def get_id(card):
        if card is not None:
            if "id" in card:
                return card["id"]
        return None

    @staticmethod
    def get_lob(card):
        return JSON._get_card_field(card, "lob")

    @staticmethod
    def get_purpose(card):
        return JSON._get_card_field(card, "purpose")

    @staticmethod
    def get_policy_premium(card):
        return JSON._get_card_field(card, "premium")

    @staticmethod
    def get_policy_number(card):
        return JSON._get_card_field(card, "policy_number")

    @staticmethod
    def get_prior_policy_number(card):
        return JSON._get_card_field(card, "prior_policy_number")

    @staticmethod
    def get_company_code(card):
        return JSON._get_card_field(card, "company_code")

    @staticmethod
    def get_original_company_code(card):
        return JSON._get_card_field(card, "original_company_code")

    @staticmethod
    def get_prior_company_code(card):
        return JSON._get_card_field(card, "prior_company_code")

    @staticmethod
    def get_prior_company_name(card):
        return JSON._get_card_field(card, "prior_company_name")

    @staticmethod
    def get_premium(card):
        return JSON._get_card_field(card, "premium")

    @staticmethod
    def get_annual_premium(card):
        return JSON._get_card_field(card, "annual_premium")

    @staticmethod
    def has_claims(card):
        return JSON._get_card_field(card, "claims")

    @staticmethod
    def has_convictions(card):
        return JSON._get_card_field(card, "convictions")

    @staticmethod
    def get_transaction_date(card):
        effective_date_str = JSON._get_card_field(card, "transaction_date")
        return datetime.datetime.strptime(effective_date_str, "%Y-%m-%d").date()

    @staticmethod
    def get_transaction_date_str(card):
        return JSON._get_card_field(card, "transaction_date")

    @staticmethod
    def get_transaction_effective_date(card):
        effective_date_str = JSON._get_card_field(card, "transaction_effective_date")
        return datetime.datetime.strptime(effective_date_str, "%Y-%m-%d").date()

    @staticmethod
    def get_transaction_effective_date_str(card):
        return JSON._get_card_field(card, "transaction_effective_date")

    @staticmethod
    def get_sequence(card):
        sequence_str = JSON._get_card_field(card, "sequence")
        try:
            seq = int(sequence_str)
        except:
            seq = 0
        return seq

    @staticmethod
    def get_sequence_str(card):
        return JSON._get_card_field(card, "sequence")

    @staticmethod
    def get_effective_date(card):
        effective_date_str = JSON._get_card_field(card, "effective_date")
        return datetime.datetime.strptime(effective_date_str, "%Y-%m-%d").date()

    @staticmethod
    def get_effective_date_str(card):
        return JSON._get_card_field(card, "effective_date")

    @staticmethod
    def get_expiry_date(card):
        expiry_date_str = JSON._get_card_field(card, "expiry_date")
        return datetime.datetime.strptime(expiry_date_str, "%Y-%m-%d").date()

    @staticmethod
    def get_expiry_date_time(card):
        expiry_date_str = JSON._get_card_field(card, "expiry_date")
        return datetime.datetime.strptime(expiry_date_str, "%Y-%m-%d")

    @staticmethod
    def get_postal_code(card):
        return JSON._get_card_field(card, "postal_code")

    @staticmethod
    def get_province_code(card):
        return JSON._get_card_field(card, "province_code")

    @staticmethod
    def get_address(card):
        return JSON._get_card_field(card, "address")

    @staticmethod
    def get_city(card):
        return JSON._get_card_field(card, "city")

    @staticmethod
    def get_date_of_birth(card):
        date_of_birth_str = JSON._get_card_field(card, "date_of_birth")

        if date_of_birth_str is not None and len(date_of_birth_str) == 10:
            try:
                datetime.datetime.strptime(date_of_birth_str, "%Y-%m-%d").date()
                return datetime.datetime.strptime(date_of_birth_str, "%Y-%m-%d").date()
            except:
                pass

        return None

    @staticmethod
    def get_date_of_birth_str(card):
        return JSON._get_card_field(card, "date_of_birth")

    @staticmethod
    def get_name(card):
        return JSON._get_card_field(card, "name")

    @staticmethod
    def get_primary_driver(jsn, vehicle_card):
        driver_id = None

        if "drivers" in vehicle_card:
            drivers = vehicle_card["drivers"]

            for driver in drivers:
                if "principal" in driver:
                    if driver["principal"]:
                        driver_id = driver["id"]
                        break

        for card in jsn:
            if "type" in card and card["type"] == "individual":
                if card["id"] == driver_id:
                    return card
        return None

    @staticmethod
    def get_drivers_licence_number(card):
        return JSON._get_card_field(card, "number")

    @staticmethod
    def get_first_name(card):
        return JSON._get_card_field(card, "first_name")

    @staticmethod
    def get_last_name(card):
        return JSON._get_card_field(card, "last_name")

    @staticmethod
    def get_vehicle_year(card):
        return JSON._get_card_field(card, "year")

    @staticmethod
    def get_vehicle_year_as_int(card):
        year = JSON._get_card_field(card, "year")
        try:
            year = int(year)
        except:
            year = None
        return year

    @staticmethod
    def get_vehicle_make(card):
        return JSON._get_card_field(card, "make")

    @staticmethod
    def get_vehicle_model(card):
        return JSON._get_card_field(card, "model")

    @staticmethod
    def get_vehicle_vin(card):
        return JSON._get_card_field(card, "vin")

    @staticmethod
    def get_limits(card):
        limits = []

        if "fields" in card:
            fields = card["fields"]

            for field in fields:
                if field.endswith("_limit"):
                    limits.append((field.split("_")[1], float(fields[field])))
        return limits

    @staticmethod
    def get_deductibles(card):
        deductibles = []

        if "fields" in card:
            fields = card["fields"]

            for field in fields:
                if field.endswith("_deductible"):
                    deductibles.append((field.split("_")[1], float(fields[field])))
        return deductibles

    @staticmethod
    def find_vehicle(jsn, vehicle):
        vehicles = JSON.get_vehicles(jsn)

        if len(vehicles) > 0:
            s_vin = JSON.get_vehicle_vin(vehicle)
            s_year = JSON.get_vehicle_year(vehicle)
            s_make = JSON.get_vehicle_make(vehicle)
            s_model = JSON.get_vehicle_model(vehicle)

            for v in vehicles:
                vin = JSON.get_vehicle_vin(v)
                year = JSON.get_vehicle_year(v)
                make = JSON.get_vehicle_make(v)
                model = JSON.get_vehicle_model(v)

                if vin == s_vin:
                    return v

                if s_year == year and s_make == make and s_model == model:
                    return v

        return None

    @staticmethod
    def find_property(jsn, property_card):
        properties = JSON.get_property_cards(jsn)

        if len(properties) > 0:
            s_address = JSON.get_address(property_card)

            for p in properties:
                address = JSON.get_address(p)

                if address == s_address:
                    return p
        return None

    @staticmethod
    def find_limit(card, limit):
        limits = JSON.get_limits(card)

        if len(limits) > 0:
            for lim in limits:
                if lim[0] == limit:
                    return lim[1]

        return None

    @staticmethod
    def find_deductible(card, deductible):
        deductibles = JSON.get_deductibles(card)

        if len(deductibles) > 0:
            for ded in deductibles:
                if ded[0] == deductible:
                    return ded[1]

        return None

    @staticmethod
    def has_coverage(card, coverage_code):
        if "fields" in card:
            fields = card["fields"]

            if "coverages" in fields:
                if coverage_code in fields["coverages"]:
                    return True
        return False

    @staticmethod
    def has_limit(card, coverage_code):
        if "fields" in card:
            fields = card["fields"]

            if "coverages" in fields:
                if coverage_code.lower() in fields["coverages"]:
                    return True
        return False

    @staticmethod
    def has_deductible(card, coverage_code):
        if "fields" in card:
            fields = card["fields"]

            if "coverages" in fields:
                if coverage_code.lower() in fields["coverages"]:
                    return True
        return False

    @staticmethod
    def has_discount(card, discount_code):
        if "fields" in card:
            fields = card["fields"]

            if "coverages" in fields:
                if discount_code.lower() in fields["coverages"]:
                    return True
        return False
