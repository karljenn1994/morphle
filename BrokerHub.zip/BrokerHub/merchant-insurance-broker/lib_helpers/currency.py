from typing import Optional

from lib_helpers.numbers import to_float


def to_dollars_and_cents(unformatted: Optional[str]) -> Optional[str]:
    """
    Convert an unformatted currency string (e.g., "0001234") into
    a string with dollars and cents (e.g., "12.34").

    :param unformatted: Raw string representation of a number may include
                        leading zeros, "+" or "-" signs.
    :return: A string formatted as dollars and cents (e.g., "12.34"),
             or None if input is invalid.
    """
    if unformatted is None:
        return None

    dollars_and_cents = unformatted.strip()

    if dollars_and_cents and len(dollars_and_cents) > 0:
        try:
            neg = ""
            dollars_and_cents = (
                dollars_and_cents.strip()
                .replace("+", "")
                .lstrip("0")
            )

            if dollars_and_cents.endswith("-"):
                dollars_and_cents = dollars_and_cents.rstrip("-")
                neg = "-"

            if len(dollars_and_cents) > 0:
                dollars_and_cents = (
                    neg
                    + dollars_and_cents[0: len(dollars_and_cents) - 2]
                    + "."
                    + dollars_and_cents[-2:]
                )
        except Exception:
            pass

    if len(dollars_and_cents) > 0:
        return to_float(dollars_and_cents)

    return None


def to_dollars(unformatted: Optional[str]) -> Optional[str]:
    """
    Convert an unformatted currency string (e.g., "0001234") into
    a whole-dollar string (e.g., "1234").

    :param unformatted: Raw string representation of a number may include
                        leading zeros, "+" or "-" signs.
    :return: A string formatted as whole dollars (e.g., "1234"),
             or None if input is invalid.
    """
    if unformatted is None:
        return None

    dollars = unformatted.strip()

    if dollars and len(dollars) > 0:
        try:
            neg = ""
            dollars = (
                dollars.strip()
                .replace("+", "")
                .lstrip("0")
            )

            if dollars.endswith("-"):
                dollars = dollars.rstrip("-")
                neg = "-"

            if len(dollars) > 0:
                dollars = neg + dollars

        except Exception:
            pass

    if len(dollars) > 0:
        return to_float(dollars)

    return None
