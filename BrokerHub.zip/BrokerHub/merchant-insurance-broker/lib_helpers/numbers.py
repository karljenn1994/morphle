from typing import Optional


def to_float(value: object) -> Optional[float]:
    """
    Safely convert a value to a float.

    :param value: Any object that can be converted to float.
    :return: Float value, or None if conversion fails.
    """
    try:
        return float(value)  # type: ignore[arg-type]
    except (ValueError, TypeError):
        return None


def is_zero_string(zero_string: str) -> bool:
    """
    Check if a string represents the integer zero.

    :param zero_string: A string potentially containing a number.
    :return: True if the string represents zero, otherwise False.
    """
    try:
        return int(zero_string) == 0
    except (ValueError, TypeError):
        return False
