from datetime import date
from typing import Optional


def to_annual_premium(
        premium: Optional[float],
        start_date: Optional[date],
        end_date: Optional[date],
        annual_basis: float = 365.0,  # use 365.2425 if you prefer mean solar year
) -> Optional[float]:
    """
    Annualize a premium that applies to the period [start, end).

    Rules:
      - end_date is EXCLUSIVE (coverage runs up to but not including end_date).

    Args:
        premium: Premium.
        start_date: Policy start of coverage.
        end_date: Policy expiry (exclusive).
        annual_basis: Number of days representing a full-term year.

    Returns:
        Rounded full-term premium, or None if inputs are invalid.
    """
    if not premium or not end_date:
        return None

    days = (end_date - start_date).days
    if days <= 0:
        return None

    return round(premium / days * annual_basis, 2)
