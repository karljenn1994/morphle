from typing import Optional


def to_full_name(name: Optional[str]) -> Optional[str]:
    """
    Extract a full name from a fixed-width encoded string.

    :param name: Encoded name string (e.g., from EDI/AL3 format).
    :return: Full name as a title-cased string, or None if invalid.
    """
    if name is None or len(name) <= 0:
        return None

    full_name: Optional[str] = None
    nt = name[0]

    if nt == "I":
        full_name = " ".join([name[9:24].strip(), name[36:55].strip()])
    elif nt == "F":
        full_name = " ".join([name[9:35].strip(), name[36:55].strip()])
    elif nt in ("T", "O"):
        full_name = name[1:51].strip()

    return full_name.title() if full_name is not None else full_name


def to_first_name(name: Optional[str]) -> Optional[str]:
    """
    Extract the first name from a fixed-width encoded string.

    :param name: Encoded name string.
    :return: First name as a title-cased string, or None if invalid.
    """
    if name is None or len(name) <= 0:
        return None

    first_name: Optional[str] = None
    nt = name[0]

    if nt == "I":
        first_name = name[9:24].strip()
    elif nt == "F":
        first_name = name[9:35].strip()

    return first_name.title() if first_name is not None else first_name


def to_last_name(name: Optional[str]) -> Optional[str]:
    """
    Extract the last name from a fixed-width encoded string.

    :param name: Encoded name string.
    :return: Last name as a title-cased string, or None if invalid.
    """
    if name is None or len(name) <= 0:
        return None

    last_name: Optional[str] = None
    nt = name[0]

    if nt in ("I", "F"):
        last_name = name[36:55].strip()

    return last_name.title() if last_name is not None else last_name


def parse_first_name(name: Optional[str]) -> Optional[str]:
    """
    Parse the first name from a free-form encoded string.

    :param name: Encoded name string (comma or space-separated).
    :return: First name as a title-cased string, or None if invalid.
    """
    if name is None or len(name) <= 0:
        return None

    full_name = " ".join(name[1:].split())
    if len(full_name) <= 0:
        return None

    first_name: Optional[str] = None
    if "," in full_name:
        first_name = " ".join(full_name.split(",")[1:]).strip()
    elif " " in full_name:
        first_name = full_name.split(" ")[0].strip()

    return first_name.title() if first_name is not None else first_name


def parse_last_name(name: Optional[str]) -> Optional[str]:
    """
    Parse the last name from a free-form encoded string.

    :param name: Encoded name string (comma or space-separated).
    :return: Last name as a title-cased string, or None if invalid.
    """
    if name is None or len(name) <= 0:
        return None

    full_name = " ".join(name[1:].split())
    if len(full_name) <= 0:
        return None

    last_name: Optional[str] = None
    if "," in full_name:
        last_name = full_name.split(",")[0].strip()
    elif " " in full_name:
        last_name = " ".join(full_name.split(" ")[1:]).strip()

    return last_name.title() if last_name is not None else last_name
