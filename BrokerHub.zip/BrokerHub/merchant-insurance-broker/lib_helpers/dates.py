import datetime
from datetime import date, datetime
from typing import Optional, Union


def date_from_string(s: Optional[Union[str, date, datetime]]) -> Optional[date]:
    """
    Convert a string, datetime, or date into a `date` object.
    Returns None if conversion fails.
    """
    if not s:
        return None
    if isinstance(s, date) and not isinstance(s, datetime):
        return s
    if isinstance(s, datetime):
        return s.date()
    try:
        return datetime.fromisoformat(str(s)).date()
    except Exception:
        return None


def date_from_edi_date(edi_date: Optional[Union[str, bytes, bytearray]]) -> Optional[date]:
    """
    Converts the EDI date into a usable `date` object.

    EDI dates can come in various formats:
    - YYYYMMDD (8 chars)
    - Encoded with year prefix (>= 5 chars, leading A-F)
    - 4-digit shorthand
    - Or already a string-like date

    :param edi_date: The date in EDI format (string or bytes)
    :return: A `date` object, or None if parsing fails
    """
    if edi_date is None:
        return None

    if isinstance(edi_date, (bytes, bytearray)):
        edi_date = edi_date.decode()

    if len(edi_date) == 8:
        return date_from_string(edi_date[0:4] + "-" + edi_date[4:6] + "-" + edi_date[6:8])

    elif len(edi_date) >= 5:
        year_char = edi_date[0]
        return_string = ""

        if year_char == "A":
            return_string = "200"
        if year_char == "B":
            return_string = "201"
        elif year_char == "C":
            return_string = "202"
        elif year_char == "D":
            return_string = "203"
        elif year_char == "E":
            return_string = "204"
        elif year_char == "F":
            return_string = "205"
        elif edi_date.isdigit():
            # If the whole date is numeric, its year <2000
            return_string = "19" + year_char

        return_string += edi_date[1] + "-"
        return_string += edi_date[2] + edi_date[3] + "-"
        return_string += edi_date[4] + edi_date[5]
        return date_from_string(return_string)

    elif len(edi_date) == 4:
        year_char = edi_date[0]
        return_string = ""

        if year_char == "B":
            return_string = "201"
        elif year_char == "C":
            return_string = "202"
        elif year_char == "D":
            return_string = "203"
        elif year_char == "E":
            return_string = "204"
        elif year_char == "F":
            return_string = "205"

        return_string += edi_date[1] + "-"
        return_string += edi_date[2] + edi_date[3]
        return date_from_string(return_string)

    else:
        return date_from_string(edi_date)


def date_to_string(d: Optional[Union[date, datetime, str]]) -> Optional[str]:
    """
    Convert a `date`, `datetime`, or string into an ISO8601 date string.
    Returns None if conversion fails.
    """
    if d is None:
        return None
    if isinstance(d, str):
        return d
    if isinstance(d, datetime):
        return d.date().isoformat()
    if isinstance(d, date):
        return d.isoformat()
    return None
