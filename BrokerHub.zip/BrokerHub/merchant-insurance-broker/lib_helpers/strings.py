def upper(val):
    if val is not None:
        return val.upper()

    return val
