import json
import sys
from datetime import datetime

from dateutil.relativedelta import relativedelta

from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import validator
from lib_policy_dom.JSON import JSON
from validations import issues_support
from validations.issues_support import create_issues_file, create_validations

this_mod = sys.modules[__name__]


def validate(validations_obj, renewal_obj, previous_policy_obj, is_multi_line):
    fm = FileManagerFactory.create_file_manager()

    # Create a JSON for the set of validations.
    validations = create_validations(validations_obj.type)

    root = Repository.policies_location
    renewal = JSON.load_card_json(fm.join(Repository.policies_location, renewal_obj.file_name)) \
        if renewal_obj is not None and renewal_obj.file_name is not None else None
    previous = JSON.load_card_json(fm.join(root, previous_policy_obj.file_name)) \
        if previous_policy_obj is not None and previous_policy_obj.file_name is not None else None

    validation_ctx = {
        "validations_obj": validations_obj,
        "renewal_obj": renewal_obj,
        "renewal_json": renewal,
        "previous_obj": previous_policy_obj,
        "previous_json": previous,
        "is_multi_line": is_multi_line,
    }

    validation_rules = validator.list_validation_rules_by_validation_id(validations_obj.id)
    for rule in validation_rules:
        if rule.enabled:
            if callable(getattr(this_mod, rule.func, None)):
                # safe to use the function
                f = getattr(this_mod, rule.func)
                cfg = json.loads(rule.cfg) if rule.cfg is not None else None
                validations["issues"].extend(f(rule, cfg, validation_ctx))

    # Write all the issues to an issues file associated with the policy file.
    issues_file_name = create_issues_file(renewal_obj)
    fm.write_string(fm.join(Repository.policies_location, issues_file_name), json.dumps(validations, indent=4))


def _append_issue(validations, issue):
    if issue is not None:
        validations["issues"].append(issue)


def _add_issue(validation_ctx, rule, ctx=None, ref_id=None):
    policy_id = validation_ctx["renewal_obj"].id
    validator.create_issue(policy_id, rule.code)
    return {
        "ref_id": ref_id,
        "type": rule.type,
        "ctx": ctx,
        "severity": rule.severity,
        "code": rule.code,
        "message": rule.message.format(ctx=ctx) if ctx is not None else rule.message,
    }


def _get_coverage_codes(cfg):
    coverage_codes = None
    if cfg is not None and "coverage_code" in cfg:
        if isinstance(cfg["coverage_code"]["value"], list):
            coverage_codes = cfg["coverage_code"]["value"]
        else:
            coverage_codes = [cfg["coverage_code"]["value"]]
    return coverage_codes


def vehicle_coverage_missing(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
    coverage_codes = _get_coverage_codes(cfg)

    if coverage_codes is not None:
        for renewal_vehicle in renewal_vehicles:
            missing_all = True
            for coverage_code in coverage_codes:
                if JSON.has_coverage(renewal_vehicle, coverage_code):
                    missing_all = False
                    break
            if missing_all:
                issues.append(_add_issue(
                    validation_ctx,
                    rule,
                    ctx=coverage_codes,
                    ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_coverage_missing_for_newer(rule, cfg, validation_ctx):
    issues = []
    coverage_codes = _get_coverage_codes(cfg)
    years_old = cfg["years_old"]["value"] if cfg is not None and "years_old" in cfg else None
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

    if coverage_codes is not None and years_old is not None:
        for renewal_vehicle in renewal_vehicles:
            year = JSON.get_vehicle_year_as_int(renewal_vehicle)
            if year is not None:
                if datetime.now().year - year < years_old:
                    missing_all = True
                    for coverage_code in coverage_codes:
                        if JSON.has_coverage(renewal_vehicle, coverage_code):
                            missing_all = False
                            break
                    if missing_all:
                        issues.append(_add_issue(
                            validation_ctx,
                            rule,
                            ctx=coverage_codes,
                            ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_deductible_missing(rule, cfg, validation_ctx):
    issues = []
    coverage_code = cfg["coverage_code"]["value"] if cfg is not None else None
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

    if coverage_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_deductible(renewal_vehicle, coverage_code):
                issues.append(
                    _add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_limit_missing(rule, cfg, validation_ctx):
    issues = []
    coverage_code = cfg["coverage_code"]["value"] if cfg is not None else None
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

    if coverage_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_limit(renewal_vehicle, coverage_code):
                issues.append(
                    _add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_deductible_increase(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
        percent = cfg["percent"]["value"] if cfg is not None else 0

        for renewal_vehicle in renewal_vehicles:
            previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_vehicle)
            if previous_vehicle is not None:
                renewal_deductibles = JSON.get_deductibles(renewal_vehicle)
                for renewal_deductible in renewal_deductibles:
                    previous_deductible = JSON.find_deductible(previous_vehicle, renewal_deductible[0])
                    if previous_deductible is not None:
                        if renewal_deductible[1] > previous_deductible:
                            pc = issues_support.calculate_percent_change(previous_deductible,
                                                                         renewal_deductible[1])
                            if pc > percent:
                                issues.append(
                                    _add_issue(
                                        validation_ctx,
                                        rule,
                                        ctx=renewal_deductible[0],
                                        ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_deductible_decrease(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
        percent = cfg["percent"]["value"] if cfg is not None else 0

        for renewal_vehicle in renewal_vehicles:
            previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_vehicle)
            if previous_vehicle is not None:
                renewal_deductibles = JSON.get_deductibles(renewal_vehicle)
                for renewal_deductible in renewal_deductibles:
                    previous_deductible = JSON.find_deductible(previous_vehicle, renewal_deductible[0])
                    if previous_deductible is not None:
                        if renewal_deductible[1] < previous_deductible:
                            pc = issues_support.calculate_percent_change(previous_deductible,
                                                                         renewal_deductible[1])
                            if pc > percent:
                                issues.append(
                                    _add_issue(
                                        validation_ctx,
                                        rule,
                                        ctx=renewal_deductible[0],
                                        ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_limit_increase(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        percent = cfg["percent"]["value"] if cfg is not None else 0
        renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

        for renewal_vehicle in renewal_vehicles:
            previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_vehicle)
            if previous_vehicle is not None:
                renewal_limits = JSON.get_limits(renewal_vehicle)
                for renewal_limit in renewal_limits:
                    previous_limit = JSON.find_limit(previous_vehicle, renewal_limit[0])
                    if previous_limit is not None:
                        if renewal_limit[1] > previous_limit:
                            pc = issues_support.calculate_percent_change(previous_limit, renewal_limit[1])
                            if pc > percent:
                                issues.append(
                                    _add_issue(
                                        validation_ctx,
                                        rule,
                                        ctx=renewal_limit[0],
                                        ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_limit_decrease(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        percent = cfg["percent"]["value"] if cfg is not None else 0
        renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

        for renewal_vehicle in renewal_vehicles:
            previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_vehicle)
            if previous_vehicle is not None:
                renewal_limits = JSON.get_limits(renewal_vehicle)
                for renewal_limit in renewal_limits:
                    previous_limit = JSON.find_limit(previous_vehicle, renewal_limit[0])
                    if previous_limit is not None:
                        if renewal_limit[1] < previous_limit:
                            pc = issues_support.calculate_percent_change(previous_limit, renewal_limit[1])
                            if pc > percent:
                                issues.append(_add_issue(
                                    validation_ctx,
                                    rule,
                                    ctx=renewal_limit[0],
                                    ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_discount_missing(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_discount(renewal_vehicle, discount_code):
                issues.append(
                    _add_issue(
                        validation_ctx,
                        rule,
                        ctx=discount_code,
                        ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_discount_missing_claims_free(rule, cfg, validation_ctx):
    issues = []
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        if not JSON.has_policy_card_claims(validation_ctx["renewal_json"]):
            renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
            for renewal_vehicle in renewal_vehicles:
                if not JSON.has_discount(renewal_vehicle, discount_code):
                    issues.append(
                        _add_issue(
                            validation_ctx,
                            rule,
                            ctx=discount_code,
                            ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_discount_missing_multi_line(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_discount(renewal_vehicle, discount_code):
                if validation_ctx["is_multi_line"]:
                    issues.append(
                        _add_issue(
                            validation_ctx,
                            rule,
                            ctx=discount_code,
                            ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_discount_missing_multi_vehicle(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_discount(renewal_vehicle, discount_code):
                if len(renewal_vehicles) > 1:
                    issues.append(
                        _add_issue(
                            validation_ctx,
                            rule,
                            ctx=discount_code,
                            ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_discount_missing_mature_driver(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None
    mature_age = cfg["mature_age"]["value"] if cfg is not None and "mature_age" in cfg else 55

    if discount_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_discount(renewal_vehicle, discount_code):
                driver = JSON.get_primary_driver(validation_ctx["renewal_json"], renewal_vehicle)
                if driver is not None:
                    if driver is not None and relativedelta(datetime.now(),
                                                            JSON.get_date_of_birth(driver)).years > mature_age:
                        issues.append(
                            _add_issue(
                                validation_ctx,
                                rule,
                                ctx=discount_code,
                                ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def vehicle_discount_missing_school_age(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None
    school_age = cfg["school_age"]["value"] if cfg is not None and "school_age" in cfg else 20

    if discount_code is not None:
        has_school_aged_driver = False
        drivers = JSON.get_individuals(validation_ctx["renewal_json"])
        for driver in drivers:
            dob = JSON.get_date_of_birth(driver)
            years = relativedelta(datetime.now(), dob).years
            if years <= school_age:
                has_school_aged_driver = True
                break
        if has_school_aged_driver:
            for renewal_vehicle in renewal_vehicles:
                if not JSON.has_discount(renewal_vehicle, discount_code):
                    issues.append(
                        _add_issue(
                            validation_ctx,
                            rule,
                            ctx=discount_code,
                            ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def policy_premium_increase(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        policy_id = JSON.get_policy_card_id(validation_ctx["renewal_json"])
        percent = cfg["percent"]["value"] if cfg is not None else 0
        previous_premium = JSON.get_policy_card_premium(validation_ctx["previous_json"])
        renewal_premium = JSON.get_policy_card_premium(validation_ctx["renewal_json"])

        if previous_premium and renewal_premium:
            previous_premium = float(previous_premium)
            renewal_premium = float(renewal_premium)

            pc = issues_support.calculate_percent_change(previous_premium, renewal_premium)
            if pc > percent:
                issues.append(_add_issue(
                    validation_ctx,
                    rule,
                    ref_id=policy_id))
    return issues


def policy_young_drivers(rule, cfg, validation_ctx):
    issues = []
    policy_id = JSON.get_policy_card_id(validation_ctx["renewal_json"])
    drivers = JSON.get_individuals(validation_ctx["renewal_json"])
    child_age = cfg["young_age"]["value"] if cfg is not None and "young_age" in cfg else None
    parent_age_min = cfg["parent_age_min"]["value"] if cfg is not None and "parent_age_min" in cfg else None
    parent_age_max = cfg["parent_age_max"]["value"] if cfg is not None and "parent_age_max" in cfg else None
    parent_driver = None

    for driver in drivers:
        dob = JSON.get_date_of_birth(driver)
        age = relativedelta(datetime.now(), dob).years
        if parent_age_min <= age <= parent_age_max:
            parent_driver = driver
            break

    if parent_driver is not None:
        for driver in drivers:
            dob = JSON.get_date_of_birth(driver)
            age = relativedelta(datetime.now(), dob).years
            if age < child_age:
                issues.append(_add_issue(
                    validation_ctx,
                    rule,
                    ref_id=policy_id))
                break
    return issues


def property_coverage_missing(rule, cfg, validation_ctx):
    issues = []
    renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])
    coverage_codes = _get_coverage_codes(cfg)

    if coverage_codes is not None:
        for renewal_property in renewal_properties:
            missing_all = True
            for coverage_code in coverage_codes:
                if JSON.has_coverage(renewal_property, coverage_code):
                    missing_all = False
                    break
            if missing_all:
                issues.append(_add_issue(
                    validation_ctx,
                    rule,
                    ctx=coverage_codes,
                    ref_id=JSON.get_id(renewal_property)))
    return issues


def property_limit_increase(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        percent = cfg["percent"]["value"] if cfg is not None else 0
        renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])

        for renewal_property in renewal_properties:
            previous_property = JSON.find_property(validation_ctx["previous_json"], renewal_property)
            if previous_property is not None:
                renewal_limits = JSON.get_limits(renewal_property)
                for renewal_limit in renewal_limits:
                    previous_limit = JSON.find_limit(previous_property, renewal_limit[0])
                    if previous_limit is not None:
                        if renewal_limit[1] > previous_limit:
                            pc = issues_support.calculate_percent_change(previous_limit, renewal_limit[1])
                            if pc > percent:
                                issues.append(
                                    _add_issue(
                                        validation_ctx,
                                        rule,
                                        ctx=renewal_limit[0],
                                        ref_id=JSON.get_id(renewal_property)))
    return issues


def property_limit_decrease(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        percent = cfg["percent"]["value"] if cfg is not None else 0
        renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])

        for renewal_property in renewal_properties:
            previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_property)
            if previous_vehicle is not None:
                renewal_limits = JSON.get_limits(renewal_property)
                for renewal_limit in renewal_limits:
                    previous_limit = JSON.find_limit(previous_vehicle, renewal_limit[0])
                    if previous_limit is not None:
                        if renewal_limit[1] < previous_limit:
                            pc = issues_support.calculate_percent_change(previous_limit, renewal_limit[1])
                            if pc > percent:
                                issues.append(_add_issue(
                                    validation_ctx,
                                    rule,
                                    ctx=renewal_limit[0],
                                    ref_id=JSON.get_id(renewal_property)))
    return issues


def property_limit_missing(rule, cfg, validation_ctx):
    issues = []
    coverage_code = cfg["coverage_code"]["value"] if cfg is not None else None
    renewal_vehicles = JSON.get_property_cards(validation_ctx["renewal_json"])

    if coverage_code is not None:
        for renewal_property in renewal_vehicles:
            if not JSON.has_limit(renewal_property, coverage_code):
                issues.append(
                    _add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_property)))
    return issues


def property_deductible_increase(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])
        percent = cfg["percent"]["value"] if cfg is not None else 0

        for renewal_property in renewal_properties:
            previous_property = JSON.find_property(validation_ctx["previous_json"], renewal_property)
            if previous_property is not None:
                renewal_deductibles = JSON.get_deductibles(renewal_property)
                for renewal_deductible in renewal_deductibles:
                    previous_deductible = JSON.find_deductible(previous_property, renewal_deductible[0])
                    if previous_deductible is not None:
                        if renewal_deductible[1] > previous_deductible:
                            pc = issues_support.calculate_percent_change(previous_deductible,
                                                                         renewal_deductible[1])
                            if pc > percent:
                                issues.append(
                                    _add_issue(
                                        validation_ctx,
                                        rule,
                                        ctx=renewal_deductible[0],
                                        ref_id=JSON.get_id(renewal_property)))
    return issues


def property_deductible_decrease(rule, cfg, validation_ctx):
    issues = []

    if "previous_json" in validation_ctx and validation_ctx["previous_json"] is not None:
        renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])
        percent = cfg["percent"]["value"] if cfg is not None else 0

        for renewal_property in renewal_properties:
            previous_property = JSON.find_property(validation_ctx["previous_json"], renewal_property)
            if previous_property is not None:
                renewal_deductibles = JSON.get_deductibles(renewal_property)
                for renewal_deductible in renewal_deductibles:
                    previous_deductible = JSON.find_deductible(previous_property, renewal_deductible[0])
                    if previous_deductible is not None:
                        if renewal_deductible[1] < previous_deductible:
                            pc = issues_support.calculate_percent_change(previous_deductible,
                                                                         renewal_deductible[1])
                            if pc > percent:
                                issues.append(
                                    _add_issue(
                                        validation_ctx,
                                        rule,
                                        ctx=renewal_deductible[0],
                                        ref_id=JSON.get_id(renewal_property)))
    return issues


def property_deductible_missing(rule, cfg, validation_ctx):
    issues = []
    coverage_code = cfg["coverage_code"]["value"] if cfg is not None else None
    renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])

    if coverage_code is not None:
        for renewal_property in renewal_properties:
            if not JSON.has_deductible(renewal_property, coverage_code):
                issues.append(
                    _add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_property)))
    return issues


def property_discount_missing(rule, cfg, validation_ctx):
    issues = []
    renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        for renewal_property in renewal_properties:
            if not JSON.has_discount(renewal_property, discount_code):
                issues.append(
                    _add_issue(
                        validation_ctx,
                        rule,
                        ctx=discount_code,
                        ref_id=JSON.get_id(renewal_property)))
    return issues


def property_discount_missing_claims_free(rule, cfg, validation_ctx):
    issues = []
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        if not JSON.has_policy_card_claims(validation_ctx["renewal_json"]):
            renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])
            for renewal_property in renewal_properties:
                if not JSON.has_discount(renewal_property, discount_code):
                    issues.append(
                        _add_issue(
                            validation_ctx,
                            rule,
                            ctx=discount_code,
                            ref_id=JSON.get_id(renewal_property)))
    return issues


def property_discount_missing_mature_owner(rule, cfg, validation_ctx):
    issues = []
    renewal_vehicles = JSON.get_property_cards(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None
    mature_age = cfg["mature_age"]["value"] if cfg is not None and "mature_age" in cfg else 55

    if discount_code is not None:
        for renewal_vehicle in renewal_vehicles:
            if not JSON.has_discount(renewal_vehicle, discount_code):
                driver = JSON.get_primary_driver(validation_ctx["renewal_json"], renewal_vehicle)
                if driver is not None:
                    if driver is not None and relativedelta(datetime.now(),
                                                            JSON.get_date_of_birth(driver)).years > mature_age:
                        issues.append(
                            _add_issue(
                                validation_ctx,
                                rule,
                                ctx=discount_code,
                                ref_id=JSON.get_id(renewal_vehicle)))
    return issues


def property_discount_missing_multi_line(rule, cfg, validation_ctx):
    issues = []
    renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])
    discount_code = cfg["discount_code"]["value"] if cfg is not None else None

    if discount_code is not None:
        for renewal_property in renewal_properties:
            if not JSON.has_discount(renewal_property, discount_code):
                if validation_ctx["is_multi_line"]:
                    issues.append(
                        _add_issue(
                            validation_ctx,
                            rule,
                            ctx=discount_code,
                            ref_id=JSON.get_id(renewal_property)))
    return issues


def vehicle_coverage_removed(rule, cfg, validation_ctx):
    issues = []
    if validation_ctx.get("previous_json") is None:
        return issues

    coverage_codes = _get_coverage_codes(cfg)
    if not coverage_codes:
        return issues

    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

    for renewal_vehicle in renewal_vehicles:
        previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_vehicle)
        if previous_vehicle:
            for coverage_code in coverage_codes:
                if JSON.has_coverage(previous_vehicle, coverage_code) and not JSON.has_coverage(renewal_vehicle,
                                                                                                coverage_code):
                    issues.append(_add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_vehicle)
                    ))
    return issues


def vehicle_coverage_added(rule, cfg, validation_ctx):
    issues = []
    if validation_ctx.get("previous_json") is None:
        return issues

    coverage_codes = _get_coverage_codes(cfg)
    if not coverage_codes:
        return issues

    renewal_vehicles = JSON.get_vehicles(validation_ctx["renewal_json"])

    for renewal_vehicle in renewal_vehicles:
        previous_vehicle = JSON.find_vehicle(validation_ctx["previous_json"], renewal_vehicle)
        if previous_vehicle:
            for coverage_code in coverage_codes:
                if not JSON.has_coverage(previous_vehicle, coverage_code) and JSON.has_coverage(renewal_vehicle,
                                                                                                coverage_code):
                    issues.append(_add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_vehicle)
                    ))
    return issues


def property_coverage_removed(rule, cfg, validation_ctx):
    issues = []
    if validation_ctx.get("previous_json") is None:
        return issues

    coverage_codes = _get_coverage_codes(cfg)
    if not coverage_codes:
        return issues

    renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])

    for renewal_property in renewal_properties:
        previous_property = JSON.find_property(validation_ctx["previous_json"], renewal_property)
        if previous_property:
            for coverage_code in coverage_codes:
                if JSON.has_coverage(previous_property, coverage_code) and not JSON.has_coverage(renewal_property,
                                                                                                 coverage_code):
                    issues.append(_add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_property)
                    ))
    return issues


def property_coverage_added(rule, cfg, validation_ctx):
    issues = []
    if validation_ctx.get("previous_json") is None:
        return issues

    coverage_codes = _get_coverage_codes(cfg)
    if not coverage_codes:
        return issues

    renewal_properties = JSON.get_property_cards(validation_ctx["renewal_json"])

    for renewal_property in renewal_properties:
        previous_property = JSON.find_property(validation_ctx["previous_json"], renewal_property)
        if previous_property:
            for coverage_code in coverage_codes:
                if not JSON.has_coverage(previous_property, coverage_code) and JSON.has_coverage(renewal_property,
                                                                                                 coverage_code):
                    issues.append(_add_issue(
                        validation_ctx,
                        rule,
                        ctx=coverage_code,
                        ref_id=JSON.get_id(renewal_property)
                    ))
    return issues
