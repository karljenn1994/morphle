import logging
from datetime import datetime

from lib_common.constants import LOGGER
from lib_persistence import policy, validator
from validations import validations_renewal
from validations.issues_support import delete_issues

from fasteners import InterProcessLock

log = logging.getLogger(LOGGER)


def validate_policy(policy_obj):
    lock = InterProcessLock(f"/tmp/validate_policy_{policy_obj.id}.lock")
    acquired = False  # Prevent uninitialized reference

    try:
        acquired = lock.acquire(timeout=5)
        if not acquired:
            log.warning(f"Could not acquire lock for policy {policy_obj.id}, skipping validation.")
            return False

        company = policy_obj.company
        lob = policy_obj.lob
        transaction_effective_date = policy_obj.transaction_effective_date
        purpose = policy.resolve_chain_purpose(policy_obj)

        now = datetime.now().date()

        if transaction_effective_date > now:
            validator_type = validator.VALIDATION_TYPE_RENEWAL + "_" + lob.lower()
        else:
            validator_type = validator.VALIDATION_TYPE_POLICY + "_" + lob.lower()

        validator_obj = validator.read_validator_by_type_trigger_company_lob(
            validator_type, purpose, company, lob)

        if validator_obj is not None:
            _validate(policy_obj, validator_obj)
            return True

        return False

    finally:
        if acquired:
            lock.release()


def _validate(policy_obj, validator_obj):
    if validator_obj.type.startswith("renewal_"):
        # Get the validation parameters.
        validations_obj = validator.read_validations_by_id(validator_obj.validation_id)

        # Read the policy being validated.
        policy_obj = policy.read_version_by_id(policy_obj.id)
        delete_issues(policy_obj)

        # Some rules will need the previous policy.
        previous_policy_obj = policy.read_active_by_policy_number_company_lob(
            policy_obj.policy_number, policy_obj.company, policy_obj.lob)

        # See if we have mult-lines.
        is_multi_line = policy.is_multi_line(policy_obj.policy_number, policy_obj.company, policy_obj.lob)

        # Run the validations.
        validations_renewal.validate(validations_obj, policy_obj, previous_policy_obj, is_multi_line)
