import json

from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import validator


def create_validations(validations_type):
    return {
        "type": validations_type,
        "issues": []
    }


def load_issues(policy_obj):
    fm = FileManagerFactory.create_file_manager()
    issues = None
    file_name = _make_issues_file_name(policy_obj)
    file_path = fm.join(Repository.policies_location, file_name)

    if fm.exists(file_path):
        txt = FileManagerFactory.create_file_manager().read_string(file_path)
        issues = json.loads(txt)

    return issues


def create_issues_file(policy_obj):
    fm = FileManagerFactory.create_file_manager()
    file_name = _make_issues_file_name(policy_obj)
    root = Repository.policies_location
    file_path = fm.join(root, file_name)
    fm.create_file(file_path)
    return file_name


def delete_issues(policy_obj):
    # Remove issues from the database.
    validator.delete_issues(policy_obj.id)

    # Remove the policy's associated validation file.
    _delete_issues_file(policy_obj)


def _make_issues_file_name(policy_obj):
    parts = policy_obj.file_name.split("_")
    new_file_name = "_".join(parts[0:len(parts) - 1]) + ".ISS"
    new_file_name = new_file_name
    return new_file_name


def _delete_issues_file(policy_obj):
    fm = FileManagerFactory.create_file_manager()
    file_name = _make_issues_file_name(policy_obj)
    root = Repository.policies_location
    full_path = fm.join(root, file_name)

    if fm.exists(full_path):
        fm.remove(full_path)


def calculate_percent_change(v1, v2):
    pc = 0
    if v2 > v1:
        pc = ((v2 - v1) / v1) * 100
    elif v2 < v1:
        pc = ((v1 - v2) / v1) * 100
    return pc


def calculate_amount_change(v1, v2):
    return abs(v2 - v1)
