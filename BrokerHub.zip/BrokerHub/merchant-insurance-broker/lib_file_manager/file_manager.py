import os
import xml.etree.ElementTree as et
from abc import ABC, abstractmethod


class FileManager(ABC):
    def join(self, *paths: str) -> str:
        return os.path.join(*paths)

    def splitext(self, path: str) -> tuple[str, str]:
        return os.path.splitext(path)

    def dirname(self, path: str) -> str:
        return os.path.dirname(path)

    def basename(self, path: str) -> str:
        return os.path.basename(path)

    @abstractmethod
    def exists(self, relative_path: str) -> bool:
        pass

    @abstractmethod
    def isfile(self, relative_path: str) -> bool:
        pass

    @abstractmethod
    def get_absolute_path(self, relative_file_path: str) -> str:
        pass

    @abstractmethod
    def remove(self, relative_file_path: str) -> None:
        pass

    @abstractmethod
    def rmdir(self, relative_folder_path: str) -> None:
        pass

    @abstractmethod
    def rmtree(self, relative_folder_path: str) -> None:
        pass

    @abstractmethod
    def mkdir(self, relative_folder_path: str) -> None:
        pass

    @abstractmethod
    def mkdirs(self, relative_folder_path: str) -> None:
        pass

    @abstractmethod
    def create_file(self, relative_file_path: str) -> None:
        pass

    @abstractmethod
    def move(self, source_relative_path: str, dest_relative_path: str) -> None:
        pass

    @abstractmethod
    def copy(self, source_relative_path: str, dest_relative_path: str) -> None:
        pass

    @abstractmethod
    def copytree(self, source_relative_path: str, dest_relative_path: str, decrypt: bool) -> None:
        pass

    @abstractmethod
    def rename(self, source_relative_path: str, dest_relative_path: str) -> None:
        pass

    @abstractmethod
    def listdir(self, relative_folder_path: str = "") -> list:
        pass

    @abstractmethod
    def walk(self, relative_folder_path: str = ""):
        pass

    @abstractmethod
    def read_file(self, file_path: str, rewrite: bool = True) -> bytes:
        pass

    @abstractmethod
    def write_file(self, file_path: str, data: bytes) -> None:
        pass

    @abstractmethod
    def read_string(self, file_path: str, rewrite: bool = True, encoding: str = 'utf-8') -> str:
        pass

    @abstractmethod
    def write_string(self, file_path: str, text: str, encoding: str = 'utf-8') -> None:
        pass

    @abstractmethod
    def parse_xml(self, relative_xml_path: str, rewrite: bool = True) -> et.ElementTree:
        pass

    @abstractmethod
    def write_xml(self, relative_xml_path: str, tree: et.ElementTree) -> None:
        pass

    @abstractmethod
    def get_key(self) -> bytes:
        """Retrieve the most recent encryption key used by the manager."""
        pass

    @abstractmethod
    def is_encrypted(self, file_path: str) -> bool:
        """Determines if a file is encrypted by checking its structure."""
        pass
