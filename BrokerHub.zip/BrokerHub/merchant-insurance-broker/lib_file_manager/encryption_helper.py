from Crypto.Cipher import AES
from Crypto.Hash import HMAC, SHA256
from Crypto.Random import get_random_bytes


class EncryptionHelper:
    VERSION_SIZE = 4
    IV_SIZE = 16
    HMAC_SIZE = 32

    def __init__(self, enable_encryption: bool):
        self.enable_encryption = enable_encryption
        self.keys = {}

    def encrypt(self, data: bytes, version: int = None) -> bytes:
        if not self.enable_encryption or not self.keys:
            return data

        # Use the latest key if no version specified
        if version is None:
            version = max(self.keys.keys())
        key = self.keys[version]
        version_bytes = version.to_bytes(self.VERSION_SIZE, 'big')
        iv = get_random_bytes(self.IV_SIZE)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        padding_length = 16 - (len(data) % 16)
        padded_data = data + bytes([padding_length] * padding_length)
        ciphertext = cipher.encrypt(padded_data)
        hmac_obj = HMAC.new(key, digestmod=SHA256)
        hmac_obj.update(iv + ciphertext)
        hmac_value = hmac_obj.digest()
        return version_bytes + iv + hmac_value + ciphertext

    def decrypt(self, data: bytes) -> bytes:
        if not self.keys:
            return data

        if len(data) < self.VERSION_SIZE + self.IV_SIZE + self.HMAC_SIZE:
            return data

        version = int.from_bytes(data[:self.VERSION_SIZE], 'big')

        if version not in self.keys:
            raise ValueError(f"No key available for version: {version}")

        key = self.keys[version]
        iv = data[self.VERSION_SIZE:self.VERSION_SIZE + self.IV_SIZE]
        hmac_value = data[self.VERSION_SIZE + self.IV_SIZE:
                          self.VERSION_SIZE + self.IV_SIZE + self.HMAC_SIZE]
        ciphertext = data[self.VERSION_SIZE + self.IV_SIZE + self.HMAC_SIZE:]
        hmac_obj = HMAC.new(key, digestmod=SHA256)
        hmac_obj.update(iv + ciphertext)

        try:
            hmac_obj.verify(hmac_value)
        except ValueError:
            raise ValueError("Integrity check failed! Data may be tampered with.")

        cipher = AES.new(key, AES.MODE_CBC, iv)
        padded_data = cipher.decrypt(ciphertext)
        padding_length = padded_data[-1]

        if padding_length > 16 or padding_length < 0:
            raise ValueError("Invalid padding length")

        return padded_data[:-padding_length]

    def get_key(self) -> bytes:
        return self.keys[max(self.keys.keys())] if self.keys else b''

    def is_encrypted(self, data: bytes) -> bool:
        if len(data) < self.VERSION_SIZE + self.IV_SIZE + self.HMAC_SIZE:
            return False

        version = int.from_bytes(data[:self.VERSION_SIZE], 'big')
        return version in self.keys
