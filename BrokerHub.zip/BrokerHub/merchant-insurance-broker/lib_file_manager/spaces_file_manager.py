import os
from io import BytesIO
from xml.etree import ElementTree as et

import boto3
from botocore.exceptions import ClientError

from lib_file_manager.encryption_helper import EncryptionHelper
from lib_file_manager.file_manager import FileManager
from lib_file_manager.key_manager import KeyManager


class SpacesFileManager(FileManager):
    def __init__(self,
                 space_name: str,
                 region: str,
                 access_key: str,
                 secret_key: str,
                 encryption_helper: EncryptionHelper):
        self.space_name = space_name
        self.region = region
        self.session = boto3.session.Session()
        self.client = self.session.client(
            's3',
            region_name=region,
            endpoint_url=f"https://{region}.digitaloceanspaces.com",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        )
        self.encryption_helper = encryption_helper
        # Load keys and set encryption status
        keys, enable_encryption = KeyManager.load_keys()
        self.encryption_helper.keys = keys
        self.encryption_helper.enable_encryption = enable_encryption

    def exists(self, relative_path: str) -> bool:
        """
        Checks if the given relative path (file or directory) exists in the Spaces bucket.
        :param relative_path: The relative path to check.
        :return: True if the path exists (as a file or directory), False otherwise.
        """
        key = relative_path.lstrip('/')
        # Check if the path is a specific key (file or folder marker) or a prefix (directory)
        return self._check_key_exists(key) or self._check_prefix_exists(key)

    def isfile(self, relative_path: str) -> bool:
        """
        Checks if the given relative path points to a file (not a folder marker) in the Spaces bucket.
        :param relative_path: The relative path to check.
        :return: True if the path is a file, False otherwise.
        """
        key = relative_path.lstrip('/')
        if not self._check_key_exists(key):
            return False

        # A "file" is an object that exists and doesn't end with a slash (folder marker)
        return not key.endswith('/')

    def get_absolute_path(self, relative_file_path: str) -> str:
        """
        Returns the absolute URI-like path of a file at the given relative path in the Spaces bucket.
        :param relative_file_path: The relative path of the file.
        :return: The absolute URI (e.g., s3://my-space/policies/file.txt).
        :raises: ValueError if the relative path is invalid or results in an invalid key.
        """
        # Normalize the key (remove leading slashes)
        key = relative_file_path.lstrip('/')

        # Validate the key (e.g., no empty key after normalization)
        if not key:
            raise ValueError("Relative path cannot result in an empty key")

        # Construct the absolute URI using the bucket name and key
        absolute_uri = f"s3://{self.space_name}/{key}"
        return absolute_uri

    def remove(self, relative_file_path: str) -> None:
        """
        Removes a file (not a folder) at the given relative path in the DigitalOcean Spaces bucket.
        :param relative_file_path: The relative path of the file to remove.
        :raises: FileNotFoundError if the file does not exist.
        :raises: OSError if the path is a folder.
        :raises: Exception if the removal fails (e.g., permissions, delete errors).
        """
        try:
            # Normalize the key (remove leading slashes)
            key = relative_file_path.lstrip('/')

            # Check if the key exists and is a file (not a folder marker)
            if not self._check_key_exists(key):
                raise FileNotFoundError(f"File not found: {key}")

            if key.endswith('/'):
                raise OSError(f"Path is a folder, not a file: {key}")

            # Delete the object
            self.client.delete_object(
                Bucket=self.space_name,
                Key=key
            )
        except ClientError as e:
            raise Exception(f"Error removing file in Spaces: {e}")

    def rmdir(self, relative_folder_path: str) -> None:
        """
        Removes a "directory" and its contents in the DigitalOcean Spaces bucket by deleting all objects under the
        prefix.
        :param relative_folder_path: The relative path of the "directory" to remove.
        :raises: Exception if the removal fails (e.g., permissions, delete errors).
        """
        try:
            # Normalize the prefix (remove leading slashes, ensure it ends with a slash)
            prefix = relative_folder_path.lstrip('/').rstrip('/') + '/'

            # Check if the "directory" exists
            if not self._check_prefix_exists(prefix):
                # In S3, if no objects exist under the prefix, the "directory" is effectively gone
                return

            # List and delete all objects under the prefix
            paginator = self.client.get_paginator('list_objects_v2')
            page_iterator = paginator.paginate(
                Bucket=self.space_name,
                Prefix=prefix
            )

            objects_to_delete = []

            for page in page_iterator:
                if 'Contents' in page:
                    for obj in page['Contents']:
                        objects_to_delete.append({'Key': obj['Key']})

            # Delete objects in batches (S3 allows up to 1000 objects per request)
            if objects_to_delete:
                for i in range(0, len(objects_to_delete), 1000):
                    batch = objects_to_delete[i:i + 1000]
                    self.client.delete_objects(
                        Bucket=self.space_name,
                        Delete={'Objects': batch, 'Quiet': True}
                    )
        except ClientError as e:
            raise Exception(f"Error removing directory in Spaces: {e}")

    def rmtree(self, relative_folder_path: str) -> None:
        """
        Recursively removes a "directory" and all its contents in the DigitalOcean Spaces bucket by deleting all
        objects under the prefix.
        :param relative_folder_path: The relative path of the "directory" to remove.
        :raises: Exception if the removal fails (e.g., permissions, delete errors).
        """
        try:
            # Normalize the prefix (remove leading slashes, ensure it ends with a slash)
            prefix = relative_folder_path.lstrip('/').rstrip('/') + '/'

            # Check if the "directory" exists
            if not self._check_prefix_exists(prefix) and not self._check_key_exists(prefix):
                # In S3, if no objects exist under the prefix and no marker exists, the "directory" is effectively gone
                return

            # List and delete all objects under the prefix, including the folder marker if it exists
            paginator = self.client.get_paginator('list_objects_v2')
            page_iterator = paginator.paginate(
                Bucket=self.space_name,
                Prefix=prefix
            )

            objects_to_delete = []

            for page in page_iterator:
                if 'Contents' in page:
                    for obj in page['Contents']:
                        objects_to_delete.append({'Key': obj['Key']})

            # Add the folder marker itself if it exists
            if self._check_key_exists(prefix):
                objects_to_delete.append({'Key': prefix})

            # Delete objects in batches (S3 allows up to 1000 objects per request)
            if objects_to_delete:
                for i in range(0, len(objects_to_delete), 1000):
                    batch = objects_to_delete[i:i + 1000]
                    self.client.delete_objects(
                        Bucket=self.space_name,
                        Delete={'Objects': batch, 'Quiet': True}
                    )
        except ClientError as e:
            raise Exception(f"Error removing directory tree in Spaces: {e}")

    def mkdir(self, relative_folder_path: str) -> None:
        """
        Creates a single "directory" in the DigitalOcean Spaces bucket if its parent exists.
        :param relative_folder_path: The relative path of the directory to create.
        :raises: ValueError if the parent "directory" doesn't exist.
        :raises: Exception if directory creation fails.
        """
        try:
            # Normalize the folder path (remove leading slashes, ensure it ends with a slash)
            folder_key = relative_folder_path.lstrip('/').rstrip('/') + '/'
            # Check if the parent "directory" exists by listing objects with the parent prefix
            parent_prefix = os.path.dirname(folder_key) or ''

            if parent_prefix and not self._check_prefix_exists(parent_prefix):
                raise ValueError(f"Parent 'directory' does not exist: {parent_prefix}")

            # Create the directory by uploading an empty object
            self.client.put_object(
                Bucket=self.space_name,
                Key=folder_key,
                Body=b'',
                ACL='private'
            )
        except ClientError as e:
            raise Exception(f"Error creating directory in Spaces: {e}")

    def mkdirs(self, relative_folder_path: str) -> None:
        """
        Creates a "directory" and any necessary parent "directories" in the DigitalOcean Spaces bucket.
        :param relative_folder_path: The relative path of the directory to create.
        :raises: Exception if directory creation fails.
        """
        try:
            # Normalize the folder path (remove leading slashes, ensure it ends with a slash)
            folder_key = relative_folder_path.lstrip('/').rstrip('/') + '/'

            # Split into components and create each level
            parts = folder_key.split('/')
            current_prefix = ''

            for part in parts[:-1]:  # Exclude the last empty part after split
                if part:  # Skip empty parts
                    current_prefix = f"{current_prefix}{part}/"

                    # Create the "directory" if it doesn't exist
                    if not self._check_prefix_exists(current_prefix):
                        self.client.put_object(
                            Bucket=self.space_name,
                            Key=current_prefix,
                            Body=b'',
                            ACL='private'
                        )
        except ClientError as e:
            raise Exception(f"Error creating directories in Spaces: {e}")

    def create_file(self, relative_file_path: str) -> None:
        """
        Creates an empty file at the given relative path in the Spaces bucket.
        :param relative_file_path: The relative path where the empty file will be created.
        :raises: FileExistsError if the file already exists.
        :raises: Exception if the creation fails (e.g., permissions, connectivity).
        """
        # Normalize the key (remove leading slashes)
        key = relative_file_path.lstrip('/')
        # Ensure the parent "directory" exists
        parent_prefix = os.path.dirname(key) or ''

        if parent_prefix and not self._check_prefix_exists(parent_prefix):
            self.mkdirs(parent_prefix)

        # Check if the file already exists
        if self._check_key_exists(key):
            raise FileExistsError(f"File already exists: {key}")

        # Create an empty object
        self.client.put_object(
            Bucket=self.space_name,
            Key=key,
            Body=b'',  # Empty byte string for an empty file
            ACL='private'
        )

    def move(self, source_relative_path: str, dest_relative_path: str) -> None:
        """
        Moves a file or folder from source_relative_path to dest_relative_path in the Spaces bucket.
        :param source_relative_path: The relative path of the file or folder to move.
        :param dest_relative_path: The relative path where the file or folder will be moved to.
        :raises: FileNotFoundError if the source does not exist.
        :raises: Exception if the move operation fails (e.g., permissions, copy/delete errors).
        """
        try:
            # Normalize paths (remove leading slashes)
            source_key = source_relative_path.lstrip('/')
            dest_key = dest_relative_path.lstrip('/')

            # Check if source exists
            if not self._check_key_exists(source_key) and not self._check_prefix_exists(source_key):
                raise FileNotFoundError(f"Source path does not exist: {source_key}")

            # Ensure the destination parent "directory" exists
            dest_dir = os.path.dirname(dest_key) or ''

            if dest_dir and not self._check_prefix_exists(dest_dir):
                self.mkdirs(dest_dir)

            # Handle file move
            if self._check_key_exists(source_key) and not source_key.endswith('/'):
                self.client.copy_object(
                    Bucket=self.space_name,
                    CopySource={'Bucket': self.space_name, 'Key': source_key},
                    Key=dest_key,
                    ACL='private'
                )
                self.client.delete_object(
                    Bucket=self.space_name,
                    Key=source_key
                )
            # Handle folder move (recursive copy and delete)
            elif self._check_prefix_exists(source_key):
                paginator = self.client.get_paginator('list_objects_v2')
                page_iterator = paginator.paginate(
                    Bucket=self.space_name,
                    Prefix=source_key,
                    Delimiter='/'
                )
                for page in page_iterator:
                    if 'Contents' in page:
                        for obj in page['Contents']:
                            obj_key = obj['Key']

                            # Skip the folder marker itself
                            if obj_key == source_key and obj_key.endswith('/'):
                                continue
                            # Compute the relative path within the source prefix
                            relative_path = obj_key[len(source_key):] if source_key else obj_key
                            new_key = f"{dest_key}{relative_path}".lstrip('/')
                            self.client.copy_object(
                                Bucket=self.space_name,
                                CopySource={'Bucket': self.space_name, 'Key': obj_key},
                                Key=new_key,
                                ACL='private'
                            )
                            self.client.delete_object(
                                Bucket=self.space_name,
                                Key=obj_key
                            )
            else:
                raise OSError(f"Source path is neither a file nor a folder: {source_key}")
        except ClientError as e:
            raise Exception(f"Error moving in Spaces: {e}")

    def copy(self, source_relative_path: str, dest_relative_path: str) -> None:
        """
        Copies a file or folder from source_relative_path to dest_relative_path in the Spaces bucket.
        :param source_relative_path: The relative path of the file or folder to copy.
        :param dest_relative_path: The relative path where the file or folder will be copied to.
        :raises: FileNotFoundError if the source does not exist.
        :raises: Exception if the copy operation fails (e.g., permissions, copy errors).
        """
        try:
            # Normalize paths (remove leading slashes)
            source_key = source_relative_path.lstrip('/')
            dest_key = dest_relative_path.lstrip('/')

            # Check if source exists
            if not self._check_key_exists(source_key) and not self._check_prefix_exists(source_key):
                raise FileNotFoundError(f"Source path does not exist: {source_key}")

            # Ensure the destination parent "directory" exists
            dest_dir = os.path.dirname(dest_key) or ''

            if dest_dir and not self._check_prefix_exists(dest_dir):
                self.mkdirs(dest_dir)

            # Handle file copy
            if self._check_key_exists(source_key) and not source_key.endswith('/'):
                self.client.copy_object(
                    Bucket=self.space_name,
                    CopySource={'Bucket': self.space_name, 'Key': source_key},
                    Key=dest_key,
                    ACL='private'
                )

            # Handle folder copy (recursive copy of all objects under the prefix)
            elif self._check_prefix_exists(source_key):
                paginator = self.client.get_paginator('list_objects_v2')
                page_iterator = paginator.paginate(
                    Bucket=self.space_name,
                    Prefix=source_key,
                    Delimiter='/'
                )
                for page in page_iterator:
                    if 'Contents' in page:
                        for obj in page['Contents']:
                            obj_key = obj['Key']

                            # Skip the folder marker itself
                            if obj_key == source_key and obj_key.endswith('/'):
                                continue

                            # Compute the relative path within the source prefix
                            relative_path = obj_key[len(source_key):] if source_key else obj_key
                            new_key = f"{dest_key}{relative_path}".lstrip('/')
                            self.client.copy_object(
                                Bucket=self.space_name,
                                CopySource={'Bucket': self.space_name, 'Key': obj_key},
                                Key=new_key,
                                ACL='private'
                            )
            else:
                raise OSError(f"Source path is neither a file nor a folder: {source_key}")
        except ClientError as e:
            raise Exception(f"Error copying in Spaces: {e}")

    def copytree(self, source_relative_path: str, dest_relative_path: str, decrypt: bool = False) -> None:
        """
        Recursively copies a "directory" and all its contents from source_relative_path to dest_relative_path in the
        Spaces bucket.
        Hidden files (starting with '.') are ignored.
        Files are inspected to determine if decryption is needed.
        :param source_relative_path: The relative path of the source "directory" to copy.
        :param dest_relative_path: The relative path where the "directory" will be copied to.
        :param decrypt: If True, attempts to decrypt files that appear to be encrypted during the copy.
        :raises: FileNotFoundError if the source "directory" does not exist.
        :raises: OSError if the source is a file or copy fails (e.g., permissions).
        :raises: Exception if the operation fails (e.g., connectivity issues).
        """
        try:
            # Normalize paths (remove leading slashes)
            source_key = source_relative_path.lstrip('/')
            dest_key = dest_relative_path.lstrip('/')

            # Check if source exists as a prefix (directory)
            if not self._check_prefix_exists(source_key):
                raise FileNotFoundError(f"Source directory not found: {source_key}")

            if self._check_key_exists(source_key) and not source_key.endswith('/'):
                raise OSError(f"Source path is a file, not a directory: {source_key}")

            # Ensure the destination parent "directory" exists
            dest_dir = os.path.dirname(dest_key) or ''

            if dest_dir and not self._check_prefix_exists(dest_dir):
                self.mkdirs(dest_dir)

            # Recursively copy all objects under the source prefix
            paginator = self.client.get_paginator('list_objects_v2')
            page_iterator = paginator.paginate(
                Bucket=self.space_name,
                Prefix=source_key,
                Delimiter='/'
            )

            for page in page_iterator:
                if 'Contents' in page:
                    for obj in page['Contents']:
                        obj_key = obj['Key']

                        # Skip the folder marker itself if it's the exact prefix
                        if obj_key == f"{source_key}/" and obj_key.endswith('/'):
                            continue

                        # Compute the relative path within the source prefix
                        relative_path = obj_key[len(source_key):] if source_key else obj_key

                        # Skip objects with hidden names (starting with '.') in their path
                        if any(part.startswith('.') for part in relative_path.split('/')):
                            continue
                        new_key = f"{dest_key}{relative_path}".lstrip('/')

                        # Download the source object
                        response = self.client.get_object(
                            Bucket=self.space_name,
                            Key=obj_key
                        )
                        content = response['Body'].read()

                        # Inspect and optionally decrypt
                        if decrypt and self.encryption_helper.enable_encryption:
                            try:
                                decrypted_content = self.encryption_helper.decrypt(content)
                                content_to_upload = decrypted_content
                                log.debug(f"Decrypted file: {obj_key}")
                            except Exception as e:
                                content_to_upload = content
                                lob.error(f"Unencrypted file or decryption failed for: {obj_key}, copying as-is: {e}")
                        else:
                            content_to_upload = content

                        # Upload to the destination
                        self.client.put_object(
                            Bucket=self.space_name,
                            Key=new_key,
                            Body=content_to_upload,
                            ACL='private'
                        )
        except ClientError as e:
            raise Exception(f"Error copying directory tree in Spaces: {e}")

    def rename(self, source_relative_path: str, dest_relative_path: str) -> None:
        """
        Renames or moves a file or folder from source_relative_path to dest_relative_path in the Spaces bucket.
        :param source_relative_path: The current relative path of the file or folder to rename.
        :param dest_relative_path: The new relative path for the file or folder.
        :raises: FileNotFoundError if the source does not exist.
        :raises: Exception if the rename operation fails (e.g., permissions, copy/delete errors).
        """
        try:
            # Normalize paths (remove leading slashes, ensure folder keys end with / if applicable)
            source_key = source_relative_path.lstrip('/')
            dest_key = dest_relative_path.lstrip('/')

            # Check if source exists
            if not self._check_key_exists(source_key):
                raise FileNotFoundError(f"Source path does not exist: {source_key}")

            # Ensure the destination parent "directory" exists
            dest_dir = os.path.dirname(dest_key) or ''
            if dest_dir and not self._check_prefix_exists(dest_dir):
                self.mkdirs(dest_dir)

            # Copy the source object to the destination
            self.client.copy_object(
                Bucket=self.space_name,
                CopySource={'Bucket': self.space_name, 'Key': source_key},
                Key=dest_key,
                ACL='private'
            )

            # Delete the source object
            self.client.delete_object(
                Bucket=self.space_name,
                Key=source_key
            )
        except ClientError as e:
            raise Exception(f"Error renaming in Spaces: {e}")

    def listdir(self, relative_folder_path: str = "") -> list:
        """
        Lists the contents (files and "directories") of the given relative folder in the Spaces bucket.
        :param relative_folder_path: The relative path of the folder to list (defaults to the root of the bucket).
        :return: A list of names (files and "directories") in the folder.
        :raises: Exception if the listing fails (e.g., permissions, bucket issues).
        """
        try:
            # Normalize the prefix (remove leading slashes, ensure it ends with a slash)
            prefix = relative_folder_path.lstrip('/').rstrip('/') + '/'
            contents = []

            # List objects and common prefixes (directories) under the prefix
            response = self.client.list_objects_v2(
                Bucket=self.space_name,
                Prefix=prefix,
                Delimiter='/'
            )

            if 'Contents' in response:
                for obj in response['Contents']:
                    key = obj['Key']
                    # Skip the folder marker itself
                    if key == prefix and key.endswith('/'):
                        continue

                    # Extract the name (remove the prefix)
                    name = key[len(prefix):] if prefix else key

                    # Only include top-level names (no subdirectories)
                    if '/' not in name:
                        contents.append(name)

            if 'CommonPrefixes' in response:
                for common_prefix in response['CommonPrefixes']:
                    # Extract the directory name (remove the trailing slash and prefix)
                    dir_name = common_prefix['Prefix'].rstrip('/')

                    if prefix:
                        dir_name = dir_name[len(prefix):]

                    # Only include top-level directory names
                    if '/' not in dir_name:
                        contents.append(dir_name)

            return contents
        except ClientError as e:
            raise Exception(f"Error listing directory in Spaces: {e}")

    def walk(self, relative_folder_path: str = ""):
        """
        Recursively walks the object tree in the DigitalOcean Spaces bucket and yields tuples (root, dirs, files).
        :param relative_folder_path: The relative prefix to start walking from (defaults to the root of the bucket).
        :yield: Tuple of (root: str, dirs: list, files: list) for each "directory" in the walk.
        """
        # Normalize the prefix (remove leading/trailing slashes, ensure it ends with a slash for prefix matching)
        prefix = relative_folder_path.lstrip('/').rstrip('/')
        if prefix:
            prefix += '/'

        # Initialize paginator for listing objects
        paginator = self.client.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(
            Bucket=self.space_name,
            Prefix=prefix,
            Delimiter='/'
        )

        # Process each page of results
        for page in page_iterator:
            # Get "directories" (common prefixes)
            dirs = []

            if 'CommonPrefixes' in page:
                for common_prefix in page['CommonPrefixes']:
                    # Extract the directory name (remove the trailing slash and prefix)
                    dir_name = common_prefix['Prefix'].rstrip('/')

                    if prefix:
                        dir_name = dir_name[len(prefix):]
                    dirs.append(dir_name)

            # Get "files" (objects in the current "directory")
            files = []

            if 'Contents' in page:
                for obj in page['Contents']:
                    key = obj['Key']

                    # Skip the folder marker itself (e.g., "data/uploads/")
                    if key.endswith('/'):
                        continue

                    # Extract the file name (remove the prefix)
                    file_name = key[len(prefix):] if prefix else key

                    # Only include files directly in the current "directory" (no deeper subpaths)
                    if '/' not in file_name:
                        files.append(file_name)

            # Yield the current "directory" (relative to the starting prefix)
            relative_root = relative_folder_path.lstrip('/')
            yield relative_root, dirs, files

            # Recursively walk subdirectories
            for dir_name in dirs:
                sub_prefix = f"{relative_folder_path.lstrip('/')}/{dir_name}" if relative_folder_path else dir_name
                yield from self.walk(sub_prefix)

    def read_file(self, file_path: str, force_reencrypt: bool = False) -> bytes:
        try:
            response = self.client.get_object(Bucket=self.space_name, Key=file_path.lstrip('/'))
            data = response['Body'].read()
            is_encrypted = self.encryption_helper.is_encrypted(data)

            if is_encrypted and self.encryption_helper.enable_encryption:
                decrypted_data = self.encryption_helper.decrypt(data)

                if force_reencrypt or (int.from_bytes(data[:self.encryption_helper.VERSION_SIZE], 'big') <
                                       max(self.encryption_helper.keys.keys())):
                    self.write_file(file_path, decrypted_data)
                return decrypted_data
            elif not is_encrypted and self.encryption_helper.enable_encryption:
                decrypted_data = data
                self.write_file(file_path, decrypted_data)
                return decrypted_data
            else:
                return data
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                raise FileNotFoundError(f"File not found in Spaces: {file_path}")
            raise Exception(f"Error reading from Spaces: {e}")

    def write_file(self, file_path: str, data: bytes) -> None:
        try:
            encrypted_data = self.encryption_helper.encrypt(data)
            self.client.put_object(
                Bucket=self.space_name,
                Key=file_path.lstrip('/'),
                Body=encrypted_data,
                ACL='private'
            )
        except ClientError as e:
            raise Exception(f"Error writing to Spaces: {e}")

    def read_string(self, file_path: str, force_reencrypt: bool = False, encoding: str = 'utf-8') -> str:
        return self.read_file(file_path, force_reencrypt).decode(encoding)

    def write_string(self, file_path: str, text: str, encoding: str = 'utf-8') -> None:
        self.write_file(file_path, text.encode(encoding))

    def parse_xml(self, relative_xml_path: str, rewrite: bool = True) -> et.ElementTree:
        """
        Parses an XML file at the given relative path in the Spaces bucket, handling encryption/decryption based on
        enable_encryption.
        :param relative_xml_path: The relative path to the XML file.
        :param rewrite: If True, rewrites the file with the processed content (e.g., re-encrypt or decrypt).
        :return: An ElementTree object representing the parsed XML.
        :raises: FileNotFoundError if the file does not exist.
        :raises: OSError if the path is a folder.
        :raises: et.ParseError if the XML file is malformed.
        :raises: Exception if there are issues accessing the file (e.g., permissions, connectivity).
        """
        try:
            # Normalize the key (remove leading slashes)
            key = relative_xml_path.lstrip('/')

            # Check if the key exists and is a file (not a folder marker)
            if not self._check_key_exists(key):
                raise FileNotFoundError(f"XML file not found: {key}")

            if key.endswith('/'):
                raise OSError(f"Path is a folder, not a file: {key}")

            # Download the file content
            response = self.client.get_object(
                Bucket=self.space_name,
                Key=key
            )
            data = response['Body'].read()

            is_encrypted = self.encryption_helper.is_encrypted(data)

            if is_encrypted and self.encryption_helper.enable_encryption:
                # The file is encrypted and encryption is on.
                decrypted_data = self.encryption_helper.decrypt(data)

                # See if we need to re-encrypt with the latest key.
                if rewrite or (int.from_bytes(data[:self.encryption_helper.VERSION_SIZE], 'big') <
                               max(self.encryption_helper.keys.keys())):
                    self.write_file(relative_xml_path, decrypted_data)

                tree = et.parse(BytesIO(decrypted_data))
                return tree

            elif is_encrypted and not self.encryption_helper.enable_encryption:
                # The file is encrypted and encryption is off.
                decrypted_data = self.encryption_helper.decrypt(data)

                # See if we need to save the decrypted version.
                if rewrite:
                    self.write_file(relative_xml_path, decrypted_data)

                tree = et.parse(BytesIO(decrypted_data))
                return tree

            elif not is_encrypted and self.encryption_helper.enable_encryption:
                # The file is not encrypted and encryption is on. Here we need to encrypt the file.
                decrypted_data = data

                if rewrite:
                    self.write_file(relative_xml_path, decrypted_data)

                tree = et.parse(BytesIO(decrypted_data))
                return tree

            else:
                # Encryption is off.
                tree = et.parse(BytesIO(data))
                return tree
        except ClientError as e:
            raise Exception(f"Error accessing XML file in Spaces: {e}")
        except et.ParseError as e:
            raise et.ParseError(f"Error parsing XML: {e}")

    def write_xml(self, relative_xml_path: str, tree: et.ElementTree) -> None:
        """
        Writes an ElementTree object to an XML file at the given relative path in the Spaces bucket.
        :param relative_xml_path: The relative path where the XML file will be written.
        :param tree: The ElementTree object to write.
        :raises: ValueError if the tree is None or invalid.
        :raises: Exception if the upload fails (e.g., permissions, connectivity).
        """
        if tree is None:
            raise ValueError("ElementTree object cannot be None")

        # Normalize the key (remove leading slashes)
        key = relative_xml_path.lstrip('/')
        # Ensure the parent "directory" exists
        parent_prefix = os.path.dirname(key) or ''

        if parent_prefix and not self._check_prefix_exists(parent_prefix):
            self.mkdirs(parent_prefix)

        root = tree.getroot()  # Get the root Element
        # Convert tree to bytes
        xml_bytes = et.tostring(root, encoding='utf-8', xml_declaration=True)

        if self.encryption_helper.enable_encryption:
            # Encrypt the content
            encrypted_content = self.encryption_helper.encrypt(xml_bytes)
            self.client.put_object(
                Bucket=self.space_name,
                Key=key,
                Body=encrypted_content,
                ACL='private'
            )
        else:
            # Upload the unencrypted content
            self.client.put_object(
                Bucket=self.space_name,
                Key=key,
                Body=xml_bytes,
                ACL='private'
            )

    def get_key(self) -> bytes:
        return self.encryption_helper.get_key()

    def is_encrypted(self, file_path: str) -> bool:
        try:
            response = self.client.get_object(Bucket=self.space_name, Key=file_path.lstrip('/'))
            data = response['Body'].read(
                self.encryption_helper.VERSION_SIZE + self.encryption_helper.IV_SIZE +
                self.encryption_helper.HMAC_SIZE)
            return self.encryption_helper.is_encrypted(data)
        except ClientError:
            return False

    def _check_prefix_exists(self, prefix: str) -> bool:
        """
        Checks if a prefix (representing a "directory") exists in the bucket by listing objects.
        :param prefix: The prefix to check.
        :return: True if the prefix exists, False otherwise.
        """
        try:
            response = self.client.list_objects_v2(
                Bucket=self.space_name,
                Prefix=prefix,
                MaxKeys=1
            )
            return 'Contents' in response or 'CommonPrefixes' in response
        except ClientError:
            return False

    def _check_key_exists(self, key: str) -> bool:
        """
        Checks if a specific key (file or folder marker) exists in the bucket.
        :param key: The object key to check.
        :return: True if the key exists, False otherwise.
        """
        try:
            self.client.head_object(Bucket=self.space_name, Key=key)
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return False
            raise
