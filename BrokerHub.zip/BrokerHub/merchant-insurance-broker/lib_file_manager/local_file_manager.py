import logging
import mimetypes
import os
import shutil
from io import BytesIO
from xml.etree import ElementTree as et

from charset_normalizer import detect

from lib_common.constants import LOGGER
from lib_file_manager.encryption_helper import EncryptionHelper
from lib_file_manager.file_manager import FileManager
from lib_file_manager.key_manager import KeyManager

log = logging.getLogger(LOGGER)


class LocalFileManager(FileManager):
    def __init__(self, base_path: str, encryption_helper: EncryptionHelper):
        self.base_path = base_path.rstrip(os.sep)
        self.encryption_helper = encryption_helper

        # Load keys and set encryption status
        keys, enable_encryption = KeyManager.load_keys()
        self.encryption_helper.keys = keys
        self.encryption_helper.enable_encryption = enable_encryption

    def exists(self, relative_path: str) -> bool:
        """
        Checks if the given relative path (file or directory) exists within the base_path.
        :param relative_path: The relative path to check.
        :return: True if the path exists, False otherwise.
        """
        full_path = os.path.join(self.base_path, relative_path.lstrip(os.sep))
        return os.path.exists(full_path)

    def isfile(self, relative_path: str) -> bool:
        """
        Checks if the given relative path points to a file within the base_path.
        :param relative_path: The relative path to check.
        :return: True if the path is a file, False otherwise.
        """
        full_path = os.path.join(self.base_path, relative_path.lstrip(os.sep))
        return os.path.isfile(full_path)

    def get_absolute_path(self, relative_file_path: str) -> str:
        """
        Returns the absolute filesystem path of a file at the given relative path within base_path.
        :param relative_file_path: The relative path of the file.
        :return: The absolute filesystem path (e.g., /app/storage/policies/file.txt).
        :raises: ValueError if the relative path is invalid or results in an invalid absolute path.
        """
        full_path = os.path.join(self.base_path, relative_file_path.lstrip(os.sep))

        # Normalize the path to resolve any relative components (e.g., ..)
        absolute_path = os.path.abspath(full_path)

        # Ensure the absolute path is within base_path to prevent path traversal
        if not os.path.commonpath([self.base_path, absolute_path]) == self.base_path:
            raise ValueError(f"Absolute path {absolute_path} is outside base_path {self.base_path}")
        return absolute_path

    def remove(self, relative_file_path: str) -> None:
        """
        Removes a file (not a directory) at the given relative path within base_path.
        :param relative_file_path: The relative path of the file to remove.
        :raises: FileNotFoundError if the file does not exist.
        :raises: OSError if the path is a directory or removal fails (e.g., permissions).
        """
        full_path = os.path.join(self.base_path, relative_file_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"File not found: {full_path}")

        if not os.path.isfile(full_path):
            raise OSError(f"Path is not a file: {full_path}")
        os.remove(full_path)

    def rmdir(self, relative_folder_path: str) -> None:
        """
        Removes a directory and its contents relative to base_path.
        :param relative_folder_path: The relative path of the directory to remove.
        :raises: FileNotFoundError if the directory does not exist.
        :raises: OSError if the directory is not empty or removal fails (e.g., permissions).
        """
        full_path = os.path.join(self.base_path, relative_folder_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"Directory not found: {full_path}")

        if not os.path.isdir(full_path):
            raise OSError(f"Path is not a directory: {full_path}")
        shutil.rmtree(full_path)

    def rmtree(self, relative_folder_path: str) -> None:
        """
        Recursively removes a directory and all its contents relative to base_path.
        :param relative_folder_path: The relative path of the directory to remove.
        :raises: FileNotFoundError if the directory does not exist.
        :raises: OSError if the path is not a directory or removal fails (e.g., permissions).
        """
        full_path = os.path.join(self.base_path, relative_folder_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"Directory not found: {full_path}")

        if not os.path.isdir(full_path):
            raise OSError(f"Path is not a directory: {full_path}")
        shutil.rmtree(full_path)

    def mkdir(self, relative_folder_path: str) -> None:
        """
        Creates a single directory relative to base_path if it doesn't exist.
        :param relative_folder_path: The relative path of the directory to create.
        :raises: FileNotFoundError if the parent directory doesn't exist.
        :raises: OSError if directory creation fails (e.g., permissions).
        """
        full_path = os.path.join(self.base_path, relative_folder_path.lstrip(os.sep))

        if os.path.exists(os.path.dirname(full_path)) or os.path.dirname(full_path) == self.base_path:
            os.mkdir(full_path)
        else:
            raise FileNotFoundError(f"Parent directory does not exist: {os.path.dirname(full_path)}")

    def mkdirs(self, relative_folder_path: str) -> None:
        """
        Creates a directory and any necessary parent directories relative to base_path if they don't exist.
        :param relative_folder_path: The relative path of the directory to create.
        :raises: OSError if directory creation fails (e.g., permissions).
        """
        full_path = os.path.join(self.base_path, relative_folder_path.lstrip(os.sep))
        os.makedirs(full_path, exist_ok=True)

    def create_file(self, relative_file_path: str) -> None:
        """
        Creates an empty file at the given relative path within base_path.
        :param relative_file_path: The relative path where the empty file will be created.
        :raises: OSError if the file cannot be created (e.g., permissions, directory does not exist).
        :raises: FileExistsError if the file already exists.
        """
        full_path = os.path.join(self.base_path, relative_file_path.lstrip(os.sep))

        # Ensure the parent directory exists
        os.makedirs(os.path.dirname(full_path) or '.', exist_ok=True)

        # Check if the file already exists
        if os.path.exists(full_path):
            raise FileExistsError(f"File already exists: {full_path}")

        # Create an empty file
        with open(full_path, 'w') as f:
            pass  # Simply opening and closing creates an empty file

    def move(self, source_relative_path: str, dest_relative_path: str) -> None:
        """
        Moves a file or folder from source_relative_path to dest_relative_path.
        Both paths are relative to base_path.
        :param source_relative_path: The relative path of the file or folder to move.
        :param dest_relative_path: The relative path where the file or folder will be moved to.
        :raises: FileNotFoundError if the source does not exist.
        :raises: OSError if the move operation fails (e.g., permissions, destination exists).
        """
        source_full_path = os.path.join(self.base_path, source_relative_path.lstrip(os.sep))
        dest_full_path = os.path.join(self.base_path, dest_relative_path.lstrip(os.sep))

        if not os.path.exists(source_full_path):
            raise FileNotFoundError(f"Source path does not exist: {source_full_path}")

        # Ensure the destination parent directory exists
        dest_dir = os.path.dirname(dest_full_path)

        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        # Use shutil.move, which handles both files and directories
        shutil.move(source_full_path, dest_full_path)

    def copy(self, source_relative_path: str, dest_relative_path: str) -> None:
        """
        Copies a file or folder from source_relative_path to dest_relative_path.
        Both paths are relative to base_path.
        :param source_relative_path: The relative path of the file or folder to copy.
        :param dest_relative_path: The relative path where the file or folder will be copied to.
        :raises: FileNotFoundError if the source does not exist.
        :raises: OSError if the copy operation fails (e.g., permissions, destination exists).
        """
        source_full_path = os.path.join(self.base_path, source_relative_path.lstrip(os.sep))
        dest_full_path = os.path.join(self.base_path, dest_relative_path.lstrip(os.sep))

        if not os.path.exists(source_full_path):
            raise FileNotFoundError(f"Source path does not exist: {source_full_path}")

        # Ensure the destination parent directory exists
        dest_dir = os.path.dirname(dest_full_path)

        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        # Copy file or directory
        if os.path.isfile(source_full_path):
            shutil.copy2(source_full_path, dest_full_path)
        elif os.path.isdir(source_full_path):
            shutil.copytree(source_full_path, dest_full_path, dirs_exist_ok=True)
        else:
            raise OSError(f"Source path is neither a file nor a directory: {source_full_path}")

    def copytree(self, source_relative_path: str, dest_relative_path: str, decrypt: bool = False) -> None:
        """
        Recursively copies a directory and all its contents from source_relative_path to dest_relative_path.
        Both paths are relative to base_path. Hidden files (starting with '.') are ignored.
        Files are inspected to determine if decryption is needed.
        :param source_relative_path: The relative path of the source directory to copy.
        :param dest_relative_path: The relative path where the directory will be copied to.
        :param decrypt: If True, attempts to decrypt files that appear to be encrypted during the copy.
        :raises: FileNotFoundError if the source directory does not exist.
        :raises: OSError if the source is not a directory, destination exists and is a file, or copy fails (e.g.,
        permissions).
        """
        source_full_path = os.path.join(self.base_path, source_relative_path.lstrip(os.sep))
        dest_full_path = os.path.join(self.base_path, dest_relative_path.lstrip(os.sep))

        if not os.path.exists(source_full_path):
            raise FileNotFoundError(f"Source directory not found: {source_full_path}")

        if not os.path.isdir(source_full_path):
            raise OSError(f"Source path is not a directory: {source_full_path}")

        if os.path.exists(dest_full_path) and os.path.isfile(dest_full_path):
            raise OSError(f"Destination exists and is a file: {dest_full_path}")

        # Ensure the destination parent directory exists
        dest_dir = os.path.dirname(dest_full_path)

        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        if decrypt and self.encryption_helper.enable_encryption:
            # Custom recursive copy with inspection and optional decryption
            def copy_with_inspection(src, dst):
                try:
                    items = os.listdir(src)
                except OSError as e:
                    log.warning(f"Unable to list directory {src}: {e}")
                    return

                for item in items:
                    # Skip hidden files and directories (starting with '.')
                    if item.startswith('.'):
                        continue

                    src_path = os.path.join(src, item)
                    dst_path = os.path.join(dst, item)

                    try:
                        if os.path.isdir(src_path):
                            os.makedirs(dst_path, exist_ok=True)
                            copy_with_inspection(src_path, dst_path)  # Recurse into subdirectory
                        else:
                            # Read the file content
                            with open(src_path, 'rb') as f:
                                content = f.read()

                            # Attempt decryption to inspect if the file is encrypted
                            try:
                                decrypted_content = self.encryption_helper.decrypt(content)
                                # If decryption succeeds, use the decrypted content
                                content_to_write = decrypted_content
                                log.debug(f"Decrypted file: {src_path}")
                            except Exception as e:
                                # If decryption fails, assume the file is unencrypted and use original content
                                content_to_write = content
                                log.error(f"Unencrypted file or decryption failed for: {src_path}, copying as-is: {e}")

                            # Write the content (decrypted or original) to the destination
                            with open(dst_path, 'wb') as f:
                                f.write(content_to_write)
                    except (OSError, IOError) as e:
                        log.warning(f"Error processing {src_path}: {e}, skipping")

            copy_with_inspection(source_full_path, dest_full_path)
        else:
            # Use shutil.copytree for direct copying (no decryption needed), ignoring hidden files
            shutil.copytree(source_full_path, dest_full_path, dirs_exist_ok=True, ignore=shutil.ignore_patterns('.*'))

    def rename(self, source_relative_path: str, dest_relative_path: str) -> None:
        """
        Renames or moves a file or folder from source_relative_path to dest_relative_path.
        Both paths are relative to base_path.
        :param source_relative_path: The current relative path of the file or folder to rename.
        :param dest_relative_path: The new relative path for the file or folder.
        :raises: FileNotFoundError if the source does not exist.
        :raises: OSError if the rename operation fails (e.g., permissions, destination exists).
        """
        source_full_path = os.path.join(self.base_path, source_relative_path.lstrip(os.sep))
        dest_full_path = os.path.join(self.base_path, dest_relative_path.lstrip(os.sep))

        if not os.path.exists(source_full_path):
            raise FileNotFoundError(f"Source path does not exist: {source_full_path}")

        # Ensure the destination parent directory exists
        dest_dir = os.path.dirname(dest_full_path)

        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        os.rename(source_full_path, dest_full_path)

    def listdir(self, relative_folder_path: str = "") -> list:
        """
        Lists the contents (files and directories) of the given relative folder within base_path.
        :param relative_folder_path: The relative path of the folder to list (defaults to the root of base_path).
        :return: A list of names (files and directories) in the folder.
        :raises: FileNotFoundError if the folder does not exist.
        :raises: OSError if the path is not a directory or listing fails.
        """
        full_path = os.path.join(self.base_path, relative_folder_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"Folder not found: {full_path}")

        if not os.path.isdir(full_path):
            raise OSError(f"Path is not a directory: {full_path}")

        return os.listdir(full_path)

    def walk(self, relative_folder_path: str = ""):
        """
        Recursively walks the directory tree relative to base_path and yields tuples (root, dirs, files).
        :param relative_folder_path: The relative path to start walking from (defaults to the root of base_path).
        :yield: Tuple of (root: str, dirs: list, files: list) for each directory in the walk.
        :raises: FileNotFoundError if the starting folder doesn't exist.
        """
        full_path = os.path.join(self.base_path, relative_folder_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"Folder not found: {full_path}")

        for root, dirs, files in os.walk(full_path):
            # Convert root to be relative to base_path
            relative_root = os.path.relpath(root, self.base_path)
            yield relative_root, dirs, files

    def is_text_file(self, file_path: str):
        # Initialize mimetypes database (optional but good practice)
        mimetypes.init()

        # Extract the extension from the file path
        _, ext = os.path.splitext(file_path)

        # If no extension, assume it's not text
        if not ext:
            return False

        # Guess the MIME type based on the extension
        mime_type, _ = mimetypes.guess_type(file_path)

        # If mime_type is None, we don't know what it is, so assume not text
        if mime_type is None:
            return False

        # Return True if the MIME type starts with 'text/'
        return mime_type.startswith('text/') or mime_type in ('application/xml',)

    def read_file(self, file_path: str, rewrite: bool = True, fix_encoding: bool = True) -> bytes:
        """
        Reads a file at the given relative path within base_path, handling encryption/decryption based on
        enable_encryption
        and ensuring the output is UTF-8 encoded bytes.
        :param file_path: The relative path to the file.
        :param rewrite: If True, rewrites the file with the processed content (e.g., re-encrypt or decrypt) in UTF-8.
        :param fix_encoding: If True, attempts are made to convert the data UTF-8.
        :return: The file content as UTF-8 encoded bytes (decrypted if applicable).
        :raises: FileNotFoundError if the file does not exist.
        """
        full_path = os.path.join(self.base_path, file_path.lstrip(os.sep))
        fix_encoding = self.is_text_file(full_path)

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"File not found: {full_path}")

        with open(full_path, "rb") as f:
            data = f.read()

        is_encrypted = self.encryption_helper.is_encrypted(data)

        if is_encrypted and self.encryption_helper.enable_encryption:
            # The file is encrypted and encryption is on.
            decrypted_data = self.encryption_helper.decrypt(data)

            # Convert decrypted data to UTF-8
            if fix_encoding:
                utf8_data = self._convert_to_utf8(decrypted_data)
            else:
                utf8_data = decrypted_data

            # See if we need to re-encrypt with the latest key.
            if rewrite or (int.from_bytes(data[:self.encryption_helper.VERSION_SIZE], 'big') <
                           max(self.encryption_helper.keys.keys())):
                self.write_file(file_path, utf8_data)

            return utf8_data

        elif is_encrypted and not self.encryption_helper.enable_encryption:
            # The file is encrypted and encryption is off.
            decrypted_data = self.encryption_helper.decrypt(data)

            # Convert decrypted data to UTF-8
            if fix_encoding:
                utf8_data = self._convert_to_utf8(decrypted_data)
            else:
                utf8_data = decrypted_data

            # See if we need to save the decrypted version.
            if rewrite:
                self.write_file(file_path, utf8_data)

            return utf8_data

        elif not is_encrypted and self.encryption_helper.enable_encryption:
            # The file is not encrypted and encryption is on.
            decrypted_data = data

            # Convert data to UTF-8
            if fix_encoding:
                utf8_data = self._convert_to_utf8(decrypted_data)
            else:
                utf8_data = decrypted_data

            if rewrite:
                self.write_file(file_path, utf8_data)

            return utf8_data

        else:
            # Encryption is off.
            # Convert data to UTF-8
            if fix_encoding:
                utf8_data = self._convert_to_utf8(data)
            else:
                utf8_data = data

            return utf8_data

    def write_file(self, file_path: str, data: bytes) -> None:
        """
        Writes the given data to a file at the specified relative path within base_path, ensuring the data is UTF-8
        encoded.
        Handles encryption if enabled.
        :param file_path: The relative path to the file.
        :param data: The data to write as UTF-8 encoded bytes.
        :param fix_encoding: If True, attempt to convert file to UTF-8.
        :raises: OSError if there are issues writing the file.
        """
        full_path = os.path.join(self.base_path, file_path.lstrip(os.sep))
        fix_encoding = self.is_text_file(full_path)

        # Ensure the directory exists
        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        if fix_encoding:
            # Ensure data is UTF-8 encoded
            utf8_data = self._ensure_utf8(data)
        else:
            utf8_data = data

        # Write the data (encrypted if enabled)
        if self.encryption_helper.enable_encryption:
            encrypted_data = self.encryption_helper.encrypt(utf8_data)
            with open(full_path, "wb") as f:
                f.write(encrypted_data)
        else:
            with open(full_path, "wb") as f:
                f.write(utf8_data)

    def read_string(self, file_path: str, rewrite: bool = True, encoding: str = 'utf-8') -> str:
        return self.read_file(file_path, rewrite).decode(encoding)

    def write_string(self, file_path: str, text: str, encoding: str = 'utf-8') -> None:
        self.write_file(file_path, text.encode(encoding))

    def parse_xml(self, relative_xml_path: str, rewrite: bool = True) -> et.ElementTree:
        """
        Parses an XML file at the given relative path within base_path, handling encryption/decryption based on
        enable_encryption.
        :param relative_xml_path: The relative path to the XML file.
        :param rewrite: If True, rewrites the file with the processed content (e.g., re-encrypt or decrypt).
        :return: An ElementTree object representing the parsed XML.
        :raises: FileNotFoundError if the file does not exist.
        :raises: OSError if the path is not a file.
        :raises: et.ParseError if the XML file is malformed.
        """
        full_path = os.path.join(self.base_path, relative_xml_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            raise FileNotFoundError(f"XML file not found: {full_path}")
        if not os.path.isfile(full_path):
            raise OSError(f"Path is not a file: {full_path}")

        with open(full_path, 'rb') as f:
            data = f.read()

        is_encrypted = self.encryption_helper.is_encrypted(data)

        if is_encrypted and self.encryption_helper.enable_encryption:
            # The file is encrypted and encryption is on.
            decrypted_data = self.encryption_helper.decrypt(data)

            # See if we need to re-encrypt with the latest key.
            if rewrite or (int.from_bytes(data[:self.encryption_helper.VERSION_SIZE], 'big') <
                           max(self.encryption_helper.keys.keys())):
                self.write_file(relative_xml_path, decrypted_data)

            tree = et.parse(BytesIO(decrypted_data))
            return tree

        elif is_encrypted and not self.encryption_helper.enable_encryption:
            # The file is encrypted and encryption is off.
            decrypted_data = self.encryption_helper.decrypt(data)

            # See if we need to save the decrypted version.
            if rewrite:
                self.write_file(relative_xml_path, decrypted_data)

            tree = et.parse(BytesIO(decrypted_data))
            return tree

        elif not is_encrypted and self.encryption_helper.enable_encryption:
            # The file is not encrypted and encryption is on. Here we need to encrypt the file.
            decrypted_data = data

            if rewrite:
                self.write_file(relative_xml_path, decrypted_data)

            tree = et.parse(BytesIO(decrypted_data))
            return tree

        else:
            # Encryption is off.
            tree = et.parse(BytesIO(data))
            return tree

    def write_xml(self, relative_xml_path: str, tree: et.ElementTree) -> None:
        """
        Writes an ElementTree object to an XML file at the given relative path within base_path.
        :param relative_xml_path: The relative path where the XML file will be written.
        :param tree: The ElementTree object to write.
        :raises: OSError if the directory cannot be created or writing fails (e.g., permissions).
        :raises: ValueError if the tree is None or invalid.
        """
        if tree is None:
            raise ValueError("ElementTree object cannot be None")

        full_path = os.path.join(self.base_path, relative_xml_path.lstrip(os.sep))

        # Ensure the parent directory exists.
        os.makedirs(os.path.dirname(full_path) or '.', exist_ok=True)

        # Get the root Element.
        root = tree.getroot()

        if self.encryption_helper.enable_encryption:
            # Convert tree to string, encode to bytes, encrypt, and write.
            xml_string = et.tostring(root, encoding='utf-8', xml_declaration=True)
            encrypted_content = self.encryption_helper.encrypt(xml_string)
            with open(full_path, 'wb') as f:
                f.write(encrypted_content)
        else:
            # Write directly to the file.
            tree.write(full_path, encoding='utf-8', xml_declaration=True)

    def get_key(self) -> bytes:
        return self.encryption_helper.get_key()

    def is_encrypted(self, file_path: str) -> bool:
        full_path = os.path.join(self.base_path, file_path.lstrip(os.sep))

        if not os.path.exists(full_path):
            return False
        with open(full_path, "rb") as f:
            data = f.read(self.encryption_helper.VERSION_SIZE + self.encryption_helper.IV_SIZE +
                          self.encryption_helper.HMAC_SIZE)
        return self.encryption_helper.is_encrypted(data)

    def _convert_to_utf8(self, data: bytes) -> bytes:
        """
        Converts the given bytes to UTF-8 encoded bytes, prioritizing Western encodings.
        :param data: The file content as bytes.
        :return: The content as UTF-8 encoded bytes.
        """
        try:
            result = detect(data)
            detected_encoding = result['encoding']

            if detected_encoding:
                detected_encoding = detected_encoding.lower()
            else:
                # Default to Windows-1252 for Western text.
                detected_encoding = 'windows-1252'

            if detected_encoding != 'utf-8':
                encoding = 'windows-1252'

            # Decode from the chosen encoding to a string, then encode to UTF-8.
            decoded_string = data.decode(encoding, errors='replace')
            return decoded_string.encode('utf-8')
        except Exception as e:
            # Fallback to UTF-8 decoding with replacement
            decoded_string = data.decode('utf-8', errors='replace')
            return decoded_string.encode('utf-8')

    def _ensure_utf8(self, data: bytes) -> bytes:
        """
        Ensures the given bytes are UTF-8 encoded. If not, attempts to decode and re-encode as UTF-8.
        :param data: The input bytes.
        :return: UTF-8 encoded bytes.
        """
        try:
            # Try decoding as UTF-8 to verify.
            data.decode('utf-8')

            # Already UTF-8 encoded.
            return data
        except UnicodeDecodeError:
            # Not UTF-8, detect the encoding and convert.
            return self._convert_to_utf8(data)
