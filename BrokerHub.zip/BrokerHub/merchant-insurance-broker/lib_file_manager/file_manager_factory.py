from typing import Optional, Type

from lib_common import constants
from lib_file_manager.encryption_helper import EncryptionHelper
from lib_file_manager.file_manager import FileManager
from lib_file_manager.local_file_manager import LocalFileManager
from lib_file_manager.spaces_file_manager import SpacesFileManager
from lib_persistence import settings


class FileManagerFactory:
    _settings_initialized = False
    _encrypted = None
    _storage_type = None
    _local_base_path = None
    _spaces_name = None
    _spaces_region = None
    _spaces_access_key = None
    _spaces_secret_key = None

    @classmethod
    def _initialize_settings(cls):
        """Load settings once and cache them for reuse."""
        if not cls._settings_initialized:
            cls._encrypted = settings.get_int_setting(constants.SETTING_SYSTEM_FILE_MANAGER_ENCRYPTED, default=0)
            cls._storage_type = settings.get_setting(
                constants.SYSTEM_FILE_MANAGER_STORAGE_TYPE, default='local').lower()
            cls._spaces_name = settings.get_setting(constants.SYSTEM_FILE_MANAGER_SPACES_NAME)
            cls._spaces_region = settings.get_setting(constants.SYSTEM_FILE_MANAGER_SPACES_REGION)
            cls._spaces_access_key = settings.get_setting(constants.SYSTEM_FILE_MANAGER_SPACES_ACCESS_KEY)
            cls._spaces_secret_key = settings.get_setting(constants.SYSTEM_FILE_MANAGER_SPACES_SPACE_SECRET_KEY)
            cls._local_base_path = settings.get_setting(constants.SETTING_SYSTEM_FOLDER, default='/opt/storage')
            cls._settings_initialized = True

    @classmethod
    def reset_settings(cls):
        """Reset cached settings for testing or reconfiguration."""
        cls._settings_initialized = False
        cls._storage_type = None
        cls._local_base_path = None
        cls._spaces_name = None
        cls._spaces_region = None
        cls._spaces_access_key = None
        cls._spaces_secret_key = None

    @staticmethod
    def create_file_manager(manager_class: Optional[Type] = None) -> FileManager:
        # Ensure settings are loaded
        FileManagerFactory._initialize_settings()

        encryption_helper = EncryptionHelper(enable_encryption=True if FileManagerFactory._encrypted else False)

        manager_type = 'local'

        if manager_class is not None:
            if manager_class == LocalFileManager:
                manager_type = 'local'
            elif manager_class == SpacesFileManager:
                manager_type = 'spaces'

        if manager_type == 'local' or FileManagerFactory._storage_type == 'local':
            return LocalFileManager(
                base_path=FileManagerFactory._local_base_path,
                encryption_helper=encryption_helper
            )

        elif manager_type == 'spaces' or FileManagerFactory._storage_type == 'spaces':
            if not all([
                FileManagerFactory._spaces_name,
                FileManagerFactory._spaces_region,
                FileManagerFactory._spaces_access_key,
                FileManagerFactory._spaces_secret_key
            ]):
                raise ValueError("Missing required DigitalOcean Spaces configuration: "
                                 "spaces_name, spaces_region, spaces_access_key, or spaces_secret_key")

            return SpacesFileManager(
                space_name=FileManagerFactory._spaces_name,
                region=FileManagerFactory._spaces_region,
                access_key=FileManagerFactory._spaces_access_key,
                secret_key=FileManagerFactory._spaces_secret_key,
                encryption_helper=encryption_helper
            )

        else:
            raise ValueError(f"Unsupported storage type: {FileManagerFactory._storage_type}")
