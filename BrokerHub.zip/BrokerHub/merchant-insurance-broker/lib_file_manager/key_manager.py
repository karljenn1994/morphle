import base64
import json

from lib_common import constants
from lib_persistence import settings


class KeyManager:
    @staticmethod
    def load_keys():
        """
        Load encryption keys from settings and determine if encryption is enabled.
        :return: Tuple of (keys: dict, enable_encryption: bool)
        :raises: ValueError if keys fail to load or are invalid
        """
        encrypted = settings.get_int_setting(constants.SETTING_SYSTEM_FILE_MANAGER_ENCRYPTED, default=0)
        keys = {}
        encryption_keys_json = settings.get_setting(
            constants.SETTING_SYSTEM_FILE_MANAGER_ENCRYPTION_KEYS,
            default=None
        )

        if encryption_keys_json:
            try:
                keys_map = json.loads(encryption_keys_json)

                for version_str, key_base64 in keys_map.items():
                    version = int(version_str)
                    decoded_key = base64.b64decode(key_base64)

                    if len(decoded_key) != 32:
                        raise ValueError(f"Key for version {version} must be 32 bytes long")
                    keys[version] = decoded_key

                if not keys:
                    raise ValueError("No valid keys loaded from settings")

            except (json.JSONDecodeError, ValueError) as e:
                raise ValueError(f"Failed to load encryption keys: {e}")

        return keys, encrypted != 0
