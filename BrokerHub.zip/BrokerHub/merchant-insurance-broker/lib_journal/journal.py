import logging
import os
from datetime import date, datetime
from json import JSONEncoder

import shortuuid

from lib_common import constants
from lib_common.constants import LOGGER
from lib_persistence import indexer, settings

log = logging.getLogger(LOGGER)


class DateTimeEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return None


class Journal(object):
    errors = None
    mail_index = None
    recent_messages = None
    mail = None
    mail_sort = None
    fetch = None
    organize = None
    status = None
    transform = None
    index = None
    purge_inbox = None
    backup = None
    collect = None
    import_policies = None
    import_users = None
    import_email = None
    notify = None
    notify_schedule = None
    scan = None
    scan_schedule = None
    campaign = None

    TYPE_START = "start"
    TYPE_ENTRY = "entry"
    TYPE_END = "end"

    STATUS_SUCCESS = "success"
    STATUS_FAILED = "failed"

    def __new__(cls, *args, **kwds):
        it = cls.__dict__.get("__it__")

        if it is not None:
            return it

        cls.__it__ = it = object.__new__(cls)
        return it

    def __init__(self):
        journal_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "journal")

        Journal.errors = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "logs", "error.log")
        Journal.mail_index = os.path.join(journal_location, "mail_index", )
        Journal.recent_messages = os.path.join(journal_location, "recent_messages")
        Journal.mail = os.path.join(journal_location, "mail")
        Journal.mail_sort = os.path.join(journal_location, "mail_sort")
        Journal.fetch = os.path.join(journal_location, "fetch")
        Journal.organize = os.path.join(journal_location, "organize")
        Journal.status = os.path.join(journal_location, "status")
        Journal.transform = os.path.join(journal_location, "transform")
        Journal.index = os.path.join(journal_location, "index")
        Journal.purge_inbox = os.path.join(journal_location, "purge_inbox")
        Journal.backup = os.path.join(journal_location, "backup")
        Journal.collect = os.path.join(journal_location, "collect")
        Journal.import_policies = os.path.join(journal_location, "import_policies")
        Journal.import_users = os.path.join(journal_location, "import_users")
        Journal.import_email = os.path.join(journal_location, "import_email")
        Journal.notify = os.path.join(journal_location, "notify")
        Journal.notify_schedule = os.path.join(journal_location, "notify_schedule")
        Journal.scan = os.path.join(journal_location, "scan")
        Journal.scan_schedule = os.path.join(journal_location, "scan_schedule")
        Journal.campaign = os.path.join(journal_location, "campaign")

    @staticmethod
    def _initialize(path):
        # Create the journal file if it does not exist.
        if not os.path.exists(path):
            with open(path, "w+"):
                pass

    @staticmethod
    def read_last_run(task_name, buffer_size=4096):
        if task_name == "indexer":
            task_name = "index"

        journal_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "journal")
        path = os.path.join(journal_location, task_name)

        if not os.path.exists(path):
            return []

        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            file_size = f.tell()
            block_end = file_size
            data = b""
            last_uuid = None
            collected_lines = []

            while block_end > 0:
                block_start = max(0, block_end - buffer_size)
                f.seek(block_start)
                block = f.read(block_end - block_start)
                data = block + data
                lines = data.split(b"\n")

                # If not at the start of a file, the first line is likely incomplete
                if block_start != 0:
                    data = lines.pop(0)
                else:
                    data = b""

                for line in reversed(lines):
                    line = line.strip()
                    if not line:
                        continue

                    parts = line.decode("utf-8", errors="ignore").split(",", 2)
                    if len(parts) < 2:
                        continue

                    current_uuid = parts[1].strip()

                    if last_uuid is None:
                        last_uuid = current_uuid

                    if current_uuid != last_uuid:
                        return list(reversed(collected_lines))

                    collected_lines.append(line.decode("utf-8", errors="ignore"))

                block_end = block_start

        return list(reversed(collected_lines))

    def _tail(self, path, lines=20, buffer=4098, reverse=True):
        self._initialize(path)

        with open(path, "r") as f:
            lines_found = []
            block_counter = -1

            while len(lines_found) < lines:
                try:
                    f.seek(block_counter * buffer, os.SEEK_END)
                except IOError:
                    f.seek(0)
                    lines_found = f.readlines()
                    break

                lines_found = f.readlines()
                block_counter -= 1

            rep = []

            for x in lines_found[-lines:]:
                if reverse:
                    rep.insert(0, x.replace("\n", ""))
                else:
                    rep.append(x.replace("\n", ""))

            return rep

    def to_json(self):
        failed_entries = indexer.get_failed_indexer_files()
        failed_entries_string = ""
        count = 0

        for entry in failed_entries:
            count += 1

            if count > 20:
                break

            failed_entries_string += (str(entry["entered"]) + ", " + entry["file_name"])

            if entry["message"] is not None:
                failed_entries_string += ", " + entry["message"]

            failed_entries_string += "\n"

        return {
            "status": "\n".join(self._tail(self.status)),
            "errors": "\n".join(self._tail(self.errors, lines=2000, reverse=False)),
            "indexer": failed_entries_string,
            "fetch": "\n".join(self._tail(self.fetch)),
            "mail": "\n".join(self._tail(self.mail)),
            "mail_sort": "\n".join(self._tail(self.mail_sort)),
            "organize": "\n".join(self._tail(self.organize)),
            "transform": "\n".join(self._tail(self.transform)),
            "index": "\n".join(self._tail(self.index)),
            "purge_inbox": "\n".join(self._tail(self.purge_inbox)),
            "collect": "\n".join(self._tail(self.collect)),
            "backup": "\n".join(self._tail(self.backup)),
            "import_policies": "\n".join(self._tail(self.import_policies)),
            "import_users": "\n".join(self._tail(self.import_users)),
            "import_email": "\n".join(self._tail(self.import_email)),
            "notify": "\n".join(self._tail(self.notify)),
            "notify_schedule": "\n".join(self._tail(self.notify_schedule)),
            "scan": "\n".join(self._tail(self.scan)),
            "schedule_schedule": "\n".join(self._tail(self.scan_schedule)),
            "campaign": "\n".join(self._tail(self.campaign)),
        }

    @staticmethod
    def write_journal_entry(journal, journal_id, record_type, status, message, v1=-1, v2=-1):
        with open(journal, "a+") as f:
            f.write("\n" + '{date_time}, {journal_id}, {record_type}, {status}, "{message}", {v1}, {v2}'.format(
                date_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), journal_id=journal_id, record_type=record_type,
                status=status, message=message, v1=v1, v2=v2, ))

    def begin_journal(self, journal, message):
        self._initialize(journal)
        journal_id = shortuuid.uuid()
        Journal.write_journal_entry(journal, journal_id, Journal.TYPE_START, Journal.STATUS_SUCCESS, message, -1, -1)
        return journal_id

    def journal(self, journal, journal_id, status, message):
        self._initialize(journal)
        Journal.write_journal_entry(journal, journal_id, Journal.TYPE_ENTRY, status, message)

    def end_journal(self, journal, journal_id, status, message, v1=-1, v2=-1):
        self._initialize(journal)
        Journal.write_journal_entry(journal, journal_id, Journal.TYPE_END, status, message, v1, v2)
