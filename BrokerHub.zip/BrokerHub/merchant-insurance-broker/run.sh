#!/bin/sh

DIR="$PWD"
SCRIPT_DIR="$(dirname "$0")"

cd $SCRIPT_DIR
SCRIPT_DIR="$PWD"

export $(grep -v '^#' $SCRIPT_DIR/.env | xargs) > /dev/null 2>&1
PYTHONPATH=$SCRIPT_DIR python $@

cd $DIR
