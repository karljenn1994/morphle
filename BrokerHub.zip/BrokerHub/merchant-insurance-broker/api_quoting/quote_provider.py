from abc import ABC, abstractmethod


class QuoteProvider(ABC):
    def __init__(self, config, quick_quote):
        self._config = config
        self._quick_quote = quick_quote
        self._quote_result = {}

    def _normalize_level(self, level):
        if level is None:
            return "error"

        if level[0:].lower() == "e":
            return "error"

        if level[0:].lower() == "w":
            return "warn"

        if level[0:].lower() == "i":
            return "info"

        return "error"

    @abstractmethod
    async def quote(self, payload, province_code, lob):
        pass

    @property
    def quote_result(self):
        return self._quote_result


