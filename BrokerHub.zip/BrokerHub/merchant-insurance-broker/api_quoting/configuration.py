import logging
import os

import yaml

# noinspection PyUnresolvedReferences
from api_quoting.quote_provider_ratebridge_auto import RateBridgeAutoQuoteProvider
# noinspection PyUnresolvedReferences
from api_quoting.quote_provider_ratebridge_hab import RateBridgeHabQuoteProvider
# noinspection PyUnresolvedReferences
from api_quoting.quote_provider_rating_web_service_auto import RatingWebServiceAutoQuoteProvider
# noinspection PyUnresolvedReferences
from api_quoting.quote_provider_rating_web_service_hab import RatingWebServiceHabQuoteProvider
# noinspection PyUnresolvedReferences
from api_quoting.quote_provider_wawanesa_auto import WawanesaAutoQuoteProvider
# noinspection PyUnresolvedReferences
from api_quoting.quote_provider_wawanesa_hab import WawanesaHabQuoteProvider
from lib_common import constants
from lib_common.constants import LOGGER
from lib_persistence import settings

log = logging.getLogger(LOGGER)


class QuotingConfiguration(object):
    def __init__(self):
        self._data = None
        self._load()

    def _load(self):
        file_path = None
        try:
            config_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "config")
            file_path = os.path.join(config_location, "quoting_config.yaml")
            with open(file_path, 'r') as file:
                self._data = yaml.safe_load(file)
            return True
        except FileNotFoundError:
            log.error(f"File '{file_path}' not found.")
        except yaml.YAMLError as e:
            log.error(f"Error while loading YAML file: {e}")
        return False

    def get_providers(self, province_code, lob, quick_quote):
        lob = lob.lower() if lob is not None else None
        province_code = province_code.upper() if province_code is not None else None

        if province_code not in self._data["providers"]:
            return None

        province_cfg = self._data["providers"][province_code]

        if province_cfg is None or lob not in province_cfg:
            return None

        province_lob_cfg = province_cfg[lob]
        providers = province_lob_cfg["providers"]
        provider_instances = []

        for provider in providers:
            config = provider["config"]
            provider_class = provider["provider"]
            provider_instances.append(globals()[provider_class](self._data["config"][config], quick_quote))

        return provider_instances
