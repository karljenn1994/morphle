import asyncio
import os
from datetime import datetime

import moment
import xmltodict
from suds.client import Client
from suds.sax.text import Raw

from lib_common import constants
from lib_persistence import settings

debug = False


class CqCreditScore:
    def __init__(self, config, quote_support):
        global debug
        self._config = config
        self._quote_support = quote_support
        self._transformation_support = self._quote_support.transformation_support
        self._value = self._transformation_support.value
        self._field = self._transformation_support.field
        self._error = self._transformation_support.transformation_log.log_error
        self._warn = self._transformation_support.transformation_log.log_warn
        self._info = self._transformation_support.transformation_log.log_info

    def get_individual_addr(self, insured):
        addr = self._field(insured, "address", default="")
        comma = addr.find(",")

        if comma != -1:
            addr = addr[:comma]

        return addr

    def get_individual_prov(self, insured):
        prov = insured["fields"]["province_code"]

        if prov is None:
            return {
                "Error": "No valid province found"
                }
        else:
            prov = prov.upper()

        return prov

    def get_individual_city(self, insured):
        city = insured["fields"]["city"]

        if city is None:
            return {
                "Error": "No valid city found"
                }

        return city

    def get_individual_postal(self, insured):
        postal = self._field(insured, "postal_code")

        if postal is None:
            return {
                "Error": "No valid Postal Code found for Location Index Lookup"
                }
        else:
            postal = postal.replace(" ", "").upper()

        return postal

    def get_insured_for_credit_check(self, snap_json):
        ret_val = None

        for i in snap_json:
            if snap_json[i].get("type") == "individual" and ret_val is None:
                if snap_json[i].get("fields") is not None:
                    ret_val = snap_json[i]

        return ret_val

    def get_region(self, prov):
        ret_val = "Maritime"

        if prov.upper() == "ON" or prov.upper() == "ONTARIO":
            ret_val = "Ontario"
        elif prov.upper() == "BC" or prov.upper() == "BRITISH COLUMBIA":
            ret_val = "British Columbia"
        elif prov.upper() == "AB" or prov.upper() == "ALBERTA":
            ret_val = "Southern Alberta"
        elif prov.upper() == "MB" or prov.upper() == "MANITOBA":
            ret_val = "Winnipeg"
        elif prov.upper() == "SK" or prov.upper() == "SASKATCHEWAN":
            ret_val = "Prairie"

        return ret_val

    async def perform_multi_credit_check(self, cq_json, lob, prov, guid):
        credit_check_required = self._config["credit_score_required"] if "credit_score_required" in self._config else True
        if not credit_check_required:
            return None

        primary_ind = self.get_insured_for_credit_check(cq_json)
        credit_check_function_map = []

        carrier_config = self._config["carriers"]

        if carrier_config is None:
            self._error("No carriers for " + prov + " have been configured")
            return None

        # Rating web service will have a single carrier. Rate bridge will have a map
        # of possibly many carriers.
        if type(carrier_config) is str:
            quote_carriers = [carrier_config]
        elif type(carrier_config) is list:
            quote_carriers = carrier_config
        else:
            quote_carriers = list(carrier_config.keys())

        skip_branches = {}

        for quote_carrier in quote_carriers:
            credit_score_required = False

            if carrier_config[quote_carrier] is not None and "credit_score_required" in carrier_config[quote_carrier]:
                credit_score_required = carrier_config[quote_carrier]["credit_score_required"]
            else:
                skip_branches["@vor" + quote_carrier] = "SkipBranch"

            if credit_score_required:
                credit_check_function_map.append(
                    self.perform_single_credit_check(primary_ind, prov, lob, quote_carrier, guid))

        promise_credit_results = await asyncio.gather(*credit_check_function_map)

        cs_response = {
            "Factor1": {},
            "Factor2": {},
            "Factor3": {},
            "Factor4": {},
            "Factor5": {},
            "Factor6": {},
            "Factor7": {},
            "Factor8": {},
            "Factor9": {},
            "Factor10": {},
            "Factor11": {},
            "Factor12": {},
            "Factor13": {},
            "Factor14": {},
            "Factor15": {},
            "Article1": {},
            "Article2": {},
            "Article3": {},
            "Article4": {},
            "Article5": {},
            "ID": "1",
            "StatusCode": {},
            "Debug": True,
            }

        for i, result in enumerate(promise_credit_results):
            if result is None:
                cs_response["@vor" + quote_carriers[i]] = "SkipBranch"
            else:
                if result["StatusCode"] == 'ERROR':
                    cs_response["@vor" + quote_carriers[i]] = "SkipBranch"
                else:
                    cs_node = result["ReceiverResponse"]

                    for factor in cs_node:
                        element_name = f'vor{quote_carriers[i]}'

                        if cs_response.get(factor[0]) is not None and factor[1] is not None:
                            cs_response[factor[0]]["@" + element_name] = factor[1]

        return {
            "CreditScore": {**skip_branches, **cs_response}
            }

    # async def perform_single_credit_check(self, enabled, env, individual, prov, lob, carrier, guid):
    async def perform_single_credit_check(self, individual, prov, lob, carrier, guid):
        env = "dev"
        carrier_config = self._value(self._config, ["carriers", carrier])

        if carrier_config is None:
            return None

        credit_score_required = self._value(carrier_config, "credit_score_required")

        if credit_score_required is None:
            return None

        consent = self._field(individual, "consent_to_credit_check", default=False, level="none")

        cq_username = self._value(self._config, "username")
        cq_password = self._value(self._config, "password")

        carrier_username = self._value(carrier_config, "username")
        carrier_password = self._value(carrier_config, "password")

        url = self._value(carrier_config, ["credit_score", "url"])
        wsdl = self._value(carrier_config, ["credit_score", "wsdl"])
        wsdl_url = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "etc", f"wsdl/{wsdl}")
        wsdl_url = "file://" + wsdl_url

        # "ReqChannelType": "CQ_HUB",
        # "BrokerID": self._value(carrier_config, "broker_code"),
        # "Language": "EN",
        header = {
            "CQCredentials": {
                "UserName": cq_username,
                "Password": cq_password,
                },
            "Caller": {
                "Name": "brunvalley.com",
                "Version": "1.0.0.126",
                "LineOfBusiness": lob.upper(),
                "Province": "ON",
                "Carrier": carrier,
                "TransID": guid,
                },
            "TPCredentials": {
                "UserName": carrier_username,
                "Password": carrier_password,
                },
            }

        currently_insured = (individual["fields"].get("years_continuously_insured") and individual["fields"][
            "years_continuously_insured"] != 0)

        body = {
            "FirstName": self._field(individual, "first_name", default=""),
            "MiddleName": self._field(individual, "middle_name", default=""),
            "LastName": self._field(individual, "last_name", default=""),
            "Address": self.get_individual_addr(individual),
            "City": self._field(individual, "city", default=""),
            "Province": self._field(individual, "province_code", default=""),
            "PostalCode": self.get_individual_postal(individual),
            "HomePhoneAreaCode": "506",
            "HomePhoneNumber": self._field(individual, "phone", default=""),
            "DateOfBirth": moment.date(self._field(individual, "date_of_birth", default=""),
                                       "MMMM DD,YYYY").isoformat(),
            "Consent": True,
            "ConsentDate": datetime.utcnow().isoformat(),
            "EffDate": datetime.utcnow().isoformat(),
            "TransactionType": "NEW_BUSINESS",
            "CurrentlyInsured": True,  # currently_insured,
            "Language": "ENGLISH",
            "CreditScoreType": "PERSONAL",
            "CallingApplication": "THIRD_PARTY",
            "CustomerType": "INDIVIDUAL",
            "ExtendedInfoSpecified": False,
            }

        if carrier == "WAWA" or carrier == "WAW2":
            region = self.get_region(prov)
            body["ExtendedInfo"] = {
                "HabType": "H",
                "Region": region,
                }
            body["ExtendedInfoSpecified"] = True

        credit_score_response = None

        client = Client(wsdl_url)
        client.set_options(location=url)
        client.set_options(soapheaders=header)

        result = client.service.GetCreditScoreStandard(Raw(xmltodict.unparse(body, full_document=False)), )

        if result is not None:
            credit_score_response = result

        return credit_score_response
