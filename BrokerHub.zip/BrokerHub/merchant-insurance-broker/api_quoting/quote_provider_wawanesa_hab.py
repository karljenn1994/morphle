from abc import ABC

import requests
import xmltodict

from api_quoting.quote_provider import QuoteProvider
from lib_quote.quote_result import QuoteStatus
from lib_quote.quote_support import QuoteSupport
from lib_persistence import policy
from lib_quote.card_to_csio_hab import CardToCSIOHab


class WawanesaHabQuoteProvider(QuoteProvider, ABC):
    def __init__(self, config, quick_quote):
        QuoteProvider.__init__(self, config, quick_quote)

    async def quote(self, request_json, province_code, lob):
        qps = QuoteSupport()
        qps.provider = "WawanesaAutoQuoteProvider"
        card_to_csio = CardToCSIOHab(self._config, self._quick_quote, qps)

        payload_xml = """
            <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"  xmlns:ns="http://www.ACORD.org/standards/PC_Surety/ACORD1/xml/">
                <soap:Body>
        """ + card_to_csio.to_csio_xml(request_json) + """
                </soap:Body>
            </soap:Envelope>                
        """

        # proxies = {
        #     'https': '165.227.38.12:3128',
        #     }

        response = requests.post(
            self._config["url"],
            data=payload_xml,
            # proxies=proxies,
            headers={
                "Content-Type": "application/soap+xml;charset=UTF-8;action=\"processRequest\"",
                },
            auth=(
                self._config["username"],
                self._config["password"]
                )
            )

        # Handle HTTP errors.
        if response.status_code != 200:
            qps.status = QuoteStatus.FAILED
            qps.error("Quote failed with unexpected status code " + str(response.status_code))
            qps.messages = qps.quote_log.get_messages()
            self._quote_result = qps.quote_result
            return

        # Make sure we got a response body.
        if not response.text:
            qps.status = QuoteStatus.FAILED
            qps.error("Missing response body")
            qps.messages = qps.quote_log.get_messages()
            self._quote_result = qps.quote_result
            return

        # Make sure it converts to JSON.
        try:
            result = xmltodict.parse(response.text)
        except Exception as error:
            qps.status = QuoteStatus.FAILED
            qps.error("Error converting the response to JSON")
            qps.error(str(error))
            qps.messages = qps.quote_log.get_messages()
            self._quote_result = qps.quote_result
            return

        # Make sure we have an ACORD node.
        acord = qps.value(result, ["soap:Envelope", "soap:Body", "ACORD"])

        if acord is None:
            qps.status = QuoteStatus.FAILED
            qps.error("Quote response envelope is malformed")
            qps.messages = qps.quote_log.get_messages()
            self._quote_result = qps.quote_result
            return

        # Make sure we have a quote response.
        quote_inq_rs = qps.value(acord, ["InsuranceSvcRs", "HomePolicyQuoteInqRs"])

        if quote_inq_rs is None:
            qps.status = QuoteStatus.FAILED
            qps.error("Quote response is malformed")
            qps.messages = qps.quote_log.get_messages()
            self._quote_result = qps.quote_result
            return

        qrs = QuoteSupport()
        qrs.insurer = "WAWA"
        qrs.insurer_description = policy.map_company_code("WAWA")[0]

        # See if we have any messages. We will fail if any error messages are detected.
        msg_status = qrs.value(quote_inq_rs, "MsgStatus", level="info")

        if msg_status is not None:
            ext_status = qrs.value(msg_status, "ExtendedStatus", level="warn")

            if ext_status is not None:
                if type(ext_status) != list:
                    ext_status = [ext_status]

                for exs in ext_status:
                    if qrs.value(exs, "ExtendedStatusCd", level="warn") is not None:
                        if qrs.value(exs, "csio:GroupInfo", level="none") is not None:
                            group_infos = exs["csio:GroupInfo"]

                            if type(group_infos) != list:
                                group_infos = [group_infos]

                            for group_info in group_infos:
                                level = qrs.value(group_info, "csio:LabelText")
                                level = level.lower() if level is not None else "error"
                                level = self._normalize_level(level)
                                message = qrs.value(group_info, ["HelpText"], level="warn")
                                message = message if message is not None else "Message text is empty"
                                qrs.log(level, message)
                        else:
                            message = qrs.value(exs, "ExtendedStatusDesc", level="warn")

                            if message is not None:
                                qrs.info(message)

        policy_summary = qrs.value(quote_inq_rs, "PolicySummaryInfo", level="error")

        if policy_summary is None:
            qrs.messages = qrs.quote_log.get_messages()
            qrs.status = QuoteStatus.FAILED

        else:
            full_term_amount = qrs.value(policy_summary, ["FullTermAmt", "Amt"], data_type=float, level="error")

            if full_term_amount is None or full_term_amount <= 0:
                qrs.messages = qrs.quote_log.get_messages()
                qrs.status = QuoteStatus.FAILED

            else:
                qrs.tracking_number = qrs.value(policy_summary, ["ItemIdInfo", "InsurerId"], level="warn",
                                                tag="Tracking number")
                qrs.total_premium = full_term_amount

                # I think we put the property id in the AgencyId during the request
                # so that wawanesa will preserve it for us?
                property_id = qrs.value(policy_summary, ["ItemIdInfo", "InsurerId"], level="error")
                qrs.add_insured_item(property_id, {
                    "premium": float(full_term_amount)
                    })

                coverages = qrs.value(quote_inq_rs, ["HomeLineBusiness", "Dwell", "Coverage"], level="warn")

                if coverages is not None:
                    for cov in coverages:
                        coverage_code = qrs.value(cov, "CoverageCd", level="info")

                        if coverage_code is None:
                            coverage_code = qrs.value(cov, ["csio:PackageCoverageName", "#text"], level="warn")

                        if coverage_code is None:
                            continue

                        coverage_code = coverage_code.replace("csio:", "")

                        try:
                            premium = qrs.value(cov, ["CurrentTermAmt", "Amt"], level="none")
                            premium = float(premium) if premium is not None else -1
                        except ValueError:
                            premium = -1
                            qrs.warn("Coverage CurrentTermAmt is not a float")

                        try:
                            limit = qrs.value(cov, ["Limit", "FormatCurrencyAmt", "Amt"], level="none")
                            limit = float(limit) if limit is not None else -1
                        except ValueError:
                            limit = -1
                            qrs.warn("Coverage Limit is not a float")

                        try:
                            deductible = qrs.value(cov, ["Deductible", "FormatCurrencyAmt", "Amt"], level="none")
                            deductible = float(deductible) if deductible is not None else -1
                        except ValueError:
                            deductible = -1
                            qrs.warn("Coverage Deductible is not a float")

                        qrs.append_coverage(
                            {
                                "code": coverage_code,
                                "limit": limit,
                                "deductible": deductible,
                                "premium": premium,
                                })

                qrs.status = QuoteStatus.SUCCESS

        qrs.messages = qrs.quote_log.get_messages()
        qps.append_quote(qrs.quote_result)
        qps.messages = qps.quote_log.get_messages()
        qps.status = QuoteStatus.SUCCESS
        self._quote_result = qps.quote_result
