import asyncio
import json
import logging
import uuid

from flask import request
from flask_restx import Namespace, Resource

from api_quoting.configuration import QuotingConfiguration
from api_quoting.quote_provider_ratebridge_auto import RateBridgeAutoQuoteProvider
from lib_common import constants
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    CODE_INVALID_ARGUMENT, CODE_INVALID_CONTENT_TYPE,
    CODE_MISSING_CONTENT, HttpException, InvalidArgument
)
from lib_common.repository import Repository
from lib_common.routes_support import response_json
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import quote

api = Namespace("broker-api/mobile/v1/quote", description="Provides vehicle and property quoting.")
log = logging.getLogger(LOGGER)


# with this (tiny local impl):
def strtobool(val: str) -> int:
    v = val.lower()
    if v in ("y", "yes", "t", "true", "on", "1"): return 1
    if v in ("n", "no", "f", "false", "off", "0"): return 0
    raise ValueError(f"invalid truth value {val!r}")


@api.route("/<province_code>/<lob>/<quick_quote>", methods=["POST"])
@api.doc(description="Provides a quote for the specified line of business.")
class Quote(Resource):
    @staticmethod
    def assert_content_type():
        if request.content_type != "application/json":
            raise HttpException("Expecting application/json content-type", error_code=CODE_INVALID_CONTENT_TYPE)

    @staticmethod
    def assert_content():
        if request.json is None or len(request.json) <= 0:
            raise HttpException("Missing json data", error_code=CODE_MISSING_CONTENT)

    @staticmethod
    def assert_province(province_code):
        if province_code is None:
            raise InvalidArgument("Invalid province code", error_code=CODE_INVALID_ARGUMENT)

    @staticmethod
    def assert_lob(lob):
        if lob is None or (lob != constants.QUOTING_LOB_AUTO and lob != constants.QUOTING_LOB_HAB):
            raise InvalidArgument("Line of business should be auto or hab", error_code=CODE_INVALID_ARGUMENT)

    @staticmethod
    async def gather_quotes(providers, province_code, lob):
        await asyncio.gather(*[provider.quote(request.json, province_code, lob) for provider in providers])

    @staticmethod
    def log_messages(messages):
        if "error" in messages:
            for error in messages["error"]:
                log.debug("ERROR: " + error)

        if "warn" in messages:
            for warn in messages["warn"]:
                log.debug("WARN: " + warn)

        if "error" in messages:
            for info in messages["info"]:
                log.debug("INFO: " + info)

    @staticmethod
    def log_all_messages(providers):
        if log.isEnabledFor(logging.DEBUG):
            for provider in providers:
                if provider.quote_result is not None:
                    if "provider" in provider.quote_result:
                        log.debug("PROVIDER: " + provider.quote_result["provider"])

                    if "messages" in provider.quote_result:
                        Quote.log_messages(provider.quote_result["messages"])

                    if "quote_results" in provider.quote_result:
                        for result in provider.quote_result["quote_results"]:
                            if "insurer" in result:
                                log.debug("RESULT FROM: " + result["insurer"])

                            if "messages" in result:
                                Quote.log_messages(result["messages"])

    @staticmethod
    def post(province_code, lob, quick_quote):
        """
        Provides a quote for the specified line of business.
        """
        # Calls will not require security because anyone can quote.
        try:
            try:
                quick_quote = bool(strtobool(quick_quote))
            except:
                quick_quote = False

            Quote.assert_content_type()
            Quote.assert_content()

            province_code = province_code.lower() if province_code is not None else None
            Quote.assert_province(province_code)

            lob = lob.lower() if lob is not None else None
            Quote.assert_lob(lob)

            # Instantiate providers for the province and line of business.
            quote_cfg = QuotingConfiguration()
            providers = quote_cfg.get_providers(province_code, lob, quick_quote)

            if providers is None or len(providers) == 0:
                raise InvalidArgument(
                    "No providers found in province " + province_code + " for line of business " + lob,
                    error_code=CODE_INVALID_ARGUMENT)

            # Execute quoting for all the providers asynchronously and gather the results.
            asyncio.run(Quote.gather_quotes(providers, province_code, lob))

            carriers = []

            for provider in providers:
                if type(provider) == RateBridgeAutoQuoteProvider:
                    if provider.quote_result is not None:
                        if "quote_results" in provider.quote_result:
                            for result in provider.quote_result["quote_results"]:
                                if result["status"] == "success":
                                    insurer = result["insurer"]
                                    carriers.append(insurer)

            for provider in providers:
                if type(provider) != RateBridgeAutoQuoteProvider:
                    duplicates = []
                    if provider.quote_result is not None:
                        if "quote_results" in provider.quote_result:
                            for result in provider.quote_result["quote_results"]:
                                insurer = result["insurer"]
                                if insurer in carriers:
                                    duplicates.append(result)
                            for duplicate in duplicates:
                                provider.quote_result["quote_results"].remove(duplicate)

            Quote.log_all_messages(providers)

            # Go through each provider and assemble the results into a response.
            return response_json(200, [provider.quote_result for provider in providers])
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/submit-quote", methods=["POST"])
@api.doc(description="Submits a quote.")
class QuoteSubmit(Resource):
    @staticmethod
    def get_insurer(quote_data):
        insurer = None

        for q in quote_data:
            quo = quote_data[q]

            if "type" in quo and quo["type"] == "quote":
                if "quote_insurer" in quo:
                    insurer = quo["quote_insurer"]
                    break

        return insurer

    @staticmethod
    def get_lob(quote_data):
        lob = "auto"

        for c in quote_data:
            if "type" in quote_data[c] and quote_data[c]["type"] == "property":
                lob = "hab"
                break

        return lob

    @staticmethod
    def post():
        """
        Submits a quote.
        """

        # No security here because anyone can submit a quote.
        try:
            fm = FileManagerFactory.create_file_manager()
            quote_data = json.loads(request.form.get('data'))
            mid = uuid.uuid1().hex
            quote_path = mid + "/QUOTE.JSON"

            try:
                company = QuoteSubmit.get_insurer(quote_data)
                lob = QuoteSubmit.get_lob(quote_data)
                email = quote_data["contact"]["email"]
                phone = quote_data["contact"]["phone"]

                # Add the quote to the database.
                quote.insert_quote(mid,
                                   company,
                                   lob.upper() if lob is not None else None,
                                   email,
                                   phone,
                                   quote_path)
            except Exception as ex:
                log.exception(ex, stack_info=True)
                return response_json(400, {
                    "message": str(ex)
                })

            #  Ensure there is a quote folder.
            quote_abs_path = fm.join(Repository.quotes_location, mid)
            fm.mkdir(quote_abs_path)

            # Save the quote data.
            quote_file = fm.join(Repository.quotes_location, quote_path)
            fm.write_string(quote_file, request.form.get('data'))

            # Save the quote images.
            for item in request.files.getlist('image'):
                fm.write_file(fm.join(Repository.quotes_location, mid, item.filename), item.read())

            return response_json(200, {
                "message": "Quote received"
            })

        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })

        finally:
            pass


@api.route("/upload/<company>/<lob>/<email>/<phone>", methods=["POST"])
@api.doc(description="Adds a quote to the system (this call comes from the LifesWallet main server).")
class AddQuote(Resource):
    """
    Adds a quote to the system (this call comes from the LifesWallet main server).
    """

    @staticmethod
    def post(company, lob, email, phone):
        fm = FileManagerFactory.create_file_manager()

        # No security here because anyone can submit a quote.
        mid = uuid.uuid1().hex
        quote_abs_path = fm.join(Repository.quotes_location, mid)
        fm.mkdir(quote_abs_path)

        quote_path = fm.join(mid, "QUOTE.PDF")
        quote_file = fm.join(Repository.quotes_location, quote_path)

        # Save the quote PDF file.
        try:
            pdf_file = request.files["quote_pdf"]
            pdf_file.save(quote_file)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})

        # Add the quote to the database.
        try:
            quote.insert_quote(
                mid,
                company,
                lob.upper() if lob is not None else None,
                email,
                phone,
                quote_path
            )

            return response_json(200, {})

        except Exception as ex:
            try:
                # remove the quote file.
                fm.remove(quote_file)
                fm.remove(quote_abs_path)
            except OSError:
                pass

            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
