import os
import uuid
from abc import ABC

import xmltodict
from suds.client import Client
from suds.sax.text import Raw

from api_quoting.credit_score_cq import CqCreditScore
from api_quoting.quote_provider import QuoteProvider
from lib_common import constants
from lib_quote.quote_result import QuoteStatus
from lib_quote.quote_support import QuoteSupport
from lib_persistence import policy, settings
from lib_quote.card_to_cq_auto import CardToCQAuto


import xml.dom.minidom


class RateBridgeAutoQuoteProvider(QuoteProvider, ABC):
    def __init__(self, config, quick_quote):
        QuoteProvider.__init__(self, config, quick_quote)

    async def quote(self, request_json, province_code, lob):
        qps = QuoteSupport()
        qps.provider = "RateBridgeAutoQuoteProvider"

        # We need to create CQ compliant IDs
        id_counter = 1
        id_map = {}

        for item in request_json.values():
            cq_id = f"0000000{id_counter}"
            item["cqID"] = cq_id
            id_counter += 1
            id_map[cq_id] = item["id"]

            if qps.value(item, "type") == "vehicle":
                # Check the package requested (Recommended vs Economical).
                quote_type = qps.field(item, "quote_coverage_type", default="recommended", level="info")
                id_map["quoteType"] = quote_type

        guid = uuid.uuid4().hex
        credit_score = await CqCreditScore(self._config, qps).perform_multi_credit_check(request_json, lob,
                                                                                         province_code.upper(), guid)

        credit_score_xml = xmltodict.unparse(credit_score, full_document=False) if credit_score is not None else None

        body = CardToCQAuto(self._config, self._quick_quote, qps, credit_score).to_cq_json(province_code.upper(),
                                                                                           request_json)
        username = qps.value(self._config, "username")
        password = qps.value(self._config, "password")

        wsdl = qps.value(self._config, "wsdl")
        wsdl_url = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "etc", f"wsdl/{wsdl}")
        wsdl_url = "file://" + wsdl_url

        client = Client(wsdl_url)
        client.set_options(location=qps.value(self._config, "url"))

        version = client.factory.create("FortusVersionType")
        version.MajorVersion = 5
        version.MinorVersion = 9
        version.Build = 4

        caller = client.factory.create("Caller")
        caller.Name = "brunvalley.com"
        caller.Version = "1.0.0.126"
        caller.Product = "ThirdParty_Web"
        caller.LineOfBusiness = lob.upper()
        caller.Province = province_code.upper()
        caller.Language = "EN"
        caller.FortusVersion = version

        creds = client.factory.create("CQCredentials")
        creds.UserName = username
        creds.Password = password

        client.set_options(soapheaders=(creds, caller), retxml=True)
        quote_request_xml = xmltodict.unparse(body, full_document=False, pretty=True)

        result = client.service.Rate(Raw(body["QuoteGUID"]), Raw(body["QuoteIterationGUID"]),
                                     Raw(xmltodict.unparse(body["xmlparam_FortusTransaction"], full_document=False)),
                                     Raw(xmltodict.unparse(body["xmlparam_ExtendedInput"], full_document=False)),
                                     Raw(xmltodict.unparse(body["xmlparam_CarrierInfo"], full_document=False)), )

        if result is None:
            qps.error("Response from RateBridge was empty")
            qps.status = QuoteStatus.FAILED
            qps.messages = qps.quote_log.get_messages()
            self._quote_result.update(qps.quote_result)
            return

        quote_response_xml = result
        result = xmltodict.parse(quote_response_xml)

        if credit_score_xml is not None:
            self._quote_result["credit_score_xml"] = credit_score_xml

        self._quote_result["quote_request_xml"] = quote_request_xml

        temp = xml.dom.minidom.parseString(quote_response_xml.decode("utf-8"))
        new_xml = temp.toprettyxml()
        self._quote_result["quote_response_xml"] = new_xml

        result = result["soap:Envelope"]["soap:Body"]["RateResponse"]["RateResult"]
        cq_carriers = None

        if result is not None:
            cq_carriers = qps.value(result, ["FortusOutputXML", "FortusTransaction", "Carriers"], level="info")

        if cq_carriers is None or len(cq_carriers) == 0:
            qps.error("No carriers found in quote response")
            qps.status = QuoteStatus.FAILED
            qps.messages = qps.quote_log.get_messages()
            self._quote_result.update(qps.quote_result)
            return

        for carrier in cq_carriers:
            qs = QuoteSupport()
            qs.insurer = carrier
            qs.insurer_description = policy.map_company_code(carrier)[0]
            self._assemble_response_from_cq(qs, carrier, cq_carriers[carrier], id_map)
            qps.append_quote(qs.quote_result)

        qps.messages = qps.quote_log.get_messages()
        qps.status = QuoteStatus.SUCCESS
        self._quote_result.update(qps.quote_result)

    def _assemble_response_from_cq(self, qs, carrier, carrier_result, id_map):
        quote_info = qs.value(carrier_result, ["CodeNames", "Auto", "QuoteInfo"])

        if quote_info is None:
            qs.status = QuoteStatus.FAILED
            qs.messages = qs.quote_log.get_messages()
            qs.error(f"Quote failed for carrier {carrier}")
            return

        cq_veh = qs.value(quote_info, "Vehicle")

        if cq_veh is not None:
            cq_vehicles = cq_veh if isinstance(cq_veh, list) else [cq_veh]

            for cq_veh in cq_vehicles:
                cq_id = qs.value(cq_veh, "ID")

                if cq_id is None:
                    continue

                orig_id = qs.value(id_map, cq_id)

                if orig_id is None:
                    continue

                veh_links = qs.value(quote_info, "VehLink", default=[])

                if type(veh_links) != list:
                    veh_links = [veh_links]

                for veh_link in veh_links:
                    # Match based on truncated ID. Want to find the vehlink that applies this vehicle.
                    if qs.value(veh_link, "VehicleID", level="info") == cq_id:
                        # In some cases (2 drivers, 2 vehicles) we receive 4 vehlinks but only 2 have DriverTotal nodes.
                        prem = qs.value(veh_link, ["DriverTotal", "FinalPremium"], data_type=float, default=-1)

                        if prem > 0:
                            self._add_all_messages_from_cq(qs, veh_link)
                            self._add_all_coverages_from_cq(qs, veh_link, orig_id)
                            self._add_all_discounts_from_cq(qs, veh_link, orig_id)

                        qs.add_insured_item(orig_id, {
                            "premium": float(prem) if prem is not None else -1
                            })

        else:
            # if CQ_veh is None, we still want to show messages.
            self._add_all_messages_from_cq(qs, quote_info)

        # Fill in the rest of the response.
        qs.total_premium = qs.value(quote_info, ["PolicyTotal", "FinalPremium"], data_type=float, level="error")

        if qs.total_premium is None or qs.total_premium <= 0:
            qs.status = QuoteStatus.FAILED
        else:
            qs.status = QuoteStatus.SUCCESS

        qs.messages = qs.quote_log.get_messages()

    def _add_all_messages_from_cq(self, qs, m_node):
        if m_node is not None:
            messages = qs.value(m_node, "Message", default=[])
            messages = [messages] if len(messages) != 0 and type(messages) is str else messages

            if type(messages) == dict:
                severity = int(qs.value(messages, "Severity", default="100"))
                level = "info" if severity == 100 else "error"
                message_text = qs.value(messages, "MessageText", level="warn")
                message_text = message_text if message_text is not None else "Message text is empty"
                qs.log(level, message_text + " (severity=" + str(severity) + ")")
            else:
                for message in messages:
                    if type(message) != tuple:
                        severity = int(qs.value(message, "Severity", default="100"))
                        level = "info" if severity == 100 else "error"
                        message_text = qs.value(message, "MessageText", level="warn")
                        message_text = message_text if message_text is not None else "Message text is empty"
                        qs.log(level, message_text + " (severity=" + str(severity) + ")")
                    else:
                        if message[0] == "MessageText":
                            level = "info"
                            message_text = message[1]
                            qs.log(level, message_text)

    def _add_all_coverages_from_cq(self, qs, m_node, orig_id):
        if m_node is not None:
            coverages = qs.value(m_node, "CoveragePremium", default=[])
            coverages = coverages if type(coverages) == list else [coverages]

            for coverage in coverages:
                pak_coverages = []

                if "Coverage" in coverage:
                    for pak_coverage in coverage["Coverage"]:
                        limit = qs.value(pak_coverage, "Limit1", default=-1, data_type=float, level="none")
                        if limit == -1:
                            limit = qs.value(pak_coverage, "Limit2", default=-1, data_type=float, level="none")

                        pak_coverages.append({
                            "code": qs.value(pak_coverage, "CSIOCode", level="info"),
                            "description": qs.value(pak_coverage, "Description", default="", level="none"),
                            "limit": float(limit),
                            "deductible": float(
                                qs.value(pak_coverage, "Deductible", default=-1, data_type=float, level="none")),
                            })

                limit = qs.value(coverage, "Limit1", default=-1, data_type=float, level="none")
                if limit == -1:
                    limit = qs.value(coverage, "Limit2", default=-1, data_type=float, level="none")

                cov = {
                    "item_id": orig_id,
                    "code": qs.value(coverage, "CarrierCovCode", level="info"),
                    "description": qs.value(coverage, "Description", default="", level="none"),
                    "limit": float(limit),
                    "deductible": float(qs.value(coverage, "Deductible", default=-1, data_type=float, level="none")),
                    "premium": float(
                        qs.value(coverage, "PremiumWithDecimal", default=-1, data_type=float, level="none")),
                    }

                if pak_coverages is not None and len(pak_coverages) > 0:
                    cov["coverages"] = pak_coverages

                qs.append_coverage(cov)

    def _add_all_discounts_from_cq(self, qs, m_node, orig_id):
        if m_node is not None:
            discounts = qs.value(m_node, "Discount", default=[])
            discounts = discounts if type(discounts) == list else [discounts]

            for discount in discounts:
                qs.append_discount({
                    "item_id": orig_id,
                    "code": qs.value(discount, "DiscountCode", level="info"),
                    "description": qs.value(discount, "Description", default="", level="none"),
                    "amount": qs.value(discount, "Amount", default=-1, data_type=float, level="none"),
                    })
