import os
from abc import ABC

import xmltodict
from suds.client import Client
from suds.sax.text import Raw

from api_quoting.quote_provider import QuoteProvider
from lib_common import constants
from lib_persistence import policy, settings
from lib_quote.card_to_cq_hab import CardToCQHab
from lib_quote.quote_result import QuoteStatus
from lib_quote.quote_support import QuoteSupport

import xml.dom.minidom

class RateBridgeHabQuoteProvider(QuoteProvider, ABC):
    def __init__(self, config, quick_quote):
        QuoteProvider.__init__(self, config, quick_quote)

    async def quote(self, request_json, province_code, lob):
        qps = QuoteSupport()
        qps.provider = "RateBridgeHabQuoteProvider"

        # We need to create CQ compliant IDs
        id_counter = 1
        id_map = {}

        for item in request_json.values():
            cq_id = f"0000000{id_counter}"
            item["cqID"] = cq_id
            id_counter += 1
            id_map[cq_id] = item["id"]

            if qps.value(item, "type") == "property":
                # Check the package requested (Recommended vs Economical).
                quote_type = qps.field(item, "quote_coverage_type", default="recommended", level="info")
                id_map["quoteType"] = quote_type

        body = CardToCQHab(self._config, self._quick_quote, qps).to_cq_json(province_code.upper(), request_json)

        username = qps.value(self._config, "username")
        password = qps.value(self._config, "password")

        wsdl = qps.value(self._config, "wsdl")
        wsdl_url = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "etc", f"wsdl/{wsdl}")
        wsdl_url = "file://" + wsdl_url

        client = Client(wsdl_url)
        client.set_options(location=qps.value(self._config, "url"))
        # client.set_options(location="http://127.0.0.1:8082/RateBridge/Version1.asmx")

        version = client.factory.create("FortusVersionType")
        version.MajorVersion = 5
        version.MinorVersion = 9
        version.Build = 4

        caller = client.factory.create("Caller")
        caller.Name = "brunvalley.com"
        caller.Version = "1.0.0.126"
        caller.Product = "ThirdParty_Web"
        caller.LineOfBusiness = lob.upper()
        caller.Province = province_code.upper()
        caller.Language = "EN"
        caller.FortusVersion = version

        creds = client.factory.create("CQCredentials")
        creds.UserName = username
        creds.Password = password

        client.set_options(soapheaders=(creds, caller), retxml=True)
        quote_request_xml = xmltodict.unparse(body, full_document=False, pretty=True)

        result = client.service.Rate(
            Raw(body["QuoteGUID"]),
            Raw(body["QuoteIterationGUID"]),
            Raw(xmltodict.unparse(body["xmlparam_FortusTransaction"], full_document=False)),
            Raw(xmltodict.unparse(body["xmlparam_ExtendedInput"], full_document=False)),
            Raw(xmltodict.unparse(body["xmlparam_CarrierInfo"], full_document=False)),
        )

        if result is None:
            qps.status = QuoteStatus.FAILED
            qps.messages = qps.quote_log.get_messages()
            qps.error("Response from RateBridge was empty")
            return

        quote_response_xml = result
        result = xmltodict.parse(quote_response_xml)
        self._quote_result["quote_request_xml"] = quote_request_xml

        temp = xml.dom.minidom.parseString(quote_response_xml.decode("utf-8"))
        new_xml = temp.toprettyxml()
        self._quote_result["quote_response_xml"] = new_xml

        result = result["soap:Envelope"]["soap:Body"]["RateResponse"]["RateResult"]
        cq_carriers = None

        if result is not None:
            # Try to get carriers here
            cq_carriers = qps.value(result, ["FortusOutputXML", "FortusTransaction", "Carriers"], level="info")

            if cq_carriers is None:
                # Try here if no carriers were found.
                cq_carriers = qps.value(result,
                                        ["QuoteResult", "QuoteResponse", "ReceiverResponse", "FortusTransaction",
                                         "Carriers"], level="info")

        if cq_carriers is None or len(cq_carriers) == 0:
            qps.error("No carriers found in quote response")
            qps.status = QuoteStatus.FAILED
            qps.messages = qps.quote_log.get_messages()
            self._quote_result.update(qps.quote_result)
            return

        for carrier in cq_carriers:
            qs = QuoteSupport()
            qs.insurer = carrier
            qs.insurer_description = policy.map_company_code(carrier)[0]
            self._assemble_response_from_cq(qs, carrier, cq_carriers[carrier], id_map)
            qps.append_quote(qs.quote_result)

        qps.messages = qps.quote_log.get_messages()
        qps.status = QuoteStatus.SUCCESS
        self._quote_result.update(qps.quote_result)

    def _assemble_response_from_cq(self, qs, carrier, carrier_result, id_map):
        quote_info = qs.value(carrier_result, ["CodeNames", "Property", "QuoteInfo"])

        if quote_info is None:
            qs.status = QuoteStatus.FAILED
            qs.messages = qs.quote_log.get_messages()
            qs.error(f"Quote failed for carrier {carrier}")
            return

        cq_property = qs.value(quote_info, "Dwelling")

        if cq_property is not None:
            cq_id = qs.value(cq_property, "ID")
            orig_id = qs.value(id_map, cq_id)

            self._add_all_messages_from_cq(qs, cq_property)
            self._add_all_coverages_from_cq(qs, cq_property, orig_id)
            self._add_all_discounts_from_cq(qs, cq_property, orig_id)
        else:
            self._add_all_messages_from_cq(qs, quote_info)

        # Fill in the rest of the response.
        # TODO: For multiple properties this will return multiple quote infos.
        tp = qs.value(quote_info, ["PolicyTotal", "FinalPremium"], default=None, level="error")
        qs.total_premium = float(tp) if tp is not None else None

        if qs.total_premium is None or qs.total_premium <= 0:
            qs.status = QuoteStatus.FAILED
        else:
            qs.status = QuoteStatus.SUCCESS

        qs.messages = qs.quote_log.get_messages()

    def _add_all_messages_from_cq(self, qs, m_node):
        if m_node is not None:
            messages = qs.value(m_node, "Message", default=[])
            messages = [messages] if len(messages) != 0 and type(messages) is str else messages

            for message in messages:
                if type(message) != tuple:
                    severity = int(qs.value(message, "Severity", default="100"))
                    level = "info" if severity == 100 else "error"
                    message_text = qs.value(message, "MessageText", level="warn")
                    message_text = message_text if message_text is not None else "Message text is empty"
                    qs.log(level, message_text + " (severity=" + str(severity) + ")")
                else:
                    if message[0] == "MessageText":
                        level = "info"
                        message_text = message[1]
                        qs.log(level, message_text)

    def _add_all_coverages_from_cq(self, qs, m_node, orig_id):
        if m_node is not None:
            coverages = qs.value(m_node, "StdCov", default=[], level="none")
            coverages = coverages if type(coverages) == list else [coverages]

            for coverage in coverages:
                qs.append_coverage(
                    {
                        "item_id": orig_id,
                        "code": qs.value(coverage, "CoverageType", level="info"),
                        "description": qs.value(coverage, "Description", level="none"),
                        "limit": qs.value(coverage, "OutCoverage", default=-1, data_type=float, level="none"),
                        "deductible": qs.value(coverage, "OutDeduct", default=-1, data_type=float, level="none"),
                        "premium": qs.value(coverage, "Premium", default=-1, data_type=float, level="none"),
                    }
                )

            coverages = qs.value(m_node, "ExtCov", default=[], level="none")
            coverages = coverages if type(coverages) == list else [coverages]

            for coverage in coverages:
                qs.append_coverage(
                    {
                        "item_id": orig_id,
                        "code": qs.value(coverage, "CoverageType", level="info"),
                        "description": qs.value(coverage, "Description", level="none"),
                        "limit": qs.value(coverage, "OutCoverage", default=-1, data_type=float, level="none"),
                        "deductible": qs.value(coverage, "OutDeduct", default=-1, data_type=float, level="none"),
                        "premium": qs.value(coverage, "Premium", default=-1, data_type=float, level="none"),
                    }
                )

    def _add_all_discounts_from_cq(self, qs, m_node, orig_id):
        if m_node is not None:
            discounts = qs.value(m_node, "Discount", default=[], level="none")
            discounts = discounts if type(discounts) == list else [discounts]

            for discount in discounts:
                qs.append_discount(
                    {
                        "item_id": orig_id,
                        "code": qs.value(discount, "DiscountType", level="info"),
                        "description": qs.value(discount, "Description", level="none"),
                        "amount": qs.value(discount, "Premium", level="info", data_type=float),
                    }
                )
