import math


class MappingUtils(object):
    """
    This utility class holds all the mapping functions.
    TODO - Fix the naming of a lot of the functions orignally created here
    Naming Convention
    OrigFormat_To_NewFormat_FieldName
    """

    @staticmethod
    def long_form_to_short_form_province(prov):
        # trim to remove whitespace
        prov = prov.trim()
        prov = prov.upper()

        if prov == "ONTARIO":
            prov = "ON"
        elif prov == "ALBERTA":
            prov = "AB"
        elif prov == "BRITISH COLUMBIA":
            prov = "BC"
        elif prov == "MANITOBA":
            prov = "MB"
        elif prov == "NEW BRUNSWICK":
            prov = "NB"
        elif prov == "NEWFOUNDLAND AND LABRADOR":
            prov = "NF"
        elif prov == "NOVA SCOTIA":
            prov = "NS"
        elif prov == "NORTHWEST TERRITORIES":
            prov = "NT"
        elif prov == "NUNAVUT":
            prov = "NU"
        elif prov == "PRINCE EDWARD ISLAND":
            prov = "PE"
        elif prov == "SASKATCHEWAN":
            prov = "SK"
        elif prov == "YUKON":
            prov = "YT"

        return prov

    @staticmethod
    def snap_to_cq_claim_type_hab(claim_type):
        return_value = "OTHER"

        if claim_type == "502":
            return_value = "BI"
        elif claim_type == "503":
            return_value = "BURG"
        elif claim_type == "505":
            return_value = "PD"
        elif claim_type == "506":
            return_value = "PD"
        elif claim_type == "534":
            return_value = "CREDITCARD"
        elif claim_type == "521":
            return_value = "ERQK"
        elif claim_type == "526":
            return_value = "EXPLOSION"
        elif claim_type == "547":
            return_value = "FIRE"
        elif claim_type == "549":
            return_value = "FOOD"
        elif claim_type == "564":
            return_value = "WIND"
        elif claim_type == "571":
            return_value = "PD"
        elif claim_type == "588":
            return_value = "PD"
        elif claim_type == "591":
            return_value = "SEWER"
        elif claim_type == "594":
            return_value = "FIRE"
        elif claim_type == "595":
            return_value = "OTHER"
        elif claim_type == "611":
            return_value = "VAND"
        elif claim_type == "627":
            return_value = "WATERDAM"
        elif claim_type == "641":
            return_value = "WIND"
        elif claim_type == "999":
            return_value = "OTHER"

        return return_value

    @staticmethod
    def property_type(prop_type):
        """
        Converts an EDI value to a Snapably value for Property Type
        #
        @param:*} claim_type
        @returns
        """
        return_value = prop_type

        if prop_type == "AP":
            return_value = "Apartment"
        elif prop_type == "AC":
            return_value = "Apartment"
        elif prop_type == "AB":
            return_value = "Apartment"
        elif prop_type == "AM":
            return_value = "Apartment"
        elif prop_type == "DT":
            return_value = "House"
        elif prop_type == "DW":
            return_value = "House"
        elif prop_type == "DX":
            return_value = "Duplex"
        elif prop_type == "RE":
            return_value = "Row/Townhouse"
        elif prop_type == "RH":
            return_value = "Row/Townhouse"
        elif prop_type == "RI":
            return_value = "Row/Townhouse"
        elif prop_type == "SD":
            return_value = "Row/Townhouse"
        elif prop_type == "TH":
            return_value = "Row/Townhouse"
        elif prop_type == "TX":
            return_value = "Triplex"

        return return_value

    @staticmethod
    def snap_to_cq_claim_type_auto(claim_type):
        """
        Converts the Snap Value into a CQ ticket type value
        @param:*} claim_type - The Snapably Value for a claim type
        """
        return_value = ""

        if claim_type == "1":
            return_value = "Collision"
        elif claim_type == "3":
            return_value = "Collision"
        elif claim_type == "4":
            return_value = "Collision"
        elif claim_type == "5":
            return_value = "Collision"
        elif claim_type == "6":
            return_value = "Collision"
        elif claim_type == "7":
            return_value = "Collision"
        elif claim_type == "8":
            return_value = "Other non-responsible Comp/SP"
        elif claim_type == "16":
            return_value = "Fire"
        elif claim_type == "17":
            return_value = "Other non-responsible Comp/SP"
        elif claim_type == "18":
            return_value = "Glass age"
        elif claim_type == "19":
            return_value = "Liability & Collision"
        elif claim_type == "20":
            return_value = "Liability & Collision"
        elif claim_type == "21":
            return_value = "Other non-responsible Comp/SP"
        elif claim_type == "22":
            return_value = "Collision"
        elif claim_type == "31":
            return_value = "Theft"
        elif claim_type == "34":
            return_value = "Vandalism"
        elif claim_type == "36":
            return_value = "Hail"

        return return_value

    @staticmethod
    def snap_to_cq_incident_type(ticket_type):
        """
        Converts the Snap Value into a CQ ticket type value
        @param:*} ticket_type - The Snapably Value for a ticket type
        """

        return_code = ""
        return_type = ""

        if ticket_type == "Driving without insurance":
            return_type = "Ins Lapse"
            return_code = "DWOI"

        return [return_code, return_type]

    @staticmethod
    def snap_to_cq_conviction_type(ticket_type):
        """
        Converts the Snap Value into a CQ ticket type value
        @param:*} ticket_type - The Snapably Value for a ticket type
        """

        return_code = ""
        return_severity = ""

        if ticket_type == "BACK":
            return_code = "FTS"
            return_severity = "Minor"
        elif ticket_type == "BIKE":
            return_code = "MINOR"
            return_severity = "Minor"
        elif ticket_type == "CPV":
            return_code = "CPV"
            return_severity = "Minor"
        elif ticket_type == "FCIC":
            return_code = "FCIC"
            return_severity = "Minor"
        elif ticket_type == "FTC":
            return_code = "FTC"
            return_severity = "Minor"
        elif ticket_type == "FTS":
            return_code = "FTS"
            return_severity = "Minor"
        elif ticket_type == "MINOR":
            return_code = "MINOR"
            return_severity = "Minor"
        elif ticket_type == "SP":
            return_code = "SP"
            return_severity = "Minor"
        elif ticket_type == "SS":
            return_code = "SS"
            return_severity = "Minor"
        elif ticket_type == "SB":
            return_code = "SB"
            return_severity = "Minor"
        elif ticket_type == "CD":
            return_code = "CD"
            return_severity = "Major"
        elif ticket_type == "CN":
            return_code = "CN"
            return_severity = "Criminal"
        elif ticket_type == "DD":
            return_code = "DD"
            return_severity = "Criminal"
        elif ticket_type == "DUS":
            return_code = "DUS"
            return_severity = "Criminal"
        elif ticket_type == "FPBT":
            return_code = "ALC"
            return_severity = "Criminal"
        elif ticket_type == "FPEI":
            return_code = "FPEI"
            return_severity = "Minor"
        elif ticket_type == "FTR":
            return_code = "FTR"
            return_severity = "Criminal"
        elif ticket_type == "FTS":
            return_code = "FTS"
            return_severity = "Minor"
        elif ticket_type == "HL":
            return_code = "HL"
            return_severity = "Minor"
        elif ticket_type == "ILC":
            return_code = "ILC"
            return_severity = "Minor"
        elif ticket_type == "MAJOR":
            return_code = "MAJOR"
            return_severity = "Major"
        elif ticket_type == "PSB":
            return_code = "PSB"
            return_severity = "Major"
        elif ticket_type == "RAC":
            return_code = "RAC"
            return_severity = "Major"

        return [return_code, return_severity]

    @staticmethod
    def snap_to_ps_dwelling_type(dwelling_type):
        """
        Converts the Snap Value into a Powersoft value
        @param:*} dwellingType - The Snapably Value
        """
        return_value = ""

        if dwelling_type == "House":
            return_value = "DET"
        elif dwelling_type == "Semi-Detached House":
            return_value = "SDT"
        elif dwelling_type == "Condo":
            pass
        elif dwelling_type == "Row/Townhouse":
            return_value = "IRW"
        elif dwelling_type == "Duplex":
            return_value = "DPX"
        elif dwelling_type == "Triplex":
            return_value = "TPX"
        elif dwelling_type == "Multi-family":
            pass

        return return_value

    @staticmethod
    def snap_to_ps_exterior_wall(exterior_wall):
        """
        Converts the Snap Value into a Powersoft value
        @param:*} exterior_wall - The Snapably Value
        """
        return_value = ""

        if exterior_wall == "Brick":
            return_value = "SB"
        elif exterior_wall == "Vinyl Siding":
            return_value = "VF"
        elif exterior_wall == "Vinyl":
            return_value = "VF"
        elif exterior_wall == "Brick Veneer":
            return_value = "BF"
        elif exterior_wall == "Veneer":
            return_value = "BF"
        elif exterior_wall == "Concrete":
            return_value = "CB"
        elif exterior_wall == "Fiber Cement":
            return_value = "CF"
        elif exterior_wall == "Logs":
            return_value = "SL"
        elif exterior_wall == "Stone":
            return_value = "SS"
        elif exterior_wall == "Stucco":
            return_value = "SF"
        elif exterior_wall == "Wood Siding":
            return_value = "WF"

        return return_value

    @staticmethod
    def snap_to_ps_num_stories(exterior_wall):
        """
        Converts the Snap Value into a Powersoft value
        @param:*} exterior_wall - The Snapably Value
        """
        return_value = ""

        if exterior_wall == "1":
            return_value = "01"
        elif exterior_wall == "1.5":
            return_value = "02"
        elif exterior_wall == "2":
            return_value = "03"
        elif exterior_wall == "2.5":
            return_value = "04"
        elif exterior_wall == "3":
            return_value = "05"
        elif exterior_wall == "BiLevel":
            return_value = "02"
        elif exterior_wall == "TriLevel":
            return_value = "03"

        return return_value

    @staticmethod
    def snap_to_ps_roof_type(roof_type):
        """
        Converts the Snap Value into a Powersoft value
        @param:*} roof_type - The Snapably Value
        """
        return_value = ""

        if roof_type == "Asphalt":
            return_value = "AT"
        elif roof_type == "Clay Tile":
            return_value = "CT"
        elif roof_type == "Concrete":
            return_value = "CL"
        elif roof_type == "Copper":
            return_value = "MP"
        elif roof_type == "Rubber":
            return_value = "RT"
        elif roof_type == "Slate Tile":
            return_value = "CT"
        elif roof_type == "Steel":
            return_value = "MP"
        elif roof_type == "Tar and Gravel":
            return_value = "TG"
        elif roof_type == "Tin":
            return_value = "MP"
        elif roof_type == "Wood Shingles":
            return_value = "CS"

        return return_value

    @staticmethod
    def snap_to_ps_claim_type(claim_type):
        """
        Converts the Snap Value into a Powersoft value
        @param:*} claim_type - The Snapably Value
        """
        return_value = ""

        if claim_type == "Personal Property Claim":
            return_value = "ARPP"
        elif claim_type == "Sewer Backup Claim":
            return_value = "SEWER"
        elif claim_type == "Liability Claim":
            return_value = "PL"
        elif claim_type == "Fire Claim":
            return_value = "FIRE"
        elif claim_type == "Wind/Hail Claim":
            return_value = "WIND"
        elif claim_type == "Other Type of Claim":
            return_value = "BLDG"
        elif claim_type == "Water Claim - Ice damming":
            return_value = "RWDAM"
        elif claim_type == "Water Claim - Weight of snow":
            return_value = "SNOW"
        elif claim_type == "Water Claim - Other":
            return_value = "WATER"

        return return_value

    @staticmethod
    def edi_to_snap_status(edi_status):
        """
        Converts the EDI policy status code into a readable format
        @param:*} edi_status - The policy status in EDI format
        """
        return_string = "Other"

        if edi_status is not None:
            if edi_status == "NBS":
                return_string = "New Business"
            elif edi_status == "PCH":
                return_string = "Policy Change"
            elif edi_status == "RII":
                return_string = "Reissue Request"
            elif edi_status == "RWL":
                return_string = "Renewal"
            elif edi_status == "XLN":
                return_string = "Cancellation"
            elif edi_status == "RWC":
                return_string = "Renewal Change"

        return return_string

    @staticmethod
    def is_numeric(num):
        """checks if num is a number"""
        if isinstance(num, str):
            return False  # we only process strings!

        # ...and ensure strings of whitespace fail
        # use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
        return not math.isnan(num) and not math.isnan(float(num))

    @staticmethod
    def snap_to_cq_nb_license_class(lic_class):
        """Maps Snapably values for CQ licence class for New Brunswick only
        @lic_class - The original licence class from Snapably
        """
        return_val = lic_class

        if lic_class is not None:
            if lic_class == "5":
                return_val = "G"
            elif lic_class == "05":
                return_val = "G"
            elif lic_class == "5L":
                return_val = "G2"
            elif lic_class == "5R":
                return_val = "G"
            elif lic_class == "9":
                return_val = "M"
            elif lic_class == "09":
                return_val = "M"
            elif lic_class == "7":
                return_val = "G1"
            elif lic_class == "07":
                return_val = "G1"
            elif lic_class == "6":
                return_val = "M"
            elif lic_class == "06":
                return_val = "M"

        return return_val

    @staticmethod
    def snap_to_cq_coverage(dwell_type, value):
        """
        this function should map the coverage required based on the value of the property
        @dwell_type - The type of dwelling
        @value - the value of the dwelling
        """
        if value is not None:
            value = ""

        return value

    @staticmethod
    def snap_to_cq_protection_class(fire_hall_distance, hydrant_distance):
        # If either field is missing, return Unprotected
        if fire_hall_distance is None or hydrant_distance is None:
            return "U"

        f_dist = float(fire_hall_distance)
        h_dist = float(hydrant_distance)

        # TODO these values are actually carrier specific.
        # We're making some tight boundaries, but this should be reviewed.
        if f_dist < 10 and h_dist <= 300:
            # Protected
            return "P"
        elif f_dist < 20 and h_dist < 600:
            # Semi protected
            return "S"
        else:
            # Unprotected
            return "U"

    @staticmethod
    def snap_to_cq_hydrant_distance(hydrant):
        if hydrant is None or hydrant == "None":
            return "0"
        else:
            return hydrant

    @staticmethod
    def snap_to_cq_pool_type(pool):
        return_string = "None"

        if pool is not None:
            if pool == "None":
                return_string = ""
            elif pool == "Above Ground":
                return_string = "AG_F"
            elif pool == "In-Ground":
                return_string = "IG_F"

        return return_string

    @staticmethod
    def snap_to_cq_garage_type(garage):
        return_string = "0"

        if garage is not None:
            if garage == "None":
                return_string = "0"
            elif garage == "Attached":
                return_string = "4"
            elif garage == "Detached":
                return_string = "6"
            elif garage == "Carport":
                return_string = "3"
            elif garage == "Built-in":
                return_string = "1"

        return return_string

    @staticmethod
    def snap_to_cq_heating_type(heat_type):
        return_string = "CENTRAL FURNACE - GAS"

        if heat_type is not None:
            if heat_type == "None":
                return_string = "NONE"
            elif heat_type == "Gas":
                return_string = "CENTRAL FURNACE - GAS"
            elif heat_type == "Propane":
                return_string = "CENTRAL FURNACE - PROPANE"
            elif heat_type == "Electric":
                return_string = "ELECTRIC"
            elif heat_type == "Wood":
                return_string = "WOOD BURNING STOVE"
            elif heat_type == "Pellets":
                return_string = "SF_P"
            elif heat_type == "Solar":
                return_string = "SOLAR"
            elif heat_type == "Radiant":
                return_string = "SPACE HEATER - ELECTRIC"
            elif heat_type == "Oil":
                return_string = "CENTRAL FURNACE - OIL"
            elif heat_type == "Other":
                return_string = "OTHER"

        return return_string

    @staticmethod
    def snap_to_cq_construction(ext_code):
        """
        We attempt to guess the construction of the building based on the exterior finish
        #
        @param:*} ext_code - The exterior finish code from Snapably
        @returns - A CQ code
        """
        return_string = "VNYL"

        if ext_code is not None:
            if ext_code == "Brick Veneer":
                return_string = "FRAME"
            elif ext_code == "Brick":
                return_string = "FRAME"
            elif ext_code == "Concrete":
                return_string = "CBLOCK"
            elif ext_code == "Logs":
                return_string = "LOG"
            elif ext_code == "Stone":
                return_string = "FRAME"
            elif ext_code == "Stucco":
                return_string = "FRAME"
            elif ext_code == "Vinyl":
                return_string = "FRAME"
            elif ext_code == "Wood":
                return_string = "FRAME"
            elif ext_code == "Wood Siding":
                return_string = "FRAME"

        return return_string

    @staticmethod
    def snap_to_cq_exterior_finish(ext_code):
        """
        Mapping to CQ exterior finish
        #
        @param:*} ext_code - The exterior finish code from Snapably
        @returns - A CQ code
        """
        return_string = "VNYL"

        if ext_code is not None:
            if ext_code == "Brick Veneer":
                return_string = "BRVN"
            elif ext_code == "Brick":
                return_string = "BRIC"
            elif ext_code == "Concrete":
                return_string = "CONC"
            elif ext_code == "Logs":
                return_string = "LGSD"
            elif ext_code == "Stone":
                return_string = "STON"
            elif ext_code == "Stucco":
                return_string = "STUCCO"
            elif ext_code == "Vinyl":
                return_string = "VNYL"
            elif ext_code == "Wood":
                return_string = "WOOD"
            elif ext_code == "Wood Siding":
                return_string = "WOOD"

        return return_string

    @staticmethod
    def snap_to_cq_ownership(owner):
        if owner == "Own":
            return "Y"
        else:
            return "N"

    @staticmethod
    def snap_to_cq_structure(struct):
        return_string = "House"

        if struct is not None:
            if struct == "House":
                return_string = "DETACHED"
            elif struct == "Duplex":
                return_string = "SEMI DETACHED"
            elif struct == "Triplex":
                return_string = "TRIPLEX"
            elif struct == "Row/Townhouse":
                return_string = "TOWNHOUSE"

        return return_string

    @staticmethod
    def snap_to_cq_roof_type(roof_type):
        return_string = "ASPHALT SHINGLES"

        if roof_type is not None:
            if roof_type == "Asphalt":
                return_string = "ASPHALT SHINGLES"
            elif roof_type == "Clay Tile":
                return_string = "CLAY TILE"
            elif roof_type == "Concrete":
                return_string = "CONCRETE TILE"
            elif roof_type == "Copper":
                return_string = "METAL TILE"
            elif roof_type == "Slate Tile":
                return_string = "SLATE TILE"
            elif roof_type == "Steel":
                return_string = "CORRUGATED STEEL"
            elif roof_type == "Tar and Gravel":
                return_string = "TAR AND GRAVEL"
            elif roof_type == "Wood Shingles":
                return_string = "WOOD SHINGLES"

        return return_string

    @staticmethod
    def snap_to_cq_dwelling_type(building_type):
        return_string = "H"

        # If it's the first building we'll consider it primary
        if building_type is not None:
            if building_type == "House":
                return_string = "H"
            elif building_type == "Duplex":
                return_string = "H"
            elif building_type == "Triplex":
                return_string = "H"
            elif building_type == "Row/Townhouse":
                return_string = "H"
            elif building_type == "Semi/Duplex":
                return_string = "H"
            elif building_type == "Apartment":
                return_string = "C"
            elif building_type == "Condo":
                return_string = "C"

        return return_string

    @staticmethod
    def pool_cd(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = None

        if edi_code is not None:
            if edi_code == "1":
                return_string = "In-Ground"
            elif edi_code == "2":
                return_string = "In-Ground"
            elif edi_code == "3":
                return_string = "In-Ground"
            elif edi_code == "4":
                return_string = "Above Ground"
            elif edi_code == "9":
                return_string = None

        return return_string

    @staticmethod
    def hydrant_distance_cd(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = None

        if edi_code is not None:
            if edi_code == "1":
                return_string = "150"
            elif edi_code == "2":
                return_string = "300"
            elif edi_code == "3":
                return_string = "500"
            elif edi_code == "0":
                return_string = "None"

        return return_string

    @staticmethod
    def snap_to_ps_hydrant_distance(distance_to_hydrant):
        """
        Converts the EDI policy status code into a readable format
        @param:*} edi_status - The policy status in EDI format
        """
        return_value = "OVER 300"
        distance_int = int(distance_to_hydrant) if str(distance_to_hydrant).isdigit() else -1

        if distance_int == -1:
            return return_value
        elif 0 < distance_int <= 150:
            return_value = "150"
        elif 150 < distance_int < 300:
            return_value = "300"

        return return_value

    @staticmethod
    def snap_to_ps_heating_type(heating_type):
        """
        Converts snapably heating type into a powersoft value
        @param:*} heatingType - The heatingType in Snap Json format
        """
        return_primary_heat_value = ""
        return_primary_fuel_value = ""

        if heating_type == "Natural Gas":
            return_primary_heat_value = "C"
            return_primary_fuel_value = "GAS"
        elif heating_type == "Propane":
            return_primary_heat_value = "C"
            return_primary_fuel_value = "LP"
        elif heating_type == "Electric":
            return_primary_heat_value = "C"
            return_primary_fuel_value = "ELECTRIC"
        elif heating_type == "Solid Fuel":
            return_primary_heat_value = "SF"
        elif heating_type == "Wood":
            return_primary_heat_value = "WS"
        elif heating_type == "Wood Pellets":
            return_primary_heat_value = "WS"
        elif heating_type == "Solar":
            return_primary_heat_value = "S"
        elif heating_type == "Radiant Heat":
            return_primary_heat_value = "R"
        elif heating_type == "Oil":
            return_primary_heat_value = "C"
            return_primary_fuel_value = "OIL"
        elif heating_type == "Other":
            return_primary_heat_value = "O"

        return [return_primary_heat_value, return_primary_fuel_value]

    @staticmethod
    def snap_to_ps_fuel_type(fuel_type):
        """
        Converts the EDI date into a usable date (YYYYMMDD)
        @param:*} edi_date - The date in EDI format
        """
        return_value = ""

        if fuel_type == "gasoline":
            return_value = "G"
        elif fuel_type == "diesel":
            return_value = "D"
        elif fuel_type == "flex":
            return_value = "H"
        elif fuel_type == "electric":
            return_value = "E"

        return return_value

    @staticmethod
    def construction_cd(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = None

        if edi_code is not None:
            if edi_code == "0":
                return_string = ""
            elif edi_code == "1":
                return_string = "Logs"
            elif edi_code == "2":
                return_string = "Vinyl"
            elif edi_code == "3":
                return_string = "Vinyl"
            elif edi_code == "5":
                return_string = "Wood Siding"
            elif edi_code == "6":
                return_string = "Wood Siding"
            elif edi_code == "B":
                return_string = "Brick"
            elif edi_code == "D":
                return_string = "Concrete"
            elif edi_code == "F":
                return_string = "Wood Siding"
            elif edi_code == "I":
                return_string = "Vinyl"
            elif edi_code == "N":
                return_string = "Stone"
            elif edi_code == "O":
                return_string = "Stucco"
            elif edi_code == "W":
                return_string = "Brick Veneer"
            elif edi_code == "V":
                return_string = "Brick Veneer"

        return return_string

    @staticmethod
    def edi_to_snap_heat_type_cd(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = ""

        if edi_code is not None:
            if edi_code == "1":
                return_string = "Other"
            elif edi_code == "2":
                return_string = "Wood"
            elif edi_code == "3":
                return_string = "Wood"
            elif edi_code == "4":
                return_string = "Radiant"
            elif edi_code == "5":
                return_string = "Pellets"
            elif edi_code == "6":
                return_string = "Solar"
            elif edi_code == "8":
                return_string = "Radiant"
            elif edi_code == "9":
                return_string = "Other"
            elif edi_code == "A":
                return_string = "Wood"
            elif edi_code == "B":
                return_string = "Wood"
            elif edi_code == "C":
                return_string = "Other"
            elif edi_code == "D":
                return_string = "Gas"
            elif edi_code == "E":
                return_string = "Electric"
            elif edi_code == "F":
                return_string = "Gas"
            elif edi_code == "G":
                return_string = "Other"
            elif edi_code == "H":
                return_string = "Other"
            elif edi_code == "I":
                return_string = "Wood"
            elif edi_code == "J":
                return_string = "Wood"
            elif edi_code == "K":
                return_string = "Electric"
            elif edi_code == "L":
                return_string = "Radiant"
            elif edi_code == "M":
                return_string = "Other"
            elif edi_code == "N":
                return_string = "None"
            elif edi_code == "O":
                return_string = "Other"
            elif edi_code == "P":
                return_string = "Other"
            elif edi_code == "Q":
                return_string = "Gas"
            elif edi_code == "R":
                return_string = "Wood"
            elif edi_code == "S":
                return_string = "Electric"
            elif edi_code == "T":
                return_string = "Wood"
            elif edi_code == "U":
                return_string = "Wood"
            elif edi_code == "V":
                return_string = "Wood"
            elif edi_code == "W":
                return_string = "Wood"
            elif edi_code == "X":
                return_string = "Wood"
            elif edi_code == "Y":
                return_string = "Wood"
            elif edi_code == "Z":
                return_string = "Other"

        return return_string

    @staticmethod
    def fire_station_distance(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = edi_code

        if edi_code is not None:
            if edi_code == "A":
                return_string = "1"
            elif edi_code == "B":
                return_string = "2"
            elif edi_code == "C":
                return_string = "3"
            elif edi_code == "D":
                return_string = "4"
            elif edi_code == "E":
                return_string = "5"
            elif edi_code == "F":
                return_string = "6"
            elif edi_code == "G":
                return_string = "7"
            elif edi_code == "H":
                return_string = "8"
            elif edi_code == "I":
                return_string = "9"
            elif edi_code == "I":
                return_string = "10"
            elif edi_code == "K":
                return_string = "11"
            elif edi_code == "L":
                return_string = "12"
            elif edi_code == "M":
                return_string = "13"
            elif edi_code == "N":
                return_string = "14"
            elif edi_code == "O":
                return_string = "15"
            elif edi_code == "P":
                return_string = "16"
            elif edi_code == "Q":
                return_string = "17"
            elif edi_code == "R":
                return_string = "18"
            elif edi_code == "S":
                return_string = "19"
            elif edi_code == "T":
                return_string = "20"
            elif edi_code == "U":
                return_string = "21"
            elif edi_code == "V":
                return_string = "22"
            elif edi_code == "W":
                return_string = "23"
            elif edi_code == "X":
                return_string = "24"
            elif edi_code == "Y":
                return_string = "25"
            elif edi_code == "Z":
                return_string = "26"

        return return_string

    @staticmethod
    def fuel_type_cd(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = ""

        if edi_code is not None:
            if edi_code == "A":
                return_string = "Oil"
            elif edi_code == "B":
                return_string = "Other"
            elif edi_code == "C":
                return_string = "Other"
            elif edi_code == "D":
                return_string = "Other"
            elif edi_code == "E":
                return_string = "Electric"
            elif edi_code == "F":
                return_string = "Other"
            elif edi_code == "G":
                return_string = "Gas"
            elif edi_code == "H":
                return_string = "Oil"
            elif edi_code == "I":
                return_string = "Oil"
            elif edi_code == "K":
                return_string = "Gas"
            elif edi_code == "L":
                return_string = "Gas"
            elif edi_code == "M":
                return_string = "Other"
            elif edi_code == "N":
                return_string = "Gas"
            elif edi_code == "O":
                return_string = "Other"
            elif edi_code == "P":
                return_string = "Propane"
            elif edi_code == "R":
                return_string = "Solar"
            elif edi_code == "S":
                return_string = "Wood"
            elif edi_code == "T":
                return_string = "Pellets"
            elif edi_code == "U":
                return_string = "Wood"
            elif edi_code == "V":
                return_string = "Other"
            elif edi_code == "W":
                return_string = "Wood"
            elif edi_code == "X":
                return_string = "Electric"
            elif edi_code == "Y":
                return_string = "Electric"
            elif edi_code == "Z":
                return_string = "Other"

        return return_string

    @staticmethod
    def roof_cd(edi_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @edi_code - The code from EDI.
        @returns - valid Snapably value
        """
        return_string = ""

        if edi_code is not None:
            if edi_code == "A":
                return_string = "Asphalt"
            elif edi_code == "B":
                return_string = "Steel"
            elif edi_code == "C":
                return_string = "Clay Tile"
            elif edi_code == "D":
                return_string = "Asphalt"
            elif edi_code == "E":
                return_string = "Asphalt"
            elif edi_code == "F":
                return_string = "Wood Shingles"
            elif edi_code == "G":
                return_string = ""
            elif edi_code == "L":
                return_string = "Steel"
            elif edi_code == "M":
                return_string = "Steel"
            elif edi_code == "N":
                return_string = "Concrete"
            elif edi_code == "O":
                return_string = ""
            elif edi_code == "P":
                return_string = ""
            elif edi_code == "R":
                return_string = "Asphalt"
            elif edi_code == "S":
                return_string = "Slate Tile"
            elif edi_code == "T":
                return_string = "Tar and Gravel"
            elif edi_code == "U":
                return_string = ""
            elif edi_code == "W":
                return_string = "Wood Shingles"
            elif edi_code == "X":
                return_string = "Wood Shingles"
            elif edi_code == "7":
                return_string = ""
            elif edi_code == "8":
                return_string = ""
            elif edi_code == "9":
                return_string = ""

        return return_string

    @staticmethod
    def foundation_type_cd(edi_value):
        """
        This function is responsible for mapping EDI values to Snap values
        @garageCode - The garage code from EDI.
        @returns - [BuildingType],[NumStories]
        """
        return_string = ""

        if edi_value is not None:
            if edi_value == "1":
                return_string = "Basement"
            elif edi_value == "2":
                return_string = "Basement"
            elif edi_value == "3":
                return_string = "Pier/Post"
            elif edi_value == "4":
                return_string = "Pier/Post"
            elif edi_value == "5":
                return_string = "Pier/Post"
            elif edi_value == "6":
                return_string = "Basement"
            elif edi_value == "7":
                return_string = "Crawl Space"
            elif edi_value == "8":
                return_string = "Slab"
            elif edi_value == "9":
                return_string = "Basement"
            elif edi_value == "B":
                return_string = "Basement"
            elif edi_value == "C":
                return_string = "Basement"
            elif edi_value == "P":
                return_string = "Basement"
            elif edi_value == "R":
                return_string = "Basement"
            elif edi_value == "S":
                return_string = "Basement"

        return return_string

    @staticmethod
    def garage_type_cd(garage_code):
        """
        This function is responsible for mapping EDI values to Snap values
        @garageCode - The garage code from EDI.
        @returns - [BuildingType],[NumStories]
        """
        return_string = ""

        if garage_code is not None:
            if garage_code == "0":
                return_string = "None"
            elif garage_code == "1":
                return_string = "Built-in"
            elif garage_code == "2":
                return_string = "Built-in"
            elif garage_code == "3":
                return_string = "Carport"
            elif garage_code == "4":
                return_string = "Attached"
            elif garage_code == "5":
                return_string = "Attached"
            elif garage_code == "6":
                return_string = "Detached"
            elif garage_code == "7":
                return_string = "Detached"
            elif garage_code == "8":
                return_string = "Attached"
            elif garage_code == "9":
                return_string = "Built-in"
            elif garage_code == "A":
                return_string = "Carport"
            elif garage_code == "B":
                return_string = "Detached"
            elif garage_code == "O":
                return_string = None

        return return_string

    @staticmethod
    def stories_and_building_type(num_stories):
        """
        This function is responsible for mapping EDI values for both number of stories AND building type
        @numstories - The numstories code from EDI.
        @returns - [BuildingType],[NumStories]
        """
        return_building_type = ""
        return_num_stories = ""

        if num_stories is not None:
            if num_stories == "10":
                return_building_type = "House"
                return_num_stories = "1"
            elif num_stories == "20":
                return_building_type = "House"
                return_num_stories = "2"
            elif num_stories == "15":
                return_building_type = "House"
                return_num_stories = "1.5"
            elif num_stories == "25":
                return_building_type = "House"
                return_num_stories = "2.5"
            elif num_stories == "30":
                return_building_type = "House"
                return_num_stories = "3"
            elif num_stories == "BL":
                return_building_type = "House"
                return_num_stories = "2"
            elif num_stories == "DX":
                return_building_type = "Duplex"
                return_num_stories = "2"
            elif num_stories == "HR":
                return_building_type = "Apartment"
                return_num_stories = "3"
            elif num_stories == "IR":
                return_building_type = "Row/Townhouse"
                return_num_stories = "2"
            elif num_stories == "OT":
                return_building_type = ""
                return_num_stories = ""
            elif num_stories == "RH":
                return_building_type = "Row/Townhouse"
                return_num_stories = "2"
            elif num_stories == "SD":
                return_building_type = "Duplex"
                return_num_stories = "2"
            elif num_stories == "TL":
                return_building_type = "Triplex"
                return_num_stories = "3"
            elif num_stories == "TX":
                return_building_type = "Triplex"
                return_num_stories = "3"

        return [return_building_type, return_num_stories]

    @staticmethod
    def num_garage_doors(edi_value):
        """
        This function is responsible for mapping EDI values to Snapably Values
        @edi_value - The value from EDI
        """
        return_string = None

        if edi_value is not None:
            if edi_value == "1":
                return_string = "1"
            elif edi_value == "1.5":
                return_string = "1.5"
            elif edi_value == "2":
                return_string = "2"
            elif edi_value == "3":
                return_string = "3"

        return return_string

    # @staticmethod
    # def edi_To_Snap_CompanyCode(compCode):
    #     """
    #     This function is responsible for mapping CSIO Company codes
    #     @compCode - The company code
    #     """
    #     return_string = ""
    #
    #     if basement is not None:
    #         basement = parseInt(basement)
    #
    #         if basement < 13:
    #             return_string = "0"
    #         elif basement > 13 & & basement < 37:
    #             return_string = "25"
    #         elif basement > 37 & & basement < 62:
    #             return_string = "50"
    #         elif basement > 62 & & basement < 87:
    #             return_string = "75"
    #         elif basement > 87:
    #             return_string = "100"
    #
    #     return return_string
    #

    @staticmethod
    def edi_to_snap_basement_finished(basement):
        """
        This function is responsible for mapping EDI values (0-100) to our Snapably Basement Finished Values
        @basement - The basement object from EDI
        """
        return_string = ""

        if basement is not None and len(basement) > 0:
            basement = int(basement)

            if basement < 13:
                return_string = "0"
            elif 13 < basement < 37:
                return_string = "25"
            elif 37 < basement < 62:
                return_string = "50"
            elif 62 < basement < 87:
                return_string = "75"
            elif basement > 87:
                return_string = "100"

        return return_string

    @staticmethod
    def bathrooms(full_baths, half_baths):
        """
        This function is responsible for mapping EDI values of bathrooms to Snapably Bathroom values
        @fullbaths - The number of full bathrooms
        @halfbaths - The number of half bathrooms
        """

        int_full_baths = 0
        int_half_baths = 0

        if full_baths is not None:
            int_full_baths = int(full_baths) if str(full_baths).isdigit() else 0

        if half_baths is not None:
            int_half_baths = int(half_baths) if str(half_baths).isdigit() else 0

        baths = int_full_baths + int_half_baths

        if baths > 5:
            baths = 5

        return baths

    @staticmethod
    def reverse_map_marital_status_cd(marital_status_cd):
        """
        This function is responsible for reversing the CSIO mappings, so they are legible on the PDF
        @driverObj - The driver object
        """
        return_string = ""

        if marital_status_cd is not None:
            if marital_status_cd == "csio:S":
                return_string = "Single"
            elif marital_status_cd == "csio:D":
                return_string = "Divorced"
            elif marital_status_cd == "csio:P":
                return_string = "Separated"
            elif marital_status_cd == "csio:S":
                return_string = "Single"
            elif marital_status_cd == "csio:W":
                return_string = "Widowed"

        return return_string

    @staticmethod
    def reverse_map_relationship_to_insured(csio_value_cd):
        """
        This function is responsible for reversing the CSIO mappings, so they are legible on the PDF
        @driverObj - The driver object
        """
        return_string = ""

        if csio_value_cd is not None:
            if csio_value_cd == "csio:B":
                return_string = "Brother/Sister"
            elif csio_value_cd == "csio:C":
                return_string = "Child"
            elif csio_value_cd == "csio:E":
                return_string = "Employee"
            elif csio_value_cd == "csio:I":
                return_string = "Insured"
            elif csio_value_cd == "csio:O":
                return_string = "Other"
            elif csio_value_cd == "csio:P":
                return_string = "Parent"
            elif csio_value_cd == "csio:S":
                return_string = "Spouse"
            elif csio_value_cd == "csio:T":
                return_string = "Third Party"

        return return_string

    @staticmethod
    def reverse_map_winter_tires_ind(csio_value_cd):
        """
        This function is responsible for reversing the CSIO mappings, so they are legible on the PDF
        @csioValueCd - The incoming csioValueCd
        """
        return_string = ""

        if csio_value_cd is not None:
            if csio_value_cd == "1":
                return_string = "Yes"
            elif csio_value_cd == "0":
                return_string = "No"

        return return_string

    @staticmethod
    def reverse_map_veh_use_cd(csio_value_cd):
        """
        This function is responsible for reversing the CSIO mappings, so they are legible on the PDF
        @csioValueCd - The incoming csioValueCd
        """
        return_string = ""

        if csio_value_cd is not None:
            if csio_value_cd == "csio:P":
                return_string = "Pleasure"
            elif csio_value_cd == "csio:B":
                return_string = "Business"
            elif csio_value_cd == "csio:C":
                return_string = "Commercial"
            elif csio_value_cd == "csio:9":
                return_string = "Other"

        return return_string

    @staticmethod
    def snap_to_csio_construction_cd(snapably_value_cd):
        """
        This function is responsible for mapping the ConstructionCD from Snapably -> Csio
        @snapablyValueCd - The incoming snapablyValueCd
        """
        return_string = ""

        if snapably_value_cd is not None:
            if snapably_value_cd == "Brick Veneer":
                return_string = "csio:F"
            elif snapably_value_cd == "Brick":
                return_string = "csio:B"
            elif snapably_value_cd == "Concrete":
                return_string = "csio:D"
            elif snapably_value_cd == "Fiber Cement":
                return_string = "csio:F"
            elif snapably_value_cd == "Log":
                return_string = "csio:1"
            elif snapably_value_cd == "Stone":
                return_string = "csio:F"
            elif snapably_value_cd == "Stucco":
                return_string = "csio:F"
            elif snapably_value_cd == "Vinyl Siding":
                return_string = "csio:F"
            elif snapably_value_cd == "Vinyl":
                return_string = "csio:F"
            elif snapably_value_cd == "Wood Siding":
                return_string = "csio:F"

        return return_string

    @staticmethod
    def snap_to_csio_exterior_wall_material_cd(snapably_value_cd):
        """
        This function is responsible for mapping the SidingCd from Snapably -> Csio
        @snapablyValueCd - The incoming snapablyValueCd
        """
        return_string = ""

        if snapably_value_cd is not None:
            if snapably_value_cd == "Brick Veneer":
                return_string = "csio:B"
            elif snapably_value_cd == "Brick":
                return_string = "csio:B"
            elif snapably_value_cd == "Concrete":
                return_string = "csio:D"
            elif snapably_value_cd == "Fiber Cement":
                return_string = "csio:C"
            elif snapably_value_cd == "Log":
                return_string = "csio:1"
            elif snapably_value_cd == "Stone":
                return_string = "csio:S"
            elif snapably_value_cd == "Stucco":
                return_string = "csio:O"
            elif snapably_value_cd == "Vinyl Siding":
                return_string = "csio:Y"
            elif snapably_value_cd == "Vinyl":
                return_string = "csio:Y"
            elif snapably_value_cd == "Wood Siding":
                return_string = "csio:U"

        return return_string

    @staticmethod
    def reverse_map_construction_cd(csio_value_cd):
        """
        This function is responsible for mapping the SidingCd from Csio -> Snapably
        @csioValueCd - The csio value
        """
        return_string = ""

        if csio_value_cd is not None:
            if csio_value_cd == "csio:W":
                return_string = "Brick Veneer"
            elif csio_value_cd == "csio:B":
                return_string = "Brick"
            elif csio_value_cd == "csio:D":
                return_string = "Concrete"
            elif csio_value_cd == "csio:C":
                return_string = "Fiber Cement"
            elif csio_value_cd == "csio:1":
                return_string = "Log"
            elif csio_value_cd == "csio:S":
                return_string = "Stone"
            elif csio_value_cd == "csio:O":
                return_string = "Stucco"
            elif csio_value_cd == "csio:Y":
                return_string = "Vinyl Siding"
            elif csio_value_cd == "csio:U":
                return_string = "Wood Siding"

        return return_string

    @staticmethod
    def snap_to_csio_foundation_type_cd(foundation_type):
        """
        #
        @param:String Value of dwelling from Snapably} foundationType
        """
        return_value = ""

        if foundation_type == "Basement":
            return_value = "6"
        elif foundation_type == "Crawlspace":
            return_value = "7"
        elif foundation_type == "Pier":
            return_value = "5"
        elif foundation_type == "Slab on Grade":
            return_value = "8"
        elif foundation_type == "Walkout Basement":
            return_value = "6"

        return return_value

    @staticmethod
    def snap_to_csio_wawanesa_foundation_type_cd(foundation_type):
        """
        #
        @param:String Value of dwelling from Snapably} foundationType
        """
        return_value = "1"

        if foundation_type == "Basement":
            return_value = "1"
        elif foundation_type == "Crawlspace":
            return_value = "7"
        elif foundation_type == "Pier":
            return_value = "5"
        elif foundation_type == "Slab on Grade":
            return_value = "8"
        elif foundation_type == "Walkout Basement":
            return_value = "1"

        return return_value

    @staticmethod
    def snap_to_csio_residence_type_cd(residence_type):
        """
        mapResidenceType
        @param:String Value of dwelling from Snapably} residenceType
        """
        return_value = ""

        if residence_type == "House":
            return_value = "DT"
        elif residence_type == "Duplex":
            return_value = "DX"
        elif residence_type == "Triplex":
            return_value = "TX"
        elif residence_type == "Row/Townhouse":
            return_value = "RH"
        elif residence_type == "Apartment":
            return_value = "AP"
        elif residence_type == "Condo":
            return_value = "AP"

        return return_value

    @staticmethod
    def reverse_map_residence_type(residence_type):
        """
        @param:String Value of dwelling from Snapably} residenceType
        """
        return_value = ""

        if residence_type == "DT":
            return_value = "House"
        elif residence_type == "DX":
            return_value = "Duplex"
        elif residence_type == "TX":
            return_value = "Triplex"
        elif residence_type == "RH":
            return_value = "Row/Townhouse"
        elif residence_type == "AP":
            return_value = "Apartment/Condo"

        return return_value

    @staticmethod
    def reverse_map_foundation_type(csio_foundation_type):
        """
        @param:String Value of dwelling from Snapably} foundationType
        """
        return_value = ""

        if csio_foundation_type == "6":
            return_value = "Basement"
        elif csio_foundation_type == "7":
            return_value = "Crawlspace"
        elif csio_foundation_type == "5":
            return_value = "Pier"
        elif csio_foundation_type == "8":
            return_value = "Slab on Grade"
        elif csio_foundation_type == "6":
            return_value = "Walkout Basement"

        return return_value

    @staticmethod
    def map_engine_type_cd(fuel_type):
        """
        @param:String Value of fuelType from Snapably} fuelType
        """
        return_value = ""

        if fuel_type == "Gasoline":
            return_value = "csio:3"
        elif fuel_type == "Flexible Fuel Vehicle":
            return_value = "csio:3"
        elif fuel_type == "Diesel":
            return_value = "csio:1"
        elif fuel_type == "Electric":
            return_value = "csio:9"

        return return_value

    @staticmethod
    def reverse_map_engine_type_cd(engine_type):
        """
        @param:String Value of fuelType from Snapably} engineType
        """
        return_value = ""

        if engine_type == "csio:3":
            return_value = "Gasoline"
        elif engine_type == "csio:1":
            return_value = "Diesel"
        elif engine_type == "csio:9":
            return_value = "Electric"

        return return_value

    @staticmethod
    def reverse_map_roofing_material_type(roof_material):
        """
        @param:String Value of dwelling from Snapably} roofMaterial
        """
        return_value = ""

        if roof_material == "A":
            return_value = "Asphalt"
        elif roof_material == "C":
            return_value = "Clay Tile"
        elif roof_material == "N":
            return_value = "Concrete"
        elif roof_material == "O":
            return_value = "Copper"
        elif roof_material == "S":
            return_value = "Slate Tile"
        elif roof_material == "L":
            return_value = "Steel"
        elif roof_material == "T":
            return_value = "Tar and Gravel"
        elif roof_material == "O":
            return_value = "Tin"
        elif roof_material == "X":
            return_value = "Wood"

        return return_value

    @staticmethod
    def snap_to_csio_roof_material_cd(roof_material):
        """
        mapRoofingMaterial
        @param:String Value of dwelling from Snapably} roofMaterial
        """
        return_value = ""

        if roof_material == "Asphalt":
            return_value = "A"
        elif roof_material == "Clay Tile":
            return_value = "C"
        elif roof_material == "Concrete":
            return_value = "N"
        elif roof_material == "Copper":
            return_value = "O"
        elif roof_material == "Slate Tile":
            return_value = "S"
        elif roof_material == "Steel":
            return_value = "L"
        elif roof_material == "Tar and Gravel":
            return_value = "T"
        elif roof_material == "Tin":
            return_value = "O"
        elif roof_material == "Wood":
            return_value = "X"

        return return_value

    @staticmethod
    def snap_to_csio_garage_type_cd(garage_type):
        """
        garageType
        @param:String Value of dwelling from Snapably} garageType
        """
        return_value = ""

        if garage_type == "None":
            return_value = "csio:0"
        elif garage_type == "Attached":
            return_value = "csio:4"
        elif garage_type == "Detached":
            return_value = "csio:6"
        elif garage_type == "Carport":
            return_value = "csio:3"
        elif garage_type == "Built-in":
            return_value = "csio:1"

        return return_value
