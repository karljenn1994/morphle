class CSIOMappingUtils:
    coverage_descriptions = {
        "TPPD": "Property Damage Liability",
        "AB": "Accident Benefits",
        "TPBI": "Bodily Injury Liability",
        "TPDC": "Direct Compensation Property Damage",
        "CMP": "Comprehensive",
        "COL": "Collision",
        "UA": "Uninsured Automobile",
        "44": "44 - Family Protection",
        "FLOOD": "Flood Damage (Surface Water)",
        "DWELL": "Dwelling (A)",
        "PL": "Liability (E)",
        "SEWER": "Sewer Back-up Coverage",
        "WATER": "Water Damage Endorsement",
        "ByLaws": "Bylaws Endorsement",
        "CLFRE": "Claim Free Protection",
    }

    @staticmethod
    def map_auto_claim_type(claim_type):
        return_value = ''

        if claim_type == '1' or claim_type == '3' or claim_type == '4' or claim_type == '5' or claim_type == '6' or claim_type == '7':
            return_value = 'Collision'
        elif claim_type == '8' or claim_type == '17' or claim_type == '21':
            return_value = 'Other non-responsible Comp/SP'
        elif claim_type == '16':
            return_value = 'Fire'
        elif claim_type == '18':
            return_value = 'Glass Breakage'
        elif claim_type == '19' or claim_type == '20':
            return_value = 'Liability & Collision'
        elif claim_type == '22':
            return_value = 'Collision'
        elif claim_type == '31':
            return_value = 'Theft'
        elif claim_type == '34':
            return_value = 'Vandalism'
        elif claim_type == '36':
            return_value = 'Hail'

        return return_value

    @staticmethod
    def map_auto_conviction_type(conviction_type):
        return_code = ''
        return_severity = ''

        if conviction_type == 'BACK':
            return_code = 'FTS'
            return_severity = 'Minor'
        elif conviction_type == 'BIKE':
            return_code = 'MINOR'
            return_severity = 'Minor'
        elif conviction_type == 'CPV':
            return_code = 'CPV'
            return_severity = 'Minor'
        elif conviction_type == 'FCIC':
            return_code = 'FCIC'
            return_severity = 'Minor'
        elif conviction_type == 'FTC':
            return_code = 'FTC'
            return_severity = 'Minor'
        elif conviction_type == 'FTS':
            return_code = 'FTS'
            return_severity = 'Minor'
        elif conviction_type == 'MINOR':
            return_code = 'MINOR'
            return_severity = 'Minor'
        elif conviction_type == 'SP':
            return_code = 'SP'
            return_severity = 'Minor'
        elif conviction_type == 'SS':
            return_code = 'SS'
            return_severity = 'Minor'
        elif conviction_type == 'SB':
            return_code = 'SB'
            return_severity = 'Minor'
        elif conviction_type == 'CD':
            return_code = 'CD'
            return_severity = 'Major'
        elif conviction_type == 'CN':
            return_code = 'CN'
            return_severity = 'Criminal'
        elif conviction_type == 'DD':
            return_code = 'DD'
            return_severity = 'Criminal'
        elif conviction_type == 'DUS':
            return_code = 'DUS'
            return_severity = 'Criminal'
        elif conviction_type == 'FPBT':
            return_code = 'ALC'
            return_severity = 'Criminal'
        elif conviction_type == 'FPEI':
            return_code = 'FPEI'
            return_severity = 'Minor'
        elif conviction_type == 'FTR':
            return_code = 'FTR'
            return_severity = 'Criminal'
        elif conviction_type == 'FTS':
            return_code = 'FTS'
            return_severity = 'Minor'
        elif conviction_type == 'HL':
            return_code = 'HL'
            return_severity = 'Minor'
        elif conviction_type == 'ILC':
            return_code = 'ILC'
            return_severity = 'Minor'
        elif conviction_type == 'MAJOR':
            return_code = 'MAJOR'
            return_severity = 'Major'
        elif conviction_type == 'PSB':
            return_code = 'PSB'
            return_severity = 'Major'
        elif conviction_type == 'RAC':
            return_code = 'RAC'
            return_severity = 'Major'

        return [return_code, return_severity]

    @staticmethod
    def map_property_claim_type(claim_type):
        return_value = 'OTHER'

        if claim_type == '502':
            return_value = 'BI'
        elif claim_type == '503':
            return_value = 'BURG'
        elif claim_type == '505':
            return_value = 'PD'
        elif claim_type == '506':
            return_value = 'PD'
        elif claim_type == '534':
            return_value = 'CREDITCARD'
        elif claim_type == '521':
            return_value = 'ERQK'
        elif claim_type == '526':
            return_value = 'EXPLOSION'
        elif claim_type == '547':
            return_value = 'FIRE'
        elif claim_type == '549':
            return_value = 'FOOD'
        elif claim_type == '564':
            return_value = 'WIND'
        elif claim_type == '571':
            return_value = 'PD'
        elif claim_type == '588':
            return_value = 'PD'
        elif claim_type == '591':
            return_value = 'SEWER'
        elif claim_type == '594':
            return_value = 'FIRE'
        elif claim_type == '595':
            return_value = 'OTHER'
        elif claim_type == '611':
            return_value = 'VAND'
        elif claim_type == '627':
            return_value = 'WATERDAM'
        elif claim_type == '641':
            return_value = 'WIND'
        elif claim_type == '999':
            return_value = 'OTHER'

        return return_value
