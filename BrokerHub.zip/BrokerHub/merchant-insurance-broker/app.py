import datetime as datetime
import os

from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_jwt_extended.exceptions import NoAuthorizationError
from flask_restx import Api
from jwt import ExpiredSignatureError

from api_branch.routes import api as branch_api
from api_claim.routes import api as claim_api
from api_health.routes import api as health_api
from api_journal.routes import api as journal_api
from api_policy.routes import api as policy_api
from api_quoting.routes import api as quoting_api
from api_sendgrid.routes_sendgrid import api as sendgrid_api
from api_ui.routes_admin import api as admin_api
from api_ui.routes_auth import api as auth_api
from api_ui.routes_auth_ext import api as auth_api_ext
from api_ui.routes_campaigns import api as campaigns_api
from api_ui.routes_claims import api as claims_api
from api_ui.routes_forms import api as surveys_api
from api_ui.routes_leads import api as leads_api
from api_ui.routes_metrics import api as metrics_api
from api_ui.routes_notifier import api as notifier_api
from api_ui.routes_pass import api as pass_api
from api_ui.routes_policies import api as policies_api
from api_ui.routes_pub import api as pub_api
from api_ui.routes_quotes import api as quotes_api
from api_ui.routes_renewals import api as renewals_api
from api_ui.routes_settings import api as settings_api
from api_ui.routes_tasks import api as tasks_api
from api_ui.routes_user import api as admin_user_api
from api_ui.routes_validators import api as validators_api
from lib_common import constants
from lib_common.log_config import setup_logging
from lib_vault.vault import Vault
from lib_persistence import settings

setup_logging()


def create_app(config_filename=None, engine=None, use_cache=True):
    vault = Vault()
    vault.initialize()

    api = Api(
        title="LifesWallet API",
        version="1.0",
        description="LifesWallet API",
        security_definitions={
            "cookieAuth": {
                "type": "apiKey",
                "in": "cookie",
                "name": "jwt"
            }
        },
        authorizations={
            "cookieAuth": {
                "type": "apiKey",
                "in": "cookie",
                "name": "jwt"
            }
        },
        error=False,
    )

    app = Flask(__name__, instance_relative_config=True)
    CORS(app, supports_credentials=True)

    env = os.environ.get(constants.ENV_ENVIRONMENT)
    if not env:
        raise RuntimeError("Missing environment.")

    if env == 'local':
        from lib_persistence import initialize_persistence
        initialize_persistence()

    app.config["JWT_COOKIE_DOMAIN"] = settings.get_setting(constants.SETTING_SYSTEM_DOMAIN, default=None)
    app.config["JWT_COOKIE_SECURE"] = True if env != 'local' else False
    app.config["JWT_COOKIE_CSRF_PROTECT"] = True if env != 'local' else False
    app.config["JWT_SECRET_KEY"] = settings.get_setting(constants.SETTING_JWT_SECRET)
    app.config["JWT_TOKEN_LOCATION"] = ["cookies"]

    # This allows sending the refresh token when launching from external apps, like gmail. This addresses
    # the issues that occur when operating the app within the gmail embedded browser.
    app.config["JWT_COOKIE_SAMESITE"] = "Lax"

    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = datetime.timedelta(
        minutes=settings.get_int_setting(constants.SETTING_JWT_ACCESS_TOKEN_EXPIRES, default=60))
    app.config["JWT_REFRESH_TOKEN_EXPIRES"] = datetime.timedelta(
        minutes=settings.get_int_setting(constants.SETTING_JWT_REFRESH_TOKEN_EXPIRES, default=60 * 24 * 5))

    print("JWT_COOKIE_DOMAIN =", app.config["JWT_COOKIE_DOMAIN"])

    JWTManager(app)
    api.init_app(app)
    app.debug = True

    @api.errorhandler(ExpiredSignatureError)
    def handle_expired_token(error):
        return {"message": "Session expired", "code": "TOKEN_EXPIRED"}, 401

    @api.errorhandler(NoAuthorizationError)
    def handle_no_token(error):
        return {"message": "Session expired", "code": "MISSING_TOKEN"}, 401

    api.add_namespace(auth_api)
    api.add_namespace(branch_api)
    api.add_namespace(auth_api_ext)
    api.add_namespace(health_api)
    api.add_namespace(journal_api)
    api.add_namespace(policy_api)
    api.add_namespace(claim_api)
    api.add_namespace(quoting_api)
    api.add_namespace(admin_api)
    api.add_namespace(admin_user_api)
    api.add_namespace(campaigns_api)
    api.add_namespace(metrics_api)
    api.add_namespace(tasks_api)
    api.add_namespace(settings_api)
    api.add_namespace(notifier_api)
    api.add_namespace(policies_api)
    api.add_namespace(renewals_api)
    api.add_namespace(claims_api)
    api.add_namespace(quotes_api)
    api.add_namespace(leads_api)
    api.add_namespace(pub_api)
    api.add_namespace(sendgrid_api)
    api.add_namespace(validators_api)
    api.add_namespace(surveys_api)
    api.add_namespace(pass_api)

    return app
