import logging
import os

import requests

from lib_common import constants
from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


class Vault:
    _instance = None
    _initialized = False
    vault_data = {}
    _vault_token = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Vault, cls).__new__(cls)
        return cls._instance

    def initialize(self):
        if self._initialized:
            log.info("Vault already initialized, skipping.")
            return

        environment = os.environ.get(constants.ENV_ENVIRONMENT)
        vault_addr = os.environ.get(constants.ENV_VAULT_ADDR)
        vault_token = os.environ.get(constants.ENV_VAULT_TOKEN)
        wrapped_token = os.environ.get(constants.ENV_VAULT_WRAPPED_TOKEN)

        if not vault_token and not wrapped_token:
            raise RuntimeError("A vault token or wrapped token was not provided.")

        if wrapped_token:
            unwrap_url = f"{vault_addr}/v1/sys/wrapping/unwrap"
            headers = {"X-Vault-Token": wrapped_token}
            log.info("Unwrapping Vault token...")
            response = requests.post(unwrap_url, headers=headers)

            if response.status_code != 200:
                log.error("Failed unwrapping vault token")
                raise RuntimeError(f"Failed to unwrap token: {response.status_code} - {response.text}")

            self._vault_token = response.json()["data"]["token"]
            log.info("Vault token unwrapped successfully.")
        else:
            self._vault_token = vault_token

        vault_path = f"secret/{environment}/settings"
        url = f"{vault_addr}/v1/{vault_path}"
        headers = {"X-Vault-Token": self._vault_token}

        log.info(f"Loading Vault settings from: {vault_path}")
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            raise RuntimeError(f"Failed to read Vault settings: {response.status_code} - {response.text}")

        self.vault_data = response.json().get("data", {})
        self._initialized = True
        log.info("Vault settings loaded successfully.")

    def write(self):
        """
        Write the entire vault_data back to Vault at secret/{environment}/settings.
        Equivalent to: vault kv put secret/{environment}/settings
        """
        if not self._initialized:
            self.initialize()

        environment = os.environ.get(constants.ENV_ENVIRONMENT)
        vault_addr = os.environ.get(constants.ENV_VAULT_ADDR)
        vault_path = f"secret/{environment}/settings"
        url = f"{vault_addr}/v1/{vault_path}"
        headers = {"X-Vault-Token": self._vault_token}

        # Prepare the payload in the format Vault KV v1 expects
        payload = self.vault_data  # KV v1 expects the data directly, no "data" wrapper

        log.info(f"Writing Vault settings to: {vault_path}")
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code not in (200, 204):
            raise RuntimeError(f"Failed to write Vault settings: {response.status_code} - {response.text}")

        log.info("Vault settings written successfully.")

    def get(self, name):
        if not self._initialized:
            self.initialize()
        return self.vault_data.get(name)

    def put(self, name, value):
        if not self._initialized:
            self.initialize()
        self.vault_data[name] = value
