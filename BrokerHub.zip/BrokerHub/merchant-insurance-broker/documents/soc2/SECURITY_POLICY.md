# Brunvalley Cloud Solutions – Security Policy

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8th, 2025

---

## Purpose

This Security Policy outlines how Brunvalley Cloud Solutions protects customer data, application systems, and supporting infrastructure in line with industry best practices and SOC 2 principles.

---

## Scope

This policy applies to:  
- All infrastructure managed by Brunvalley (droplets, Vault, backups).  
- All customer data (EDI, policy files, database).  
- All devices used to access or manage customer systems (work laptops).  
- All team members.

---

## Physical Security

- Devices used for work are kept in a secured home environment.
- Laptops are password-protected and not left unattended in public.

---

## Device Security

- Laptops use strong, unique passwords.
- Devices are kept up to date with the latest security patches.
- Disk encryption (FileVault) is planned for MacBooks.
- A password manager (KeePass) is used to generate and store all business-related credentials.

---

## Network Security

- All production servers are hosted on DigitalOcean’s SOC 2–certified infrastructure.
- SSH access is restricted by IP and uses SSH keys only.
- UFW and DigitalOcean cloud firewalls are configured to allow only required ports.
- Sensitive API keys and credentials are stored in Vault and never hardcoded.

---

## Data Security

- EDI policy files are stored on the droplet; encryption at rest is supported and enabled as required.
- Backups include all critical files, databases, and configurations, and are stored on a local NAS. Backup encryption is planned.
- Backups are transferred securely over SSH.

---

## Access Control

- Only Greg Parker has administrative access to production servers and Vault.
- Other team member access is limited to business operations, sales, and support; no direct server or database access.
- SSH keys are stored only on authorized developer devices and protected by local device security.
- Access permissions are reviewed as needed and when roles change.

---

## Monitoring and Vulnerability Management

- Grafana, node_exporter, and promtail are used to monitor server health and log activity.
- A health check API confirms application uptime.
- Vuls is used to scan for OS and package vulnerabilities.
- Web application vulnerability scanning is planned.
- Critical patches are applied as soon as practical.

---

## Incident Response

- Security incidents are handled according to the documented [INCIDENT_RESPONSE_PLAN.md](INCIDENT_RESPONSE_PLAN.md).

---

## Data Classification

- Customer EDI and policy files: **Confidential**
- Internal project documentation and planning: **Internal Use Only**
- No public data is stored or distributed.

---

## Policy Review

This policy will be reviewed at least once a year and updated as needed.

---

**Contact:**  
Greg Parker  
greg.parker@brunvalley.com
---
