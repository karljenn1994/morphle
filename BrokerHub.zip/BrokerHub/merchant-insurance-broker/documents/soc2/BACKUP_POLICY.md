# Brunvalley Cloud Solutions – Backup Policy

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8, 2025

---

## Purpose

This Backup Policy defines how Brunvalley Cloud Solutions creates, stores, secures, and manages backups to ensure customer data can be restored in the event of a failure or data loss.

---

## Scope

This policy applies to:
- Customer EDI files and policy data
- Databases and configuration files
- Supporting application data

---

## Backup Frequency

- Full backups are created weekly using automated Celery tasks.
- Backups include all critical files, databases, and configuration files stored under `/opt/[customer]/`.

---

## Backup Storage

- Backups are stored in the `/opt/[customer]/backups/` directory on the production droplet.
- Backups are transferred securely over SSH and stored offsite.

---

## Backup Security

- Backups may include encrypted EDI files when at-rest encryption is enabled.
- Backup archives themselves can be encrypted for additional protection.
- Backup transfer uses secure SSH connections.

---

## Retention

- Backups are retained until storage limits require older files to be purged.
- Customers can request older backups to be deleted if required.
- A defined retention schedule will be formalized as services expand.

---

## Testing

- Backup restoration processes will be tested at least annually to confirm data integrity and recovery readiness.

---

## Roles and Responsibilities

- Greg Parker is responsible for ensuring backup tasks run as expected, storage is maintained, and restores can be performed.
- Any changes to backup procedures are versioned and documented.

---

## Review

This policy will be reviewed annually or after any major incident or restoration test.

---

**Contact:**  
Greg Parker  
greg.parker@brunvalley.com
