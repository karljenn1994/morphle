# Brunvalley Cloud Solutions – Disaster Recovery Plan

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8th, 2025

---

## Purpose

This Disaster Recovery Plan (DRP) describes how Brunvalley Cloud Solutions will recover and restore services and customer data in the event of a major disaster or outage.

---

## Scope

This plan covers:
- Complete or partial failure of production servers or droplets.
- Major hardware failure or data loss.
- Physical loss of local backup storage.
- Natural disasters impacting local infrastructure or developer devices.

---

## Objectives

- **Recovery Time Objective (RTO):** Restore critical services within **4–8 hours** of a total outage.
- **Recovery Point Objective (RPO):** Maximum potential data loss is limited to the time between backups and any available source re-import (e.g., CSIONet).

---

## Backup Strategy

- Weekly backups include EDI policy files, database data, and configuration files.
- Backups are stored on the production droplet and synced over SSH to offsite storage.
- Backups are encrypted.

---

## Recovery Process

1️⃣ **Server Failure (Droplet Outage)**
- Deploy a new droplet in the same or alternate DigitalOcean region.
- Adjust internal routing to the new droplet.
- Apply the necessary firewall and server configurations.
- Restore the latest verified backup.
- Reconnect to CSIONet and re-import any EDI records needed to fill gaps.

2️⃣ **Vault Failure**
- Restore Vault configuration and secrets from secure offsite backup.

3️⃣ **Loss of Local Backup Storage**
- Recreate or replace offsite backup storage.
- Synchronize with live server latest backups.

4️⃣ **Developer Device Loss**
- Reinstall required tools on a new device.
- Delete SSH access to remote servers.
- Grant SSH access with new keys.

---

## Testing

- Backup and restore processes will be tested at least once per year.
- Test results will be documented.

---

## Roles and Responsibilities

**Responsible Person:** Greg Parker  
- Ensure backups run successfully.
- Maintain offsite copies of critical secrets and backup archives.
- Oversee restore procedures and recovery steps.

---

## Updates

This Disaster Recovery Plan will be reviewed annually or following any major incident.

---

**Contact:**  
Greg Parker  
greg.parker@brunvalley.com
(506)651-9292

