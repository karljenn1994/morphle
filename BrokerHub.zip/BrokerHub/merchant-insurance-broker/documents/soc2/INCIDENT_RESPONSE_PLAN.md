# Brunvalley Cloud Solutions – Incident Response Plan

**Version:** 1.0  
**Owner:** Greg Parker
**Last Updated:** July 8th, 2025

---

## Purpose

Ensure any security incident that could affect customer data, system availability, or our services is detected, contained, investigated, and communicated promptly and effectively.

---

## Scope

This plan applies to:  
- All systems managed by Brunvalley Cloud Solutions (e.g., Broker Hub application, backup systems, Vault).  
- All data under our control, including customer policy data and credentials.  
- All personnel.

---

## Roles and Responsibilities

**Incident Response Owner:** Greg Parker
- Identify, contain, investigate, and resolve all security incidents.  
- Notify affected brokerages and coordinate any required third-party support.  
- Document the incident and any follow-up actions.

---

## Incident Definition

An **incident** includes but is not limited to:
- Unauthorized access to servers, Vault, or sensitive customer data.
- Compromise of SSH keys, Vault credentials, or backup storage.
- Data loss or data corruption.
- Major service outage due to malicious or accidental causes.

---

## Incident Response Steps

### 1️⃣ Detection
- Monitor systems daily (Grafana, server health checks, vulnerability scans).
- Investigate alerts or unusual activity immediately.

### 2️⃣ Containment
- Restrict or disable access where compromise is suspected (e.g., rotate keys, shut down services).
- Isolate affected systems to prevent further spread.

### 3️⃣ Investigation
- Determine root cause and scope of the incident.
- Collect relevant logs and evidence.

### 4️⃣ Eradication & Recovery
- Remove the cause of the incident (e.g., patch vulnerability, rotate secrets).
- Restore services using verified backups if needed.

### 5️⃣ Notification
- Notify affected brokerages as soon as possible, ideally within **72 hours** of confirmed impact.
- Provide updates until resolution.

### 6️⃣ Post-Incident Review
- Document the incident, impact, and response steps.
- Implement improvements to prevent recurrence.

---

## Testing & Maintenance

- Review this plan **at least annually** or after any major incident.
- Update as needed to keep it relevant as our services grow.

---

**Contact:**  
Greg Parker  
greg.parker@brunvalley.com
(506)651-9292
---
