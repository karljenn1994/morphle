# Brunvalley Cloud Solutions – Onboarding & Offboarding Checklist

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8th, 2025

---

## Purpose

This checklist outlines the steps Brunvalley Cloud Solutions follows to securely onboard and offboard any team members or contractors who require access to company systems or customer data.

---

## Scope

Covers:
- New team members
- Contractors or trusted technical partners
- Roles that require access to production servers, Vault, or confidential customer data

---

## Onboarding Steps

1️⃣ Verify identity and role requirements  
2️⃣ Provide only the minimum necessary access for the role  
3️⃣ Set up unique SSH keys (if server access is needed)  
4️⃣ Add to required Google Workspace accounts (with 2FA)  
5️⃣ Add to Trello or other planning tools as needed  
6️⃣ Provide security best practice briefing (strong passwords, secure devices)  
7️⃣ Document access granted

---

## Offboarding Steps

1️⃣ Revoke all SSH keys from production servers  
2️⃣ Disable or remove Google Workspace account access  
3️⃣ Remove from Trello and other collaboration tools  
4️⃣ Rotate any relevant Vault keys or secrets  
5️⃣ Document offboarding steps completed

---

## Responsibility

Greg Parker is responsible for ensuring all onboarding and offboarding steps are followed and documented.

---

## Review

This checklist will be reviewed annually or when there are changes to the team structure.

---

**Contact:**  
Greg Parker  
greg.parker@brunvalley.com

