# Brunvalley Cloud Solutions – Data Classification

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8th, 2025

---

## Purpose

This document outlines how Brunvalley Cloud Solutions classifies the data it handles to ensure appropriate security measures are applied.

---

## Data Categories

Brunvalley data is classified into three categories:

### 1️⃣ Confidential

- Customer EDI files (insurance policies and related data)
- Policyholder names, emails, and contact details
- Vault secrets and API keys
- Backups containing customer data

**Handling:**  
- Stored securely on production droplets and backup storage.
- Access limited to authorized personnel (Greg Parker).
- May be encrypted at rest; always protected in transit.

---

### 2️⃣ Internal Use Only

- Internal documentation and project notes
- Planning boards and tasks (e.g., Trello)
- Configuration details unrelated to customer policy data

**Handling:**  
- Stored in Google Workspace and Trello.
- Accessible to Brunvalley team only.
- Not shared externally.

---

### 3️⃣ Public

- Brunvalley does not process or distribute public data as part of its core services.

---

## Review

This classification will be reviewed annually or when services change significantly.

---

**Contact:**  
Greg Parker  
greg.parker@brunvalley.com

