# Brunvalley Cloud Solutions – Privacy Policy

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8th, 2025

---

## Purpose

This Privacy Policy explains what data Brunvalley Cloud Solutions (“Brunvalley”) collects, why we collect it, how we use it, and how we protect it.

---

## What We Collect

Brunvalley processes insurance policy data (“EDI”) and related customer information on behalf of insurance brokerages.  
Information we may store includes:
- Policyholder names
- Policyholder contact information (e.g., email)
- Policy details and coverage information
- Information provided directly by brokerages for quoting or processing

---

## How We Collect It

Customer policy data is received securely via:
- Integration with CSIONet APIs
- Files or data brokerages choose to share for quoting or processing

---

## How We Use It

We use customer data solely to:
- Operate and maintain the Broker Hub application
- Deliver services requested by brokerages, including quoting and policy processing
- Provide support to brokerages when needed

---

## How We Protect It

- All data is stored on servers hosted with DigitalOcean, which maintains SOC 2 certification for its infrastructure.
- SSH access is restricted, firewall rules are in place, and secrets are managed in Vault.
- Sensitive policy files can be encrypted at rest.
- Backups are taken regularly and stored securely.

---

## How Long We Keep It

- Customer data is retained for as long as the brokerage remains a Brunvalley customer.
- If a brokerage terminates its relationship with Brunvalley, all related data and backups are deleted.
- Individual end-customer records may remain as part of brokerage records unless otherwise arranged.

---

## Sharing

- Customer data may be shared only with trusted third-party quoting engines or services specified by the brokerage.
- We do not sell or share data with any other third parties.

---

## Customer Rights

- Brokerages can request that Brunvalley delete their stored data if they stop using our services.
- Requests can be made to the contact below and will be handled promptly.

---

## Contact

Questions or requests related to this policy can be sent to:  
Greg Parker  
greg.parker@brunvalley.com
---

## Updates

This Privacy Policy may be updated as needed and will be version-controlled alongside our application source code.

