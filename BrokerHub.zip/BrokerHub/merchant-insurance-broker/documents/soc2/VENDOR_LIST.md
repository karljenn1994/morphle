# Brunvalley Cloud Solutions – Vendor List

**Version:** 1.0  
**Owner:** Greg Parker  
**Last Updated:** July 8th, 2025

---

## Purpose

This vendor list documents the key third-party services Brunvalley Cloud Solutions relies on to deliver its application and services.

---

## Vendors

| Vendor         | Purpose                                 | Security Certifications/Notes                   |
|----------------|-----------------------------------------|-------------------------------------------------|
| **DigitalOcean** | Cloud hosting for all production droplets, Vault server, and monitoring tools | SOC 2 Type II Certified infrastructure |
| **CSIONet**    | Secure EDI and eDocs distribution for insurance brokerages | Industry standard for insurance data |
| **Fortis (example)** | Third-party quoting engine for insurance | Security assurances managed by brokerages |
| **Google Workspace** | Email, internal communication, shared drive storage | Google’s SOC 2/ISO 27001 for Workspace |
| **Trello**     | Project planning and internal task tracking | Used for internal planning only |

---

## Review Process

- Vendors are reviewed annually to confirm they continue to meet security expectations.
- Any new vendors will be checked for reasonable security practices or certifications.
- Documentation of key certifications (e.g., DigitalOcean’s SOC 2) is kept on file when available.

---

## Contact

Questions about vendor security or this list can be sent to:  
Greg Parker  
greg.parker@brunvalley.com

