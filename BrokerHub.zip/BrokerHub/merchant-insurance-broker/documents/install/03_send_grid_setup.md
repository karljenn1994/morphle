# SENDGRID BROKERAGE SETUP

## Create a Sub-user

## Add Domain and IP addresses

## Create API Key

## Create Marketing Group

## Authenticate Single Sender