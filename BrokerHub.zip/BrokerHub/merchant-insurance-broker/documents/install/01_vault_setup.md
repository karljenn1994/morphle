# BROKERAGE VAULT SETUP

## Create/Write Brokerage Policy

```
# Write the policy
vault policy write [brokerage]-policy policy-[brokerage].hcl

# Verify its there.
vault policy list

# Read it back.
vault policy read [broker]-policy
```

## Create/Write Brokerage Settings

```
# Write the settings.
./vault-settings-write [brokerage]

# Read them back to verify.
./vault-settings-read [brokerage]
```

## Generate Brokerage Token

```
# Generate a token for the server configuration.
vault token create -policy=[brokerage]-policy
```