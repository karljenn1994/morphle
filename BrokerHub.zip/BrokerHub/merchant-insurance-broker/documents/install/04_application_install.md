# BROKERAGE SERVER SETUP AND INSTALLATION

## Create Droplet

* Create a new Ubuntu droplet
* Locally add `/etc/hosts` entry
* Add `~/.ssh/config` entry

## Copy Merchant Insurance Broker Config

```
scp -r ~/config <server>:/opt/config
```

## Update Ubuntu

```
sudo apt update
sudo apt install build-essential libssl-dev zlib1g-dev libbz2-dev \
  libreadline-dev libsqlite3-dev curl libncursesw5-dev xz-utils tk-dev \
  libxml2-dev libxmlsec1-dev libffi-dev liblzma-dev
```

## Install pyenv

```
curl https://pyenv.run | bash
```

Add to end of `/root/.bashrc`:

```
export PYENV_ROOT="$HOME/.pyenv"
command -v pyenv >/dev/null || export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"
```

```
cd /root/.pyenv
./bin/pyenv install 3.13.0
```

## Install Nginx

```
sudo apt install nginx
```

## Install Certbot

```
sudo apt install certbot python3-certbot-nginx
```

## Install MySQL Client

```
sudo apt install -y mysql-client
```

## Configure Certbot

* Add an **A record** for the broker in the DigitalOcean console
* Run:

```
certbot certonly --standalone -d [brokerage].mybrokerhub.ca
```

## Create broker user

```
useradd --system --no-create-home --shell /usr/sbin/nologin broker
```

## Create the broker folder

* Copy merchant-insurance-broker/opt folder and files into the server /opt folder
* Rename [broker] to the broker name
* Change ownership to the broker account

```
# Change ownership to broker.
chown -R broker:broker /opt/[broker]

# Set base permission on each file.
chmod -R a=r,u+rw /opt/[broker]

# Add execute on directories.
chmod -R a+X /opt/[broker]
```

## Configure Nginx

* Remove default site from Nginx
* Alter the [broker]-nginx.conf for the particular environment.

```
ln -sf /opt/config/[broker]-nginx.conf /etc/nginx/sites-enabled/[broker]-nginx.conf
```

## Configure UFW

```
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw delete allow 'Nginx HTTP'
sudo ufw allow 9100/tcp
sudo ufw enable
```

## Configure App Services

```
ln -s /opt/config/[broker]-tasks.service /etc/systemd/system/[broker]-tasks.service
ln -s /opt/config/[broker]-api.service /etc/systemd/system/[broker]-api.service
```

## Configure App

### Brokerage configuration file
```
nano /opt/config/[broker].conf
```

* Update ENVIRONMENT to broker name
* Update LOGS_LOCATION to use the broker name
* Add VAULT_TOKEN

### Import mapping

* edit /opt/[broker]/config/import_mappings.yaml
  * Make sure columns match broker's report

### Quoting mapping

* edit /opt/[broker]/config/quoting_config.yaml


## Start Services

```
# Start services
systemctl daemon-reload
systemctl start [broker]-api
systemctl start [broker]-tasks
systemctl start nginx

# Make sure things started correctly.
journalctl -u [broker]-api -f --lines 2000
journalctl -u [broker]-tasks -f --lines 2000
```
