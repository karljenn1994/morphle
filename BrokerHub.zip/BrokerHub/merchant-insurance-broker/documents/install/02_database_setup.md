# BROKERAGE DATABASE SETUP

## Create a New Schema

policy_index_[brokerage]

## Install Base Tables

## Configure Settings