# Initialize Vault 

`vault operator init`


# Status

`vault status`
  

# Enable Key Value Storage

`vault secrets enable -path=secret kv`


# Write Secrets

`vault kv put secret/broker/csionet username=[username]  password=[password]`

# Read Secrets

`vault kv get secret/broker/csionet`

# Delete a Seret

`vault kv delete secret/broker/csionet`


# List Policies

`vault policy list`


# Create a Policy
```
vault policy write local-policy - <<EOF
  path "secret/local/*" {
  capabilities = ["read"]
}
EOF
```

# Create a Token

vault token create -policy=broker-policy

# Read a Policy

`vault policy read broker-policy`
