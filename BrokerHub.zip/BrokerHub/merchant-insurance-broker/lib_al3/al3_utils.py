from lib_common.exceptions import (
    AL3Exception, CODE_AL3_MISSING_COMPANY, CODE_AL3_MISSING_POLICY_NUMBER,
    CODE_UNSUPPORTED_POLICY_TYPE
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_helpers import date_from_edi_date, date_to_string
from lib_persistence import policy

al3_extensions = (".txt", ".al3", ".edi", ".dat")


def remove_spaces(v):
    if v is not None:
        return v.replace(" ", "")
    return v


def has(obj, key):
    if obj is None:
        return False

    parts = key.split(".")

    for x in parts:
        if obj is None or x not in obj:
            return False
        else:
            obj = obj[x]

    return True


def val(obj, item, default):
    if has(obj, "data." + item + ".value"):
        v = obj["data"][item]["value"].strip()

        if len(v) > 0:
            return v

    return default


def int_val(obj, item, default: int) -> int:
    if has(obj, "data." + item + ".value"):
        v = obj["data"][item]["value"].strip()
        if v:
            try:
                return int(v)
            except (ValueError, TypeError):
                return default
    return default


def group_val(obj, group, item, default):
    if has(obj, group + ".data." + item + ".value"):
        return obj[group]["data"][item]["value"]

    return default


def find_groups_by_group_name(data, name):
    results = []
    _append_groups_by_group_name(data, name, results)
    return results


def _append_groups_by_group_name(data, name, results):
    for key, value in data.items():
        if "children" in value:
            _append_groups_by_group_name(value["children"], name, results)

        if name in key:
            results.append(value)


def find_groups_by_group_name_as_map(data, name):
    results = {}
    _append_groups_by_group_name_as_map(data, name, results)
    return results


def _append_groups_by_group_name_as_map(data, name, results):
    for key, value in data.items():
        if "children" in value:
            _append_groups_by_group_name_as_map(value["children"], name, results)

        if name in key:
            results[key] = value


def find_group_by_group_name(data, name):
    results = []
    _append_groups_by_group_name(data, name, results)

    if len(results) > 0:
        return results[0]

    return None


def make_al3_folder(al3_object):
    fm = FileManagerFactory.create_file_manager()
    five_bpi = find_group_by_group_name(al3_object, "5BPI")

    policy_no = fix_policy_number(val(five_bpi, "01", None))

    if policy_no is None:
        raise AL3Exception("Missing policy number in 5BPI", error_code=CODE_AL3_MISSING_POLICY_NUMBER)

    company = val(five_bpi, "03", None)

    if company is None:
        raise AL3Exception("Missing company name in 5BPI", error_code=CODE_AL3_MISSING_COMPANY)

    company, _ = policy.map_company_code(company)

    return fm.join(company.upper(), policy_no.upper(), )


def fix_policy_number(policy_number):
    # Some policy numbers have a prefix that we don't want. For example, North Bridge uses "PA " or "XL " but does not
    # include the prefix in their customer documents.
    if policy_number is not None and (policy_number.startswith("PA ") or policy_number.startswith("XL ")):
        return policy_number.split(" ")[-1]
    return policy_number


def make_al3_file_name(al3_object):
    err_msg = ""

    five_bpi = find_group_by_group_name(al3_object, "5BPI")
    policy_no = fix_policy_number(val(five_bpi, "01", None))

    if policy_no is None:
        err_msg += " policy,"

    company, _ = policy.map_company_code(val(five_bpi, "03", None))

    if company is None:
        err_msg += " company,"

    lob = val(five_bpi, "04", None)

    if lob.lower() != "auto" and lob.lower() != "cauto" and lob.lower() != "habl":
        raise AL3Exception("Policy type " + lob + " not supported", error_code=CODE_UNSUPPORTED_POLICY_TYPE)
    elif lob is None:
        err_msg += " lob,"

    two_trg = find_group_by_group_name(al3_object, "2TRG")
    tx_date = val(two_trg, "20", None)

    if tx_date is not None:
        tx_date = date_to_string(date_from_edi_date(tx_date.encode()))
        tx_date = tx_date.upper()
        tx_date = tx_date.split("T")[0]
        tx_date = tx_date.replace("-", "")
    else:
        err_msg += " transaction date,"

    policy_effective_date = val(five_bpi, "06", None)

    if policy_effective_date is not None:
        policy_effective_date = date_to_string(date_from_edi_date(policy_effective_date.encode()))
        policy_effective_date = policy_effective_date.upper()
        policy_effective_date = policy_effective_date.split("T")[0]
        policy_effective_date = policy_effective_date.replace("-", "")
    else:
        err_msg += " policy effective date,"

    purpose = val(two_trg, "25", None)

    if purpose is None:
        err_msg += " purpose,"

    seq = val(two_trg, "19", None)

    if seq is None:
        err_msg += " seq,"

    if len(err_msg) <= 0:
        file_name = (
                company
                + "_" + tx_date
                + "_" + policy_effective_date
                + "_" + seq
                + "_" + policy_no
                + "_" + lob
                + "_" + purpose
                + ".AL3"
        ).upper()

    else:
        file_name = None

    return file_name, err_msg
