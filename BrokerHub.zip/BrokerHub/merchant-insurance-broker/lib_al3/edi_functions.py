al3_groups = [
    "1MHG161",
    "2TCG135",
    "2TCG240",
    "2TRG240",
    "3MTG240",
    "5AMI240",
    "5AOI240",
    "5ATT240",
    "5BIS240",
    "5BNG240",
    "5BPI240",
    "5CHG240",
    "5CNR240",
    "5EFT240",
    "5FOR240",
    "5ICG240",
    "5ISI240",
    "5LAG240",
    "5LHG240",
    "5MOH240",
    "5NAG240",
    "5OIC240",
    "5PAY240",
    "5PIG240",
    "5PPH240",
    "5RMK240",
    "5SLC240",
    "5SNG240",
    "6ACH240",
    "6BKS240",
    "6CAF240",
    "6COM240",
    "6CVH240",
    "6CVS240",
    "6HRU240",
    "6IIG240",
    "6IVC240",
    "6NTL240",
    "6ODI240",
    "6PAH240",
    "6PPI240",
    "6PPS240",
    "6REP240",
    "6SAC240",
    "6SAD240",
    "6SAH240",
    "6SAP240",
    "6SAV240",
    "6TRL240",
    "6WAI240",
    "6WOI240",
    "6WSG240",
    "9ACH240",
    "9AOI240",
    "9BIS240",
    "9SAD240",
    "9SAV240",
    "9BKS240",
    "9CVS240",
    "9LHG240",
    "6UVG240",
    "9HRU240",
    "9PAH240",
    "7SAV240",
    "7SAD240",
    "6MEM240",
    "5PTS113",
    "2IDA240",
    "9LAG240",
    "9ISI240",
    "7CVS240",
    "5PSU138",
    "7BIS240",
    "6DOG240",
]


def convert_1mhg(edi_data):
    # Response Data
    return_data = {}
    char_index = 10

    sequence = {
        # "number": "01",
        "description": "Message Address (Origination)",
        # "length": 18,
        "value": edi_data[char_index : char_index + 18].strip(),
        # "csio_xpath": "$context/*/MessageAddressOrigination",
    }

    return_data["01"] = sequence
    char_index = char_index + 18
    sequence = {
        # "number": "02",
        "description": "Message Address (Destination)",
        # "length": 18,
        "value": edi_data[char_index : char_index + 18].strip(),
        # "csio_xpath": "SignonRq/SignonPswd/CustId/SPName",
    }

    return_data["02"] = sequence
    char_index = char_index + 18
    sequence = {
        # "number": "03",
        "description": "Contract Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "InsuranceSvcRq/*/Producer/ContractNumber",
    }

    return_data["03"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "04",
        "description": "Password (User)",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "SignonRq/SignonPswd/CustPswd",
    }

    return_data["04"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "05",
        "description": "System Type Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "$context/*/SystemTypeCode",
    }

    return_data["05"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "06",
        "description": "Interface Software Revision Level",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$context/*/InterfaceSoftwareRevisionLevel",
    }

    return_data["06"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "07",
        "description": "Message Sequence Number",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "InsuranceSvcRq/*/RqUID",
    }

    return_data["07"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "08",
        "description": "Message Transmission Date/Time",
        # "length": 13,
        "value": edi_data[char_index : char_index + 13].strip(),
        # "csio_xpath": "SignonRq/ClientDt",
    }

    return_data["08"] = sequence
    char_index = char_index + 13
    sequence = {
        # "number": "09",
        "description": "Count Unit Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/CountUnitCode",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Special Handling",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "",
    }

    return_data["10"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "11",
        "description": "Message Standard Revision Level",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "$context/*/MessageStandardRevisionLevel",
    }

    return_data["11"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "12",
        "description": "Transmission Status Flag",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/TransmissionStatusFlagCode",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Message Response Code",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["13"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "14",
        "description": "Error Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "",
    }

    return_data["14"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "15",
        "description": "Network Reference Number",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "",
    }

    return_data["15"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "16",
        "description": "Network Reserved for Future Use",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "",
    }

    return_data["16"] = sequence
    char_index = char_index + 20
    return return_data


def convert_2tcg(edi_data):
    # Response Data
    return_data = {}
    char_index = 135

    return return_data


def convert_2trg(edi_data):
    # Response Data
    return_data = {}
    char_index = 10

    sequence = {
        # "number": "01",
        "description": "CSIO Standard Version Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "$context/*/CSIOStandardVersionNumber",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Application Software Revision Level",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "SignonRq/ProxyClient/Version",
    }

    return_data["02"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "03",
        "description": "Transaction Image",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Automation Level",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/AutomationLevel",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Transaction Category",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "$context/*/TransactionCategory",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Policy Type Routing Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/PolicyTypeRoutingCode",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Line of Business Routing Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "InsuranceSvcRq/*/PersPolicy/LOBCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "08",
        "description": "Transaction Function",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "*/*[contains('HomePolicyModRq HomePolicyQuoteInqRq HomePolicyReissueRq HomePolicyRenewRq DwellValuationInqRq PersAutoPolicyAddRq PersAutoPolicyModRq PersAutoPolicyQuoteInqRq PersAutoPolicyReissueRq PersAutoPolicyRenewRq PolicyPartialImageCancelRq PolicyPartialImageReinstateRq PolicySyncRq', name(.))]",
    }

    return_data["08"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "09",
        "description": "Processing Cycle Status",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/ProcessingCycleStatus",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Initial Transaction Mode",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/InitialTransactionMode",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Special Response Option",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/SpecialResponseOption",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Error Processing Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/ErrorProcessingCode",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Formal Transaction Address (Sender)",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "$context/*/FormalTransactionAddressSender",
    }

    return_data["13"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "14",
        "description": "Informal Transaction Address (Sender)",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "$context/*/InformalTransactionAddressSender",
    }

    return_data["14"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "15",
        "description": "Formal Transaction Address (Recipient)",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "",
    }

    return_data["15"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "16",
        "description": "Informational Trans.Address (Recipient)",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "",
    }

    return_data["16"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "17",
        "description": "Special Handling",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "",
    }

    return_data["17"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "18",
        "description": "Origination Reference Information",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "InsuranceSvcRq/*/PersPolicy/PersApplicationInfo/InsuredInfo/NameAddress/ItemIdInfo",
    }

    return_data["18"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "19",
        "description": "Transaction Sequence Number",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "InsuranceSvcRq/RqUID",
    }

    return_data["19"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "20",
        "description": "Transaction Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "SignonRq/ClientDt",
    }

    return_data["20"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "21",
        "description": "Processing Cycle Number",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$context/*/ProcessingCycleNumber",
    }

    return_data["21"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "22",
        "description": "DATA ELEMENT NOT USED",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["22"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "23",
        "description": "Transaction Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "InsuranceSvcRq#TransactionEffectiveDt",
    }

    return_data["23"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "24",
        "description": "Response Automation Level",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "$context/*/ResponseAutomationLevel",
    }

    return_data["24"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "25",
        "description": "Cycle/Business Purpose",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "*/*[contains('HomePolicyModRq HomePolicyQuoteInqRq HomePolicyReissueRq HomePolicyRenewRq DwellValuationInqRq PersAutoPolicyAddRq PersAutoPolicyModRq PersAutoPolicyQuoteInqRq PersAutoPolicyReissueRq PersAutoPolicyRenewRq PolicyPartialImageCancelRq PolicyPartialImageReinstateRq PolicySyncRq', name(.))]",
    }

    return_data["25"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "26",
        "description": "Synchronization DataElement",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "",
    }

    return_data["26"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "27",
        "description": "Formal Transaction Address Suffix (Sender)",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["27"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "28",
        "description": "Formal Transaction Address Suffix (Recipient)",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["28"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "29",
        "description": "Province/State",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "InsuranceSvcRq/*/PersPolicy/ControllingStateProvCd",
    }

    return_data["29"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "30",
        "description": "Reason Amended Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "InsuranceSvcRs/Status",
    }

    return_data["30"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "31",
        "description": "Issuing Broker Flag",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "InsuranceSvcRq/*/PersPolicy/IssuingBrokerInd",
    }

    return_data["31"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 44,
        "value": edi_data[char_index : char_index + 44].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 44
    return return_data


def convert_3mtg(edi_data):
    # Response Data
    return_data = {}
    char_index = 10

    sequence = {
        # "number": "01",
        "description": "Total Data in Message",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "'00000000'",
    }

    return_data["01"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "02",
        "description": "Additional Data Flag",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "'0'",
    }

    return_data["02"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "03",
        "description": "Communications Text Flag",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "'0'",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Communications Text",
        # "length": 220,
        "value": edi_data[char_index : char_index + 220].strip(),
        # "csio_xpath": "",
    }

    return_data["04"] = sequence
    char_index = char_index + 220
    return return_data


def convert_5ami(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Association Membership Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "AssociationCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "03",
        "description": "Association / Club Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "AssociationNumber",
    }

    return_data["03"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "04",
        "description": "Membership Number",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "MembershipNumber",
    }

    return_data["04"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "05",
        "description": "Membership Effective Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "MembershipEffectiveDt",
    }

    return_data["05"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "06",
        "description": "Membership Expiration Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "MembershipExpirationDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 44,
        "value": edi_data[char_index : char_index + 44].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 44
    return return_data


def convert_5aoi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "02",
        "description": "Nature of Interest Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NatureOfInterestCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Interest Rank",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "InterestRank",
    }

    return_data["03"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "04",
        "description": "Interest is Payor Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PayorInd",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Additional/Other Interests Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "NameAddress/CommlName/CompanyName",
    }

    return_data["05"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "06",
        "description": "Policy Frequency Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PolicyFrequencyCd",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Policy Required/Issued Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PolicyRequiredIssuedCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Policy Date Required/Issued",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "PolicyRequiredIssuedDt",
    }

    return_data["08"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "09",
        "description": "Certificate Frequency Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CertificateFrequencyCd",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Certificate Required/Issued Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CertificateRequiredIssuedCd",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Certificate Date Required",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CertificateRequiredIssuedDt",
    }

    return_data["11"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "12",
        "description": "Bill Frequency Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "BillFrequencyCd",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Informational Billing",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "InformationalBillingInd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Interest Holder Account No.",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "AccountNumberId",
    }

    return_data["14"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "15",
        "description": "Interest End Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "InterestEndDt",
    }

    return_data["15"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "16",
        "description": "Amount Of Mortgage",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "MortgageAmt",
    }

    return_data["16"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "17",
        "description": "Institution Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "AccountNumberId",
    }

    return_data["17"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "18",
        "description": "Routing Number",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "AccountNumberId",
    }

    return_data["18"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "19",
        "description": "Type Of Coverage Interest",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CoverageInterestCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 88,
        "value": edi_data[char_index : char_index + 88].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 88
    return return_data


def convert_5att(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Attachment Type Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "AttachmentTypeCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "02",
        "description": "Attachment Description",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "AttachmentDesc",
    }

    return_data["02"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "03",
        "description": "Responsibility Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "AttachmentResponsibilityCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Additional Description",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "AttachmentDesc",
    }

    return_data["04"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "05",
        "description": "Status of Document",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "StatusOfDocumentCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 164,
        "value": edi_data[char_index : char_index + 164].strip(),
        # "csio_xpath": "StatusOfDocumentCd",
    }

    return_data["99"] = sequence
    char_index = char_index + 164
    return return_data


def convert_5bis(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Insured's Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "UnparsedName",
    }

    return_data["01"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "02",
        "description": "Company's ID for Insured",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "",
    }

    return_data["02"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "03",
        "description": "Agency's/Brokerage's ID for Insured",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "PersApplicationInfo/InsuredInfo/NameAddress/ItemIdInfo",
    }

    return_data["03"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "04",
        "description": "Legal Entity Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PersApplicationInfo/InsuredInfo/NameAddress/LegalEntityCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 88,
        "value": edi_data[char_index : char_index + 88].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 88
    return return_data


def convert_5bng(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Binder Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "EffectiveDtTime",
    }

    return_data["01"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "02",
        "description": "Binder Effective Time",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "EffectiveDtTime",
    }

    return_data["02"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "03",
        "description": "Binder Expiration Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ExpirationDtTime",
    }

    return_data["03"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "04",
        "description": "Binder Expiration Time",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ExpirationDtTime",
    }

    return_data["04"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "05",
        "description": "Binder Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "AgencyBinderNumber",
    }

    return_data["05"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "06",
        "description": "New Binder Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NewBinderInd",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Binder Purpose Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "BinderPurposeCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Document Used",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "FormNumber",
    }

    return_data["08"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "09",
        "description": "Non-Standard Conditions Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NonStandardConditionsInd",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Quote Valid Until Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "QuoteValidUntilDt",
    }

    return_data["10"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 142,
        "value": edi_data[char_index : char_index + 142].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 142
    return return_data


def convert_5bpi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Policy Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "PolicyNumber",
    }

    return_data["01"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "02",
        "description": "Billing Account Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "BillingAccountNumber",
    }

    return_data["02"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "03",
        "description": "Company Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "NAICCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "04",
        "description": "Line of Business Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "LOBCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "05",
        "description": "Line of Business Sub-code",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "LOBSubCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "06",
        "description": "Policy Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "EffectiveDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "07",
        "description": "Policy Expiration Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ExpirationDt",
    }

    return_data["07"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "08",
        "description": "Producer Sub-code",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "Producer/ProducerSubcode",
    }

    return_data["08"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "09",
        "description": "Original Policy Inception Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "OriginalInceptionDt",
    }

    return_data["09"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "10",
        "description": "Renewal Term",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "RenewalTerm",
    }

    return_data["10"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "11",
        "description": "Full Term Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "CurrentTermAmt/Amt",
    }

    return_data["11"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "12",
        "description": "Net Change Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NetChangeAmt/Amt",
    }

    return_data["12"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "13",
        "description": "Other Insurance with Company Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "OtherInsuranceWithCompanyCd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Signed By Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "SignedByCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Short Term Premium Method Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ShortTermPremiumMethodCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Billing Method Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "BillingMethodCd",
    }

    return_data["16"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "17",
        "description": "Payor Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PayorCd",
    }

    return_data["17"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "18",
        "description": "Language Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LanguageCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "19",
        "description": "Risk Bound Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '58']/YesNoCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "20",
        "description": "Document Handling Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MailToCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "Multiple Policy Discount Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MultiPolDiscCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Group Number",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "GroupId",
    }

    return_data["22"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "23",
        "description": "Lead Insurer Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "",
    }

    return_data["23"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "24",
        "description": "Insurance Cancelled/Declined/ Refused Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '23']/YesNoCd",
    }

    return_data["24"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "25",
        "description": "Previous Insurance Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '27']/YesNoCd",
    }

    return_data["25"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "26",
        "description": "Business Classification Code",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "CompanyProductCd|PartialPolicy/AccountNumberId",
    }

    return_data["26"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "27",
        "description": "Quote Id Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "QuoteInfo/CompanyQuoteNumber",
    }

    return_data["27"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "28",
        "description": "Non-Taxable FullTerm Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NonTaxableAmt",
    }

    return_data["28"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "29",
        "description": "Continuous Policy Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ContinuousInd",
    }

    return_data["29"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "30",
        "description": "Application Signed Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "SignedDt",
    }

    return_data["30"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 35,
        "value": edi_data[char_index : char_index + 35].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 35
    return return_data


def convert_5chg(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Charge Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "ChargeTypeCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Charge Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "EffectiveDt",
    }

    return_data["02"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "03",
        "description": "Account Month Designator",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "AccountMonthDt",
    }

    return_data["03"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "04",
        "description": "Amount",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NetChangeAmt/Amt | CurrentTermAmt/Amt",
    }

    return_data["04"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "05",
        "description": "Commission Rate",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CommisionRatePct",
    }

    return_data["05"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "06",
        "description": "Commission Rate for Sub-agent",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "SubProducerCommissionRatePct",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "07",
        "description": "Commission Rate 2",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CommissionRatePct",
    }

    return_data["07"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "08",
        "description": "Commission Rate 2 for Sub-agent",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "SubProducerCommissionRatePct",
    }

    return_data["08"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "09",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["09"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "10",
        "description": "Company Item Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["10"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "11",
        "description": "Group Item Category",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["11"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "12",
        "description": "Commission Amount",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "CommissionAmt",
    }

    return_data["12"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "13",
        "description": "Posting Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "PostingDt",
    }

    return_data["13"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "14",
        "description": "Non-taxable Amount",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NonTaxableAmt",
    }

    return_data["14"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 119,
        "value": edi_data[char_index : char_index + 119].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 119
    return return_data


def convert_5cnr(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Requester Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CancelNonRenewInfo/RequesterCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "02",
        "description": "Reason Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "CancelNonRenewInfo/CancelReasonCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Policy/Voucher Obtained Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CancelNonRenewInfo/CancelEvidenceObtainedCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Method Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CancelNonRenewInfo/CancellationTypeCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Subject to Audit Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CancelNonRenewInfo/SubjectToAuditInd",
    }

    return_data["05"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "06",
        "description": "Unearned Factor",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "CancelNonRenewInfo/UnearnedFactor",
    }

    return_data["06"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "07",
        "description": "THIS ELEMENT DELETED",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "",
    }

    return_data["07"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 189,
        "value": edi_data[char_index : char_index + 189].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 189
    return return_data


def convert_5eft(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Routing Number",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "AccountNumberInfo/TransitNumberId",
    }

    return_data["01"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "02",
        "description": "Institution Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "AccountNumberInfo/InstitutionIdNumber",
    }

    return_data["02"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "03",
        "description": "EFT Account Number",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "substring(AccountNumberInfo/AccountNumberId, 1, 12)",
    }

    return_data["03"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "04",
        "description": "Name on Account",
        # "length": 40,
        "value": edi_data[char_index : char_index + 40].strip(),
        # "csio_xpath": "AccountBankName",
    }

    return_data["04"] = sequence
    char_index = char_index + 40
    sequence = {
        # "number": "05",
        "description": "EFT Account Number Extension",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "substring(AccountNumberInfo/AccountNumberId, 13, 6)",
    }

    return_data["05"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 144,
        "value": edi_data[char_index : char_index + 144].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 144
    return return_data


def convert_5for(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "02",
        "description": "Form Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "FormNumber",
    }

    return_data["02"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "03",
        "description": "Form Name",
        # "length": 50,
        "value": edi_data[char_index : char_index + 50].strip(),
        # "csio_xpath": "FormName",
    }

    return_data["03"] = sequence
    char_index = char_index + 50
    sequence = {
        # "number": "04",
        "description": "Form Edition Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "EditionDt",
    }

    return_data["04"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "05",
        "description": "Form Data Area",
        # "length": 80,
        "value": edi_data[char_index : char_index + 80].strip(),
        # "csio_xpath": "FormDataArea",
    }

    return_data["05"] = sequence
    char_index = char_index + 80
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 61,
        "value": edi_data[char_index : char_index + 61].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 61
    return return_data


def convert_5icg(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_5isi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Insured's Date of Birth",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "InsuredInfo/BirthDt",
    }

    return_data["01"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "02",
        "description": "Insured's Occupation Class Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "InsuredInfo/OccupationClassCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Insured's Marital Status",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "InsuredInfo/MaritalStatusCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Insured's Years Employed",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "InsuredInfo/NumYrsEmployed",
    }

    return_data["04"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "05",
        "description": "Co-insured's Date of Birth",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CoInsuredInfo/BirthDt",
    }

    return_data["05"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "06",
        "description": "Co-insured's Occupation Class Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "CoInsuredInfo/OccupationClassCd",
    }

    return_data["06"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "07",
        "description": "Co-insured's Years Employed",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "CoInsuredInfo/NumYrsEmployed",
    }

    return_data["07"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "08",
        "description": "Years Known by Agent/Broker",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumYrsKnownByAgentBroker",
    }

    return_data["08"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "09",
        "description": "Previous Mailing Address Line1",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "PreviousAddress/Addr1",
    }

    return_data["09"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "10",
        "description": "Previous Mailing Address Line2",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "PreviousAddress/Addr2",
    }

    return_data["10"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "11",
        "description": "Previous Mailing Address City",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "PreviousAddress/City",
    }

    return_data["11"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "12",
        "description": "Previous Mailing Address Province",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PreviousAddress/StateProvCd",
    }

    return_data["12"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "13",
        "description": "Business New to Office Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../QuestionAnswer[normalize-space(QuestionCd) = '01']/YesNoCd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Special Circumstances",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../QuestionAnswer[normalize-space(QuestionCd) = '02']/YesNoCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Insured's Employer Code",
        # "length": 11,
        "value": edi_data[char_index : char_index + 11].strip(),
        # "csio_xpath": "InsuredInfo/EmployerCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 11
    sequence = {
        # "number": "16",
        "description": "Co-insured's Employer Code",
        # "length": 11,
        "value": edi_data[char_index : char_index + 11].strip(),
        # "csio_xpath": "CoInsuredInfo/EmployerCd",
    }

    return_data["16"] = sequence
    char_index = char_index + 11
    sequence = {
        # "number": "17",
        "description": "Insured's Occupation Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "InsuredInfo/OccupationCd",
    }

    return_data["17"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "18",
        "description": "Co-insured's Occupation Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "CoInsuredInfo/OccupationCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "19",
        "description": "Commercial Vehicle Operator Record Number",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "",
    }

    return_data["19"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "20",
        "description": "Insured Owns a Property (Home/Condo",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ResidenceOwnedRentedCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "Previous Mailing Address Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "PreviousAddress/PostalCode",
    }

    return_data["21"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "22",
        "description": "Country",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "PreviousAddress/CountryCd",
    }

    return_data["22"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "23",
        "description": "Date Insured by Agent/Broker",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "KnownSinceDt",
    }

    return_data["23"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "24",
        "description": "Year First Insured",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "FirstInsuredDt",
    }

    return_data["24"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 42,
        "value": edi_data[char_index : char_index + 42].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 42
    return return_data


def convert_5lag(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "LocationIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Street Address Line1",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "Addr1",
    }

    return_data["02"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "03",
        "description": "Street Address Line2",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "Addr2",
    }

    return_data["03"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "04",
        "description": "City",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "City",
    }

    return_data["04"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "05",
        "description": "Province Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "StateProvCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "PostalCode",
    }

    return_data["06"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "07",
        "description": "County",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "County",
    }

    return_data["07"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "08",
        "description": "Tax Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "TaxCd",
    }

    return_data["08"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "09",
        "description": "Town Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "CountyTownCd",
    }

    return_data["09"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "10",
        "description": "Company Location Number",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "LocationIdInfo/FixedId",
    }

    return_data["10"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "11",
        "description": "Country",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "CountryCd",
    }

    return_data["11"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 80,
        "value": edi_data[char_index : char_index + 80].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 80
    return return_data


def convert_5lhg(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "THIS ELEMENT DELETED",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["01"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "02",
        "description": "Loss Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "LossDt",
    }

    return_data["02"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "03",
        "description": "Basic Loss Type (Coverage Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "CoverageCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "04",
        "description": "Line of Business Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "LOBCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "05",
        "description": "Line of Business Sub-Code",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "LOBSubCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "06",
        "description": "Loss Location Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossLocationCd",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Loss Location Number",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "LocationIdInfo/ItemId",
    }

    return_data["07"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "08",
        "description": "Loss Location Description",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "LossLocationDesc",
    }

    return_data["08"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "09",
        "description": "Kind of Loss #1 Amount Paid",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "TotalPaidAmt[1]",
    }

    return_data["09"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "10",
        "description": "Probable Amount Incurred",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "ProbableIncurredAmt",
    }

    return_data["10"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "11",
        "description": "Claim Settled Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ClaimSettledInd",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Loss Description",
        # "length": 80,
        "value": edi_data[char_index : char_index + 80].strip(),
        # "csio_xpath": "LossDesc",
    }

    return_data["12"] = sequence
    char_index = char_index + 80
    sequence = {
        # "number": "13",
        "description": "Kind Of Loss Code #1",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "LossTypeCd[1]",
    }

    return_data["13"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "14",
        "description": "Kind of Loss Code #2",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "LossTypeCd[2]",
    }

    return_data["14"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "15",
        "description": "Kind of Loss #2 Amount Paid",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "TotalPaidAmt[2]",
    }

    return_data["15"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "16",
        "description": "Kind of Loss Code #3",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "LossTypeCd[3]",
    }

    return_data["16"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "17",
        "description": "Kind of Loss #3 Amount Paid",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "TotalPaidAmt[3]",
    }

    return_data["17"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "18",
        "description": "Claim File Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "ClaimFileNum",
    }

    return_data["18"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "19",
        "description": "Company Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "LossCompanyCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "20",
        "description": "Fixed Identifier",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["20"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 0,
        "value": edi_data[char_index : char_index + 0].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 0
    return return_data


def convert_5moh(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Year",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemDefinition/ModelYear",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Make",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ItemDefinition/Manufacturer",
    }

    return_data["02"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "03",
        "description": "Model",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ItemDefinition/Model",
    }

    return_data["03"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "04",
        "description": "Identifier/Serial Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "ItemDefinition/SerialIdNumber",
    }

    return_data["04"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "05",
        "description": "Purchase Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "Dwell/PurchaseDt",
    }

    return_data["05"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "06",
        "description": "New When Purchased Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PurchasedNewInd",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Purchase Price",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "CostNewAmt",
    }

    return_data["07"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "08",
        "description": "With Contents Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "WithContentsInd",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Tie Down Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "TieDownCd",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Length",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "Length",
    }

    return_data["10"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "11",
        "description": "Width",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "Width",
    }

    return_data["11"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "12",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Mobile Home Park Name",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "NameOfMobileHomePark",
    }

    return_data["13"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "14",
        "description": "Installation/Foundation Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "FoundationCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Addition Area",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "AdditionArea",
    }

    return_data["16"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "17",
        "description": "Porch/Deck Area",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "DeckInfo",
    }

    return_data["17"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "18",
        "description": "Value of Contents Included in Purchase Price",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "ContentsValueAmt",
    }

    return_data["18"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "19",
        "description": "Arctic Insulation Package Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ArcticInsulationInd",
    }

    return_data["19"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "20",
        "description": "Skirt Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "SkirtTypeCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "CSA Approved Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CSAApprovedInd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Detachment from Other Buildings Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DetachmentFromOtherBldgInd",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Distance to Nearest Building",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DistanceToNearestBldg",
    }

    return_data["23"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "24",
        "description": "Registered/Licensed Park Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MobileHomeInParkInd",
    }

    return_data["24"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "25",
        "description": "Park Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ParkTypeCd",
    }

    return_data["25"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "26",
        "description": "Number of Lots in Mobile Home Park",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "NumPermSpacesMobileHomePark",
    }

    return_data["26"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 57,
        "value": edi_data[char_index : char_index + 57].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 57
    return return_data


def convert_5nag(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier for Vehicle",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Name and Address Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NameAddressTypeCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "NameAddress",
    }

    return_data["03"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "04",
        "description": "Street Address Line1",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "Addr1",
    }

    return_data["04"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "05",
        "description": "Street Address Line2",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "Addr2",
    }

    return_data["05"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "06",
        "description": "City",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "City",
    }

    return_data["06"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "07",
        "description": "Province/State Abbreviation",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "StateProvCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "08",
        "description": "Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "PostalCode",
    }

    return_data["08"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "09",
        "description": "Phone Type",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Phone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "HomePhone",
    }

    return_data["10"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "11",
        "description": "Phone Type",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Phone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "BusPhone",
    }

    return_data["12"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "13",
        "description": "Date of Birth",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["13"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "14",
        "description": "Country",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "CountryCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 13,
        "value": edi_data[char_index : char_index + 13].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 13
    return return_data


def convert_5oic(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Policy Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "PolicyNumber",
    }

    return_data["01"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "02",
        "description": "Company Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CarrierName",
    }

    return_data["02"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "03",
        "description": "Line of Business Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "LOBCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "04",
        "description": "Line of Business Subcode",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "LOBSubCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "05",
        "description": "Policy Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "EffectiveDt",
    }

    return_data["05"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "06",
        "description": "Policy Expiration Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ExpirationDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 158,
        "value": edi_data[char_index : char_index + 158].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 158
    return return_data


def convert_5pay(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Payment Plan Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PaymentPlanCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Day of Month Due/Preferred Day",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DayOfMonthDue",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Downpayment Amount",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "DepositAmt",
    }

    return_data["03"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "04",
        "description": "Percent Downpayment",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DownPaymentPercentage",
    }

    return_data["04"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "05",
        "description": "Number of Payments",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumPayments",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Number of Months between Payments",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumMonthsBetweenPayments",
    }

    return_data["06"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "07",
        "description": "DELETED ELEMENT",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["07"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "08",
        "description": "Installment / Percentage",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "InstallmentPercentage",
    }

    return_data["08"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "09",
        "description": "Downpayment Collected",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "CollectedByAgentAmt",
    }

    return_data["09"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "10",
        "description": "Method of Payment Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "MethodOfPaymentCd",
    }

    return_data["10"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "11",
        "description": "Credit Card Number",
        # "length": 16,
        "value": edi_data[char_index : char_index + 16].strip(),
        # "csio_xpath": "CreditCard/AccountNumberId",
    }

    return_data["11"] = sequence
    char_index = char_index + 16
    sequence = {
        # "number": "12",
        "description": "Credit Card Expiry Date",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "CreditCard/ExpirationDt",
    }

    return_data["12"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "13",
        "description": "Tax Exemption Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "TaxExemptionInd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Credit Card Holder's Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "CreditCard/AccountName",
    }

    return_data["14"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "15",
        "description": "Downpayment Cheque Number",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "CheckNumber",
    }

    return_data["15"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "16",
        "description": "Downpayment Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "ChequeDepositDt",
    }

    return_data["16"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "17",
        "description": "Next Withdrawal Amount",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NextWithdrawalAmt",
    }

    return_data["17"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "18",
        "description": "Next Withdrawal Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "NextWithdrawalDt",
    }

    return_data["18"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "19",
        "description": "Second Withdrawal Amount",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "SecondWithdrawalAmt",
    }

    return_data["19"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "20",
        "description": "Second Withdrawal Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "SecondWithdrawalDt",
    }

    return_data["20"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "21",
        "description": "Installment Fee",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "InstallmentFeeAmt",
    }

    return_data["21"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "22",
        "description": "Credit Card Company",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "CreditCard/CCCompanyCd",
    }

    return_data["22"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "23",
        "description": "Downpayment Method of Payment Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DepositMethodOfPaymentCd",
    }

    return_data["23"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "24",
        "description": "Electronic Payment Type Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "ElectronicFundsTransfer/ElectronicPaymentTypeCd",
    }

    return_data["24"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "25",
        "description": "Total Estimated",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "../TotalEstimatedAmt/Amt",
    }

    return_data["25"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 2
    return return_data


def convert_5pig(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Line of Business Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["01"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "02",
        "description": "Line of Business Subcode",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["02"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "03",
        "description": "Full Term Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "",
    }

    return_data["03"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "04",
        "description": "PMA Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["04"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "05",
        "description": "Company Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["05"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "06",
        "description": "Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "t",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "07",
        "description": "Company Product Code",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["07"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 170,
        "value": edi_data[char_index : char_index + 170].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 170
    return return_data


def convert_5pph(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Company Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "NAICCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "02",
        "description": "Company Name",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "CarrierName",
    }

    return_data["02"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "03",
        "description": "Policy Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "PolicyNumber",
    }

    return_data["03"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "04",
        "description": "Prior Policy Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PolicyTerminatedCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Policy Transfer Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PolicyTransferInd",
    }

    return_data["05"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "06",
        "description": "Termination Date of Prior Policy",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ExpirationDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "07",
        "description": "Claim History Report Status",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ClaimHistoryStatusCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "THIS ELEMENT DELETED",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["08"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "09",
        "description": "Line of Business Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "LOBSubCd",
    }

    return_data["09"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "10",
        "description": "Reason for Transfer Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ReasonForTransferCd",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Date Insured has had Insurance Since",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "OriginalInceptionDt",
    }

    return_data["11"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "12",
        "description": "Reason Policy Cancelled/Declined/Lapsed Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PolicyTerminatedCd",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Non-payment Details",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NonPaymentDetailCd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Claims History Report Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "ClaimHistoryReportDt",
    }

    return_data["14"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 118,
        "value": edi_data[char_index : char_index + 118].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 118
    return return_data


def convert_5rmk(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Data Element Referenced",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "@idRef",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Remarks Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "count(preceding::Remark) + 1",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Remarks Impact Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "'N'",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Remarks Text",
        # "length": 160,
        "value": edi_data[char_index : char_index + 160].strip(),
        # "csio_xpath": "RemarkText",
    }

    return_data["04"] = sequence
    char_index = char_index + 160
    sequence = {
        # "number": "05",
        "description": "Remarks Type Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RemarkTypeCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 43,
        "value": edi_data[char_index : char_index + 43].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 43
    return return_data


def convert_5slc(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "SubLocationIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Sublocation Description",
        # "length": 80,
        "value": edi_data[char_index : char_index + 80].strip(),
        # "csio_xpath": "SubLocationDesc",
    }

    return_data["02"] = sequence
    char_index = char_index + 80
    sequence = {
        # "number": "03",
        "description": "Company Sublocation Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "SubLocationIdInfo",
    }

    return_data["03"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 126,
        "value": edi_data[char_index : char_index + 126].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 126
    return return_data


def convert_5sng(edi_data):
    # Response Data
    return_data = {}

    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }
    return_data["01"] = sequence

    char_index = char_index + 2

    sequence = {
        # "number": "02",
        "description": "Name type Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }
    return_data["02"] = sequence

    char_index = char_index + 3

    sequence = {
        # "number": "03",
        "description": "Supplementary name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "",
    }
    return_data["03"] = sequence

    char_index = char_index + 60

    sequence = {
        # "number": "04",
        "description": "Legal entity code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }
    return_data["04"] = sequence

    char_index = char_index + 2

    sequence = {
        # "number": "05",
        "description": "DEC Name Group Sequence Number",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }
    return_data["05"] = sequence

    char_index = char_index + 1

    sequence = {
        # "number": "06",
        "description": "Date of Birth",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }
    return_data["06"] = sequence

    char_index = char_index + 8

    sequence = {
        # "number": "07",
        "description": "Employer Code",
        # "length": 11,
        "value": edi_data[char_index : char_index + 11].strip(),
        # "csio_xpath": "",
    }
    return_data["07"] = sequence

    char_index = char_index + 11

    sequence = {
        # "number": "08",
        "description": "Occupation Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }
    return_data["08"] = sequence

    char_index = char_index + 3

    sequence = {
        # "number": "09",
        "description": "Relationship to Applicant Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }
    return_data["09"] = sequence

    return return_data


def convert_6ach(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier for Vehicle",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "VehicleIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Percentage Responsibility",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "PercentResp",
    }

    return_data["02"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "03",
        "description": "Fixed Identifier for Driver",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DriverIdInfo/FixedId",
    }

    return_data["03"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "04",
        "description": "Driver's Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60],
        # "csio_xpath": "/CSIO/InsuranceSvcRq/*/*/PersDriver[DriverIdInfo/FixedId = $current-accident/DriverIdInfo/FixedId]/UnparsedName",
    }

    return_data["04"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "05",
        "description": "Accident/Claim Description",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "AccidentViolationDesc",
    }

    return_data["05"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "06",
        "description": "Chargeable Acc./Claim TP/BI",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/Coverage/CoverageCd[.='TPBI']",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Chargeable Acc./Claim TP/PD",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/Coverage/CoverageCd[.='TPPD']",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Chargeable Acc./Claim Acc.Ben.",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/Coverage/CoverageCd[.='AB']",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Chargeable Acc./Claim Collision",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/Coverage/CoverageCd[.='COL']",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Chargeable Acc./Claim OPD",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/Coverage/CoverageCd[.='CMP']",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11a",
        "description": "Chargeable Acc./Claim DCPD",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/Coverage/CoverageCd[.='TPDC']",
    }

    return_data["11a"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11b",
        "description": "Reserved for Future Use",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "",
    }

    return_data["11b"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "11c",
        "description": "Direct Comp. Prop. Damage Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LossPayment[Coverage/CoverageCd[.='TPDC']]/LossPaymentAmt/Amt",
    }

    return_data["11c"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "12",
        "description": "Third Party Bodily Injury Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LossPayment[Coverage/CoverageCd[.='TPBI']]/LossPaymentAmt/Amt",
    }

    return_data["12"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "13",
        "description": "Third Party Property Damage Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LossPayment[Coverage/CoverageCd[.='TPPD']]/LossPaymentAmt/Amt",
    }

    return_data["13"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "14",
        "description": "Accident Benefits Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LossPayment[Coverage/CoverageCd[.='AB']]/LossPaymentAmt/Amt",
    }

    return_data["14"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "15",
        "description": "Collision Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LossPayment[Coverage/CoverageCd[.='COL']]/LossPaymentAmt/Amt",
    }

    return_data["15"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "16",
        "description": "Other Physical Damage Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LossPayment[Coverage/CoverageCd[.='CMP']]/LossPaymentAmt/Amt",
    }

    return_data["16"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "17",
        "description": "Reserved For Future Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["17"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "18",
        "description": "Date of Loss",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "AccidentViolationDt",
    }

    return_data["18"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "19",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["19"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "20",
        "description": "Kind of Loss Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "21",
        "description": "Company Code",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CompanyCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 0,
        "value": edi_data[char_index : char_index + 0].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 0
    return return_data


def convert_6bks(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_6caf(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_6com(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_6cvh(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Coverage Code (Habitational",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "DiscountSurchargeFactorCd|CoverageCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "02",
        "description": "Coverage Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CreditSurchargeDt|EffectiveDt",
    }

    return_data["02"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "03",
        "description": "Coverage Expiration Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ExpirationDt",
    }

    return_data["03"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "04",
        "description": "Percent of Coinsurance",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["04"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "05",
        "description": "Rate",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "Rate",
    }

    return_data["05"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "06",
        "description": "Full Term Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "CurrentTermAmt | NumericValue/FormatCurrencyAmt",
    }

    return_data["06"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "07",
        "description": "Net Change Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NetChangeAmt",
    }

    return_data["07"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "08",
        "description": "Occurrence Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["08"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "09",
        "description": "Form Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "Form/FormNumber",
    }

    return_data["09"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "10",
        "description": "Form Edition Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "Form/Editiondt",
    }

    return_data["10"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "11",
        "description": "Limit",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "Limit/FormatCurrencyAmt/Amt",
    }

    return_data["11"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "12",
        "description": "First Deductible",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "Deductible[1]/FormatCurrencyAmt/Amt",
    }

    return_data["12"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "13",
        "description": "Second Deductible",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "Deductible[2]/FormatCurrencyAmt/Amt",
    }

    return_data["13"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "14",
        "description": "First Deductible Type Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "Deductible[1]/DeductibleTypeCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "15",
        "description": "Second Deductible Type Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "Deductible[2]/DeductibleTypeCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "16",
        "description": "Number Of",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Option[1]/OptionValue",
    }

    return_data["16"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "17",
        "description": "First Type Of",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "Limit/ValuationCd",
    }

    return_data["17"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "18",
        "description": "Second Type Of",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "Limit/LimitAppliesToCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "19",
        "description": "Third Type Of",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "Option[2]/OptionCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "20",
        "description": "Fourth Type Of",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "Option[3]/OptionCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "21",
        "description": "Territory Zone",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "TerritoryCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "22",
        "description": "Yes/No Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Option/OptionValue",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Numeric Value DataElement",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "NumericValue/FormatPercentage",
    }

    return_data["23"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "24",
        "description": "Description DataElement",
        # "length": 72,
        "value": edi_data[char_index : char_index + 72].strip(),
        # "csio_xpath": "CoverageDesc",
    }

    return_data["24"] = sequence
    char_index = char_index + 72
    sequence = {
        # "number": "25",
        "description": "Subscription Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["25"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 16,
        "value": edi_data[char_index : char_index + 16].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 16
    return return_data


def convert_6cvs(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_6hru(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Habitational Coverage Form Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PolicyTypeCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Construction Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Construction/ConstructionTypeCd[1]",
    }

    return_data["02"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "03",
        "description": "Year Built",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "Construction/YearBuilt",
    }

    return_data["03"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "04",
        "description": "Number of Families",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/NumFamilies",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Number of Rooms",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellOccupancy/NumRooms",
    }

    return_data["05"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "06",
        "description": "Replacement Cost",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "DwellInspectionValuation/EstimatedReplCostAmt",
    }

    return_data["06"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "07",
        "description": "Risk Structure Type Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellOccupancy/ResidenceTypeCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "08",
        "description": "Occupancy Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellOccupancy/DwellUseCd",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Dwelling Rented to Others",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellOccupancy/NumWeeksRentedToOthers",
    }

    return_data["09"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "10",
        "description": "Territory Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "DwellRating/TerritoryCd",
    }

    return_data["10"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "11",
        "description": "Premium Table",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellRating/PremiumGroup",
    }

    return_data["11"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "12A",
        "description": "Hydrant Distance Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/DistanceToHydrantCd",
    }

    return_data["12A"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12B",
        "description": "THIS ELEMENT DELETED",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["12B"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "13",
        "description": "Hydrant Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellStateSupplement/HydrantTypeCd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14A",
        "description": "Fire Hall Distance Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/DistanceToFireStationCd",
    }

    return_data["14A"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14B",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["14B"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Rating Method Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellRating/RatingMethodCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Fire/EC Rate",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "DwellRating/FireECRate",
    }

    return_data["16"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "17",
        "description": "Number of Units",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellOccupancy/NumApartments",
    }

    return_data["17"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "18",
        "description": "OL&T Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellRating/OLAndTCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "19",
        "description": "Responding Fire Hall",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "Location/FireDistrict",
    }

    return_data["19"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "20",
        "description": "Protectional Device Code (Fire",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/ProtectionalDeviceFireCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "Protectional Device Code (Burglar",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/ProtectionalDeviceBurglarCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Protectional Device Code (Smoke",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/ProtectionalDeviceSmokeCd",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Protectional Device Indicator (Sprinkler",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/ProtectionalDeviceSprinklerCd",
    }

    return_data["23"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "24",
        "description": "Swimming Pool Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "SwimmingPool/AboveGroundInd",
    }

    return_data["24"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "25",
        "description": "Maximum Depth of Swimming Pool",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "SwimmingPool/MaxDepth",
    }

    return_data["25"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "26",
        "description": "Electrical Wiring Code/Year",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "concat(BldgImprovements/WiringImprovementCd, substring(BldgImprovements/WiringImprovementYear,3,2))",
    }

    return_data["26"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "27",
        "description": "Plumbing Code/Year",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "concat(BldgImprovements/PlumbingImprovementCd, substring(BldgImprovements/PlumbingImprovementYear,3,2))",
    }

    return_data["27"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "28",
        "description": "Heating Code/Year",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "concat(BldgImprovements/HeatingImprovementCd, substring(BldgImprovements/HeatingImprovementYear,3,2))",
    }

    return_data["28"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "29",
        "description": "Primary Heating Apparatus Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/HeatSourcePrimaryCd",
    }

    return_data["29"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "30",
        "description": "Primary Fuel Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/FuelTypeCd",
    }

    return_data["30"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "31",
        "description": "Primary Heating Apparatus Installation Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '21']/YesNoCd",
    }

    return_data["31"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "32",
        "description": "Roof Code/Year",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "concat(BldgImprovements/RoofingImprovementCd, substring(BldgImprovements/RoofingImprovementYear,3,2))",
    }

    return_data["32"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "33",
        "description": "Under Construction Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '04']/YesNoCd",
    }

    return_data["33"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "34",
        "description": "Business Conducted on Premises Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '56']/YesNoCd",
    }

    return_data["34"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "35",
        "description": "Number of Full Time Residence Employees",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NumEmployeesFullTimeResidence",
    }

    return_data["35"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "36",
        "description": "Auxiliary Heating Apparatus Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/HeatSourceSupplementalCd",
    }

    return_data["36"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "37",
        "description": "Auxiliary Fuel Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/AuxFuelTypeCd",
    }

    return_data["37"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "38",
        "description": "Auxiliary Heating Apparatus Installation Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '53']/YesNoCd",
    }

    return_data["38"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "39",
        "description": "Residence Condition Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HousekeepingConditionCd",
    }

    return_data["39"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "40",
        "description": "Premises Access Security Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellProtection/ProtectionalDeviceOtherCd",
    }

    return_data["40"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "41",
        "description": "Rooms Rented to Others",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellOccupancy/NumRoomsRented",
    }

    return_data["41"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "42",
        "description": "Company Product Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "PersPolicy/CompanyProductCd",
    }

    return_data["42"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "43",
        "description": "Construction Type Code2",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Construction/ConstructionTypeCd[1]",
    }

    return_data["43"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "44",
        "description": "Construction Type Code3",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Construction/ConstructionTypeCd[2]",
    }

    return_data["44"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "45",
        "description": "Construction Type Code4",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Construction/ConstructionTypeCd[3]",
    }

    return_data["45"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "46",
        "description": "Construction Type Code5",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Construction/ConstructionTypeCd[4]",
    }

    return_data["46"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "47",
        "description": "Other Major Renovation",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "concat(BldgImprovements/OtherImprovementCd, substring(BldgImprovements/OtherImprovementYear,3,2))",
    }

    return_data["47"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "48",
        "description": "Type of Business/Mercantile",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PublicOfficeInd",
    }

    return_data["48"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "49",
        "description": "Electric Service Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ElectricalPanelCd",
    }

    return_data["49"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "50",
        "description": "Electric Number of Amps Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ElectricNumOfAmpsCd",
    }

    return_data["50"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "51",
        "description": "Plumbing Percentage Copper",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellInspectionValuation/InteriorFinishInfo/PercentOfMaterial[1]",
    }

    return_data["51"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "52",
        "description": "Plumbing Percentage Plastic",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellInspectionValuation/InteriorFinishInfo/PercentOfMaterial[2]",
    }

    return_data["52"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "53",
        "description": "Plumbing Percentage Other",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellInspectionValuation/InteriorFinishInfo/PercentOfMaterial[3]",
    }

    return_data["53"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "54",
        "description": "Electric Rad. Heat Ceiling Size",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellInspectionValuation/ElectricRadHeatCeilingInfo/HeatCeilingSize",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Electric Rad. Heat Ceiling Make",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "DwellInspectionValuation/ElectricRadHeatCeilingInfo/HeatCeilingMake",
    }

    return_data["55"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "56",
        "description": "Electric Rad. Heat Ceiling Year",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/ElectricRadHeatCeilingInfo/HeatCeilingYear",
    }

    return_data["56"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "57",
        "description": "Number of Outbuildings",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumOtherStructures",
    }

    return_data["57"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "58",
        "description": "Outbuilding Type of Use Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellInspectionValuation/DetachedStructures/Outbuilding/TypeOfUseCd",
    }

    return_data["58"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "59",
        "description": "Outbuilding Const. Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/DetachedStructures/Outbuilding/ConstructionTypeCd",
    }

    return_data["59"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "60",
        "description": "Outbuilding Heating Apparatus",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/DetachedStructures/Outbuilding/HeatingApparatusCd",
    }

    return_data["60"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "61",
        "description": "Outbuilding Fuel Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/DetachedStructures/Outbuilding/FuelTypeCd",
    }

    return_data["61"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "62",
        "description": "Outbuilding Value",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "OtherStructureAmt/Amt",
    }

    return_data["62"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "63",
        "description": "Date Property Seen By Broker",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DwellInspectionValuation/InspectionDt",
    }

    return_data["63"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "64",
        "description": "Number of Boarders/Roomers",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellOccupancy/NumBoarders",
    }

    return_data["64"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "65",
        "description": "Owner Occupies a Unit  Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellOccupancy/OwnerOccupiesUnitInd",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "66",
        "description": "Electrical Wiring Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "WiringTypeCd",
    }

    return_data["66"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "67",
        "description": "Occupancy Year",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellOccupancy/YearOfOccupancy",
    }

    return_data["67"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 36,
        "value": edi_data[char_index : char_index + 36].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 36
    return return_data


def convert_6iig(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Inspection Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "DwellInspectionValuation/InspectionDt",
    }

    return_data["01"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "02",
        "description": "Area",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "DwellInspectionValuation/TotalArea",
    }

    return_data["02"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "03",
        "description": "Inspection Report Source Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/InspectionReportSourceCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Photograph Obtained Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/PhotographObtainedInd",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Market Value",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "DwellInspectionValuation/MarketValueAmt",
    }

    return_data["05"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "06",
        "description": "Market Value Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "DwellInspectionValuation/MarketValueDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "07",
        "description": "Purchase Price",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "DwellInspectionValuation/PurchasePriceAmt",
    }

    return_data["07"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "08",
        "description": "Purchase Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "PurchaseDt",
    }

    return_data["08"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "09",
        "description": "Replacement Cost",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "DwellInspectionValuation/EstimatedReplCostAmt",
    }

    return_data["09"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "10",
        "description": "Replacement Cost Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "DwellInspectionValuation/DwellValuationDt",
    }

    return_data["10"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "11",
        "description": "Construction Quality Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Construction/CarrierConstructionClassCd",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Inspection Source",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "DwellInspectionValuation/NameAddress[string-length(.) > 0] | DwellInspectionValuation/ValuationProviderCd[string-length(.) > 0]",
    }

    return_data["12"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 126,
        "value": edi_data[char_index : char_index + 126].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 126
    return return_data


def convert_6ivc(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Number of Storeys Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DwellInspectionValuation/NumStoriesInDwellingCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "Ground Floor Area",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/GroundFloorArea",
    }

    return_data["02"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "03",
        "description": "Number of Extra Full Bathrooms",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/BathroomInfo/NumBathrooms",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Number of Half Bathrooms",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/BathroomInfo/NumBathrooms",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Bathrooms - Extra Fixtures",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/BathroomInfo/ExtraFixtures",
    }

    return_data["05"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "06",
        "description": "Finished Attic Area",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/FinishedAtticArea",
    }

    return_data["06"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "07",
        "description": "Finished Basement Area",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/SubstructureInfo/PercentOfGroundFloor",
    }

    return_data["07"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "08",
        "description": "Porch/Deck Type & Construction",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/DeckInfo/DeckTypeCd",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Porch/Deck Area",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/DeckInfo/SurfaceArea",
    }

    return_data["09"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "10",
        "description": "Number of Fireplaces - Inside Chimney",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/FireplaceInfo/NumFireplaces",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Number of Fireplaces - Outside Chimney",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/FireplaceInfo/NumFireplaces",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Number of Extra Fireplaces",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/FireplaceInfo/NumFireplaces",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Prefabricated Metal Fireplaces",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/FireplaceInfo/NumFireplaces",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Prefabricated Fireplace Inserts",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/FireplaceInfo/NumFireplaces",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Air Conditioning Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/AirConditioningCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Garage Size",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/GarageInfo/NumVehs",
    }

    return_data["16"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "17",
        "description": "Garage Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/GarageInfo/GarageTypeCd",
    }

    return_data["17"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "18",
        "description": "Roof Covering Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/RoofMaterialCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "19",
        "description": "Solarium/Sunroom Area",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/SunroomArea",
    }

    return_data["19"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "20",
        "description": "Swimming Pool - Size",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "SwimmingPool/PoolSizeCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "Swimming Pool - Construction",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "SwimmingPool/PoolConstructionCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Number of Saunas",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/NumOfSaunas",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Number of Wood Burning Stoves",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/NumOfWoodBurningStoves",
    }

    return_data["23"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "24",
        "description": "Heat Pump Heating Sys.Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(Explanation) = 'HeatPumpHeatingSystem']/YesNoCd",
    }

    return_data["24"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "25",
        "description": "Central Vacuum Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '05']/YesNoCd",
    }

    return_data["25"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "26",
        "description": "Security and Fire Alarm",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '06']/YesNoCd",
    }

    return_data["26"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "27",
        "description": "Smoke Alarm(s",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/SmokeAlarmNum",
    }

    return_data["27"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "28",
        "description": "Basic Intercom System",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '07']/YesNoCd",
    }

    return_data["28"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "29",
        "description": "Automatic Garage Door Openers",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DwellInspectionValuation/GarageInfo/GarageDoorOpenerNum",
    }

    return_data["29"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "30",
        "description": "Basement Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '08']/YesNoCd",
    }

    return_data["30"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "31",
        "description": "Other Features Type",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "DwellInspectionValuation/OtherFeaturesType",
    }

    return_data["31"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "32",
        "description": "Other Features Type Amount",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "DwellInspectionValuation/OtherFeaturesTypeAmt",
    }

    return_data["32"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "33",
        "description": "Ground Area W/O Basement",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DwellInspectionValuation/GroundFoolrArea",
    }

    return_data["33"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "34",
        "description": "% Of Type 1 Exter. Wall Const.",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellInspectionValuation/ExteriorWallMaterialInfo/ConstructionType1Pct",
    }

    return_data["34"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "35",
        "description": "% Of Type 2 Exter. Wall Const.",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellInspectionValuation/ExteriorWallMaterialInfo/ConstructionType2Pct",
    }

    return_data["35"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "36",
        "description": "% Of Type 3 Exter. Wall Const.",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DwellInspectionValuation/ExteriorWallMaterialInfo/ConstructionType3Pct",
    }

    return_data["36"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "37",
        "description": "Total Living Area",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["37"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "38",
        "description": "Foundation Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["38"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "39",
        "description": "Finished Basement Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["39"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "40",
        "description": "Interior Wall Construction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["40"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "41",
        "description": "Interior Wall Construction Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["41"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "42",
        "description": "Interior Wall Construction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["42"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "43",
        "description": "Interior Wall Construction Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["43"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "44",
        "description": "Interior Wall Construction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["44"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "45",
        "description": "Interior Wall Construction Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["45"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "46",
        "description": "Interior Floor Finish",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["46"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "47",
        "description": "Interior Floor Finish Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["47"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "48",
        "description": "Interior Floor Finish",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["48"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "49",
        "description": "Interior Floor Finish Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["49"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "50",
        "description": "Interior Floor Finish",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["50"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "51",
        "description": "Interior Floor Finish Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["51"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "52",
        "description": "Ceiling Construction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["52"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "53",
        "description": "Ceiling Construction Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["53"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "54",
        "description": "Ceiling Construction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Ceiling Construction Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["55"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "56",
        "description": "Ceiling Construction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["56"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "57",
        "description": "Ceiling Construction Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["57"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "58",
        "description": "Interior Wall Height",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["58"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "59",
        "description": "Interior Wall Height Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["59"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "60",
        "description": "Interior Wall Height",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["60"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "61",
        "description": "Interior Wall Height Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["61"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "62",
        "description": "Interior Wall Height",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["62"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "63",
        "description": "Interior Wall Height Percentage",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["63"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "64",
        "description": "Number of Kitchens",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["64"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "65",
        "description": "Kitchen 1 Quality",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "66",
        "description": "Kitchen 2 Quality",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["66"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "67",
        "description": "Number of Full Bathrooms",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["67"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "68",
        "description": "Impact Resistance Class",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["68"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "69",
        "description": "Roof Geometry Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["69"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 43,
        "value": edi_data[char_index : char_index + 43].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 43
    return return_data


def convert_6ntl(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_6odi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier for Driver",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Company Driver's Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["02"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "03",
        "description": "Class",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RateClassCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "04",
        "description": "Driving Record/Third Party Liability",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecTPBI",
    }

    return_data["04"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "05",
        "description": "Driving Record/Physical Damage",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecColl",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Conviction/Accident Surcharge",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Coverage/CreditOrSurcharge/NumericValue/FormatPercentage",
    }

    return_data["06"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "07",
        "description": "Driving Record/ Third Party Liability-Property Damage",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecTPPD",
    }

    return_data["07"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "08",
        "description": "Driving Record/Accident Benefits",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecAB",
    }

    return_data["08"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "09",
        "description": "Occurrence Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["09"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 188,
        "value": edi_data[char_index : char_index + 188].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 188
    return return_data


def convert_6pah(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HeatingUnitInfo/ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Primary/Auxiliary Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/PrimaryAuxCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "03",
        "description": "Certified",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '09']/YesNoCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "04",
        "description": "Type of Manufacture",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ManufactureTypeCd",
    }

    return_data["04"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "05",
        "description": "Name of Manufacturer",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "HeatingUnitInfo/ManufacturerName",
    }

    return_data["05"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "06",
        "description": "Type Of Installation",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/InstallationType",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Type of Combustion",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/CombustionTypeCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Frequency Of Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/FrequencyOfUseCd",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Distance From Back Wall",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/DistFromWall",
    }

    return_data["09"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "10",
        "description": "Wall Protection",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '10']/YesNoCd",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Floor Protection",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '11']/YesNoCd",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Attached To Primary Heating Unit",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '12']/YesNoCd",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Pipe Clearing Distance From Wall",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/PipeClearingDistFromWall",
    }

    return_data["13"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "14",
        "description": "Pipe Attached Direct. To Chimney",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '13']/YesNoCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Chimney Type",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/ChimneyTypeCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Chimney Used By Other Htg. Units",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '14']/YesNoCd",
    }

    return_data["16"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "17",
        "description": "Frequency Of Chimney Cleaning/Yr",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyCleaning/ChimneyCleaningPerYr",
    }

    return_data["17"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "18",
        "description": "Frequency Of Pipe Cleaning/Yr",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyCleaning/PipeCleaningPerYr",
    }

    return_data["18"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "19",
        "description": "Non-flammable Ash Container Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '15']/YesNoCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "20",
        "description": "Inspected By Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/InspectedByCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "No. of Face Cords Used Annually",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "HeatingUnitInfo/NumOfFaceCordsUsedPerYr",
    }

    return_data["21"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "22",
        "description": "Pipe Through Flammable Partition",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '16']/YesNoCd",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Location",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/HeatingUnitLocationCd",
    }

    return_data["23"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "24",
        "description": "Pipe Clearance from Ceiling",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distane/PipeClearenceFromCeiling",
    }

    return_data["24"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "25",
        "description": "Heating Unit Installation Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "HeatingUnitInfo/InstallationDt",
    }

    return_data["25"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "26",
        "description": "Ventilated Metal Collar Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '17']/YesNoCd",
    }

    return_data["26"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "27",
        "description": "Chimney Certification Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '18']/YesNoCd",
    }

    return_data["27"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "28",
        "description": "Floor Protection Beyond Rear of Stove",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/FloorProtection/BeyondRearOfStove",
    }

    return_data["28"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "29",
        "description": "Floor Protection Beyond Right Side of Stove",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/FloorProtection/BeyondRightOfStove",
    }

    return_data["29"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "30",
        "description": "Floor Protection Beyond Left Side of Stove",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/FloorProtection/BeyondLeftOfStove",
    }

    return_data["30"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "31",
        "description": "Floor Protection Beyond Front of Stove",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/FloorProtection/BeyondFrontOfStove",
    }

    return_data["31"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "32",
        "description": "Ash Container Equipped with a Metal Lid",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '19']/YesNoCd",
    }

    return_data["32"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "33",
        "description": "Ash Container Placed on Non- flammable Surface",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/QuestionAnswer[normalize-space(QuestionCd) = '20']/YesNoCd",
    }

    return_data["33"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "34",
        "description": "Oil Tank Location",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Dwell/OilStorageTankLocationCd",
    }

    return_data["34"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "35",
        "description": "Year of the Oil Tank",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HeatingUnitInfo/OilTankYrDt",
    }

    return_data["35"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "36",
        "description": "Certifying Entity",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/CertifyingEntityCd",
    }

    return_data["36"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "37",
        "description": "Heating Apparatus Installation",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/HeatingApparatusInstallationCd",
    }

    return_data["37"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "38",
        "description": "Name of Installer of Double Walled Metal Chimney",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "HeatingUnitInfo/InstallerName",
    }

    return_data["38"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "39",
        "description": "Distance From Floor",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/DistFromFloor",
    }

    return_data["39"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "40",
        "description": "Distance From Ceiling",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/DistFromCeiling",
    }

    return_data["40"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "41",
        "description": "Distance From Side Wall",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/DistFromSideWall",
    }

    return_data["41"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "42",
        "description": "Distance to Combustible Material",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/DistToCombustibleMaterial",
    }

    return_data["42"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "43",
        "description": "Length of Stove Pipe",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/StovePipeLength",
    }

    return_data["43"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "44",
        "description": "Oil Tank Status Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/OilTankStatusCd",
    }

    return_data["44"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "45",
        "description": "Chimney Lining Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/LiningCd",
    }

    return_data["45"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "46",
        "description": "Year Chimney Built/Installed",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/YearBuilt",
    }

    return_data["46"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "47",
        "description": "Location of Chimney Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/UnitLocationCd",
    }

    return_data["47"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "48",
        "description": "Chimney Last Cleaning Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyCleaning/LastCleanedDt",
    }

    return_data["48"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "49",
        "description": "Chimney Cleaned By Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyCleaning/ProfessionallyCleanedInd",
    }

    return_data["49"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "50",
        "description": "No. of Hours per Day",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "HeatingUnitInfo/NumHoursPerDay",
    }

    return_data["50"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "51",
        "description": "No. of Days per Year",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/NumDaysPerYear",
    }

    return_data["51"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "52",
        "description": "Fuel Usage Other Than Wood",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HeatingUnitInfo/NumUnitsOtherThanWood",
    }

    return_data["52"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "53",
        "description": "Fuel Measurement Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/UnitMeasurementCd",
    }

    return_data["53"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "54",
        "description": "Year of Heating Unit Manufacture",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HeatingUnitInfo/YearBuilt",
    }

    return_data["54"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "55",
        "description": "Chimney Flue Rated Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/FlueRatedInd",
    }

    return_data["55"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "56",
        "description": "Shortest Distance of Stovepipe to Corner",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/PipeDistanceToCorner",
    }

    return_data["56"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "57",
        "description": "Shortest Distance of Stovepipe to Backwall",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/PipeDistToBackwall",
    }

    return_data["57"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "58",
        "description": "Stove Pipe Construction Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/PipeConstructionCd",
    }

    return_data["58"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "59",
        "description": "No. of Elbows in Stove Pipe",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimenyInfo/NumStovePipeElbows",
    }

    return_data["59"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "61",
        "description": "Construction Type of Backwall Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/SurroundingConstructionInfo/BackwallConstructionCd",
    }

    return_data["61"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "62",
        "description": "Construction Type of Ceiling Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/SurroundingConstructionInfo/CeilingConstructionCd",
    }

    return_data["62"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "63",
        "description": "Wett Certified Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/WettCertifiedInd",
    }

    return_data["63"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "64",
        "description": "Pipe Through Concealed Space Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ChimneyInfo/ConcealedSpaceInd",
    }

    return_data["64"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "65",
        "description": "Non-combustible Pad Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/NonCombustiblePadInd",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "66",
        "description": "Shielding Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ShieldInfo/ShieldTypeCd",
    }

    return_data["66"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "67",
        "description": "Shield Permanently Installed Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/PermanentlyInstalledInd",
    }

    return_data["67"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "68",
        "description": "Shield Distance to Wall",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance#ShieldDistToWall",
    }

    return_data["68"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "69",
        "description": "Shield Distance to Top of Stove",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance#ShieldDistToStoveTop",
    }

    return_data["69"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "70",
        "description": "Shield Distance to Floor",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "HeatingUnitInfo/Distance/ShieldDistToFloor",
    }

    return_data["70"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "71",
        "description": "Wall Spacers Non-combustible Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/WallSpacersNonCombustibleInd",
    }

    return_data["71"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "72",
        "description": "Shield One inch from Wall Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ShieldOneInchAwayInd",
    }

    return_data["72"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "73",
        "description": "Air Space Top and Bottom Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/AirSpaceInd",
    }

    return_data["73"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "74",
        "description": "Modifications since Installation indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HeatingUnitInfo/ModifiedInd",
    }

    return_data["74"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 8
    return return_data


def convert_6ppi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemDefinition/ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Serial Number",
        # "length": 15,
        "value": edi_data[char_index : char_index + 15].strip(),
        # "csio_xpath": "ItemDefinition/SerialIdNumber",
    }

    return_data["02"] = sequence
    char_index = char_index + 15
    sequence = {
        # "number": "03",
        "description": "Item Description",
        # "length": 150,
        "value": edi_data[char_index : char_index + 150].strip(),
        # "csio_xpath": "ItemDefinition/ItemDesc",
    }

    return_data["03"] = sequence
    char_index = char_index + 150
    sequence = {
        # "number": "04",
        "description": "Valuation Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "SalesReceiptAppraisal/SalesReceiptAppraisalDt",
    }

    return_data["04"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "05",
        "description": "Item Value",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ItemValueAmt",
    }

    return_data["05"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "06",
        "description": "Professional/Business Use Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PropertyScheduleModifications/ProfessionalCommercialUseInd",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "07",
        "description": "Exhibited Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PropertyScheduleModifications/ExhibitedInd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Company Item Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["08"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 24,
        "value": edi_data[char_index : char_index + 24].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 24
    return return_data


def convert_6pps(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Property Class Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PropertyClassCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Total Items Per Summary Group",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "NumItemsPerSummary",
    }

    return_data["03"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "04",
        "description": "Total Value Per Summary Group",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "ItemValueAmt",
    }

    return_data["04"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 192,
        "value": edi_data[char_index : char_index + 192].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 192
    return return_data


def convert_6rep(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_6sac(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Coverage Code (Automobile",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "DiscountSurchargeFactorCd|CoverageCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "02",
        "description": "Coverage Effective Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CreditSurchargeDt|EffectiveDt",
    }

    return_data["02"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "03",
        "description": "Coverage Expiration Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ExpirationDt",
    }

    return_data["03"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "04",
        "description": "Percent of Coinsurance - *Data element not used in the Standards",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["04"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "05",
        "description": "Rate",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "Rate",
    }

    return_data["05"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "06",
        "description": "Full Term Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "CurrentTermAmt/Amt|NumericValue/FormatCurrencyAmt",
    }

    return_data["06"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "07",
        "description": "Net Change Premium",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "NetChangeAmt",
    }

    return_data["07"] = sequence
    char_index = char_index + 12
    sequence = {
        # "number": "08",
        "description": "Occurrence Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["08"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "09",
        "description": "Form Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "Form/FormNumber",
    }

    return_data["09"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "10",
        "description": "Form Edition Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "Form/EditionDt",
    }

    return_data["10"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "11",
        "description": "Limit1",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "Limit[1]/FormatCurrencyAmt/Amt",
    }

    return_data["11"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "12",
        "description": "Limit2",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "Limit[2]/FormatCurrencyAmt/Amt",
    }

    return_data["12"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "13",
        "description": "Deductible Amount",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "Deductible/FormatCurrencyAmt",
    }

    return_data["13"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "14",
        "description": "Numeric Value",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "NumericValue/FormatPercentage",
    }

    return_data["14"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "15",
        "description": "Optional Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Option/OptionCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "16",
        "description": "Description",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "CoverageDesc",
    }

    return_data["16"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "17",
        "description": "Yes/No Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Option/OptionValue",
    }

    return_data["17"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 46,
        "value": edi_data[char_index : char_index + 46].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 46
    return return_data


def convert_6sad(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index: char_index + 4].strip(),
        # "csio_xpath": "DriverIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Company Driver's Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DriverIdInfo/ItemId",
    }

    return_data["02"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "03",
        "description": "Driver's Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60],
        # "csio_xpath": "UnparsedName",
    }

    return_data["03"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "04",
        "description": "Driver's License Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "License[1]/DriversLicenseNumber",
    }

    return_data["04"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "05",
        "description": "Licensed Jurisdiction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "License[1]/LicensedStateProvCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Date of Birth",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "BirthDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "07",
        "description": "Driver Sex Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "GenderCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Non-licensed Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '30']/YesNoCd",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Years Licensed #1",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "License[1]/LicensedDt",
    }

    return_data["09"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "10",
        "description": "THIS ELEMENT DELETED",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["10"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "11",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Years Licenced #2",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "License[2]/LicensedDt",
    }

    return_data["12"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "13",
        "description": "THIS ELEMENT DELETED",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["13"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "14",
        "description": "Restricted Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "RestrictedInd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Driver Marital Status Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MaritalStatusCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Driver Relationship to Applicant",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DriverRelationshipToApplicantCd",
    }

    return_data["16"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "17",
        "description": "Driver/Non-driver Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '31']/YesNoCd",
    }

    return_data["17"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "18",
        "description": "Driver Training Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DriverTrainingCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "19",
        "description": "Good Student Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "GoodStudentCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "20",
        "description": "Student Grade Codes",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "YoungDriverSupplement/HighSchoolGradeAverage",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "Distant Driver Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '32']/YesNoCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Disability Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '33']/YesNoCd",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Defensive Driver Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DefensiveDriverCd",
    }

    return_data["23"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "24",
        "description": "Defensive Driver Date",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DefensiveDriverDt",
    }

    return_data["24"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "25",
        "description": "Senior Citizen Discount Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '34']/YesNoCd",
    }

    return_data["25"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "26",
        "description": "License Suspended/Cancelled/ Lapsed Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '35']/YesNoCd",
    }

    return_data["26"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "27",
        "description": "Reason License Suspended/ Cancelled/Lapsed Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "SuspensionRevocationReasonCd",
    }

    return_data["27"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "28",
        "description": "Insurance Cancelled/Declined/ Refused Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '23']/YesNoCd",
    }

    return_data["28"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "29",
        "description": "Driver Occupation Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "OccupationCd",
    }

    return_data["29"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "30A",
        "description": "Driver Grid Level",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "DriverGridLevel",
    }

    return_data["30A"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "30B",
        "description": "Grid Level Determination Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "GridLevelDeterminationDt",
    }

    return_data["30B"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "30C",
        "description": "Prior Insurer Grid Level",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "PriorInsurerGridLevel",
    }

    return_data["30C"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "30D",
        "description": "Grid Conviction /Accident Surcharge",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "CreditOrSurcharge/GridConvictionAccidentSurcharge",
    }

    return_data["30D"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "31",
        "description": "Date Hired",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HiredDt",
    }

    return_data["31"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "32",
        "description": "Number of Years Known by Agent/Broker",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "../../PersPolicy/PersApplicationInfo/NumYrsPrincipalDriverKnownByAgentBroker",
    }

    return_data["32"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "33",
        "description": "Financial Responsibility",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "FilingCd",
    }

    return_data["33"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "34",
        "description": "Filing Province",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "FilingStateProvCd",
    }

    return_data["34"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "35",
        "description": "Date First Licensed  in Canada for License Class Code #1",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "License[1]/FirstLicensedCurrentStateDt",
    }

    return_data["35"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "36",
        "description": "Date First Licensed  in Canada for License Class Code #2",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "License[2]/FirstLicensedCurrentStateDt",
    }

    return_data["36"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "37",
        "description": "License Class Code #1",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "License[1]/LicenseClassCd",
    }

    return_data["37"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "38",
        "description": "License Class Code #2",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "License[2]/LicenseClassCd",
    }

    return_data["38"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "39",
        "description": "Date of MVR",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "MVRDt",
    }

    return_data["39"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "40",
        "description": "Non-smoker Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '36']/YesNoCd",
    }

    return_data["40"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "41",
        "description": "Proof of Preferred Driver Qualification Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '42']/YesNoCd",
    }

    return_data["41"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "42",
        "description": "Date Driver Has Owned Vehicle",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "VehicleOwnerDt",
    }

    return_data["42"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "43",
        "description": "Employer Code",
        # "length": 11,
        "value": edi_data[char_index : char_index + 11].strip(),
        # "csio_xpath": "EmployerCd",
    }

    return_data["43"] = sequence
    char_index = char_index + 11
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 0,
        "value": edi_data[char_index : char_index + 0].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 0
    return return_data


def convert_6sah(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Conviction Date",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ConvictionDt",
    }

    return_data["01"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "02",
        "description": "Conviction Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "ConvictionCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "03",
        "description": "Number of",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumberOf",
    }

    return_data["03"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "04",
        "description": "History Number",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["04"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "05",
        "description": "DELETED DATA ELEMENT",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["05"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "06",
        "description": "Reason License Suspended/Cancelled/Lapsed Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["06"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 190,
        "value": edi_data[char_index : char_index + 190].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 190
    return return_data


def convert_6sap(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "THIS ELEMENT DELETED",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["01"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "02",
        "description": "THIS ELEMENT DELETEDe",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "",
    }

    return_data["02"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "03",
        "description": "THIS ELEMENT DELETED",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "",
    }

    return_data["03"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "04",
        "description": "THIS ELEMENT DELETED",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "",
    }

    return_data["04"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "05",
        "description": "THIS ELEMENT DELETED",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Total Number of Licensed Drivers in Household",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PersApplicationInfo/NumLicensedResidents",
    }

    return_data["06"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "07",
        "description": "Total Number of Vehicles in Household",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PersApplicationInfo/NumVehsInHousehold",
    }

    return_data["07"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "08",
        "description": "Number of Non-licensed Residents",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PersApplicationInfo/NumNonLicensedResidents",
    }

    return_data["08"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "09",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Registered Owner Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../PersAutoLineOfBusiness/PersVehicle[1]/QuestionAnswer[normalize-space(QuestionCd) = '43']/YesNoCd",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Other Drivers in Household Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../PersAutoLineOfBusiness/PersVehicle[1]/QuestionAnswer[normalize-space(QuestionCd) = '44']/YesNoCd",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Drivers Qualified Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../PersAutoLineOfBusiness/PersVehicle[1]/QuestionAnswer[normalize-space(QuestionCd) = '45']/YesNoCd",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Material Misrepresentation Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../PersAutoLineOfBusiness/PersVehicle[1]/QuestionAnswer[normalize-space(QuestionCd) = '46']/YesNoCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Fraud Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "../PersAutoLineOfBusiness/QuestionAnswer[normalize-space(QuestionCd) = '47']/YesNoCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Average Number of Automobiles",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["16"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "17",
        "description": "Average Value of Each Automobile",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["17"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "18",
        "description": "Maximum Number of Automobiles",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "d",
    }

    return_data["18"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "19",
        "description": "Maximum Collective Value",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["19"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "20",
        "description": "Value of the Most Expensive Unit",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["20"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "21",
        "description": "Maximum Number of Buses/Charter Service",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["21"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 83,
        "value": edi_data[char_index : char_index + 83].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 83
    return return_data


def convert_6sav(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Company Vehicle Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "VehicleIdInfo/ItemId",
    }

    return_data["01"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "02",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "VehicleIdInfo/FixedId",
    }

    return_data["02"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "03",
        "description": "Vehicle Code",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "VehicleSymbolCd",
    }

    return_data["03"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "04",
        "description": "Vehicle Year",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ModelYear",
    }

    return_data["04"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "5A",
        "description": "Vehicle Make",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "Manufacturer",
    }

    return_data["5A"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "5B",
        "description": "Vehicle Model",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "Model",
    }

    return_data["5B"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "06",
        "description": "Vehicle Body Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "VehicleBodyTypeCd",
    }

    return_data["06"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "07",
        "description": "V.I.N. (Serial Number",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "VehicleIdentificationNumber",
    }

    return_data["07"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "08",
        "description": "Number of Cylinders",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumCylinders",
    }

    return_data["08"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "09",
        "description": "Displacement",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "HorsepowerDisplacement",
    }

    return_data["09"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "10",
        "description": "Date Purchased",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "PurchaseDt",
    }

    return_data["10"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "11",
        "description": "New/Used Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NewUsedCd",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Purchase Price",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "PurchasePriceAmt",
    }

    return_data["12"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "13",
        "description": "List Price New",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "CostNewAmt",
    }

    return_data["13"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "14",
        "description": "Gross Vehicle Weight",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "GrossVehOrCombinedWeight",
    }

    return_data["14"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "15",
        "description": "Licensed Province/State",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RegistrationStateProvCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "16",
        "description": "Garage Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "GaragingCd",
    }

    return_data["16"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "17",
        "description": "Territory",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "TerritoryCd",
    }

    return_data["17"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "18",
        "description": "Town Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "TownCd",
    }

    return_data["18"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "19",
        "description": "Location",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "LocationCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "20",
        "description": "Class",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RateClassCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "21",
        "description": "Sub-class Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "RateSubClassCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Driving Record/Third Party Liability",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecTPBI",
    }

    return_data["22"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "23",
        "description": "Driving Record/Physical Damage",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecColl",
    }

    return_data["23"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "24",
        "description": "Vehicle Rate Group",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RateGroupColl",
    }

    return_data["24"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "25",
        "description": "Conviction/Accident Surcharge",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["25"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "26",
        "description": "Facility Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ResidualMarketFacilityInd",
    }

    return_data["26"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "27",
        "description": "Driver Number 1 Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$driver-vehicle-1/DriverIdInfo/FixedId",
    }

    return_data["27"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "28",
        "description": "Driver Number 1 Percent",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "$driver-vehicle-1/PercentOfUse",
    }

    return_data["28"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "29",
        "description": "Driver Number 2 Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$driver-vehicle-2/DriverIdInfo/FixedId",
    }

    return_data["29"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "30",
        "description": "Driver Number 2 Percent",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "$driver-vehicle-2/PercentOfUse",
    }

    return_data["30"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "31",
        "description": "Driver Number 3 Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$driver-vehicle-3/DriverIdInfo/FixedId",
    }

    return_data["31"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "32",
        "description": "Driver Number 3 Percent",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "$driver-vehicle-3/PercentOfUse",
    }

    return_data["32"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "33",
        "description": "Driver Number 4 Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$driver-vehicle-4/DriverIdInfo/FixedId",
    }

    return_data["33"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "34",
        "description": "Driver Number 4 Percent",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "$driver-vehicle-4/PercentOfUse",
    }

    return_data["34"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "35",
        "description": "Driver Number 5 Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "$driver-vehicle-5/DriverIdInfo/FixedId",
    }

    return_data["35"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "36",
        "description": "Driver Number 5 Percent",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "$driver-vehicle-5/PercentOfUse",
    }

    return_data["36"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "37",
        "description": "Vehicle Use Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "VehicleUseCd",
    }

    return_data["37"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "38",
        "description": "Commuting Distance",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "NumMilesOneWay",
    }

    return_data["38"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "39",
        "description": "Distance Driven Annually",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "EstimatedAnnualMileage",
    }

    return_data["39"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "40",
        "description": "Goods for Compensation",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '48']/YesNoCd",
    }

    return_data["40"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "41",
        "description": "Rent/Lease to Others Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '41']/YesNoCd",
    }

    return_data["41"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "42",
        "description": "Carry Passengers for Compensation",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '37']/YesNoCd",
    }

    return_data["42"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "43",
        "description": "Explosive/Radioactive Material Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '38']/YesNoCd",
    }

    return_data["43"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "44",
        "description": "Carpool Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CarpoolInd",
    }

    return_data["44"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "45",
        "description": "Number of Passengers",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumPassengers",
    }

    return_data["45"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "46",
        "description": "Anti-theft Device Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "AntiTheftDeviceCd",
    }

    return_data["46"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "47",
        "description": "Type Of Fuel Used",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "EngineTypeCd",
    }

    return_data["47"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "48",
        "description": "Modification Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "AlteredInd",
    }

    return_data["48"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "49",
        "description": "Value of Modification",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "AlterationsAmt",
    }

    return_data["49"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "50",
        "description": "Existing Unrepaired Damage Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ExistingUnrepairedDamageInd",
    }

    return_data["50"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "51",
        "description": "Multi-car Discount Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MultiCarDiscountInd",
    }

    return_data["51"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "52",
        "description": "Premium Deviation Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '39']/YesNoCd",
    }

    return_data["52"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "53",
        "description": "Tax",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "Tax",
    }

    return_data["53"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "54",
        "description": "Rating Plan Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RatingPlanId",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Driving Record/Third Party Liability-Property Damage",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecTPPD",
    }

    return_data["55"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "56",
        "description": "Driving Record/Accident Benefits",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecAB",
    }

    return_data["56"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "57",
        "description": "Vehicle Length",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "VehicleLength",
    }

    return_data["57"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "58",
        "description": "Towing Vehicle Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "TowingVehicleIdInfo/FixedId",
    }

    return_data["58"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 0,
        "value": edi_data[char_index : char_index + 0].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 0
    return return_data


def convert_6trl(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Vacation Travel Trailer Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "TravelTrailerTypeCd",
    }

    return_data["01"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "02",
        "description": "Make",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ItemDefinition/Manufacturer",
    }

    return_data["02"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "03",
        "description": "Model",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ItemDefinition/Model",
    }

    return_data["03"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "04",
        "description": "Length",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "Length",
    }

    return_data["04"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "05",
        "description": "Identification /Serial Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "ItemDefinition/SerialIdNumber",
    }

    return_data["05"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "06",
        "description": "Purchase Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "Dwell/PurchaseDt",
    }

    return_data["06"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "07",
        "description": "New When Purchased Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PurchasedNewInd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Purchase Price",
        # "length": 7,
        "value": edi_data[char_index : char_index + 7].strip(),
        # "csio_xpath": "PurchasePriceAmt",
    }

    return_data["08"] = sequence
    char_index = char_index + 7
    sequence = {
        # "number": "09",
        "description": "CSA Approved Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CSAApprovedInd",
    }

    return_data["09"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "10",
        "description": "Storage Location Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "StorageLocationCd",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "11",
        "description": "Licensed for Road Use Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "RoadLicensedInd",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "License Plate Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "LicencePlateNumber",
    }

    return_data["12"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "13",
        "description": "License Province State",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "LicensedStateProvCd",
    }

    return_data["13"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "14",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["14"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 105,
        "value": edi_data[char_index : char_index + 105].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 105
    return return_data


def convert_6wai(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemDefinition/ItemIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Watercraft Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PropulsionTypeCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "03",
        "description": "Year Built",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "ItemDefinition/ModelYear",
    }

    return_data["03"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "04",
        "description": "Make / Description",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "ItemDefinition/ItemDesc",
    }

    return_data["04"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "05",
        "description": "Identification /Serial Number",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ItemDefinition/SerialIdNumber",
    }

    return_data["05"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "06",
        "description": "Displacement",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "Capacity",
    }

    return_data["06"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "07",
        "description": "Horsepower",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Horsepower",
    }

    return_data["07"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "08",
        "description": "Length",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Length",
    }

    return_data["08"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "09",
        "description": "Speed",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Speed",
    }

    return_data["09"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "10",
        "description": "Navigation Period Begins",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "NavigationPeriod/BeginDt",
    }

    return_data["10"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "11",
        "description": "Navigation Period Ends",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "NavigationPeriod/EndDt",
    }

    return_data["11"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "12",
        "description": "Waters Navigated Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "WatersNavigatedCd",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Number of Operators Under 21 Years",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NumOperatorsUnder21Yrs",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Water Skiing Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '57']/YesNoCd",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Primary Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "WatercraftUseCd",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Item Value",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "PresentValueAmt",
    }

    return_data["16"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "17",
        "description": "Purchase Price",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "PurchasePriceAmt",
    }

    return_data["17"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "18",
        "description": "Company Item Number",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["18"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "19",
        "description": "Power Squadron Proficiency Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '55']/YesNoCd",
    }

    return_data["19"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "20",
        "description": "Watercraft Construction Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "HullMaterialTypeCd",
    }

    return_data["20"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "21",
        "description": "Sailing School Certificate Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '54']/YesNoCd",
    }

    return_data["21"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "22",
        "description": "Winter Location Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "WinterLocationCd",
    }

    return_data["22"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "23",
        "description": "Winter Location Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "WinterLocationPostalCode",
    }

    return_data["23"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "24",
        "description": "Mooring At Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MooringAtCd",
    }

    return_data["24"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "25",
        "description": "Mooring At Location Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "MooringAtPostalCode",
    }

    return_data["25"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "26",
        "description": "Principal Operator Fixed ID",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DriverIdInfo/FixedId",
    }

    return_data["26"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "27",
        "description": "Secondary Operator Fixed ID",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DriverIdInfo/FixedId",
    }

    return_data["27"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "28",
        "description": "Tertiary Operator Fixed ID",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "DriverIdInfo/FixedId",
    }

    return_data["28"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "29",
        "description": "Model",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ItemDefinition/Model",
    }

    return_data["29"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "30",
        "description": "Purchase Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "PurchaseDt",
    }

    return_data["30"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "31",
        "description": "New When Purchased Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PurchasedNewInd",
    }

    return_data["31"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "32",
        "description": "Value of Contents Included in Purchase Price",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "ContentsAmt",
    }

    return_data["32"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "33",
        "description": "Watercraft Style Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "WaterUnitTypeCd",
    }

    return_data["33"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "34",
        "description": "Watercraft Storage Details Type Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "StorageDetailCd",
    }

    return_data["34"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "35",
        "description": "Value of Non-standard Equipment",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "NonStandardEquipmentAmt",
    }

    return_data["35"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "36",
        "description": "License Plate Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "LicencePlateNumber",
    }

    return_data["36"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "37",
        "description": "Registration Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "RegistrationNumber",
    }

    return_data["37"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 12,
        "value": edi_data[char_index : char_index + 12].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 12
    return return_data


def convert_6woi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier Watercraft Operator",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "PersDriver/DriverIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Operator Name",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "PersDriver/NameAddress",
    }

    return_data["02"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "03",
        "description": "Date of Birth",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "PersDriver/BirthDt",
    }

    return_data["03"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "04",
        "description": "Driver's License Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "PersDriver/License[1]/DriverLicenseNumber",
    }

    return_data["04"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "05",
        "description": "Licensed Jurisdiction",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PersDriver/License[1]/LicenseStateProvCd",
    }

    return_data["05"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "06",
        "description": "Certificate Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "PersDriver/License[1]/DriverLicenseNumber",
    }

    return_data["06"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "07",
        "description": "Power Squadron Certificate Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '55']/YesNoCd",
    }

    return_data["07"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "08",
        "description": "Sailing School Certificate Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '54']/YesNoCd",
    }

    return_data["08"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "09",
        "description": "Date of MVR",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "PersDriver/MVRDt",
    }

    return_data["09"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "10",
        "description": "Canadian Coast Guard Pleasure Craft Operator Card Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PersDriver/CoastGuardOperatorCardInd",
    }

    return_data["10"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 75,
        "value": edi_data[char_index : char_index + 75].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 75
    return return_data


def convert_6wsg(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "01",
        "description": "Fixed Identifier",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "BoatIdInfo/FixedId",
    }

    return_data["01"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "02",
        "description": "Class Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "WaterUnitTypeCd",
    }

    return_data["02"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "03",
        "description": "Total Items Per Summary Group",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "NumUnits",
    }

    return_data["03"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "04",
        "description": "Total Value Per Summary Group",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "PresentValueAmt",
    }

    return_data["04"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 192,
        "value": edi_data[char_index : char_index + 192].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 192
    return return_data


def convert_9ach(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "51",
        "description": "Claim File Number",
        # "length": 20,
        "value": edi_data[char_index : char_index + 20].strip(),
        # "csio_xpath": "ClaimFileNum",
    }

    return_data["51"] = sequence
    char_index = char_index + 20
    sequence = {
        # "number": "52",
        "description": "Kind of Loss Code #1",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd[1]",
    }

    return_data["52"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "53",
        "description": "Kind of Loss #1 Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DamageTotalAmt[1]",
    }

    return_data["53"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "54",
        "description": "Kind of Loss Code #2",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd[2]",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Kind of Loss #2 Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DamageTotalAmt[2]",
    }

    return_data["55"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "56",
        "description": "Kind of Loss Code #3",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd[3]",
    }

    return_data["56"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "57",
        "description": "Kind of Loss #3 Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DamageTotalAmt[3]",
    }

    return_data["57"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "58",
        "description": "Kind of Loss Code #4",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd[4]",
    }

    return_data["58"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "59",
        "description": "Kind of Loss #4 Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DamageTotalAmt[4]",
    }

    return_data["59"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "60",
        "description": "Kind of Loss Code #5",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd[5]",
    }

    return_data["60"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "61",
        "description": "Kind of Loss #5 Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DamageTotalAmt[5]",
    }

    return_data["61"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "62",
        "description": "Kind of Loss Code #6",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AccidentViolationCd[6]",
    }

    return_data["62"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "63",
        "description": "Kind of Loss #6 Amount",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DamageTotalAmt[6]",
    }

    return_data["63"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "64",
        "description": "Claim Settled Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ClaimSettledInd",
    }

    return_data["64"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "65",
        "description": "Loss Coverage Portion Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "CoverageCd",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "66",
        "description": "Claim Forgiveness Applied Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ForgivenessAppliedInd",
    }

    return_data["66"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "67",
        "description": "Cause of Loss Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "LossCauseCd",
    }

    return_data["67"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "68",
        "description": "TP Claim Paid Back Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LossPayment/ClaimPaidBackCd",
    }

    return_data["68"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 123,
        "value": edi_data[char_index : char_index + 123].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 123
    return return_data


def convert_9aoi(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "51",
        "description": "Street Address Line1",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "NameAddress/Addr1",
    }

    return_data["51"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "52",
        "description": "Street Address Line2",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "NameAddress/Addr2",
    }

    return_data["52"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "53",
        "description": "City",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "NameAddress/City",
    }

    return_data["53"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "54",
        "description": "Province Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NameAddress/StateProvCd",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "NameAddress/PostalCode",
    }

    return_data["55"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "56",
        "description": "Telephone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "NameAddress/Phone",
    }

    return_data["56"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "57",
        "description": "Interest's Alternate Telephone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "NameAddress/AltPhone",
    }

    return_data["57"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "58",
        "description": "Town Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["58"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "59",
        "description": "Country",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "NameAddress/CountryCd",
    }

    return_data["59"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 84,
        "value": edi_data[char_index : char_index + 84].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 84
    return return_data


def convert_9bis(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "51",
        "description": "Street Address Line1",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "Addr1",
    }

    return_data["51"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "52",
        "description": "Street Address Line2",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "Addr2",
    }

    return_data["52"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "53",
        "description": "City",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "City",
    }

    return_data["53"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "54",
        "description": "Province/State Abbreviation",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "StateProvCd",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "PostalCode",
    }

    return_data["55"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "56",
        "description": "Insured's Telephone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "Phone",
    }

    return_data["56"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "57",
        "description": "Insured's Alternate Telephone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "AltPhone",
    }

    return_data["57"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "58",
        "description": "Town Code",
        # "length": 5,
        "value": edi_data[char_index : char_index + 5].strip(),
        # "csio_xpath": "",
    }

    return_data["58"] = sequence
    char_index = char_index + 5
    sequence = {
        # "number": "59",
        "description": "Fax Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "Fax",
    }

    return_data["59"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "60",
        "description": "Type of Business",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "BusinessTypeCd",
    }

    return_data["60"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "61",
        "description": "Country",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "CountryCd",
    }

    return_data["61"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "62",
        "description": "Privacy Act Consent Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PrivacyActConsentCd",
    }

    return_data["62"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 67,
        "value": edi_data[char_index : char_index + 67].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 67
    return return_data


def convert_9sad(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "51",
        "description": "Street Address Line1",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "NameAddress/Addr1",
    }

    return_data["51"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "52",
        "description": "Street Address Line2",
        # "length": 30,
        "value": edi_data[char_index : char_index + 30].strip(),
        # "csio_xpath": "NameAddress/Addr2",
    }

    return_data["52"] = sequence
    char_index = char_index + 30
    sequence = {
        # "number": "53",
        "description": "City",
        # "length": 19,
        "value": edi_data[char_index : char_index + 19].strip(),
        # "csio_xpath": "NameAddress/City",
    }

    return_data["53"] = sequence
    char_index = char_index + 19
    sequence = {
        # "number": "54",
        "description": "Province/State Abbrev.",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NameAddress/StateProvCd",
    }

    return_data["54"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "55",
        "description": "Postal Code",
        # "length": 9,
        "value": edi_data[char_index : char_index + 9].strip(),
        # "csio_xpath": "NameAddress/PostalCode",
    }

    return_data["55"] = sequence
    char_index = char_index + 9
    sequence = {
        # "number": "56",
        "description": "Driver's Telephone Number",
        # "length": 14,
        "value": edi_data[char_index : char_index + 14].strip(),
        # "csio_xpath": "NameAddress/Phone",
    }

    return_data["56"] = sequence
    char_index = char_index + 14
    sequence = {
        # "number": "57",
        "description": "Date First Licensed in Canada For License Class Code #3",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "License[3]/FirstLicensedCurrentStateDt",
    }

    return_data["57"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "58",
        "description": "License Class Code #3",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "License[3]/LicenseClassCd",
    }

    return_data["58"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "59A",
        "description": "Driver Training Code #2",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "DriverTrainingCd",
    }

    return_data["59A"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "59B",
        "description": "Driver Training Date #2",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DriverTrainingCompletionDt",
    }

    return_data["59B"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "59C",
        "description": "MVR Report Status",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "MVRReportStatusCd",
    }

    return_data["59C"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "59D",
        "description": "Driver Training Date #1",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "DriverTrainingCompletionDt",
    }

    return_data["59D"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "59E",
        "description": "Conviction Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PersApplicationInfo/AnyLossesAccidentsConvictionsInd",
    }

    return_data["59E"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "60",
        "description": "First Chance Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "FirstChanceInd",
    }

    return_data["60"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "60A",
        "description": "THIS ELEMENT DELETED",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["60A"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "61",
        "description": "SAAQ Authorization Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '49']/YesNoCd",
    }

    return_data["61"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "62",
        "description": "Date Driver Has Held Insurance License Class Code #1",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "ContInsuranceSinceDt",
    }

    return_data["62"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "63",
        "description": "Date Driver Has Held Insurance as Principal Operator License Class Code #1",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "ContPrincOpSinceDt",
    }

    return_data["63"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "64",
        "description": "Restriction Code #1",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "RestrictionCd",
    }

    return_data["64"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "65",
        "description": "Decl.for Retiree Discount Form Completed and Signed Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '50']/YesNoCd",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "66",
        "description": "Date of Prior Carrier Report",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "PriorCarrierReportDt",
    }

    return_data["66"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "67",
        "description": "Fainting Dizziness or Loss of Consciousness Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "QuestionAnswer[normalize-space(QuestionCd) = '51']/YesNoCd",
    }

    return_data["67"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "68",
        "description": "Credit for Years Licensed Outside Canada",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "CreditYearsNum",
    }

    return_data["68"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "69",
        "description": "Date Continuously Licensed From, Outside Canada",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "LicensedOutsideCountryDt",
    }

    return_data["69"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "70",
        "description": "Country Licensed In, Outside Canada",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "NonResidentLicenceCountryCd",
    }

    return_data["70"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "71",
        "description": "Recent Date Coverage Ceased",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "CoverageCeasedDt",
    }

    return_data["71"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "72",
        "description": "Months Without Coverage",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "NumMonthsWithoutCoverage",
    }

    return_data["72"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "73",
        "description": "Reason Coverage Ceased",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "ReasonCoverageCeasedCd",
    }

    return_data["73"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "74",
        "description": "Date Driver Has Held Insurance License Class Code #2",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["74"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "75",
        "description": "Date Driver Has Held Insurance License Class Code #3",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["75"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "76",
        "description": "Restriction Code #2",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "RestrictionCd",
    }

    return_data["76"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 1
    return return_data


def convert_9sav(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "61",
        "description": "Alternate Province/State Vehicle Used",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AltProvStateUsedCd",
    }

    return_data["61"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "62",
        "description": "Percentage Use in Alternate Province/State",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "AltProvStateUsedPct",
    }

    return_data["62"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "63",
        "description": "Distance Driven Annually for Occasional Business Use",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "BusinessAnnualMileage",
    }

    return_data["63"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "64",
        "description": "Vehicle Sub-code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "VehicleSubCd",
    }

    return_data["64"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "65",
        "description": "Reason TPL Coverage Declined Cd.",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "ReasonTPLDeclinedCd",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "66",
        "description": "Anti-theft Engraving Device Manufacturer Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AntiTheftEngravingDevMfgCd",
    }

    return_data["66"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "67",
        "description": "Anti-theft Product Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AntiTheftProductCd",
    }

    return_data["67"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "68",
        "description": "Vehicle Rate Group- Comp.",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RateGroupComp",
    }

    return_data["68"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "69",
        "description": "Vehicle Rate Group- Acc.Ben.",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RateGroupAB",
    }

    return_data["69"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "70",
        "description": "Vehicle Rate Group- Direct Comp",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "RateGroupDC",
    }

    return_data["70"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "71",
        "description": "Vehicle Pre-inspection",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "PreInspectionCd",
    }

    return_data["71"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "72",
        "description": "Taxi/Limo License Plate Number",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "TaxiLicensePlateNumber",
    }

    return_data["72"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "73",
        "description": "Reason Vehicle Pre-inspection Not Required",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "PreInspectionNotRequiredCd",
    }

    return_data["73"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "74",
        "description": "Driving Record/Direct Comp.",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "DrivingRecDCPD",
    }

    return_data["74"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "75",
        "description": "Width",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "VehicleWidth",
    }

    return_data["75"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "76",
        "description": "Facility - Tier Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "FacilityTierCd",
    }

    return_data["76"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "77",
        "description": "Refusing Carrier for Facility",
        # "length": 6,
        "value": edi_data[char_index : char_index + 6].strip(),
        # "csio_xpath": "RefusingCompanyCd",
    }

    return_data["77"] = sequence
    char_index = char_index + 6
    sequence = {
        # "number": "78",
        "description": "Facility - Tier Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "FacilityTierDt",
    }

    return_data["78"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "79",
        "description": "Vehicle Licensed Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "LicensedInd",
    }

    return_data["79"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "80",
        "description": "Vehicle License Plate Number",
        # "length": 10,
        "value": edi_data[char_index : char_index + 10].strip(),
        # "csio_xpath": "LicensePlateNumber",
    }

    return_data["80"] = sequence
    char_index = char_index + 10
    sequence = {
        # "number": "81",
        "description": "Anti-theft Electronic Immobilizer Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AntiTheftProductCd",
    }

    return_data["81"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "82",
        "description": "Anti-theft Audible Alarm Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AntiTheftProductCd",
    }

    return_data["82"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "83",
        "description": "Anti-theft Vehicle Tracking System Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "AntiTheftProductCd",
    }

    return_data["83"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "84",
        "description": "Grid Rated Driver Fixed ID",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "/DriverVehicle/GridDriverIdInfo/FixedId",
    }

    return_data["84"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "85",
        "description": "Grid Rated Occasional Driver Fixed ID",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "/DriverVehicle/GridYoungDriverIdInfo/FixedId",
    }

    return_data["85"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "86",
        "description": "Grid Rated Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "GridRatedInd",
    }

    return_data["86"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "87",
        "description": "Number of Days Use in Alternate Province/State",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "NumDaysDrivenPerYrAltProvState",
    }

    return_data["87"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "88",
        "description": "IBC Vehicle Model Description",
        # "length": 100,
        "value": edi_data[char_index : char_index + 100].strip(),
        # "csio_xpath": "Model",
    }

    return_data["88"] = sequence
    char_index = char_index + 100
    sequence = {
        # "number": "89",
        "description": "No Frills Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "NoFrillsInd",
    }

    return_data["89"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 28,
        "value": edi_data[char_index : char_index + 28].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 28
    return return_data


def convert_9bks(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_9cvs(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_9lhg(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "51",
        "description": "Claim Forgiveness Applied Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "Loss/ForgivenessAppliedInd",
    }

    return_data["51"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "52",
        "description": "Cause of Loss Code",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "Loss/LossCauseCd",
    }

    return_data["52"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "53",
        "description": "Policy Number",
        # "length": 25,
        "value": edi_data[char_index : char_index + 25].strip(),
        # "csio_xpath": "Loss/PolicyNumber",
    }

    return_data["53"] = sequence
    char_index = char_index + 25
    sequence = {
        # "number": "99",
        "description": "Reserved for Future Use",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["99"] = sequence
    char_index = char_index + 1
    return return_data


def convert_6uvg(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    return return_data


def convert_9hru(edi_data):
    # Response Data
    return_data = {}
    char_index = 30

    sequence = {
        # "number": "0",
        "description": "Monitored By",
        # "length": 60,
        "value": edi_data[char_index : char_index + 60].strip(),
        # "csio_xpath": "",
    }

    return_data["0"] = sequence
    char_index = char_index + 60
    sequence = {
        # "number": "1",
        "description": "Trampoline Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["1"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "2",
        "description": "Garden Tractor Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["2"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "3",
        "description": "Golf Cart Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["3"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "4",
        "description": "Unlicensed Recreational Vehicle Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["4"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "5",
        "description": "Motorized Wheelchair Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["5"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "6",
        "description": "Watercraft Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["6"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "7",
        "description": "Primary Heating Apparatus Location Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["7"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "8",
        "description": "Auxiliary Heating Apparatus Location Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["8"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "9",
        "description": "Smoke Detector Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["9"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "10",
        "description": "Access Code",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["10"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "11",
        "description": "Smoker(s) Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["11"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "12",
        "description": "Water Mitigation Measures in Place",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["12"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "13",
        "description": "Renewable Energy Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["13"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "14",
        "description": "Septic Tank Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["14"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "15",
        "description": "Superior Shuttle Tanker Service Ind.",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["15"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "16",
        "description": "Plumbing Percentage Galvanized",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["16"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "17",
        "description": "Sewer Back Up Prevention",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["17"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "18",
        "description": "Plumbing Percentage ABS",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["18"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "19",
        "description": "Plumbing Percentage PVC",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["19"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "20",
        "description": "Plumbing Percentage PEX",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["20"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "21",
        "description": "Plumbing Percentage POLB",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["21"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "22",
        "description": "Main Shut Off Sensors",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["22"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "23",
        "description": "Main Valve Shut Off Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["23"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "24",
        "description": "Door Lock Type Codes",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["24"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "25",
        "description": "Number of Bedrooms",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["25"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "26",
        "description": "Sump Pump Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["26"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "27",
        "description": "Sump Pump Auxiliary Power Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["27"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "28",
        "description": "Backflow Valve Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["28"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "29",
        "description": "Renewable Energy Type",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["29"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "30",
        "description": "Installation Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["30"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "31",
        "description": "Installation Location",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["31"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "32",
        "description": "Tied to Grid Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["32"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "33",
        "description": "Tracking Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["33"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "34",
        "description": "Leased Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["34"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "35",
        "description": "Electrical Strength",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["35"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "36",
        "description": "Item Value",
        # "length": 11,
        "value": edi_data[char_index : char_index + 11].strip(),
        # "csio_xpath": "",
    }

    return_data["36"] = sequence
    char_index = char_index + 11
    sequence = {
        # "number": "37",
        "description": "Pool Fenced Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["37"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "38",
        "description": "Number of Mortgages",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["38"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "39",
        "description": "Water Heater Year",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["39"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "40",
        "description": "Plumbing Percentage Lead",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["40"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "41",
        "description": "Water Heater Apparatus Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["41"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "42",
        "description": "Water Heater Fuel Type Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["42"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "43",
        "description": "Water Heater Professional Installation Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["43"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "44",
        "description": "Water Heater Approved by ULC/CSA/WH Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["44"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "45",
        "description": "Auxiliary Sump Pump Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["45"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "46",
        "description": "Auxiliary Sump Pump Auxiliary Power Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["46"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "47",
        "description": "Auxiliary Backflow Valve Type",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["47"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "48",
        "description": "Land Area",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["48"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "49",
        "description": "Sewer Back Up Questionnaire Completion Date",
        # "length": 8,
        "value": edi_data[char_index : char_index + 8].strip(),
        # "csio_xpath": "",
    }

    return_data["49"] = sequence
    char_index = char_index + 8
    sequence = {
        # "number": "50",
        "description": "Criminal Record Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["50"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "51",
        "description": "Spa Code",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["51"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "52",
        "description": "Maximum Depth of Spa",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["52"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "53",
        "description": "Spal Built/Installed Year",
        # "length": 4,
        "value": edi_data[char_index : char_index + 4].strip(),
        # "csio_xpath": "",
    }

    return_data["53"] = sequence
    char_index = char_index + 4
    sequence = {
        # "number": "54",
        "description": "Appartment in Basement Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["54"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "55",
        "description": "Overland Water Zone",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["55"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "56",
        "description": "Sewer Backup Zone",
        # "length": 3,
        "value": edi_data[char_index : char_index + 3].strip(),
        # "csio_xpath": "",
    }

    return_data["56"] = sequence
    char_index = char_index + 3
    sequence = {
        # "number": "57",
        "description": "Insured acting as Contractor Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["57"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "58",
        "description": "Number of Days Occupied Per Month",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["58"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "59",
        "description": "Number of Cannabis Plants",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["59"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "60",
        "description": "Products Sold Outside Canada Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["60"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "61",
        "description": "Internet Sales Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["61"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "62",
        "description": "Extinguishing Agent Codes",
        # "length": 2,
        "value": edi_data[char_index : char_index + 2].strip(),
        # "csio_xpath": "",
    }

    return_data["62"] = sequence
    char_index = char_index + 2
    sequence = {
        # "number": "63",
        "description": "Absentee Landlord Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["63"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "64",
        "description": "Property Manager Indicator",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["64"] = sequence
    char_index = char_index + 1
    sequence = {
        # "number": "65",
        "description": "Leak Detection Monitoring Type",
        # "length": 1,
        "value": edi_data[char_index : char_index + 1].strip(),
        # "csio_xpath": "",
    }

    return_data["65"] = sequence
    char_index = char_index + 1
    return return_data
