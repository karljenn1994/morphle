import json
import logging

from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_al3 import edi_functions
from lib_al3.edi_functions import al3_groups, convert_1mhg

log = logging.getLogger(LOGGER)


class AL3ToJSON(object):
    def __new__(cls, *args, **kwds):
        it = cls.__dict__.get("__it__")

        if it is not None:
            return it

        cls.__it__ = it = object.__new__(cls)
        it.init(*args, **kwds)
        return it

    def init(self):
        pass

    @staticmethod
    def load(file_name):
        return FileManagerFactory.create_file_manager().read_string(file_name, encoding="latin-1")

    @staticmethod
    def load_bytes(file_name):
        return FileManagerFactory.create_file_manager().read_file(file_name)

    @staticmethod
    def save_str(full_path, str):
        FileManagerFactory.create_file_manager().write_string(full_path, str)

    @staticmethod
    def save_map(full_path, al3_map):
        out_json = json.dumps(al3_map, ensure_ascii=False, indent=4, sort_keys=False)
        FileManagerFactory.create_file_manager().write_string(full_path, out_json)

    @staticmethod
    def delete(file_path):
        fm = FileManagerFactory.create_file_manager()
        fm.remove(file_path)

    @staticmethod
    def to_json(al3_string):
        al3_string = AL3ToJSON._run_length_decode(al3_string)
        al3_string = al3_string.replace("\r", "")
        al3_string = al3_string.replace("\n", "")
        al3_string = al3_string.replace("\x1d", "")
        al3_string = al3_string.replace("?", " ")
        current_index = 0
        policy = {}

        for group in al3_groups[1:]:
            al3_string = al3_string.replace(group, "\n" + group)

        records = al3_string.split("\n")
        records = [x for x in records if len(x.strip()) != 0]

        for record in records:
            header = AL3ToJSON._get_record_header(record)

            if len(record) > header["record_length"]:
                record = bytes(record, "iso-8859-1").decode("utf_8").encode("utf_8").decode("utf_8")

            if len(record) != header["record_length"]:
                raise AL3Exception("Bad record length")

            group = "convert_" + header["group_id"].lower()
            parts = {}

            if header["group_id"] != "1MHG":
                if callable(getattr(edi_functions, group, None)):
                    # safe to use the function
                    f = getattr(edi_functions, group)
                    parts = f(record)
                else:
                    # Some files contain garbage at the end. This will be the first sign the parser has hit garbage.
                    if "\x03" in header["group_id"]:
                        log.error("Could not parse EDI file")

                if "parent_fixed_id" not in header:
                    # Top level item that won't have children.
                    policy[header["group_id"]] = {"data": parts}

                elif len(header["parent_fixed_id"]) == 0:
                    # Top level item that will have children.
                    key = str(header["group_id"]) + "-" + str(header["fixed_id"])
                    policy[key] = {"data": parts}

                else:
                    # Item that has a parent.
                    key = str(header["group_id"]) + "-" + str(header["fixed_id"])
                    parent_key = str(header["parent_group_id"]) + "-" + str(header["parent_fixed_id"])
                    parent = AL3ToJSON._find_value_by_key(policy, parent_key)

                    if parent is not None:
                        AL3ToJSON._create_key(parent, "children", {})
                        parent["children"][key] = {"data": parts}
                        # parent["children"][key] = {}

            # Move to the next record.
            if header["record_length"] == 0:
                raise AL3Exception("Record length cannot be zero")

            current_index = current_index + header["record_length"]

        return policy

    @staticmethod
    def read_message_header(al3_string):
        al3_string = AL3ToJSON._run_length_decode(al3_string)
        return {
            'data': convert_1mhg(al3_string)
        }

    @staticmethod
    def to_list(al3_string):
        policy_list = []
        al3_string = AL3ToJSON._run_length_decode(al3_string)
        al3_string = al3_string.replace("\r", "")
        al3_string = al3_string.replace("\n", "")
        al3_string = al3_string.replace("\x1d", "")
        al3_string = al3_string.replace("?", " ")

        for group in al3_groups[1:]:
            al3_string = al3_string.replace(group, "\n" + group)

        records = al3_string.split("\n")
        records = [x for x in records if len(x.strip()) != 0]
        current_policy = ""

        for record in records:
            header = AL3ToJSON._get_record_header(record)

            if len(record) > header["record_length"]:
                record = bytes(record, "iso-8859-1").decode("utf_8").encode("utf_8").decode("utf_8")

            if len(record) != header["record_length"]:
                raise AL3Exception("Bad record length")

            group_id = header["group_id"]

            if group_id == "1MHG":
                if len(current_policy) > 0:
                    policy_list.append(current_policy)
                current_policy = ""
            elif group_id == "2TRG":
                if len(current_policy) > 0:
                    policy_list.append(current_policy)
                current_policy = record
            else:
                current_policy += record

        # Append the last one.
        if len(current_policy) > 0:
            policy_list.append(current_policy)

        return policy_list

    @staticmethod
    def _run_length_decode(al3):
        skip = 0
        return_string = ""

        # Go through file looking for a "\x1D" compression character.
        for i in range(0, len(al3)):
            if skip > 0:
                skip = skip - 1
                continue

            if al3[i] == "\x1d":
                # If we find one, we know the next two digits are a hex.
                hex_val = al3[i + 1] + al3[i + 2]
                dec = int(hex_val, 16)

                # The next character is the one that repeats.
                repeating_char = al3[i + 3]

                return_string += repeating_char * dec

                # Now skip over the next three characters.
                skip = 3
            else:
                return_string += al3[i]

        return return_string

    @staticmethod
    def _get_record_header(record):
        group_id = record[0:4].strip()

        if group_id in ["2TRG", "2TCG", "3MTG"]:
            header = {
                "group_id": group_id,
                "record_length": int(record[4:7].strip()),
            }
        else:
            header = {
                "group_id": group_id,
                "record_length": int(record[4:7].strip()),
                "fixed_id": record[10:16].strip(),
                "parent_group_id": record[16:20].strip(),
                "parent_fixed_id": record[20:26].strip(),
            }

        return header

    @staticmethod
    def _find_values_by_key(data, target, results):
        for key, value in data.items():
            if "children" in value:
                AL3ToJSON._find_values_by_key(value["children"], target, results)

            if key == target:
                results.append(value)

    @staticmethod
    def _find_value_by_key(data, target):
        results = []
        AL3ToJSON._find_values_by_key(data, target, results)

        if len(results) <= 0:
            return None

        return results[0]

    @staticmethod
    def _create_key(target, key, value):
        if key not in target:
            target[key] = value
