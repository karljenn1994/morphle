#!/usr/bin/env python3
import argparse
import logging
import os
import shutil
import sys
from contextlib import contextmanager

import requests
import sqlalchemy as db
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from lib_common import constants

# ------------------------
# Logging setup
# ------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


# ------------------------
# Custom exceptions
# ------------------------
class PolicyNotFound(Exception):
    """Raised when a policy does not exist in the source branch."""


class PolicyNotMovable(Exception):
    """Raised when a policy exists but cannot be moved (e.g., linked to a user)."""


# ------------------------
# Vault helpers
# ------------------------
def get_vault_settings(vault_token, environment, vault_addr=None):
    vault_addr = vault_addr or os.environ.get("VAULT_ADDR")
    if not vault_addr:
        log.error("❌ Vault address not provided")
        sys.exit(1)
    url = f"{vault_addr}/v1/secret/{environment}/settings"
    headers = {"X-Vault-Token": vault_token}
    resp = requests.get(url, headers=headers)
    if resp.status_code != 200:
        log.error(f"❌ Vault fetch failed: {resp.status_code} - {resp.text}")
        sys.exit(1)
    return resp.json().get("data", {})


# ------------------------
# DB helpers
# ------------------------
def make_engine(settings):
    db_user = settings[constants.SETTING_DB_USER]
    db_password = settings[constants.SETTING_DB_PASSWORD]
    db_host = settings[constants.SETTING_DB_HOST]
    db_name = settings[constants.SETTING_DB_NAME]
    conn_str = f"mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}"
    return db.create_engine(
        conn_str,
        pool_pre_ping=True,
        pool_recycle=3600,
        pool_size=10,
        max_overflow=10,
    )


@contextmanager
def get_connection(engine):
    with engine.connect() as conn:
        yield conn


# ------------------------
# Validation helpers
# ------------------------
def verify_policy_exists(src_conn, policy_number, company, lob):
    row = src_conn.execute(
        text("""SELECT id FROM policy 
                WHERE policy_number=:pn AND company=:company AND lob=:lob"""),
        {"pn": policy_number, "company": company, "lob": lob},
    ).mappings().first()
    if not row:
        return None
    return row["id"]


def assert_no_user_policy(src_conn, policy_id):
    row = src_conn.execute(
        text("SELECT 1 FROM user_policy WHERE policy_id=:pid LIMIT 1"),
        {"pid": policy_id},
    ).first()
    return row is None


# ------------------------
# Migration helpers
# ------------------------
def migrate_policy_records(src_conn, dst_conn, policy_number, company, lob, dry_run=False):
    try:
        policies = src_conn.execute(
            text("SELECT * FROM policy WHERE policy_number=:pn AND company=:company AND lob=:lob"),
            {"pn": policy_number, "company": company, "lob": lob}
        ).mappings().all()

        if not policies:
            log.warning(f"❌ No policies found for {policy_number}/{company}/{lob}")
            return False

        # ensure no user_policy links for ANY version
        for p in policies:
            pid = p["id"]
            row = src_conn.execute(
                text("SELECT 1 FROM user_policy WHERE policy_id=:pid LIMIT 1"),
                {"pid": pid}
            ).first()
            if row:
                log.warning(f"❌ Policy {pid} is linked to a user; cannot move")
                return False

        for policy_row in policies:
            pid = policy_row["id"]

            if dry_run:
                log.info(f"[DRY RUN] Would insert policy {pid} into destination")
            else:
                try:
                    cols = ", ".join([f"`{c}`" for c in policy_row.keys()])
                    vals = ", ".join([f":{c}" for c in policy_row.keys()])
                    dst_conn.execute(
                        text(f"INSERT INTO policy ({cols}) VALUES ({vals})"),
                        dict(policy_row)
                    )
                except Exception as ex:
                    log.error(f"❌ Failed inserting policy {pid} into destination: {ex}")
                    return False

            for table in ["indexer", "policy_insured", "policy_issue"]:
                rows = src_conn.execute(
                    text(f"SELECT * FROM {table} WHERE policy_id=:pid"),
                    {"pid": pid}
                ).mappings().all()
                if dry_run:
                    log.info(f"[DRY RUN] Would insert {len(rows)} row(s) from {table} for {pid}")
                else:
                    try:
                        for row in rows:
                            cols = ", ".join([f"`{c}`" for c in row.keys()])
                            vals = ", ".join([f":{c}" for c in row.keys()])
                            dst_conn.execute(
                                text(f"INSERT INTO {table} ({cols}) VALUES ({vals})"),
                                dict(row)
                            )
                    except Exception as ex:
                        log.error(f"❌ Failed inserting rows into {table} for policy {pid}: {ex}")
                        return False

            if not dry_run:
                try:
                    src_conn.execute(text("DELETE FROM indexer WHERE policy_id=:pid"), {"pid": pid})
                    src_conn.execute(text("DELETE FROM policy_insured WHERE policy_id=:pid"), {"pid": pid})
                    src_conn.execute(text("DELETE FROM policy_issue WHERE policy_id=:pid"), {"pid": pid})
                    src_conn.execute(text("DELETE FROM policy WHERE id=:pid"), {"pid": pid})
                except Exception as ex:
                    log.error(f"❌ Failed cleaning up source records for {pid}: {ex}")
                    return False

        return True
    except Exception as ex:
        log.error(f"❌ Unexpected error during migrate_policy_records: {ex}")
        return False


def move_policy_files(src_branch, dst_branch, company, policy_number, dry_run=False):
    src_dir = f"/opt/{src_branch}/policies/{company}/{policy_number}"
    dst_dir = f"/opt/{dst_branch}/policies/{company}/{policy_number}"

    if not os.path.exists(src_dir):
        log.warning(f"⚠️ No files to move: {src_dir}")
        return True

    if dry_run:
        log.info(f"[DRY RUN] Would move files {src_dir} → {dst_dir}")
        return True

    try:
        os.makedirs(os.path.dirname(dst_dir), exist_ok=True)
        shutil.move(src_dir, dst_dir)
        log.info(f"Moved files {src_dir} → {dst_dir}")
        return True
    except Exception as ex:
        log.error(f"❌ Failed to move files from {src_dir} → {dst_dir}: {ex}")
        return False


# ------------------------
# Orchestrator
# ------------------------
def move_policy(policy_number, company, lob,
                src_token, dst_token,
                src_branch, dst_branch,
                vault_addr=None, dry_run=False):
    src_settings = get_vault_settings(src_token, src_branch, vault_addr)
    dst_settings = get_vault_settings(dst_token, dst_branch, vault_addr)

    src_engine = make_engine(src_settings)
    dst_engine = make_engine(dst_settings)

    try:
        with get_connection(src_engine) as src_conn, get_connection(dst_engine) as dst_conn:
            policy_id = verify_policy_exists(src_conn, policy_number, company, lob)
            if not policy_id:
                raise PolicyNotFound(f"{policy_number}/{company}/{lob} not found in {src_branch}")

            if not assert_no_user_policy(src_conn, policy_id):
                raise PolicyNotMovable(f"{policy_number}/{company}/{lob} is linked to a user")

            if dry_run:
                log.info(f"[DRY RUN] Verified policy {policy_number}/{company}/{lob} exists and is safe to move")
                success = migrate_policy_records(src_conn, dst_conn, policy_number, company, lob, dry_run=True)
                if not success:
                    raise RuntimeError("Migration aborted due to errors")
            else:
                success = migrate_policy_records(src_conn, dst_conn, policy_number, company, lob, dry_run=False)
                if not success:
                    src_conn.rollback()
                    dst_conn.rollback()
                    raise RuntimeError("Migration aborted due to errors")
                src_conn.commit()
                dst_conn.commit()

        # only run after DB work succeeded
        if not move_policy_files(src_branch, dst_branch, company, policy_number, dry_run=dry_run):
            raise RuntimeError("File move failed — migration incomplete")

        if dry_run:
            log.info(f"✅ [DRY RUN] Completed migration simulation for {policy_number}/{company}/{lob}")
        else:
            log.info(f"✅ Completed migration of {policy_number}/{company}/{lob}")

    except (SQLAlchemyError, OSError) as ex:
        log.error(f"❌ Migration failed with unexpected error: {ex}")
        raise
    finally:
        src_engine.dispose()
        dst_engine.dispose()


# ------------------------
# CLI
# ------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Move a policy from one branch to another")
    parser.add_argument("--policy", required=True, help="Policy number")
    parser.add_argument("--company", required=True, help="Company code")
    parser.add_argument("--lob", required=True, help="LOB code")
    parser.add_argument("--src-branch", required=True, help="Source branch name")
    parser.add_argument("--dst-branch", required=True, help="Destination branch name")
    parser.add_argument("--src-token", required=True, help="Vault token for source branch")
    parser.add_argument("--dst-token", required=True, help="Vault token for destination branch")
    parser.add_argument("--vault-addr", default=None, help="Vault address (default: $VAULT_ADDR)")
    parser.add_argument("--dry-run", action="store_true", help="Dry run (simulate only)")
    args = parser.parse_args()

    try:
        move_policy(
            args.policy,
            args.company,
            args.lob,
            args.src_token,
            args.dst_token,
            args.src_branch,
            args.dst_branch,
            vault_addr=args.vault_addr,
            dry_run=args.dry_run
        )
    except PolicyNotFound as e:
        log.warning(f"⚠️ {e}")
        sys.exit(0)  # skip is not fatal in CLI
    except PolicyNotMovable as e:
        log.warning(f"⚠️ {e}")
        sys.exit(0)  # skip is not fatal in CLI
    except Exception as e:
        log.error(f"❌ {e}")
        sys.exit(1)
