import csv
import logging
import os
import yaml
from datetime import datetime

from sqlalchemy import text

from lib_common import constants, exceptions
from lib_common.constants import LOGGER
from lib_common.exceptions import TaskException
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_file_manager.local_file_manager import LocalFileManager
from lib_persistence import get_connection, settings
from lib_al3 import al3_utils

log = logging.getLogger(LOGGER)

REQUIRED_YAML_KEYS = {
    "csv_column_mappings": {"policy_number", "company_code", "lob"},
    "company_mappings": {},
    "lob_mappings": {},
}


def validate_import_mappings(import_mappings):
    if not isinstance(import_mappings, dict):
        raise TaskException("import_mappings.yaml must contain a top-level dictionary.",
                            error_code=exceptions.CODE_TASK_FAILED)
    for key, required_subkeys in REQUIRED_YAML_KEYS.items():
        if key not in import_mappings:
            raise TaskException(f"Missing required key '{key}' in import_mappings.yaml",
                                error_code=exceptions.CODE_TASK_FAILED)
        section = import_mappings[key]
        if required_subkeys and not isinstance(section, dict):
            raise TaskException(f"'{key}' must be a dictionary in import_mappings.yaml.",
                                error_code=exceptions.CODE_TASK_FAILED)
        if isinstance(section, dict):
            if required_subkeys:
                missing = required_subkeys - set(section.keys())
                if missing:
                    raise TaskException(f"Missing keys in '{key}': {', '.join(missing)}",
                                        error_code=exceptions.CODE_TASK_FAILED)


def validate_csv_headers(csv_headers, expected_columns):
    missing = [col for col in expected_columns if col not in csv_headers]
    if missing:
        raise TaskException(f"CSV file is missing required columns: {', '.join(missing)}",
                            error_code=exceptions.CODE_TASK_FAILED)


def branch_name_from_file(file_path, fm):
    filename = fm.basename(file_path)
    name = filename[:-4].lower() if filename.lower().endswith(".csv") else filename.lower()
    # Split on first "_" and take the first part
    return name.split("_", 1)[0]


def backup_file(file_path, fm):
    base_name = fm.basename(file_path)
    import_dir = fm.dirname(fm.dirname(file_path))
    backup_dir = fm.join(import_dir, "backup", "policy_list")
    fm.mkdirs(backup_dir)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = fm.join(backup_dir, f"{base_name}.{timestamp}.bak")

    fm.move(file_path, backup_path)
    print(f"📦 Moved processed file to backup: {backup_path}")


def map_company_code(import_mappings, code):
    """Map a raw broker company code to an internal company code."""
    company_mappings = import_mappings["company_mappings"]
    return company_mappings.get(code)


def map_lob(import_mappings, code):
    """Map a raw broker LOB to an internal LOB."""
    lob_mappings = import_mappings["lob_mappings"]
    return lob_mappings.get(code)


def import_branch_policy(optional_connection=None):
    fm = FileManagerFactory.create_file_manager(LocalFileManager)

    # --- Load and validate mappings ONCE ---
    config_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "config")
    mappings_path = os.path.join(config_location, "import_mappings.yaml")

    with open(mappings_path, "r") as f:
        import_mappings = yaml.safe_load(f)
        validate_import_mappings(import_mappings)

    csv_mappings = import_mappings["csv_column_mappings"]
    policy_number_column = csv_mappings["policy_number"]
    company_column = csv_mappings["company_code"]
    lob_column = csv_mappings["lob"]

    # --- Process CSV files ---
    policy_list_dir = fm.join("import", "policy_list")
    if not fm.exists(policy_list_dir):
        print(f"⚠️ No directory found: {policy_list_dir}")
        return

    files = [f for f in fm.listdir(policy_list_dir) if f.lower().endswith(".csv")]
    if not files:
        print(f"⚠️ No CSV files found in {policy_list_dir}")
        return

    for file_path in files:
        branch = branch_name_from_file(file_path, fm)
        print(f"\n📂 Processing {file_path} for branch '{branch}' ...")

        try:
            csv_file_path = fm.join(policy_list_dir, file_path)

            with open(fm.get_absolute_path(csv_file_path), newline="", encoding="utf-8-sig") as csvfile:
                reader = csv.DictReader(csvfile)
                validate_csv_headers(reader.fieldnames, [policy_number_column, company_column, lob_column])

                processed = skipped = 0
                seen = set()

                with get_connection(optional_connection) as connection:
                    for row in reader:
                        raw_policy = row.get(policy_number_column, "").strip()
                        raw_company = row.get(company_column, "").strip()
                        raw_lob = row.get(lob_column, "").strip()

                        policy_number = al3_utils.fix_policy_number(raw_policy)
                        company = map_company_code(import_mappings, raw_company)
                        lob = map_lob(import_mappings, raw_lob)

                        if not policy_number:
                            print(f"⚠️ Skipped invalid policy_number '{raw_policy}'")
                            skipped += 1
                            continue

                        if policy_number in seen:
                            print(f"⚠️ Duplicate policy_number '{policy_number}' → skipped")
                            skipped += 1
                            continue

                        if not company:
                            print(f"⚠️ Skipped unmapped company '{raw_company}' for policy {policy_number}")
                            skipped += 1
                            continue

                        if not lob:
                            print(f"⚠️ Skipped unmapped LOB '{raw_lob}' for policy {policy_number}")
                            skipped += 1
                            continue

                        seen.add(policy_number)

                        try:
                            connection.execute(
                                text("""
                                    INSERT INTO branch_policy (branch, policy_number, company, lob)
                                    VALUES (:branch, :policy_number, :company, :lob)
                                    ON DUPLICATE KEY UPDATE
                                        branch = VALUES(branch),
                                        company = VALUES(company),
                                        lob = VALUES(lob)
                                """),
                                {
                                    "branch": branch,
                                    "policy_number": policy_number,
                                    "company": company,
                                    "lob": lob,
                                }
                            )
                            print(f"✅ Imported policy {policy_number} (company={company}, lob={lob})")
                            processed += 1
                        except Exception as e:
                            skipped += 1
                            print(f"⚠️ Failed to insert {policy_number}: {e}")

                    connection.commit()

                print(f"✅ Finished {csv_file_path}: Imported {processed}, skipped {skipped}, branch={branch}")

        except Exception as e:
            print(f"❌ Failed processing {file_path}: {e}")
            continue

    # --- Backup the entire folder like users ---
    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    import_dir = fm.dirname(policy_list_dir)
    backup_folder = fm.join(import_dir, f"policy_list-{current_time}")

    fm.rename(policy_list_dir, backup_folder)
    fm.mkdir(policy_list_dir)

    print(f"📦 Backed up policy_list to {backup_folder} and recreated empty folder.")


if __name__ == "__main__":
    import_branch_policy()
