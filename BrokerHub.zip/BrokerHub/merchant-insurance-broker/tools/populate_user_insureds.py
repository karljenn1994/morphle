from typing import Any, Dict, List

from sqlalchemy import text

from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import find_group_by_group_name, find_groups_by_group_name, val
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_helpers import to_full_name
from lib_persistence import get_connection


def _list_active_policies(optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM policy p
             WHERE p.active=1
        """))


def _list_indexer_policies(optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT p.*
              FROM indexer i, policy p
             WHERE p.id = i.policy_id
               AND i.policy_id IS NOT NULL
        """))


def _insert_insureds(policy_id: str, insured_names: List[str], optional_connection=None):
    with get_connection(optional_connection) as connection:
        for insured_name in insured_names:
            connection.execute(text(
                """
                 INSERT IGNORE
                   INTO policy_insured (policy_id, insured_name)
                 VALUES (:policy_id, :insured_name)
               """
            ).bindparams(
                policy_id=policy_id,
                insured_name=insured_name
            ))

        if not optional_connection:
            connection.commit()


def _collect_al3_insured_names(al3_json: Dict[str, Any]) -> List[str]:
    """
    Extract insured and co-insured names from an AL3 JSON structure.
    Removes extra spaces from each name.

    :param al3_json: Parsed AL3 JSON as a nested dict.
    :return: A list of insured/co-insured full names.
    """
    insured_names: List[str] = []
    five_bis: Dict[str, Any] | None = find_group_by_group_name(al3_json, "5BIS")
    if five_bis:
        if raw_name := to_full_name(val(five_bis, "01", None)):
            name = " ".join(raw_name.split())
            insured_names.append(name)

        five_sngs = find_groups_by_group_name(five_bis.get("children", {}), "5SNG")

        insured_names.extend(
            " ".join(coinsured_name.split())
            for five_sng in five_sngs
            if (coinsured_name := to_full_name(val(five_sng, "03", None)))
        )
    return insured_names


print("Starting to populate insured policies")
fm = FileManagerFactory.create_file_manager()

for p in _list_active_policies():
    if p.file_name:
        al3_file_name = p.file_name.replace(".JSON", ".AL3")
        txt = AL3ToJSON.load(fm.join(Repository.policies_location, al3_file_name))
        j = AL3ToJSON().to_json(txt)
        names: list[str] = _collect_al3_insured_names(j)
        _insert_insureds(p.id, names)
        print(names)


for p in _list_indexer_policies():
    if p.file_name:
        al3_file_name = p.file_name.replace(".JSON", ".AL3")
        txt = AL3ToJSON.load(fm.join(Repository.policies_location, al3_file_name))
        j = AL3ToJSON().to_json(txt)
        names: list[str] = _collect_al3_insured_names(j)
        print(names)


print()
print("Done")
print()
