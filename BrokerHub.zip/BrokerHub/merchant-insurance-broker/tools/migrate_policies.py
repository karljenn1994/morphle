#!/usr/bin/env python3
import argparse
import logging
import os
import sys

from sqlalchemy import text

from migrate_policy import (
    get_connection,
    get_vault_settings,
    make_engine,
    move_policy,
    PolicyNotFound,
    PolicyNotMovable,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


def load_conf(branch):
    """Load .conf file for a branch (shell-style KEY=VALUE)."""
    conf_path = os.path.join("/opt/config", f"{branch}.conf")
    if not os.path.exists(conf_path):
        log.error(f"❌ Config file not found: {conf_path}")
        sys.exit(1)

    values = {}
    with open(conf_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, val = line.split("=", 1)
            values[key.strip()] = val.strip()

    token = values.get("VAULT_TOKEN")
    addr = values.get("VAULT_ADDR")

    if not token or not addr:
        log.error(f"❌ Missing VAULT_TOKEN or VAULT_ADDR in {conf_path}")
        sys.exit(1)

    return token, addr


def migrate_policies_bulk(src_branch, dst_branch, dry_run=False):
    # Load Vault tokens and addr for both branches
    src_token, vault_addr = load_conf(src_branch)
    dst_token, _ = load_conf(dst_branch)

    # Get DB settings for each branch
    src_settings = get_vault_settings(src_token, src_branch, vault_addr)
    dst_settings = get_vault_settings(dst_token, dst_branch, vault_addr)

    src_engine = make_engine(src_settings)
    dst_engine = make_engine(dst_settings)

    with get_connection(src_engine) as src_conn, get_connection(dst_engine) as dst_conn:
        rows = src_conn.execute(
            text("SELECT policy_number, company, lob FROM branch_policy WHERE branch=:branch"),
            {"branch": dst_branch}
        ).mappings().all()

        if not rows:
            log.warning(f"⚠️ No policies found in {src_branch}.branch_policy for {dst_branch}")
            return

        log.info(f"Found {len(rows)} policies to migrate from {src_branch} → {dst_branch}")

        for idx, row in enumerate(rows, 1):
            policy_number = row["policy_number"]
            company = row["company"]
            lob = row["lob"]

            # Check if already exists in destination → skip silently
            dst_row = dst_conn.execute(
                text("""SELECT id FROM policy 
                        WHERE policy_number=:pn AND company=:c AND lob=:l"""),
                {"pn": policy_number, "c": company, "l": lob}
            ).first()

            if dst_row:
                continue  # already migrated, no log

            try:
                move_policy(
                    policy_number,
                    company,
                    lob,
                    src_token,
                    dst_token,
                    src_branch,
                    dst_branch,
                    vault_addr=vault_addr,
                    dry_run=dry_run
                )
                log.info(f"[{idx}/{len(rows)}] ✅ Migrated {policy_number}/{company}/{lob}")
            except PolicyNotFound as e:
                log.warning(f"[{idx}/{len(rows)}] ⚠️ Skipped {policy_number}/{company}/{lob} ({e})")
                continue
            except PolicyNotMovable as e:
                log.warning(f"[{idx}/{len(rows)}] ⚠️ Skipped {policy_number}/{company}/{lob} ({e})")
                continue
            except Exception as e:
                log.error(f"❌ Migration aborted at policy {policy_number}: {e}")
                sys.exit(1)

    src_engine.dispose()
    dst_engine.dispose()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bulk migrate policies from one branch to another")
    parser.add_argument("--src-branch", required=True, help="Source branch (e.g., begin)")
    parser.add_argument("--dst-branch", required=True, help="Destination branch (e.g., distinct)")
    parser.add_argument("--dry-run", action="store_true", help="Simulate only, make no changes")
    args = parser.parse_args()

    migrate_policies_bulk(
        args.src_branch,
        args.dst_branch,
        dry_run=args.dry_run
    )
