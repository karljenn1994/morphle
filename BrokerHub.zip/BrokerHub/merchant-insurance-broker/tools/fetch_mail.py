import argparse
import logging
import math
import re
from datetime import datetime, timezone

import requests
from dateutil import parser as dateutil_parser

from lib_common import authentication, constants
from lib_common.constants import LOGGER
from lib_common.exceptions import CODE_CSIONET_SIGNIN_FAILED, HttpException
from lib_common.mailbox import Mailbox
from lib_common.repository import Repository
from lib_persistence import settings
from lib_vault.vault import Vault

CSIO_NET_URL = "http://localhost:4000/branch-api/web/v1/messages"
PAGE_SIZE = 100
REQUEST_TIMEOUT = (5, 45)  # connect, read
MAX_RETRIES = 3
log = logging.getLogger(LOGGER)

_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._\-\s]+")


def _as_list(x):
    if not x:
        return []
    return x if isinstance(x, list) else [x]


def _safe_name(name: str, max_len: int = 255) -> str:
    name = _SAFE_NAME_RE.sub("", name or "")
    name = " ".join(name.split())
    return name[:max_len]


def _fmt_csio_range(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    dt = dt.astimezone(timezone.utc).replace(microsecond=0)
    return dt.isoformat(timespec="seconds").replace("+00:00", "") + ".00Z"


def _post(payload):
    last_exc = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            return requests.post(CSIO_NET_URL, json=payload, timeout=REQUEST_TIMEOUT)
        except Exception as e:
            last_exc = e
            if attempt == MAX_RETRIES:
                raise
            log.warning("CSIO POST retry %d/%d due to %s", attempt, MAX_RETRIES, repr(e))
    raise last_exc


def _get_response_object(response):
    response_json = response.json()
    if response.status_code != 200:
        error_msg = "Failed to sign in to CSIONet"
        if "Response" in response_json and "Status" in response_json:
            error_msg = response_json["Response"]["Status"]
        raise HttpException(error_msg, error_code=CODE_CSIONET_SIGNIN_FAILED)
    if "Response" not in response_json:
        raise HttpException("Response object missing in response", error_code=CODE_CSIONET_SIGNIN_FAILED)
    return response_json["Response"]


def _sign_in():
    api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)

    if api_key:
        branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
        branch_token = authentication.generate_branch_mail_token(api_key)
        data = {"CommandType": "SignIn", "Branch": branch_name, "BranchToken": branch_token}
        _get_response_object(_post(data))
        return branch_token
    else:
        username = Vault().get(constants.SETTING_CSIONET_USER)
        password = Vault().get(constants.SETTING_CSIONET_PASSWORD)

        if not username or not password:
            return None

        data = {"CommandType": "SignIn", "CSIOnetID": username, "CSIOnetPassword": password}

        response = _get_response_object(_post(data))

        if "SessionGUID" not in response:
            raise HttpException("Session GUID missing in response object", error_code=CODE_CSIONET_SIGNIN_FAILED)

        return response["SessionGUID"]


def _sign_out(session_guid):
    if session_guid:

        try:
            api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
            branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
            branch_token = authentication.generate_branch_mail_token(api_key)
            _post({
                "CommandType": "SignOut",
                "SessionGUID": session_guid,
                "Branch": branch_name,
                "BranchToken": branch_token
            })
        except Exception as e:
            log.error(e, exc_info=True)


def _fetch_messages(session_guid, from_date_time: datetime, to_date_time: datetime, page=1, page_size=PAGE_SIZE):
    start_time = _fmt_csio_range(from_date_time)
    end_time = _fmt_csio_range(to_date_time)
    api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
    branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
    branch_token = authentication.generate_branch_mail_token(api_key)

    data = {
        "CommandType": "List",
        "SessionGUID": session_guid,
        "FromDateTime": start_time,
        "ToDateTime": end_time,
        "Page": page,
        "PageSize": page_size,
        "Branch": branch_name,
        "BranchToken": branch_token
    }
    return _get_response_object(_post(data))


def _retrieve_message(session_guid, message_id):
    data = {"CommandType": "Retrieve", "SessionGUID": session_guid, "MessageGUID": message_id, "Delete": 0}
    return _get_response_object(_post(data))


def _ack_message(session_guid, message_id):
    data = {"CommandType": "Acknowledge", "SessionGUID": session_guid, "MessageGUID": message_id}
    return _get_response_object(_post(data))


def _release_message(session_guid, message_id):
    data = {"CommandType": "Release", "SessionGUID": session_guid, "MessageGUID": message_id}
    return _get_response_object(_post(data))


def _attachments(obj):
    atts = obj.get("Attachments", {})
    return _as_list(atts.get("Attachment", []))


def _folder_name(message_datetime: str, message_guid: str) -> str:
    dt = dateutil_parser.isoparse(message_datetime)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    dt = dt.astimezone(timezone.utc).replace(microsecond=0)
    dt_part = dt.strftime("%Y-%m-%d_%H-%M-%S")
    guid_part = (message_guid or "").replace(".", "_")
    name = f"{dt_part}_{guid_part}" if guid_part else dt_part
    return _safe_name(name)


def process_page(resp, session_guid, dry_run: bool = False):
    messages = _as_list(resp.get("Message", []))
    messages.sort(key=lambda me: dateutil_parser.isoparse(me["DateTime"]))

    for m in messages:
        guid = m["MessageGUID"]
        try:
            obj = _retrieve_message(session_guid, guid)
            atts = _attachments(obj)

            # Save attachments; if this throws, we won't ACK.
            Mailbox().save_api_attachments(
                Repository.mail_inbox_location,
                atts,
                m["DateTime"],
                guid,
                dry_run=dry_run
            )

            # Only ACK when not dry-run and after successful save.
            if not dry_run:
                _ack_message(session_guid, guid)
                log.info("ACKed %s", guid)

        except Exception as e:
            log.error("Failed processing %s: %s", guid, e, exc_info=True)
            # Optional: proactively release so it can be retried elsewhere.
            if not dry_run:
                try:
                    _release_message(session_guid, guid)
                    log.info("Released %s after failure", guid)
                except Exception as re:
                    log.warning("Release failed for %s: %s", guid, re)


def valid_iso8601(value):
    try:
        dt = dateutil_parser.isoparse(value)
    except Exception:
        raise argparse.ArgumentTypeError(f"Invalid datetime format: {value}")
    if dt.tzinfo is None:
        return dt.replace(tzinfo=None)
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def main(start_dt: datetime, end_dt: datetime, dry_run: bool = False):
    session_guid = None
    try:
        session_guid = _sign_in()
        if not session_guid:
            raise HttpException("Failed to authenticate with CSIONet")

        if start_dt.tzinfo is None:
            start_dt = start_dt.replace(tzinfo=timezone.utc)
        if end_dt.tzinfo is None:
            end_dt = end_dt.replace(tzinfo=timezone.utc)

        first = _fetch_messages(session_guid, start_dt, end_dt)
        total = int(first.get("MessagesAvailable", 0))
        pages = math.ceil(total / PAGE_SIZE) if total > 0 else 0

        if total > 0:
            process_page(first, session_guid, dry_run)
            for page in range(2, pages + 1):
                resp = _fetch_messages(session_guid, start_dt, end_dt, page, PAGE_SIZE)
                process_page(resp, session_guid, dry_run)

        log.info("Completed. messages_available=%s pages=%s dry_run=%s", total, pages, dry_run)

    finally:
        if session_guid:
            _sign_out(session_guid)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="Fetch CSIONet messages within a datetime range.")
    parser.add_argument("--start-dt", required=True, type=valid_iso8601,
                        help="Start datetime (e.g. 2024-06-01T00:00:00 or with Z/offset)")
    parser.add_argument("--end-dt", required=True, type=valid_iso8601,
                        help="End datetime (e.g. 2024-06-01T23:59:59 or with offset)")
    parser.add_argument("--dry-run", action="store_true", help="Fetch/parse but do not write files")
    args = parser.parse_args()

    main(start_dt=args.start_dt, end_dt=args.end_dt, dry_run=args.dry_run)
