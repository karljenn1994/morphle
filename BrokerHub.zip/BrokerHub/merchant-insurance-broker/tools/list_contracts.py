#!/usr/bin/env python3
import sys
import logging

from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import val
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_common.repository import Repository

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("unsorted-check")


def extract_contract(full_path):
    """
    Extract the contract number from an AL3 file.
    """
    al3 = AL3ToJSON.load(full_path)
    header = AL3ToJSON.read_message_header(al3)
    return val(header, "03", default=None)


def scan_unsorted(root_path, fm):
    """
    Walk through the unsorted/al3_no_branch_mapping folder,
    return a set of contract numbers.
    """
    contracts = set()

    if not fm.exists(root_path):
        print(f"Folder not found: {root_path}")
        return contracts

    for root, dirs, files in fm.walk(root_path):
        for file in files:
            file_path = fm.join(root, file)
            try:
                contract = extract_contract(file_path)
                if contract:
                    contracts.add(contract)
            except Exception as e:
                log.warning("Failed parsing %s: %s", file_path, e)

    return contracts


if __name__ == "__main__":
    fm = FileManagerFactory.create_file_manager()
    default_root = fm.join(Repository.mail_root_location, "unsorted", "al3_no_branch_mapping")
    root_path = sys.argv[1] if len(sys.argv) > 1 else default_root

    contracts = scan_unsorted(root_path, fm)
    if contracts:
        print("Unique missing contracts:")
        for c in sorted(contracts):
            print(c)
    else:
        print("No contracts found.")
