import json

from flask import Response
from flask_restx import Namespace, Resource
from sqlalchemy import text

from lib_common import constants
from lib_persistence import get_connection, settings, task

api = Namespace("broker-api/mobile/v1/health", description="Provides monitoring.")


@api.route("", methods=["GET"])
class Health(Resource):
    @staticmethod
    def get():
        try:
            status = {
                'name': settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME),
                'status': 'success',
                'mysql': 'available',
                'tasks': []
            }

            try:
                with get_connection() as connection:
                    # See if mysql is available.
                    row = connection.execute(text("SELECT 1")).first()

                    if row is None:
                        status['status'] = 'failed'
                        status['mysql'] = 'unavailable'

                    status['tasks'].append({"fetch": task.get_task_status('fetch')})
                    status['tasks'].append({'organize': task.get_task_status('organize')})
                    status['tasks'].append({'transform': task.get_task_status('transform')})
                    status['tasks'].append({'notify_schedule': task.get_task_status('notify_schedule')})
                    status['tasks'].append({'index': task.get_task_status('index')})
                    status['tasks'].append({'notify': task.get_task_status('notify')})
            except:
                status['status'] = 'failed'
                status['mysql'] = 'unavailable'

            return Response(
                json.dumps(status, default=str), status=200, mimetype="application/json")

        except Exception:
            return Response(json.dumps({}), status=500, mimetype="application/json")
