import json
import logging
import random
from datetime import datetime, timedelta, timezone

from dateutil import parser as dateutil_parser
from flask import Response, request
from flask_restx import Namespace, Resource

from lib_common import constants
from lib_common.authentication import get_user_id_email_from_headers
from lib_common.constants import LOGGER
from lib_common.repository import Repository
from lib_email.emailer import Emailer
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_helpers.strings import upper
from lib_persistence import campaign, collector, policy, settings, user
from lib_policy_dom.policy_dom import PolicyDOM

api = Namespace("broker-api/mobile/v1/policy", description="Provides access to policy information.")
log = logging.getLogger(LOGGER)


@api.route("/connect", methods=["POST"])
@api.doc(description="Look up a client, attach them to their policies and return their user id "
                     "identity at the brokerage.", security="bearer")
class ClientConnect(Resource):
    @staticmethod
    def _verify_email(broker_hub_email, lifeswallet_email) -> bool:
        # See if the user knows the proper BrokerHub email for
        # their account.
        user_id = user.lookup_user_id_by_email(broker_hub_email)

        if not user_id:
            # We don't have that email in the system, so no point
            # continuing to verify the alternative.
            return False

        from_email = settings.get_setting(constants.SETTING_SENDGRID_FROM_EMAIL)
        reply_email = settings.get_setting(constants.SETTING_SENDGRID_REPLY_EMAIL)
        template_obj = campaign.lookup_template("Connect", locale='en', permanent=True)
        body = template_obj.body.decode()

        # Generate a code and store it for verification.
        code = f"{random.randint(0, 9999):04d}"

        # Expiry in 10 minutes, with timezone awareness
        code_expires = datetime.now(timezone.utc) + timedelta(minutes=10)

        # Store the LifesWallet email as an alternative.
        user.upsert_alternative_email(user_id, lifeswallet_email, False, code, code_expires)

        # Email the user's at their LifesWallet email so they can
        # verify they own it.
        Emailer({"verification_code": code}, body, template_obj.subject).send_email(
            from_email,
            lifeswallet_email,
            reply_email=reply_email,
            bypass=True
        )

        return True

    @staticmethod
    def _verify_code(lifeswallet_email, verification_code) -> str | None:
        user_id = user.lookup_user_id_by_verification_code(lifeswallet_email, verification_code)

        if not user_id:
            return None

        user.upsert_alternative_email(user_id, lifeswallet_email, True, None)
        return user_id

    @staticmethod
    def post():
        """
        Look up a client, attach them to their policies and return their user id identity at the brokerage.
        """

        # Extract the email the user is using in LifesWallet. If the email exists in the system,
        # we will also get the client id of the user.
        client_id, lifeswallet_email = get_user_id_email_from_headers(request.headers)

        if not lifeswallet_email:
            # Every request from the client should have their email in the bearer token
            return Response(json.dumps({"message": "Email missing"}), status=401, mimetype="application/json")

        if not client_id:
            # No client id, but there is an email. This indicates that the user might be trying
            # to use an alternative email to make the connection. Here we start the email verification
            # process.
            verification_code = request.json.get("verification_code")
            brokerhub_email = request.json.get("brokerhub_email")

            if verification_code:
                # We have the verification code that we sent them, let's verify the code.
                verification_code = verification_code.strip()
                client_id = ClientConnect._verify_code(lifeswallet_email, verification_code)
                if not client_id:
                    # Code did not match, so exit here.
                    return Response(status=401)

            elif brokerhub_email:
                # Their email from LifesWallet is not on file, so let's start an email
                # verification process for the email they think might be on file.
                brokerhub_email = brokerhub_email.strip()
                log.info("User" + brokerhub_email + " has requested to connect using " + lifeswallet_email)
                if not ClientConnect._verify_email(brokerhub_email, lifeswallet_email):
                    return Response(status=401)

                # The verification process has begun, so exit here. We need to send a clientId
                # placeholder here so that merchant_integration won't return a 500 to LifesWallet.
                return Response(json.dumps({
                    "message": "Verification pending",
                    "clientId": "pending"
                }), status=200, mimetype="application/json")

        if client_id is None:
            # No sure who this is.
            return Response(status=401, mimetype="application/json")

        log.info("Connecting user " + lifeswallet_email)
        user.connect(client_id)
        user.upsert_user_info(
            client_id,
            first_name=upper(request.json.get("first_name")),
            last_name=upper(request.json.get("last_name")),
            date_of_birth=request.json.get("birth_date"),
            postal_code=upper(request.json.get("postal_code")),
            province=upper(request.json.get("province_code")),
            drivers_licence_number=upper(request.json.get("drivers_licence")))

        return Response(json.dumps({
            "message": "Verified",
            "clientId": client_id
        }), status=200, mimetype="application/json")


@api.route("/disconnect", methods=["DELETE"])
@api.doc(description="Disconnect a user from their policies.", security="bearer")
class ClientDisconnect(Resource):
    @staticmethod
    def delete():
        """
        Disconnect a user from their policies.
        """
        user_id, _ = get_user_id_email_from_headers(request.headers)

        if user_id is None or len(user_id) <= 0:
            return Response(
                json.dumps({
                    "message": "User id invalid"
                }),
                status=401,
                mimetype="application/json")

        # Mark the client as disconnected.
        user.disconnect(user_id)

        # delete_user_policies(user)
        return Response(json.dumps({
            "message": "Disconnected"
        }), status=200, mimetype="application/json")


@api.route("/check_for_updates", methods=["GET"])
@api.doc(description="Check to see if there are policy updates for the user.", security="bearer")
class CheckForUpdates(Resource):
    @staticmethod
    def get():
        """
        Check to see if there are policy updates for the user.

        last_check:
          - Optional query param (ISO 8601). Examples:
            2025-09-04T14:30:00Z, 2025-09-04T14:30:00-03:00, 2025-09-04
          - Parsed with dateutil (handles Z and offsets).
          - If naive (no timezone), treated as UTC.
        """
        client_id, email = get_user_id_email_from_headers(request.headers)
        if not client_id:
            return Response(json.dumps({"message": "Client id not provided"}), status=401, mimetype="application/json")

        collector.schedule_collection(client_id)

        last_check_str = request.args.get("last_check")
        if not last_check_str:
            return Response(json.dumps(False), status=200, mimetype="application/json")

        try:
            last_check_dt = dateutil_parser.isoparse(last_check_str)
        except Exception:
            return Response(json.dumps({"message": "Invalid last_check format"}),
                            status=400,
                            mimetype="application/json")

        # Normalize to UTC (assume UTC if naive)
        if last_check_dt.tzinfo is None:
            last_check_dt = last_check_dt.replace(tzinfo=timezone.utc)
        else:
            last_check_dt = last_check_dt.astimezone(timezone.utc)

        # Get user's last update (assumed stored in UTC or naive-UTC). Normalize similarly.
        last_update = user.lookup_last_update_by_user_id(client_id)
        if last_update is None:
            return Response(json.dumps(False), status=200, mimetype="application/json")

        if last_update.tzinfo is None:
            last_update_utc = last_update.replace(tzinfo=timezone.utc)
        else:
            last_update_utc = last_update.astimezone(timezone.utc)

        has_updates = last_check_dt.date() < last_update_utc.date()
        return Response(json.dumps(has_updates), status=200, mimetype="application/json")


@api.route("/policies", methods=["POST"])
@api.doc(description="Get a list of the user's policies.", security="bearer")
class PolicyList(Resource):
    @staticmethod
    def post():
        """
        Get a list of the user's policies.
        """
        fm = FileManagerFactory.create_file_manager()
        user_id, email = get_user_id_email_from_headers(request.headers)

        if user_id is None or len(user_id) <= 0:
            return Response(
                json.dumps({
                    "message": "User id invalid"
                }),
                status=401,
                mimetype="application/json")

        file_names = policy.read_active_files_by_user_id(user_id)
        response = []

        for file_name in file_names:
            # File name can be null if this is a placeholder policy. Ignore it until
            # the policy is processed.
            if file_name is not None:
                policy_json = PolicyDOM.load(fm.join(Repository.policies_location, file_name)).to_cards_json()
                if policy_json is not None:
                    response.append(policy_json)

        return response


@api.route("/files", methods=["POST"])
@api.doc(description="Get a list of the user's files.", security="bearer")
class PolicyFiles(Resource):
    @staticmethod
    def post():
        """
        Get a list of the user's files.
        """
        user_id, email = get_user_id_email_from_headers(request.headers)

        if user_id is None or len(user_id) <= 0:
            return Response(
                json.dumps(
                    {
                        "message": "Client id not provided",
                    }
                ),
                status=401,
                mimetype="application/json")

        policy_card = request.get_json()

        if policy_card is None:
            return Response(
                json.dumps(
                    {
                        "message": "Policy card not provided",
                    }),
                status=400,
                mimetype="application/json")

        policy_number = policy_card["fields"]["policy_number"]

        if policy_number is None:
            return Response(
                json.dumps(
                    {
                        "message": "Policy number missing",
                    }
                ),
                status=400,
                mimetype="application/json")

        lob = policy_card["fields"]["lob"]

        if lob is None:
            return Response(
                json.dumps(
                    {
                        "message": "Line of business missing",
                    }),
                status=400,
                mimetype="application/json")

        company = policy_card["fields"]["company"] if "company" in policy_card["fields"] \
            else policy_card["fields"]["company_code"]

        if company is None:
            return Response(
                json.dumps(
                    {
                        "message": "Company missing",
                    }),
                status=400,
                mimetype="application/json")

        file_names = policy.list_pdfs(policy_number, lob, company)

        return file_names


@api.route("/file", methods=["POST"])
@api.doc(description="Return the specified file.", security="bearer")
class PolicyFile(Resource):
    @staticmethod
    def post():
        """
        Return the specified file.
        """
        user_id, email = get_user_id_email_from_headers(request.headers)

        if user_id is None or len(user_id) <= 0:
            return Response(
                json.dumps(
                    {
                        "message": "Client id not provided",
                    }),
                status=401,
                mimetype="application/json")

        user_obj = user.lookup_user_by_email(email)

        if user_obj is None:
            return Response(
                json.dumps(
                    {
                        "message": "User not found",
                    }),
                status=400,
                mimetype="application/json")

        file_details = request.get_json()

        if file_details is None:
            return Response(
                json.dumps(
                    {
                        "message": "File details not provided",
                    }
                ),
                status=400,
                mimetype="application/json",
            )

        policy_number = file_details["policy_number"]

        if policy_number is None:
            return Response(
                json.dumps(
                    {
                        "message": "Policy number missing",
                    }),
                status=400,
                mimetype="application/json",
            )

        lob = file_details["lob"]

        if lob is None:
            return Response(
                json.dumps(
                    {
                        "message": "Line of business missing",
                    }),
                status=400,
                mimetype="application/json")

        company = file_details["company"]

        if company is None:
            return Response(
                json.dumps(
                    {
                        "message": "Company missing",
                    }),
                status=400,
                mimetype="application/json")

        file_name = file_details["file_name"]

        if company is None:
            return Response(
                json.dumps(
                    {
                        "message": "File name missing",
                    }),
                status=400,
                mimetype="application/json")

        pdf, _ = policy.read_pdf(user_obj, policy_number, company, lob, file_name)

        if not pdf:
            return Response(
                json.dumps({"message": "File not found."}),
                status=404,
                mimetype="application/json"
            )

        return Response(pdf, mimetype="application/pdf")
