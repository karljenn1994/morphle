import csv
import logging
import os
import re
import uuid
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Optional

import yaml
from sqlalchemy import text

from lib_common import constants, exceptions
from lib_common.constants import LOGGER
from lib_common.exceptions import TaskException
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_file_manager.local_file_manager import LocalFileManager
from lib_persistence import campaign, get_connection, notifier, policy, settings, user
from lib_al3 import al3_utils
from tasks.celery_app import app

log = logging.getLogger(LOGGER)

EMAIL_REGEX = re.compile(r"^[^@]+@[^@]+\.[^@]+$")

REQUIRED_YAML_KEYS = {
    "csv_column_mappings": {"email", "account", "company_code", "lob", "policy_number"},
    "company_mappings": None,
    "lob_mappings": None,
}


def validate_import_mappings(import_mappings):
    """
    Validate the structure of an import_mappings.yaml configuration.
    """
    if not isinstance(import_mappings, dict):
        raise TaskException(
            "import_mappings.yaml must contain a top-level dictionary.",
            error_code=exceptions.CODE_TASK_FAILED
        )

    for key, required_subkeys in REQUIRED_YAML_KEYS.items():
        if key not in import_mappings:
            raise TaskException(
                f"Missing required key '{key}' in import_mappings.yaml",
                error_code=exceptions.CODE_TASK_FAILED
            )

        section = import_mappings[key]
        if required_subkeys:
            if not isinstance(section, dict):
                raise TaskException(
                    f"'{key}' must be a dictionary in import_mappings.yaml.",
                    error_code=exceptions.CODE_TASK_FAILED
                )
            missing = required_subkeys - set(section.keys())
            if missing:
                raise TaskException(
                    f"Missing keys in '{key}': {', '.join(missing)}",
                    error_code=exceptions.CODE_TASK_FAILED
                )


def validate_csv_headers(csv_headers, expected_columns):
    """
    Ensure that a CSV file includes all required columns.
    """
    missing = [col for col in expected_columns if col not in csv_headers]
    if missing:
        raise TaskException(
            f"CSV file is missing required columns: {', '.join(missing)}",
            error_code=exceptions.CODE_TASK_FAILED
        )


def is_valid_email(email: str) -> bool:
    """
    Basic sanity check for email format.
    """
    return bool(email) and EMAIL_REGEX.match(email.strip()) is not None


def map_company_code(import_mappings, code):
    """Map a raw broker company code to an internal company code."""
    company_mappings = import_mappings["company_mappings"]
    for key in company_mappings:
        if key == code:
            return company_mappings[key]
    return None


def map_lob(import_mappings, code):
    """Map a raw broker LOB to an internal LOB."""
    lob_mappings = import_mappings["lob_mappings"]
    for key in lob_mappings:
        if code == key:
            return lob_mappings[key]
    return None


def insert_user(connection, email, account_name, status):
    """
    Insert a user if not present; otherwise fetch existing.
    Returns (user_obj, inserted: bool).
    """
    inserted = False

    row = connection.execute(text("""
        SELECT u.id, ui.locale
          FROM user u
          INNER JOIN user_info ui 
             ON u.id = ui.user_id
         WHERE u.email=:email
        """).bindparams(email=email)).first()

    if not row:
        user_id = uuid.uuid1().hex
        connection.execute(text("""
            INSERT INTO user (id, email, status) 
            VALUES (:user_id, :email, :status)
            """).bindparams(user_id=user_id, email=email, status=status))
        inserted = True

        connection.execute(text("""
            INSERT INTO user_role (user_id, role)
            VALUES (:user_id, :role)
            """).bindparams(user_id=user_id, role="user"))

        connection.execute(text("""
            INSERT INTO user_info (user_id, account_name) 
            VALUES (:user_id, :account_name)
            """).bindparams(user_id=user_id, account_name=account_name))
    else:
        user_id = row.id

    user_obj = user.lookup_user_by_id(user_id, optional_connection=connection)
    return user_obj, inserted


def insert_policy(connection, user_obj, policy_number, company, lob):
    """
    Insert or link a user to an active policy version.
    Returns True if a notification should be sent.
    """
    send_notification = False
    policy_downloaded = False

    policy_obj = policy.read_active_by_policy_number_company_lob(
        policy_number,
        company,
        lob,
        optional_connection=connection
    )

    if not policy_obj:
        policy_id = policy.create(policy_number, company, lob, optional_connection=connection)
    else:
        policy_id = policy_obj.id
        policy_downloaded = bool(policy_obj.file_name)

    mapped = connection.execute(text("""
        SELECT 1
          FROM user_policy 
         WHERE user_id=:user_id 
           AND policy_id=:policy_id;
        """).bindparams(user_id=user_obj.id, policy_id=policy_id)).first()

    if not mapped:
        user.add_policy(user_obj.id, policy_id, notify=True, optional_connection=connection)
        if policy_downloaded:
            send_notification = True
    else:
        policy.update_notify(policy_id, user_obj.id, True, optional_connection=connection)

    if not send_notification:
        if policy_downloaded and user_obj.status == 'uploaded':
            send_notification = True

    return send_notification


def notify_user(connection,
                user_obj,
                policy_number,
                company,
                lob,
                journal_id,
                campaign_obj: Optional[object] = None):
    """
    Create or queue a notification for a user.

    Behavior:
    - If `campaign_obj` is supplied, use it directly (skip purpose-based lookup).
      * If there is no latest policy, SKIP (log + journal) to avoid inviting without context.
    - If `campaign_obj` is None, use the existing policy-purpose-based logic (including renewal % calc).
      * If no matching campaign: journal FAILED (unchanged behavior).
    """
    premium_change_percent = None
    latest_policy = policy.read_version_latest(policy_number, company, lob)

    # If a campaign is explicitly provided (e.g., the 'invitation' client campaign)
    if campaign_obj is not None:
        # Require the latest policy to build proper 'regarding' context
        if not latest_policy:
            msg = (f"Skipping notify: no latest policy for user {user_obj.email}, "
                   f"policy {policy_number}, company {company}, lob {lob}")
            Journal().journal(Journal.import_users, journal_id, Journal.STATUS_SUCCESS, msg)
            log.info(msg)
            return
        active_campaign = campaign_obj
    else:
        # Purpose-based path (existing behavior)
        active_campaign = None
        if latest_policy and latest_policy.purpose:
            if latest_policy.purpose == 'RWL':
                previous_policy = policy.read_active_by_policy_number_company_lob(policy_number, company, lob)
                if previous_policy and latest_policy.id == previous_policy.id:
                    previous_policy = policy.read_version_previous(previous_policy.id)

                if previous_policy and latest_policy.annual_premium and previous_policy.annual_premium:
                    premium_change_percent = _calc_premium_change_percent(
                        previous_policy.annual_premium,
                        latest_policy.annual_premium
                    )

            active_campaign = campaign.lookup_policy_campaign_active(
                latest_policy.purpose,
                latest_policy.company,
                latest_policy.lob,
                user_obj.status,
                user_obj.province,
                premium_change_percent,
                optional_connection=connection
            )

        if active_campaign is None:
            ctx_purpose = latest_policy.purpose if latest_policy else "unknown"
            msg = (f"No campaign found for purpose {ctx_purpose}, user {user_obj.email}, "
                   f"policy {policy_number}")
            Journal().journal(Journal.import_users, journal_id, Journal.STATUS_FAILED, msg)
            log.info(msg)
            return

    # Create or reuse today's notifier entry and add the recipient
    now = datetime.now().date()
    notifier_id = notifier.get_pending_notification(active_campaign.id, now)
    if notifier_id is None:
        notifier_id = notifier.create_notification(active_campaign.id, now)

    recipient = SimpleNamespace(company=company, policy_number=policy_number, lob=lob)

    tx_eff = latest_policy.transaction_effective_date if latest_policy else None
    pol_eff = latest_policy.policy_effective_date if latest_policy else None
    pol_exp = latest_policy.policy_expiry_date if latest_policy else None

    reg = campaign.build_regarding(active_campaign, recipient, tx_eff, pol_eff, pol_exp)
    notifier.add_recipient(user_obj.id, notifier_id, active_campaign.id, reg, locale=user_obj.locale)


def _calc_premium_change_percent(premium, new_premium):
    """Percent change: positive if increased, negative if decreased."""
    if premium is None or new_premium is None:
        return 0
    if premium == new_premium:
        return 0
    if new_premium > premium:
        return (new_premium - premium) / premium * 100
    if new_premium < premium:
        return -((premium - new_premium) / premium * 100)
    return 0


@app.task
def execute(previous_task=None):
    """
    Celery task to import users from CSV files.
    - Processes all `dump_*.csv` first (no notifications).
    - Then processes all `new_*.csv` (notifications sent).
    - Then processes all `invite_*.csv` (notifications sent via the invitation client campaign).
    - Validates mappings, checks CSV headers, maps users to policies, logs progress.
    - After all files are processed, backs up the entire import folder.

    :param previous_task: Optional ID for chained tasks.
    :return: (True, number of imported users)
    """
    journal_id = ""
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS
    num_imported = 0
    total_users = 0

    try:
        fm = FileManagerFactory.create_file_manager(LocalFileManager)
        journal_id = Journal().begin_journal(Journal.import_users, "Starting to import users")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to import users")

        config_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "config")
        mappings_path = os.path.join(config_location, "import_mappings.yaml")

        with open(mappings_path, 'r') as file:
            import_mappings = yaml.safe_load(file)
            validate_import_mappings(import_mappings)

        email_column = import_mappings["csv_column_mappings"]["email"]
        account_column = import_mappings["csv_column_mappings"]["account"]
        company_code_column = import_mappings["csv_column_mappings"]["company_code"]
        lob_column = import_mappings["csv_column_mappings"]["lob"]
        policy_number_column = import_mappings["csv_column_mappings"]["policy_number"]

        # Get all files in the import folder.
        if fm.exists(Repository.import_users_location):
            all_files = fm.listdir(Repository.import_users_location)

            # Separate dump_, new_, and invite_ files.
            dump_files = sorted([f for f in all_files if f.startswith("dump_") and f.endswith(".csv")])
            new_files = sorted([f for f in all_files if f.startswith("new_") and f.endswith(".csv")])
            invite_files = sorted([f for f in all_files if f.startswith("invite_") and f.endswith(".csv")])

            # Processing order: dump_ first, then new_, then invite_
            files_to_process = dump_files + new_files + invite_files

            if files_to_process:
                # Look up the invitation campaign.
                invitation_campaign = None
                if invite_files:
                    with get_connection() as connection:
                        invitation_campaign = campaign.lookup_client_campaign_active(
                            "invitation",
                            permanent=True,
                            optional_connection=connection
                        )

                    # FAIL FAST: invite files exist, but no invitation campaign configured.
                    if invite_files and not invitation_campaign:
                        raise TaskException(
                            "Invite files found but no active 'invitation' client campaign is configured.",
                            error_code=exceptions.CODE_TASK_FAILED
                        )

                for current_file in files_to_process:
                    file_path = fm.join(Repository.import_users_location, current_file)
                    is_new = current_file.startswith("new_")
                    is_invite = current_file.startswith("invite_")
                    should_notify = is_new or is_invite

                    try:
                        with open(fm.get_absolute_path(file_path), newline="", encoding="utf-8-sig") as csvfile:
                            reader = csv.DictReader(csvfile)
                            rows = list(reader)
                            expected_csv_columns = list(import_mappings["csv_column_mappings"].values())
                            validate_csv_headers(reader.fieldnames, expected_csv_columns)
                            total_users += len(rows)

                            for i, p in enumerate(rows):
                                account_name = p[account_column]
                                broker_lob = p[lob_column]
                                broker_company = p[company_code_column]
                                policy_number = al3_utils.fix_policy_number(p[policy_number_column])

                                if not policy_number or "BINDER" in policy_number:
                                    msg = f'Policy {policy_number} is invalid: {account_name}'
                                    Journal().journal(Journal.import_users, journal_id, end_status, msg)
                                    log.info(msg)
                                    continue

                                raw_email = p.get(email_column, "").strip()
                                email = raw_email if is_valid_email(raw_email) else None

                                if not email:
                                    msg = (f'Email {email} is missing or invalid: '
                                           f'{account_name}, {policy_number}')
                                    Journal().journal(Journal.import_users, journal_id, end_status, msg)
                                    log.info(msg)
                                    continue

                                lob_val = map_lob(import_mappings, broker_lob)
                                if not lob_val:
                                    msg = (f'Line of business {broker_lob} is not supported: '
                                           f'{email}, {account_name}, {policy_number}')
                                    Journal().journal(Journal.import_users, journal_id, end_status, msg)
                                    log.info(msg)
                                    continue

                                company_val = map_company_code(import_mappings, broker_company)
                                if not company_val:
                                    msg = (f'Company code {broker_company} is not supported: '
                                           f'{email}, {account_name}, {policy_number}')
                                    Journal().journal(Journal.import_users, journal_id, end_status, msg)
                                    log.info(msg)
                                    continue

                                with get_connection() as connection:
                                    user_obj, inserted = insert_user(
                                        connection,
                                        email,
                                        account_name,
                                        status="uploaded"
                                    )

                                    send_notification = insert_policy(
                                        connection,
                                        user_obj,
                                        policy_number,
                                        company_val,
                                        lob_val
                                    )

                                    if should_notify and send_notification:
                                        # For invite files, pass the pre-fetched invitation campaign.
                                        notify_user(
                                            connection,
                                            user_obj,
                                            policy_number,
                                            company_val,
                                            lob_val,
                                            journal_id,
                                            campaign_obj=(invitation_campaign if is_invite else None)
                                        )

                                    connection.commit()

                                if inserted:
                                    num_imported += 1
                                else:
                                    msg = f"User {email} existed"
                                    Journal().journal(Journal.import_users, journal_id, Journal.STATUS_SUCCESS, msg)
                                    log.info(msg)

                    except Exception as e:
                        end_status = _handle_error_import_users_file(journal_id, current_file, e)

                # Backup the entire folder after all files are done
                current_time = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
                backup_folder = fm.join(Repository.import_location, f"users-{current_time}")
                fm.rename(Repository.import_users_location, backup_folder)
                fm.mkdir(Repository.import_users_location)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = f"Successfully imported {num_imported} of {total_users} user(s)"
        else:
            if num_imported > 0:
                end_msg = f"Failed but imported {num_imported} of {total_users} user(s)"
            else:
                end_msg = "User import failed"

            raise TaskException(end_msg, error_code=exceptions.CODE_TASK_FAILED)

        return True, num_imported

    except Exception as e:
        end_status, end_msg = _handle_error_import_users(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.import_users, journal_id, end_status, end_msg, num_imported, total_users)


def _handle_error_import_users(journal_id, e):
    """Top-level error handler."""
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] import users error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while importing users"


def _handle_error_import_users_file(journal_id, file, e):
    """File-level error handler."""
    if file:
        log.error(f"[{journal_id}] failed while importing file {file}")
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] import users error: {message}", exc_info=True)
    return Journal.STATUS_FAILED
