import json
import logging

import requests

from lib_common import constants, exceptions
from lib_common.authentication import generate_collection_token
from lib_common.constants import LOGGER
from lib_common.exceptions import TaskException
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_journal.journal import Journal
from lib_persistence import collector, lead, policy, settings
from lib_policy_dom.policy_dom import PolicyDOM
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


def upper(val):
    if val is not None:
        return val.upper()

    return val


def _vehicle_exists(vehicles, vehicle):
    veh_year = upper(vehicle.vehicle_year)
    veh_make = upper(vehicle.vehicle_make)
    veh_model = upper(vehicle.vehicle_model)
    veh_vin = upper(vehicle.vehicle_vin)

    for v in vehicles:
        v_year = upper(v.vehicle_year)
        v_make = upper(v.vehicle_make)
        v_model = upper(v.vehicle_model)
        v_vin = upper(v.vehicle_vin)

        if v_vin == veh_vin:
            return True

        if v_year == veh_year and (v_make in veh_make or veh_make in v_make) and (
                v_model in veh_model or veh_model in v_model):
            return True

    return False


def _property_exists(properties, prop):
    for p in properties:
        if upper(p.address) == upper(prop.address) and upper(p.city) == upper(prop.city) and upper(p.province) == upper(
                prop.province) and upper(p.postal_code) == upper(prop.postal_code):
            return True

    return False


def _card_exists(cards, card):
    for c in cards:
        if upper(c.name) == upper(card.name) and upper(c.type) == upper(card.type):
            return True

    return False


def _collect_life(user_id):
    vehicles = []
    properties = []
    loyalties = []

    collection_url = settings.get_setting(constants.SETTING_LIFES_WALLET_COLLECTION_API_URL)

    if collection_url is None or len(collection_url) <= 0:
        return None

    connect_endpoint = settings.get_setting(
        constants.SETTING_LIFES_WALLET_COLLECTION_API_URL) + "/" + settings.get_setting(
        constants.SETTING_BROKERAGE_ID) + "/" + user_id

    if connect_endpoint is not None and len(connect_endpoint) > 0:
        collect_token = generate_collection_token()

        if collect_token is None:
            return None

        # Build a brokerage token to authenticate the request.
        response_from_collector = requests.get(connect_endpoint, headers={
            "Authorization": "Bearer " + collect_token
        })

        if response_from_collector.status_code != 200:
            return None

        data = json.loads(response_from_collector.json())

        for row in data:
            if row["type"] == "auto":
                vehicles.append(row)
                collector.insert_vehicle(user_id, "life", vehicle_year=row["vehicle_year"],
                                         vehicle_make=row["vehicle_make"], vehicle_model=row["vehicle_model"],
                                         vehicle_vin=row["vehicle_vin"])
                continue

            if row["type"] == "property":
                properties.append(row)
                collector.insert_property(user_id, "life", address=row["address"], city=row["city"],
                                          province=row["province"], postal_code=row["postal_code"], )
                continue

            if row["type"] == "loyalty":
                loyalties.append(row)
                collector.insert_card(user_id, "life", name=row["name"], card_type=row["type"])
                continue

    return vehicles, properties, loyalties


def _collect_csio(user_id):
    fm = FileManagerFactory.create_file_manager()
    policies = policy.list_active_by_user_id(user_id, in_effect=False)

    for p in policies:
        if p.file_name is not None:
            policy_dom = PolicyDOM.load(fm.join(Repository.policies_location, p.file_name))
            vehicles = policy_dom.vehicles

            for v in vehicles:
                collector.insert_vehicle(
                    user_id,
                    "csio",
                    vehicle_year=v.vehicle_year,
                    vehicle_make=v.make,
                    vehicle_model=v.model,
                    vehicle_vin=v.vin)

            properties = policy_dom.properties

            for prop in properties:
                collector.insert_property(
                    user_id,
                    "csio",
                    address=prop.address,
                    city=prop.city,
                    province=prop.province_code,
                    postal_code=prop.postal_code)


def _generate_leads(user_id, email):
    csio_vehicles = collector.list_collected_autos(user_id, "csio")
    life_vehicles = collector.list_collected_autos(user_id, "life")

    for life_vehicle in life_vehicles:
        if not _vehicle_exists(csio_vehicles, life_vehicle):
            lead.create_lead(user_id, life_vehicle.id, "auto", "uninsured")

    csio_properties = collector.list_collected_properties(user_id, "csio")
    life_properties = collector.list_collected_properties(user_id, "life")

    for life_property in life_properties:
        if not _property_exists(csio_properties, life_property):
            lead.create_lead(user_id, life_property.id, "property", "uninsured")


@app.task
def execute(previous_task=None):
    journal_id = ""
    n_users = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        journal_id = Journal().begin_journal(Journal.collect, "Starting to collect")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to collect")

        rows = collector.get_ready_to_collect()

        for r in rows:
            collector_id = None
            user_id = None

            try:
                collector_id = r.id
                user_id = r.user_id
                email = r.email

                collector.delete_collections(user_id, "life")
                collector.delete_collections(user_id, "csio")
                lead.delete_leads(user_id)

                _collect_life(user_id)
                _collect_csio(user_id)

                _generate_leads(user_id, email)

                n_users += 1
                collector.mark_collected(collector_id)
            except Exception as e:
                message = getattr(e, "message", str(e))
                collector.mark_collector_failed(collector_id, message)
                _handle_error_collecting_user(journal_id, user_id, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully collected {n} users".format(n=n_users)
        else:
            if n_users > 0:
                end_msg = "Failed but collected {n} users".format(n=n_users)
            else:
                end_msg = "Failed collecting".format(n=n_users)

            raise TaskException(
                end_msg,
                error_code=exceptions.CODE_TASK_FAILED
            )

        return True, n_users

    except Exception as e:
        end_status, end_msg = _handle_error_collecting(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.collect, journal_id, end_status, end_msg, n_users)


def _handle_error_collecting_user(journal_id, user_id, e):
    if user_id is not None:
        log.error(f"[{journal_id}] failed while collecting user {user_id}")

    message = getattr(e, "message", str(e))

    log.error(f"[{journal_id}] collecting error: {message}", exc_info=True)

    return Journal.STATUS_FAILED


def _handle_error_collecting(journal_id, e):
    message = getattr(e, "message", str(e))

    log.error(f"[{journal_id}] collect error: {message}", exc_info=True)

    return Journal.STATUS_FAILED, message or "Failed while collecting"
