import logging
from datetime import datetime

from tasks.celery_app import app
from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception, XMLException
from lib_journal.journal import Journal
from lib_persistence import indexer, persistence

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    journal_id = ""
    num_scheduled = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        journal_id = Journal().begin_journal(Journal.scan_schedule, "Starting to schedule scans")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to schedule scans")

        entries = indexer.get_indexer_files(persistence.INDEXER_SCAN_SCHEDULE)

        for entry in entries:
            file = None
            entry_id = None

            try:
                entry_id = entry.id

                # Create an entry to scan the policy now.
                indexer.add_to_indexer(
                    persistence.INDEXER_SCAN,
                    entry.file_name,
                    policy_id=entry.policy_id,
                    process=datetime.now().date())

                # Create another entry to scan on the policy on the transaction effective date.
                indexer.add_to_indexer(
                    persistence.INDEXER_SCAN,
                    entry.file_name,
                    policy_id=entry.policy_id,
                    process=entry.transaction_effective_date)

                num_scheduled += 1

                # Move the current entry to the indexing phase.
                indexer.update_name(entry_id, persistence.INDEXER_INDEX, policy_id=entry.policy_id)

            except (AL3Exception, XMLException) as e:
                indexer.mark_indexer_failed(entry_id, e.message, code=e.code)

            except Exception as e:
                if entry_id is not None:
                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)

                end_status = _handle_error_scheduling_scan_file(journal_id, file, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully scheduled a scan for {n} files".format(n=num_scheduled)
        else:
            if num_scheduled > 0:
                end_msg = "Failed but scheduled a scan for {n} files".format(n=num_scheduled)
            else:
                end_msg = "Failed scheduling scans"

            # raise TaskException(
            #     end_msg,
            #     error_code=exceptions.CODE_TASK_FAILED
            # )

        return True, num_scheduled

    except Exception as e:
        end_status, end_msg = _handle_error_scheduling_scan(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.scan_schedule, journal_id, end_status, end_msg, num_scheduled)


def _handle_error_scheduling_scan(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] scheduling scan error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while scheduling scan"


def _handle_error_scheduling_scan_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while scheduling scan {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] scheduling scan error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
