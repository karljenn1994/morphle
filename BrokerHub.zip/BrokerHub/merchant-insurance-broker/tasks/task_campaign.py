import logging

from lib_common import exceptions
from lib_common.constants import LOGGER
from lib_common.exceptions import TaskException
from lib_journal.journal import Journal
from lib_persistence import campaign
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    journal_id = ""
    num_executed = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        journal_id = Journal().begin_journal(Journal.campaign, "Starting to execute campaigns")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to execute campaigns")

        campaigns = campaign.list_campaigns_active()

        for campaign_obj in campaigns:
            name = campaign_obj.name

            try:
                if campaign_obj.scheduled:
                    campaign.execute_campaign(campaign_obj.id)
                    num_executed += 1

            except Exception as e:
                end_status = _handle_error_executing_campaign(journal_id, name, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully execute {n} campaigns".format(n=num_executed)
        else:
            if num_executed > 0:
                end_msg = "Failed but executed {n} campaigns".format(n=num_executed)
            else:
                end_msg = "Failed executing campaigns"

            raise TaskException(
                end_msg,
                error_code=exceptions.CODE_TASK_FAILED
            )

        return True, num_executed

    except Exception as e:
        end_status, end_msg = _handle_error_executing_campaigns(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.campaign, journal_id, end_status, end_msg, num_executed)


def _handle_error_executing_campaigns(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] executing campaigns error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while executing campaigns"


def _handle_error_executing_campaign(journal_id, name, e):
    if name is not None:
        log.error(f"[{journal_id}] failed executing campaign {name}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] failed executing campaign: {message}", exc_info=True)

    return Journal.STATUS_FAILED
