import logging
import math
import os
from datetime import datetime, timezone

import requests
from dateutil import parser as dateutil_parser

from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import al3_extensions, val
from lib_common import authentication, constants
from lib_common.constants import LOGGER
from lib_common.exceptions import CODE_CSIONET_SIGNIN_FAILED, HttpException
from lib_common.mailbox import Mailbox
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_journal.journal import Journal
from lib_persistence import branch, get_connection, indexer, persistence, policy, settings
from lib_policy_dom.policy_dom import PolicyDOM
from lib_vault.vault import Vault
from lib_xml_dom.xml_dom import XmlDOM, xml_extensions
from tasks.celery_app import app

PAGE_SIZE = 100
REQUEST_TIMEOUT = (5, 45)  # connect, read
MAX_RETRIES = 3
CSIO_NET_URL = "https://web.csionet.com/v1/MessageServices.aspx"

log = logging.getLogger(LOGGER)


# -------------------------
# Mode helpers
# -------------------------
def _is_gateway() -> bool:
    """Gateway mode: this instance pulls mail from CSIONet for all branches."""
    return settings.get_bool_setting(constants.SETTING_SYSTEM_MAIL_IS_GATEWAY)


def _is_branch_mode() -> bool:
    """Branch mode: this instance pulls mail from a gateway using a Branch + BranchToken."""
    api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
    return (not _is_gateway()) and bool(api_key)


def _is_normal_mode() -> bool:
    """Normal mode: single-tenant; pulls from CSIONet only for itself."""
    return (not _is_gateway()) and (not _is_branch_mode())


def _self_branch_name() -> str:
    # Canonical name for this instance as a branch
    return settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER) or ""


def _email_url() -> str:
    """
    Endpoint selection:
      - branch mode -> gateway branch endpoint
      - gateway mode -> CSIONet (or configured passthrough)
      - normal mode -> CSIONet
    """
    if _is_branch_mode():
        return settings.get_setting(constants.SETTING_SYSTEM_MAIL_BRANCH_URL)
    if _is_gateway():
        return settings.get_setting(constants.SETTING_SYSTEM_MAIL_GATEWAY_URL) or CSIO_NET_URL
    return CSIO_NET_URL


def _all_mail_location(fm=None) -> str:
    fm = fm or FileManagerFactory.create_file_manager()
    path = fm.join(Repository.mail_root_location, Repository.mail_all_mail_location)
    if not fm.exists(path):
        try:
            fm.mkdirs(path)
        except Exception:
            pass
    return path


# -------------------------
# Utilities + HTTP helpers
# -------------------------
def _as_list(x):
    if not x:
        return []
    return x if isinstance(x, list) else [x]


def _normalize_csio_ts(s: str) -> str:
    if not s:
        return s
    s = s.replace("T:", "T")
    if not s.endswith("Z"):
        s = s + "Z"
    return s


def _csio_post(payload):
    last_exc = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            url = _email_url()
            return requests.post(url, json=payload, timeout=REQUEST_TIMEOUT)
        except Exception as e:
            last_exc = e
            if attempt == MAX_RETRIES:
                raise
            log.warning("CSIO POST retry %d/%d due to %s", attempt, MAX_RETRIES, repr(e))
    raise last_exc


def _get_response_object(response):
    response_json = response.json()
    if response.status_code != 200:
        error_msg = "Failed to sign in to CSIONet"
        if "Response" in response_json and "Status" in response_json:
            error_msg = response_json["Response"]["Status"]
        raise HttpException(error_msg, error_code=CODE_CSIONET_SIGNIN_FAILED)
    if "Response" not in response_json:
        raise HttpException("Response object missing in response", error_code=CODE_CSIONET_SIGNIN_FAILED)
    return response_json["Response"]


# -------------------------
# Auth flows (mode-aware)
# -------------------------
def _sign_in():
    """
    Sign-in:
      - branch mode:   Branch + BranchToken to gateway
      - gateway/normal: CSIONet credentials
    """
    if _is_branch_mode():
        api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
        branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
        branch_token = authentication.generate_branch_mail_token(api_key) if api_key else None

        data = {
            "CommandType": "SignIn",
            "Branch": branch_name,
            "BranchToken": branch_token
        }
        response = _get_response_object(_csio_post(data))
    else:
        # gateway OR normal → CSIONet creds
        username = Vault().get(constants.SETTING_CSIONET_USER)
        password = Vault().get(constants.SETTING_CSIONET_PASSWORD)
        if not username or not password:
            return None
        data = {
            "CommandType": "SignIn",
            "CSIOnetID": username,
            "CSIOnetPassword": password
        }
        response = _get_response_object(_csio_post(data))

    if "SessionGUID" not in response:
        raise HttpException("Session GUID missing in response object", error_code=CODE_CSIONET_SIGNIN_FAILED)
    return response["SessionGUID"]


def _sign_out(session_guid):
    if not session_guid:
        return
    try:
        if _is_branch_mode():
            api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
            branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
            branch_token = authentication.generate_branch_mail_token(api_key) if api_key else None
            data = {
                "CommandType": "SignOut",
                "SessionGUID": session_guid,
                "Branch": branch_name,
                "BranchToken": branch_token
            }
        else:
            data = {"CommandType": "SignOut", "SessionGUID": session_guid}
        _csio_post(data)
    except Exception as e:
        log.error(e, exc_info=True)


# -------------------------
# Gateway/Branch message ops
# -------------------------
def _ack_message(session_guid: str, message_id: str):
    """
    Acknowledge (gateway branch API only).
    Must never be sent to CSIONet directly.
    """
    if not _is_branch_mode():
        return
    api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
    branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
    branch_token = authentication.generate_branch_mail_token(api_key) if api_key else None
    data = {
        "CommandType": "Acknowledge",
        "SessionGUID": session_guid,
        "MessageGUID": message_id,
        "Branch": branch_name,
        "BranchToken": branch_token,
    }
    _get_response_object(_csio_post(data))


def _release_message(session_guid: str, message_id: str):
    """
    Release a lease (gateway branch API only).
    Must never be sent to CSIONet directly.
    """
    if not _is_branch_mode():
        return
    api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
    branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
    branch_token = authentication.generate_branch_mail_token(api_key) if api_key else None
    data = {
        "CommandType": "Release",
        "SessionGUID": session_guid,
        "MessageGUID": message_id,
        "Branch": branch_name,
        "BranchToken": branch_token,
    }
    _get_response_object(_csio_post(data))


# -------------------------
# Message helpers
# -------------------------
def _folder_basename(message_datetime: str, message_guid: str) -> str:
    dt = dateutil_parser.isoparse(message_datetime)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    dt = dt.astimezone(timezone.utc).replace(microsecond=0)
    dt_part = dt.strftime("%Y-%m-%d_%H-%M-%S")
    guid_part = (message_guid or "").replace(".", "_")
    return f"{dt_part}_{guid_part}" if guid_part else dt_part


class CursorState:
    def __init__(self, start_dt_str: str):
        self.max_dt_str = start_dt_str
        self.guids_at_max = set()
        self.processed = 0
        self.skipped_recent = 0
        self.num_read = 0

    def consider(self, guid: str, msg_dt_str: str):
        if msg_dt_str > self.max_dt_str:
            self.max_dt_str = msg_dt_str
            self.guids_at_max = {guid}
        elif msg_dt_str == self.max_dt_str:
            self.guids_at_max.add(guid)


def _attachments(obj):
    if "Attachments" in obj and "Attachment" in obj["Attachments"]:
        return _as_list(obj["Attachments"]["Attachment"])
    return []


def _retrieve_message(session_guid, message_id):
    """
    Retrieve:
      - branch mode: include Branch/BranchToken (to gateway)
      - gateway/normal: CSIONet retrieve with SessionGUID only
    """
    if _is_branch_mode():
        api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
        branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
        branch_token = authentication.generate_branch_mail_token(api_key) if api_key else None
        data = {
            "CommandType": "Retrieve",
            "SessionGUID": session_guid,
            "MessageGUID": message_id,
            "Branch": branch_name,
            "BranchToken": branch_token,
            "Delete": 0
        }
    else:
        data = {
            "CommandType": "Retrieve",
            "SessionGUID": session_guid,
            "MessageGUID": message_id,
            "Delete": 0
        }
    return _get_response_object(_csio_post(data))


def _fetch_messages(session_guid, from_date_time, to_date_time, page=1, page_size=PAGE_SIZE):
    """
    List:
      - branch mode: include Branch/BranchToken (to gateway)
      - gateway/normal: CSIONet list with SessionGUID only
    """
    if _is_branch_mode():
        api_key = Vault().get(constants.SETTING_SYSTEM_MAIL_BRANCH_API_KEY)
        branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
        branch_token = authentication.generate_branch_mail_token(api_key) if api_key else None
        data = {
            "CommandType": "List",
            "SessionGUID": session_guid,
            "Branch": branch_name,
            "BranchToken": branch_token,
            "FromDateTime": from_date_time,
            "ToDateTime": to_date_time,
            "Page": page,
            "PageSize": page_size,
        }
    else:
        data = {
            "CommandType": "List",
            "SessionGUID": session_guid,
            "FromDateTime": from_date_time,
            "ToDateTime": to_date_time,
            "Page": page,
            "PageSize": page_size,
        }
    return _get_response_object(_csio_post(data))


# -------------------------
# Indexing helpers
# -------------------------
def _enqueue_inbox_folder(fm, folder_path: str):
    """
    Enqueue all files within `folder_path` for indexing with paths
    relative to Repository.mail_inbox_location (folder/filename.ext).
    """
    try:
        folder_name = fm.basename(folder_path)
        for f_name in fm.listdir(folder_path):
            if f_name.startswith("."):
                continue
            rel_path = fm.join(folder_name, f_name)
            indexer.add_to_indexer(persistence.INDEXER_ORGANIZE, rel_path)
    except Exception as e:
        log.warning("Failed to enqueue inbox files for %s: %s", folder_path, e)


# -------------------------
# Page processing
# -------------------------
def _process_page_response(resp, recent_messages_set, session_guid, state: CursorState, save_root: str):
    raw_messages = resp.get("Message", [])
    messages = _as_list(raw_messages)
    messages.sort(key=lambda m: m["DateTime"])

    fm = FileManagerFactory.create_file_manager()

    for msg in messages:
        guid = msg["MessageGUID"]
        msg_dt_str = msg["DateTime"]

        if guid in recent_messages_set:
            state.skipped_recent += 1
            state.consider(guid, msg_dt_str)
            continue

        try:
            # Ensure clean target directory
            target_folder = None
            try:
                basename = _folder_basename(msg_dt_str, guid)
                target_folder = fm.join(save_root, basename)
                if fm.exists(target_folder):
                    fm.rmtree(target_folder)
            except Exception as e:
                if target_folder:
                    log.warning("Failed removing existing target folder %s: %s", target_folder, e)

            # Retrieve + save
            obj = _retrieve_message(session_guid, guid)
            attachments = _attachments(obj)
            saved = Mailbox().save_api_attachments(  # returns paths relative to save_root
                save_root,
                attachments,
                msg_dt_str,
                guid,
                obj.get('MessageType')
            )

            # Index at fetch time in NON-gateway modes (branch or normal),
            # because in those modes save_root == inbox and mail are "ours".
            if (not _is_gateway()) and saved and (save_root == Repository.mail_inbox_location):
                for rel in saved:
                    indexer.add_to_indexer(persistence.INDEXER_ORGANIZE, rel)

            # Branch mode only: Acknowledge after successful save
            if _is_branch_mode():
                _ack_message(session_guid, guid)
                log.info("ACKed %s", guid)

        except Exception as e:
            log.error("Failed processing %s: %s", guid, e, exc_info=True)
            # Branch mode only: Release on failure so it can be retried elsewhere
            if _is_branch_mode():
                try:
                    _release_message(session_guid, guid)
                    log.info("Released %s after failure", guid)
                except Exception as re:
                    log.warning("Release failed for %s: %s", guid, re)

        # advance cursor regardless (we only dedupe on GUIDs at same second)
        state.consider(guid, msg_dt_str)
        state.processed += 1
        state.num_read += 1


# -------------------------
# Cursor read/write
# -------------------------
def _read_cursor():
    mail_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "mail")
    mail_index_file = os.path.join(mail_location, ".mail_index")

    try:
        with open(mail_index_file, "r") as f:
            raw = f.read().strip()
            start_dt_str = raw or "1973-01-01T00:00:00.00Z"
    except FileNotFoundError:
        start_dt_str = "1973-01-01T00:00:00.00Z"

    start_dt_str = _normalize_csio_ts(start_dt_str)

    guids = set()
    try:
        recent_messages_file = os.path.join(mail_location, ".recent_messages")
        with open(recent_messages_file, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    guids.add(line)
    except FileNotFoundError:
        pass

    return start_dt_str, guids


def _write_cursor(state: CursorState):
    mail_location = os.path.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "mail")
    with open(os.path.join(mail_location, ".mail_index"), "w+") as f:
        f.write(_normalize_csio_ts(state.max_dt_str))
    with open(os.path.join(mail_location, ".recent_messages"), "w") as f:
        for g in sorted(state.guids_at_max):
            f.write(g + "\n")


# -------------------------
# Junk helper
# -------------------------
def _move_to_junk(fm, root, policy_number: str):
    junk_root = fm.join(Repository.mail_root_location, "junk")
    if not fm.exists(junk_root):
        fm.mkdirs(junk_root)
    dest = fm.join(junk_root, fm.basename(root))
    try:
        if fm.exists(dest):
            fm.rmtree(dest)
        fm.move(root, dest)
        log.info("Moved %s to junk (policy=%s)", root, policy_number)
    except Exception as e:
        log.warning("Failed to move %s to junk: %s", root, e)


# -------------------------
# AL3/XML helpers
# -------------------------
def _extract_contract_and_policy_entries(full_path):
    """
    Extract contract number plus (policy_number, company, lob) triples
    from an AL3 file.
    """
    entries = []
    al3_tr = AL3ToJSON()
    al3 = al3_tr.load(full_path)
    header = al3_tr.read_message_header(al3)
    contract = val(header, "03", default=None)

    records = al3_tr.to_list(al3)
    if records:
        for record in records:
            al3_json = AL3ToJSON().to_json(record)
            policy_dom = PolicyDOM.from_al3_json(al3_json)
            if policy_dom.policy and policy_dom.policy.number:
                policy_number = policy_dom.policy.number
                company = policy.map_company_code(policy_dom.policy.company)
                lob = policy_dom.policy.lob
                entries.append((policy_number, company, lob))

    return contract, entries


def _move_to_unsorted(fm, root, reason_folder):
    unsorted_root = fm.join(Repository.mail_root_location, "unsorted", reason_folder)
    if not fm.exists(unsorted_root):
        fm.mkdirs(unsorted_root)
    dest = fm.join(unsorted_root, fm.basename(root))
    try:
        if fm.exists(dest):
            fm.rmtree(dest)
        fm.move(root, dest)
        log.info("Moved %s to unsorted/%s", root, reason_folder)
    except Exception as e:
        log.warning("Failed to move %s to unsorted/%s: %s", root, reason_folder, e)


# -------------------------
# Fetch (mode-aware)
# -------------------------
def fetch_mail():
    """
    Modes:
      - Normal mode:  fetch -> inbox/ (index immediately)
      - Branch mode:  fetch -> inbox/ (index immediately, ACK per message; RELEASE on failure)
      - Gateway:      fetch -> all_mail/ (no indexing/ACK here)
    """
    journal_id = ""
    start_idx = -1
    end_msg = ""
    end_status = None
    session_guid = None
    jm = Journal()
    fm = FileManagerFactory.create_file_manager()

    try:
        start_date_time_str, recent_messages = _read_cursor()
        journal_id = jm.begin_journal(Journal.mail, f"Starting to read messages from {start_date_time_str}")

        session_guid = _sign_in()
        if session_guid is None:
            end_status = Journal.STATUS_FAILED
            end_msg = "Failed fetching messages (missing credentials)"
            return

        # Decide to save root based on mode
        if _is_gateway():
            save_root = _all_mail_location(fm)
        else:
            # branch OR normal → inbox
            save_root = Repository.mail_inbox_location

        end_date_time_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.00Z")

        resp0 = _fetch_messages(session_guid, start_date_time_str, end_date_time_str)
        total_available = int(resp0.get("MessagesAvailable", 0))
        pages = math.ceil(total_available / PAGE_SIZE) if total_available > 0 else 0
        state = CursorState(start_date_time_str)

        if total_available > 0:
            _process_page_response(resp0, recent_messages, session_guid, state, save_root)
            for page in range(2, pages + 1):
                resp = _fetch_messages(session_guid, start_date_time_str, end_date_time_str, page, PAGE_SIZE)
                _process_page_response(resp, recent_messages, session_guid, state, save_root)

        _write_cursor(state)

        end_status = Journal.STATUS_SUCCESS
        end_msg = (
            f"Fetched {state.processed} new message(s); "
            f"skipped {state.skipped_recent} seen-at-same-second; "
            f"available_at_start={total_available}"
        )
        return

    except Exception as e:
        message = getattr(e, "message", str(e))
        log.error(f"[{journal_id}] fetching messages error: {message}", exc_info=True)
        end_msg = message or "Failed while fetching messages"
        end_status = Journal.STATUS_FAILED
        raise
    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)
        Journal().end_journal(Journal.mail, journal_id, end_status, end_msg, start_idx,
                              0 if end_status != Journal.STATUS_SUCCESS else None)
        _sign_out(session_guid)


# -------------------------
# Sort (gateway only)
# -------------------------
def sort_mail():
    if not _is_gateway():
        return

    journal_id = ""
    end_msg = ""
    end_status = None
    num_sorted = 0
    jm = Journal()
    fm = FileManagerFactory.create_file_manager()

    self_branch = _self_branch_name()

    try:
        journal_id = jm.begin_journal(Journal.mail, "Starting to sort messages (gateway mode)")
        source_root = _all_mail_location(fm)

        # Pass 1: AL3
        for root, dirs, files in fm.walk(source_root):
            if len(dirs) > 0:
                continue
            moved = False
            for file in files:
                if moved:
                    break
                try:
                    is_num_ext = fm.splitext(file)[1].strip(".").isnumeric()
                    if file.lower().endswith(al3_extensions) or is_num_ext:
                        with get_connection() as connection:
                            try:
                                contract, entries = _extract_contract_and_policy_entries(fm.join(root, file))
                            except Exception:
                                _move_to_unsorted(fm, root, "al3_invalid")
                                moved = True
                                break

                            if not contract:
                                _move_to_unsorted(fm, root, "al3_no_contract")
                                moved = True
                                break

                            branch_name = branch.lookup_branch_contract_by_contract_number(
                                contract, optional_connection=connection
                            )
                            if not branch_name:
                                log.error("No contract mapping for contract " + contract)
                                _move_to_unsorted(fm, root, "al3_no_branch_mapping")
                                moved = True
                                break

                            # Validate company mapping
                            valid_entries = []
                            for policy_number, company, lob in entries:
                                if not company:
                                    log.warning("Unmapped company for policy %s", policy_number)
                                    _move_to_unsorted(fm, root, "al3_no_company_mapping")
                                    moved = True
                                    break
                                valid_entries.append((policy_number, company, lob))
                            if moved:
                                break

                            try:
                                # Destination depends on whether it's our own branch
                                if self_branch and branch_name == self_branch:
                                    dest_parent = Repository.mail_inbox_location
                                else:
                                    dest_parent = fm.join(Repository.mail_root_location, "branches", branch_name)

                                if not fm.exists(dest_parent):
                                    fm.mkdirs(dest_parent)

                                dest = fm.join(dest_parent, fm.basename(root))
                                if fm.exists(dest):
                                    fm.rmtree(dest)

                                fm.move(root, dest)

                                # Index only when moved into inbox (self branch)
                                if dest_parent == Repository.mail_inbox_location:
                                    _enqueue_inbox_folder(fm, dest)

                                branch.upsert_branch_policies(
                                    branch_name, valid_entries, optional_connection=connection
                                )
                                connection.commit()

                                num_sorted += 1
                                moved = True
                                break
                            except Exception as e:
                                log.warning("Failed to move AL3 folder %s: %s", root, e)
                                break
                except Exception as e:
                    log.error("Error processing AL3 folder %s: %s", root, e, exc_info=True)

        # Pass 2: XML
        for root, dirs, files in fm.walk(source_root):
            if len(dirs) > 0:
                continue
            moved = False
            for file in files:
                if moved:
                    break
                try:
                    if file.lower().endswith(xml_extensions):
                        try:
                            xml_dom = XmlDOM.load(fm.join(root, file))
                        except Exception:
                            _move_to_unsorted(fm, root, "xml_invalid")
                            moved = True
                            break

                        policy_number = xml_dom.policy_number
                        company = policy.map_company_code(xml_dom.company)
                        lob = xml_dom.lob

                        if not policy_number:
                            _move_to_unsorted(fm, root, "xml_no_policy")
                            moved = True
                            break

                        if policy_number in ("N/A", "BINDER", "Control Report"):
                            _move_to_junk(fm, root, policy_number)
                            moved = True
                            break

                        if not company:
                            _move_to_unsorted(fm, root, "xml_no_company_mapping")
                            moved = True
                            break

                        branch_name = branch.lookup_branch_policy_by_policy_number(policy_number)
                        if not branch_name:
                            log.info(
                                "XML %s has policy %s but no branch mapping; leaving in all_mail for retry",
                                root,
                                policy_number,
                            )
                            break

                        try:
                            if self_branch and branch_name == self_branch:
                                dest_parent = Repository.mail_inbox_location
                            else:
                                dest_parent = fm.join(Repository.mail_root_location, "branches", branch_name)

                            if not fm.exists(dest_parent):
                                fm.mkdirs(dest_parent)

                            dest = fm.join(dest_parent, fm.basename(root))
                            if fm.exists(dest):
                                fm.rmtree(dest)
                            fm.move(root, dest)

                            if dest_parent == Repository.mail_inbox_location:
                                _enqueue_inbox_folder(fm, dest)

                            with get_connection() as connection:
                                branch.upsert_branch_policies(
                                    branch_name, [(policy_number, company, lob)], optional_connection=connection
                                )
                                connection.commit()

                            num_sorted += 1
                            moved = True
                            break
                        except Exception as e:
                            log.warning("Failed to move XML folder %s: %s", root, e)
                            break
                except Exception as e:
                    log.error("Error processing XML folder %s: %s", root, e, exc_info=True)

        end_msg = f"Sorted {num_sorted} new message(s) (gateway mode)"
        end_status = Journal.STATUS_SUCCESS
    except Exception as e:
        message = getattr(e, "message", str(e))
        log.error(f"[{journal_id}] sorting messages error: {message}", exc_info=True)
        end_msg = message or "Failed while sorting messages"
        end_status = Journal.STATUS_FAILED
        raise
    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)
        Journal().end_journal(Journal.mail, journal_id, end_status, end_msg)


@app.task
def execute(_=None):
    fetch_mail()

    # Only sort in gateway mode
    if _is_gateway():
        sort_mail()
