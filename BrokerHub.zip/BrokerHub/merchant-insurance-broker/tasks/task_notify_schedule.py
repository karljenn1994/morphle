import logging
from datetime import datetime, timedelta

from lib_common import constants
from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception, XMLException
from lib_journal.journal import Journal
from lib_persistence import campaign, indexer, notifier, persistence, policy, settings
from lib_persistence.campaign import build_regarding
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    journal_id = ""
    num_scheduled = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        journal_id = Journal().begin_journal(Journal.notify_schedule, "Starting to schedule notifications")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to schedule notifications")

        entries = indexer.get_indexer_files(persistence.INDEXER_NOTIFY_SCHEDULE)

        for entry in entries:
            file = None
            entry_id = None

            try:
                entry_id = entry.id
                policy_id = entry.policy_id
                policy_number = entry.policy_number
                company = entry.company
                purpose = entry.purpose
                lob = entry.lob
                new_premium = entry.annual_premium
                transaction_effective_date = entry.transaction_effective_date
                policy_effective_date = entry.policy_effective_date
                policy_expiry_date = entry.policy_expiry_date
                in_renewal_chain = entry.in_renewal_chain

                # For renewal chains, we only want to notify about the renewal
                # but not the upstream changes.
                if in_renewal_chain and purpose != "RWL":
                    continue

                # See if we have a policy in the system. We don't have anyone to notify
                # if the policy is not attached to a user. Note - when users are imported we
                # create an active placeholder policy, so there should always be an active
                # policy available as long as users are mapped to the policy.
                policy_details = policy.read_active_by_policy_number_company_lob(
                    policy_number, company, lob
                )

                if policy_details is not None:
                    # For renewals, we calculate the premium change percentage. We may not notify
                    # the recipients for renewals that are over the specified premium change threshold rule.
                    premium_change_percent = _calc_premium_change_percent(
                        policy_details.annual_premium,
                        new_premium) if purpose == 'RWL' else None

                    # NOTE - we send notifications right away even if the policy is future indexed. The
                    # customer won't see the change, etc., but they can see the documents.
                    num_scheduled += _schedule_notifications(
                        purpose,
                        policy_details.id,
                        company,
                        lob,
                        transaction_effective_date,
                        policy_effective_date,
                        policy_expiry_date,
                        premium_change_percent)

                indexer.update_name(entry_id, persistence.INDEXER_SCAN_SCHEDULE, policy_id=policy_id)

            except (AL3Exception, XMLException) as e:
                indexer.mark_indexer_failed(entry_id, e.message, code=e.code)

            except Exception as e:
                if entry_id is not None:
                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)

                end_status = _handle_error_scheduling_file(journal_id, file, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully scheduled {n} files".format(n=num_scheduled)
        else:
            if num_scheduled > 0:
                end_msg = "Failed but scheduled {n} files".format(n=num_scheduled)
            else:
                end_msg = "Failed scheduling files".format(n=num_scheduled)

            # raise TaskException(
            #     end_msg,
            #     error_code=exceptions.CODE_TASK_FAILED
            # )

        return True, num_scheduled

    except Exception as e:
        end_status, end_msg = _handle_error_scheduling(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.notify_schedule, journal_id, end_status, end_msg, num_scheduled)


def _schedule_notifications(purpose,
                            policy_id,
                            company,
                            lob,
                            transaction_effective_date,
                            policy_effective_date,
                            policy_expiry_date,
                            premium_change_percent=None):
    # See if any users are attached to this policy.
    recipients = campaign.lookup_policy_recipients_by_policy_id(policy_id)

    if recipients is None or len(recipients) <= 0:
        return 0

    purpose = purpose.upper()
    notification_date = datetime.now().date()
    notification_date = notification_date + timedelta(
        days=settings.get_int_setting(constants.SETTING_NOTIFICATION_DELAY, default=2)
    )

    num_added = 0
    for recipient in recipients:
        # Determine if we have a campaign for this policy and recipient.
        campaign_obj = campaign.lookup_policy_campaign_active(
            purpose,
            company,
            lob,
            recipient.status,
            recipient.province,
            premium_change_percent
        )

        if campaign_obj is None or campaign_obj.id is None or not campaign_obj.active:
            return 0

        # See if we already have a notification scheduled for this campaign. If so, we want
        # to group them together instead of creating a bunch of separate notifications for the
        # admin to deal with.
        notifier_id = notifier.get_pending_notification(campaign_obj.id, notification_date)

        if notifier_id is None:
            notifier_id = notifier.create_notification(campaign_obj.id, notification_date)

        re = build_regarding(
            campaign_obj,
            recipient,
            transaction_effective_date,
            policy_effective_date,
            policy_expiry_date
        )
        notifier.add_recipient(recipient.id, notifier_id, campaign_obj.id, re)
        num_added += 1

    return num_added


def _calc_premium_change_percent(premium, new_premium):
    if premium is None or new_premium is None:
        return 0

    if premium == new_premium:
        return 0

    if new_premium > premium:
        return (new_premium - premium) / premium * 100

    if new_premium < premium:
        return -((premium - new_premium) / premium * 100)

    return 0


def _handle_error_scheduling(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] scheduling error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while scheduling"


def _handle_error_scheduling_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while scheduling {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] scheduling error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
