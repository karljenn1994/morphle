import base64
import logging
import uuid
from datetime import datetime, timezone

from google.oauth2 import service_account
from googleapiclient.discovery import build

from lib_common import constants
from lib_common.constants import LOGGER
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_file_manager.local_file_manager import LocalFileManager
from lib_persistence import settings
from tasks.celery_app import app

log = logging.getLogger(LOGGER)
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']


def _get_gmail_service():
    fm = FileManagerFactory.create_file_manager(LocalFileManager)
    credentials_path = fm.get_absolute_path(fm.join("config", "google.json"))
    email_address = settings.get_setting(constants.SETTING_IMPORT_GMAIL_ACCOUNT)

    credentials = service_account.Credentials.from_service_account_file(
        credentials_path, scopes=SCOPES
    )
    delegated = credentials.with_subject(email_address)
    service = build('gmail', 'v1', credentials=delegated, cache_discovery=False)
    return service


def _download_attachments(message, broker_key):
    to_headers = [h['value'] for h in message['payload'].get('headers', []) if
                  h['name'].lower() in ['to', 'delivered-to']]
    expected = settings.get_setting(constants.SETTING_IMPORT_EXPECTED_RECIPIENT_PREFIX).lower()

    if not any(expected in h.lower() for h in to_headers):
        return 0, False

    count = 0
    service = _get_gmail_service()
    message_id = message['id']

    for part in message['payload'].get('parts', []):
        if part['filename'] and part['filename'].endswith('.csv'):
            att_id = part['body'].get('attachmentId')
            if att_id:
                att = service.users().messages().attachments().get(userId='me',
                                                                   messageId=message_id,
                                                                   id=att_id).execute()
                file_data = base64.urlsafe_b64decode(att['data'].encode('UTF-8'))

                fm = FileManagerFactory.create_file_manager(LocalFileManager)
                timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
                unique_id = uuid.uuid4().hex[:8]
                new_filename = f"new_users_{timestamp}_{unique_id}.csv"
                new_path = fm.join(Repository.import_users_location, new_filename)
                abs_path = fm.get_absolute_path(new_path)

                with open(abs_path, 'wb') as f:
                    f.write(file_data)

                count += 1

    return count, bool(count)


@app.task
def execute(previous_task=None):
    journal_id = ""
    fetched = 0
    end_status = Journal.STATUS_SUCCESS
    end_msg = ""

    try:
        journal_id = Journal().begin_journal(Journal.import_email, "Polling Gmail for import CSVs")
        service = _get_gmail_service()
        response = service.users().messages().list(userId='me', labelIds=['INBOX'], q="is:unread").execute()
        messages = response.get('messages', [])

        if not messages:
            return True, "No unread messages"

        for msg in messages:
            try:
                message = service.users().messages().get(userId='me', id=msg['id']).execute()
                num_saved, should_mark_read = _download_attachments(message, broker_key=None)

                if num_saved:
                    fetched += num_saved
                    Journal().journal(Journal.import_email, journal_id, Journal.STATUS_SUCCESS,
                                      f"Fetched {num_saved} attachment(s) from message {msg['id']}")

                if should_mark_read:
                    service.users().messages().modify(
                        userId='me', id=msg['id'], body={'removeLabelIds': ['UNREAD']}).execute()

            except Exception as e:
                log.error(f"[{journal_id}] Failed to process message {msg['id']}: {e}", exc_info=True)
                end_status = Journal.STATUS_FAILED

        total_messages = len(messages)
        if end_status == Journal.STATUS_SUCCESS:
            end_msg = f"Fetched {fetched} attachment(s) from {total_messages} email(s)"
        else:
            end_msg = f"Failed, but processed {total_messages} email(s) - fetched {fetched} attachment(s)"
        return True, end_msg

    except Exception as e:
        end_status, end_msg = _handle_error_import_email(journal_id, e)
        raise

    finally:
        Journal().end_journal(Journal.import_email, journal_id, end_status, end_msg, fetched)


def _handle_error_import_email(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] import_email error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while polling Gmail"
