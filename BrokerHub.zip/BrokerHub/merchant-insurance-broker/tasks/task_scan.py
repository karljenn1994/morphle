import logging

from lib_common import exceptions
from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception, TaskException, XMLException
from lib_journal.journal import Journal
from lib_persistence import indexer, persistence, policy
from tasks.celery_app import app
from validations import validations_support

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    journal_id = ""
    num_scanned = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        journal_id = Journal().begin_journal(Journal.scan, "Starting to scan")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to schedule scans")

        entries = indexer.get_indexer_files(persistence.INDEXER_SCAN, ignore_process_date=True)

        for entry in entries:
            file = None
            entry_id = None

            try:
                entry_id = entry.id

                if not entry.policy_id:
                    indexer.mark_indexer_failed(entry_id, "Missing policy", code=exceptions.CODE_INVALID_ARGUMENT)
                    end_status = Journal.STATUS_FAILED
                    continue

                policy_obj = policy.read_version_by_id(entry.policy_id)

                if not policy_obj:
                    indexer.mark_indexer_failed(entry_id, "Missing policy", code=exceptions.CODE_INVALID_ARGUMENT)
                    end_status = Journal.STATUS_FAILED
                    continue

                if policy_obj:
                    if validations_support.validate_policy(policy_obj):
                        num_scanned += 1

                indexer.remove_from_indexer(entry_id)

            except (AL3Exception, XMLException) as e:
                indexer.mark_indexer_failed(entry_id, e.message, code=e.code)
                pass

            except Exception as e:
                if entry_id is not None:
                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)

                end_status = _handle_error_scanning_file(journal_id, file, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully scanned {n} files".format(n=num_scanned)
        else:
            if num_scanned > 0:
                end_msg = "Failed but scanned {n} files".format(n=num_scanned)
            else:
                end_msg = "Failed scanning"

            raise TaskException(
                end_msg,
                error_code=exceptions.CODE_TASK_FAILED
            )

        return True, num_scanned

    except Exception as e:
        end_status, end_msg = _handle_error_scanning(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.scan, journal_id, end_status, end_msg, num_scanned)


def _handle_error_scanning(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] scan error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while scheduling scan"


def _handle_error_scanning_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while scheduling scan {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] scan error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
