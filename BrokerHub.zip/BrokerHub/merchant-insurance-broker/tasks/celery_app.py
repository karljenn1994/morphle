from celery import Celery

app = Celery("brokerhub")

app.conf.update({
    "timezone": "UTC",
    "broker_url": "filesystem://localhost",
    "broker_connection_retry_on_startup": True,
    "result_persistent": False,
    "task_serializer": "json",
    "result_serializer": "json",
    "accept_content": ["json"],
    # Additional config (beat, transport options, etc.) are handled in celery.py
})
