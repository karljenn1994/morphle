import logging
import os
import shutil
import subprocess
import tarfile
from datetime import datetime
from pathlib import Path

from lib_common.exceptions import TaskException
from tasks.celery_app import app
from lib_common import constants, exceptions
from lib_common.constants import LOGGER
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_vault.vault import Vault
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_file_manager.local_file_manager import LocalFileManager

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    journal_id = ""
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        fm = FileManagerFactory.create_file_manager()
        local_fm = FileManagerFactory().create_file_manager(LocalFileManager)
        journal_id = Journal().begin_journal(Journal.backup, "Starting to backup")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to backup")

        # Create a backup folder
        current_time = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        backup_folder = fm.join(Repository.backup_location, str(current_time))

        # Ensure directories exist
        local_fm.mkdirs(backup_folder)
        fm.mkdirs(backup_folder)

        # Uncomment and adjust these as needed
        local_fm.copytree(Repository.config_location,
                          local_fm.join(backup_folder, Repository.config_location),
                          decrypt=True)
        local_fm.copytree(Repository.journal_location,
                          local_fm.join(backup_folder, Repository.journal_location),
                          decrypt=True)
        local_fm.copytree(Repository.pub_location, local_fm.join(backup_folder, Repository.pub_location), decrypt=True)
        fm.copytree(Repository.mail_inbox_location, fm.join(backup_folder, Repository.mail_inbox_location), decrypt=True)
        fm.copytree(Repository.policies_location, fm.join(backup_folder, Repository.policies_location), decrypt=True)
        fm.copytree(Repository.quotes_location, fm.join(backup_folder, Repository.quotes_location), decrypt=True)
        fm.copytree(Repository.claims_location, fm.join(backup_folder, Repository.claims_location), decrypt=True)

        # Verify mysqldump is available
        if not shutil.which('mysqldump'):
            raise FileNotFoundError("mysqldump not found in system PATH")

        # Backup database
        sql_backup_file = str(Path(local_fm.get_absolute_path(backup_folder)) / "policy_index.sql")

        # Verify write permissions
        backup_dir = os.path.dirname(sql_backup_file)
        if not os.access(backup_dir, os.W_OK):
            raise PermissionError(f"No write permission to {backup_dir}")

        # Get database credentials with validation
        required_vars = {
            'db_user': constants.SETTING_DB_USER,
            'db_password': constants.SETTING_DB_PASSWORD,
            'db_host': constants.SETTING_DB_HOST,
            'db_name': constants.SETTING_DB_NAME
        }
        db_params = {}
        for name, var in required_vars.items():
            value = Vault().get(var)
            if not value:
                raise ValueError(f"Missing environment variable {var}")
            db_params[name] = value

        # Parse host and port
        host_port = db_params['db_host'].split(":")
        host = host_port[0]
        port = host_port[1] if len(host_port) > 1 else "3306"

        # Build and execute mysqldump command
        command = [
            'mysqldump',
            f'-h{host}',
            f'-P{port}',
            f'-u{db_params["db_user"]}',
            f'-p{db_params["db_password"]}',
            '--single-transaction',
            '--set-gtid-purged=OFF',
            db_params['db_name']
        ]

        with open(sql_backup_file, 'w') as f:
            process = subprocess.run(
                command,
                stdout=f,
                stderr=subprocess.PIPE,
                text=True,
                check=False
            )

        # Handle backup results
        if process.returncode == 0:
            if log.isEnabledFor(logging.DEBUG):
                log.debug("Backup successful")
            end_msg = "Backup Successful"
            end_status = Journal.STATUS_SUCCESS
        else:
            error_msg = f"Backup failed with return code {process.returncode}: {process.stderr}"
            if log.isEnabledFor(logging.DEBUG):
                log.debug(error_msg)
            end_status = Journal.STATUS_FAILED
            end_msg = error_msg
            raise Exception(error_msg)

        # Compress the backup folder into a tar.gz file
        absolute_backup_folder = local_fm.get_absolute_path(backup_folder)
        tar_file_folder = local_fm.get_absolute_path(Repository.backup_location)
        tar_file_name = f"{current_time}.tar.gz"
        tar_file_path = fm.join(tar_file_folder, tar_file_name)

        if log.isEnabledFor(logging.DEBUG):
            log.debug(f"Compressing backup folder {absolute_backup_folder} to {tar_file_path}")

        with tarfile.open(tar_file_path, "w:gz") as tar:
            tar.add(absolute_backup_folder, arcname=os.path.basename(absolute_backup_folder))

        if log.isEnabledFor(logging.DEBUG):
            log.debug(f"Compression successful: {tar_file_path}")

        end_msg += f"; Compressed backup to {tar_file_name}"

        # Remove the backup folder after successful compression
        if log.isEnabledFor(logging.DEBUG):
            log.debug(f"Removing backup folder {absolute_backup_folder}")
        shutil.rmtree(absolute_backup_folder)
        if log.isEnabledFor(logging.DEBUG):
            log.debug(f"Backup folder {absolute_backup_folder} removed")
        end_msg += f"; Removed backup folder {current_time}"

        if end_status != Journal.STATUS_SUCCESS:
            raise TaskException(
                end_msg,
                error_code=exceptions.CODE_TASK_FAILED
            )

        return True, -1

    except Exception as e:
        end_status, end_msg = _handle_error_backup(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.backup, journal_id, end_status, end_msg)


def _handle_error_backup(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] backup error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while backing up"
