import logging

from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception, MissingFieldException, XMLException
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import get_connection, indexer, persistence, policy, user
from lib_policy_dom.JSON import JSON
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    journal_id = ""
    num_indexed = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS
    entry_id = None

    try:
        fm = FileManagerFactory.create_file_manager()
        journal_id = Journal().begin_journal(Journal.index, "Starting to index")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to index")

        entries = indexer.get_indexer_files(persistence.INDEXER_INDEX, ignore_process_date=False)

        for entry in entries:
            file = entry.file_name

            try:
                entry_id = entry.id
                policy_id = entry.policy_id

                if file.lower().endswith(JSON.extensions):
                    card_json = JSON.load_card_json(fm.join(Repository.policies_location, file))
                    lob = JSON().get_policy_card_lob(card_json)

                    with get_connection() as connection:
                        if lob == "AUTO":
                            _upsert_auto(connection, policy_id, card_json)
                        elif lob == "HABL":
                            _upsert_property(connection, policy_id, card_json)

                        connection.commit()

                num_indexed += 1

                indexer.remove_from_indexer(entry_id, recalculate_flags=True)

            except (AL3Exception, XMLException, MissingFieldException) as e:
                indexer.mark_indexer_failed(entry_id, e.message, code=e.code)

            except Exception as e:
                if entry_id is not None:
                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)

                end_status = _handle_error_indexing_file(journal_id, file, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully indexed {n} files".format(n=num_indexed)
        else:
            end_msg = "Failed but indexed {n} files".format(n=num_indexed)

        return True, num_indexed

    except Exception as e:
        end_status, end_msg = _handle_error_indexing(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.index, journal_id, end_status, end_msg, num_indexed)


def _map_company(company_code, company_name, optional_connection=None):
    mapped_company_code = None
    if company_code is not None:
        mapped_company_code, _ = policy.map_company_code(company_code,
                                                         allow_none=True,
                                                         optional_connection=optional_connection)
    if company_code is None and company_name is not None:
        mapped_company_code, _ = policy.map_company_name(company_name, optional_connection=optional_connection)
    return mapped_company_code


def _verify_match(lob, current_json, prior_lob, prior_json):
    if lob == 'AUTO' and prior_lob == 'AUTO':
        licences = JSON.get_drivers_licences(current_json)
        licence_numbers = [JSON.get_drivers_licence_number(li) for li in licences]
        prior_licences = JSON.get_drivers_licences(prior_json)
        prior_licence_numbers = [JSON.get_drivers_licence_number(li) for li in prior_licences]

        # If the same set of drivers is on both policies, then we have a match.
        return set(licence_numbers) == set(prior_licence_numbers)

    elif lob == 'HABL' and prior_lob == 'HABL':
        # Make sure the insured's date of birth and the postal code matches.
        policy_card = JSON.get_policy_card(current_json)
        postal_code = JSON.get_postal_code(policy_card)
        prior_policy_card = JSON.get_policy_card(prior_json)
        prior_postal_code = JSON.get_postal_code(prior_policy_card)

        if postal_code != prior_postal_code:
            return False

        individuals = JSON.get_individuals(current_json)
        date_of_births = [JSON.get_date_of_birth_str(ind) for ind in individuals]
        prior_individuals = JSON.get_individuals(prior_json)
        prior_date_of_births = [JSON.get_date_of_birth_str(ind) for ind in prior_individuals]

        return set(date_of_births) == set(prior_date_of_births)

    return False


def _map_prior_policy_users(connection, policy_id, current_json):
    fm = FileManagerFactory.create_file_manager()
    policy_card = JSON.get_policy_card(current_json)
    policy_number = JSON.get_policy_number(policy_card)
    lob = JSON.get_lob(policy_card)
    company_code = JSON.get_company_code(policy_card)
    if company_code is not None:
        company_code, _ = policy.map_company_code(company_code, allow_none=True, optional_connection=connection)

    if policy_number is not None and company_code is not None:
        prior_policy_number = JSON.get_prior_policy_number(policy_card)
        mapped_prior_company_code = _map_company(
            JSON.get_prior_company_code(policy_card),
            JSON.get_prior_company_name(policy_card), optional_connection=connection)

        if prior_policy_number is not None and mapped_prior_company_code is not None and lob is not None:
            prior_policy_obj = policy.read_active_by_policy_number_company_lob(
                prior_policy_number, mapped_prior_company_code, lob, optional_connection=connection)

            if prior_policy_obj is not None and prior_policy_obj.file_name is not None:
                prior_file = fm.join(Repository.policies_location, prior_policy_obj.file_name)
                prior_json = JSON.load_card_json(prior_file)
                prior_lob = JSON.get_policy_card_lob(prior_json)

                if _verify_match(lob, current_json, prior_lob, prior_json):
                    users = user.lookup_users_by_policy_id(prior_policy_obj.id, optional_connection=connection)
                    if users is not None and len(users) > 0:
                        for user_obj in users:
                            user.add_policy(user_obj.id, policy_id, notify=user_obj.notify, optional_connection=connection)


def _upsert_auto(connection, policy_id, card_json):
    # Make this policy the active version.
    policy.update_active_version(policy_id, optional_connection=connection)

    # Map prior policy users.
    _map_prior_policy_users(connection, policy_id, card_json)

    return policy_id


def _upsert_property(connection, policy_id, card_json):
    # Map prior policy users.
    _map_prior_policy_users(connection, policy_id, card_json)

    # Make this policy the active version.
    policy.update_active_version(policy_id, optional_connection=connection)

    return policy_id


def _handle_error_indexing(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] indexing error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while indexing"


def _handle_error_indexing_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while indexing {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] indexing error: {message}", exc_info=True)

    return Journal.STATUS_FAILED


def upper(val):
    if val is not None:
        return val.upper()
    return val


def remove_spaces(val):
    if val is not None:
        return val.replace(" ", "")
    return val


def remove_leading_zeros(val):
    if val is not None:
        return val.lstrip("0")
    return val
