import logging
from datetime import datetime

import shortuuid

from lib_common import exceptions, constants
from lib_common.constants import LOGGER
from lib_common.exceptions import TaskException
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import indexer, persistence, settings
from lib_xml_dom.xml_dom import XmlDOM
from lib_al3.al3_utils import al3_extensions
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


# -------------------------
# Mode helpers
# -------------------------
def _is_gateway() -> bool:
    return settings.get_bool_setting(constants.SETTING_SYSTEM_MAIL_IS_GATEWAY)


def _all_mail_location(fm=None) -> str:
    fm = fm or FileManagerFactory.create_file_manager()
    path = fm.join(Repository.mail_root_location, Repository.mail_all_mail_location)
    if not fm.exists(path):
        try:
            fm.mkdirs(path)
        except Exception:
            pass
    return path


@app.task
def execute(previous_task=None):
    journal_id = ""
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS
    num_imported = 0
    total_policies = 0

    try:
        fm = FileManagerFactory.create_file_manager()
        journal_id = Journal().begin_journal(Journal.import_policies, "Starting to import policies")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to import policies")

        current_file = ""

        for root, dirs, files in fm.walk(Repository.import_policies_location):
            if len(dirs) > 0:
                continue
            try:
                sub_dir = shortuuid.uuid()

                # decide where to drop imported policies
                if _is_gateway():
                    parent = _all_mail_location(fm)
                else:
                    parent = Repository.mail_inbox_location

                folder = fm.join(parent, sub_dir)
                fm.mkdirs(folder)

                for file_name in files:
                    current_file = file_name
                    file_path = fm.join(root, file_name)
                    out_file = fm.join(folder, file_name)
                    is_num_ext = fm.splitext(out_file)[1].strip(".").isnumeric()

                    lower_out_file = out_file.lower()

                    if (lower_out_file.endswith(al3_extensions)
                            or is_num_ext
                            or lower_out_file.endswith(XmlDOM.extensions)
                            or lower_out_file.endswith(".pdf")
                            or lower_out_file.endswith(".xls")
                            or lower_out_file.endswith(".json")):
                        total_policies += 1

                        fm.write_file(out_file, fm.read_file(file_path, rewrite=False))

                        indexer.add_to_indexer(persistence.INDEXER_ORGANIZE, fm.join(sub_dir, file_name))
                        num_imported += 1
            except Exception as e:
                end_status = _handle_error_import_policies_file(journal_id, current_file, e)

        # Backup the policies we tried to import.
        current_time = datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        backup_folder = fm.join(Repository.import_location, "policies-" + current_time)
        fm.rename(Repository.import_policies_location, backup_folder)
        fm.mkdir(Repository.import_policies_location)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = f"Successfully imported {num_imported} of {total_policies} file(s)"
        else:
            if num_imported > 0:
                end_msg = f"Failed but imported {num_imported} of {total_policies} file(s)"
            else:
                end_msg = "Policy import failed"

            raise TaskException(end_msg, error_code=exceptions.CODE_TASK_FAILED)

        return True, num_imported
    except Exception as e:
        end_status, end_msg = _handle_error_import_policies(journal_id, e)
        raise
    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)
        Journal().end_journal(Journal.import_policies, journal_id, end_status, end_msg, num_imported, total_policies)


def _handle_error_import_policies(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] import policies error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while importing policies"


def _handle_error_import_policies_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while importing policy {file}")
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] import policies error: {message}", exc_info=True)
    return Journal.STATUS_FAILED
