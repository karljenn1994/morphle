import logging
import os
from datetime import datetime
from logging.config import dictConfig

import pytz
import sqlalchemy as db
from celery import chain, schedules
from celery.signals import after_setup_logger, task_failure, task_prerun, task_success
from sqlalchemy import update
from sqlalchemy_celery_beat.models import CrontabSchedule, PeriodicTask, PeriodicTaskChanged
from sqlalchemy_celery_beat.session import SessionManager

from lib_common import constants
from lib_common.environment import print_environment
from lib_vault.vault import Vault
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import settings
from lib_persistence.task import update_task_status
from tasks import (
    task_backup,
    task_campaign,
    task_collect,
    task_fetch,
    task_import_email,
    task_import_policies,
    task_import_users,
    task_index,
    task_notify,
    task_notify_schedule,
    task_organize,
    task_purge_inbox,
    task_scan,
    task_scan_schedule,
    task_transform
)
from tasks.celery_app import app

LOGGING_FORMAT = "%(levelname)s: %(asctime)s %(message)s"
LOGGING_LEVEL = logging.DEBUG

if constants.LOGGING_LEVEL in os.environ:
    LOGGING_LEVEL = os.environ[constants.LOGGING_LEVEL]

logging.basicConfig(format=LOGGING_FORMAT, level=LOGGING_LEVEL)
print_environment()

Vault().initialize()
db_user = Vault().get(constants.SETTING_DB_USER)
db_password = Vault().get(constants.SETTING_DB_PASSWORD)
db_host = Vault().get(constants.SETTING_DB_HOST)
db_name = Vault().get(constants.SETTING_DB_NAME)
db_conn_str = f"mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}"

cwd = os.getcwd()

# branch-specific folder, like /opt/distinct/var/celery
system_folder = settings.get_setting(constants.SETTING_SYSTEM_FOLDER)
messages_dir = os.path.join(system_folder, "var", "celery")
os.makedirs(messages_dir, exist_ok=True)

session_manager = SessionManager()
_, session_maker = session_manager.create_session(db_conn_str)

app.conf.update({
    'beat_scheduler': 'sqlalchemy_celery_beat.schedulers:DatabaseScheduler',
    'beat_max_loop_interval': 10,
    'beat_dburi': db_conn_str,
    'beat_schema': db_name,
    'worker_max_tasks_per_child': 10,
    "broker_transport_options": {
        "data_folder_in": messages_dir,
        "data_folder_out": messages_dir,
    },
})


@after_setup_logger.connect
def setup_loggers(logger, **kwargs):
    fm = FileManagerFactory.create_file_manager()
    logs_location = fm.join(settings.get_setting(constants.SETTING_SYSTEM_FOLDER), "logs")

    config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": LOGGING_FORMAT,
                "datefmt": "%Y/%m/%d %H:%M:%S"
            },
        },
        "handlers": {
            "file": {
                "level": LOGGING_LEVEL,
                "class": "logging.FileHandler",
                "filename": fm.join(logs_location, "tasks.log"),
                "formatter": "default",
            },
            "stdout": {
                "level": LOGGING_LEVEL,
                "class": "logging.StreamHandler",
                "formatter": "default",
            },
        },
        "loggers": {
            "default": {
                "handlers": ["file", "stdout"],
                "level": LOGGING_LEVEL,
                "propagate": True,
            }
        },
        "root": {
            "handlers": ["file", "stdout"],
            "level": LOGGING_LEVEL,
        },
    }

    dictConfig(config)


def get_task_name(sender):
    task_name = None
    if sender is not None:
        if sender.name == "tasks.celery.indexer":
            task_name = "indexer"

        if task_name is None:
            task_name = sender.name.split(".")[1].replace("task_", "")
    return task_name


@task_prerun.connect
def task_started(sender=None, task=None, **kwargs):
    task_name = get_task_name(sender)

    if task_name is not None:
        update_task_status(task_name=task_name, status='running', status_timestamp=datetime.now(pytz.UTC))


@task_success.connect
def task_succeeded(sender=None, task=None, **kwargs):
    task_name = get_task_name(sender)

    if task_name is not None:
        update_task_status(task_name=task_name,
                           status='succeeded',
                           status_timestamp=datetime.now(pytz.UTC),
                           last_successful_run=datetime.now(pytz.UTC))


@task_failure.connect
def task_failed(sender=None, task=None, **kwargs):
    task_name = get_task_name(sender)

    if task_name is not None:
        update_task_status(task_name=task_name, status='failed', status_timestamp=datetime.now(pytz.UTC))


@app.task
def update_task_schedule(name, status, minute="*", hour="*", days_of_week="*", months_of_year="*"):
    session = session_maker()
    task = "tasks.celery." + name
    cron_schedule = CrontabSchedule.from_schedule(
        session,
        schedules.crontab(
            minute=minute,
            hour=hour,
            day_of_week=days_of_week,
            day_of_month="*",
            month_of_year=months_of_year
        )
    )
    result = session.execute(db.select(PeriodicTask).where(PeriodicTask.name == name)).first()

    if result is None:
        stmt = db.insert(PeriodicTask).values(
            name=name, task=task, enabled=1 if status == 'enabled' else 0,
            schedule_id=cron_schedule.id, discriminator=cron_schedule.discriminator)
    else:
        stmt = db.update(PeriodicTask).values(
            enabled=1 if status == 'enabled' else 0,
            schedule_id=cron_schedule.id,
            discriminator=cron_schedule.discriminator).where(PeriodicTask.name == name)

    session.execute(stmt)
    session.commit()
    PeriodicTaskChanged.update_from_session(session)


@app.task(bind=True)
def pause_task(self, name):
    session = session_maker()
    session.execute(update(PeriodicTask).where(PeriodicTask.name == name).values(enabled=False))
    session.commit()
    PeriodicTaskChanged.update_from_session(session)


@app.task(bind=True)
def unpause_task(self, name):
    session = session_maker()
    session.execute(update(PeriodicTask).where(PeriodicTask.name == name).values(enabled=True))
    session.commit()
    PeriodicTaskChanged.update_from_session(session)


@app.task(bind=True)
def indexer(self):
    chain(
        task_fetch.execute.s()
        | task_organize.execute.s()
        | task_transform.execute.s()
        | task_notify_schedule.execute.s()
        | task_scan_schedule.execute.s()
        | task_index.execute.s()
        | task_purge_inbox.execute.s()
    )()


@app.task(bind=True)
def collect(self):
    chain(task_collect.execute.s())()


@app.task(bind=True)
def backup(self):
    chain(task_backup.execute.s())()


@app.task(bind=True)
def import_policies(self):
    chain(task_import_policies.execute.s())()


@app.task(bind=True)
def import_users(self):
    chain(task_import_users.execute.s())()


@app.task(bind=True)
def import_email(self):
    chain(task_import_email.execute.s())()


@app.task(bind=True)
def notify(self):
    chain(task_notify.execute.s())()


@app.task(bind=True)
def notify_schedule(self):
    chain(task_notify_schedule.execute.s())()


@app.task(bind=True)
def scan(self):
    chain(task_scan.execute.s())()


@app.task(bind=True)
def scan_schedule(self):
    chain(task_scan_schedule.execute.s())()


@app.task(bind=True)
def campaign(self):
    chain(task_campaign.execute.s())()
