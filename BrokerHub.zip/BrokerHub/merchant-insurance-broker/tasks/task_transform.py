import logging

from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import indexer, persistence, policy
from lib_policy_dom.policy_dom import PolicyDOM
from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import al3_extensions
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    """ """

    journal_id = ""
    num_transformed = 0
    total_policies = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        fm = FileManagerFactory.create_file_manager()
        journal_id = Journal().begin_journal(Journal.transform, "Starting to transform messages")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to transform messages")

        entries = indexer.get_indexer_files(persistence.INDEXER_TRANSFORM)

        for entry in entries:
            file = None
            entry_id = entry.id
            policy_id = entry.policy_id

            try:
                file = entry.file_name
                root = Repository.policies_location
                is_num_ext = fm.splitext(file)[1].strip(".").isnumeric()

                if file.lower().endswith(al3_extensions) or is_num_ext:
                    total_policies += 1
                    file_name_no_ext = fm.splitext(file)[0]
                    card_json_file = file_name_no_ext + ".JSON"
                    txt = AL3ToJSON().load(fm.join(root, file))
                    al3_map = AL3ToJSON().to_json(txt)
                    PolicyDOM.from_al3_json(al3_map).save(fm.join(root, card_json_file))
                    num_transformed += 1

                    indexer.update_name(entry_id, persistence.INDEXER_NOTIFY_SCHEDULE, policy_id=policy_id)
                    indexer.update_file_name(entry_id, card_json_file)
                    policy.update_file_name(policy_id, card_json_file)

            except AL3Exception as e:
                if entry_id is not None:
                    indexer.mark_indexer_failed(entry_id, message=e.message, code=e.code)

                end_status = _handle_error_transforming_file(journal_id, file, e)

            except Exception as e:
                if entry_id is not None:
                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)

                end_status = _handle_error_transforming_file(journal_id, file, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully transformed {n} out of {t} files".format(n=num_transformed, t=total_policies)
        else:
            end_msg = "Failed, transformed {n} out of {t} files".format(n=num_transformed, t=total_policies)

            # raise TaskException(
            #     end_msg,
            #     error_code=exceptions.CODE_TASK_FAILED
            # )

        return True, num_transformed

    except Exception as e:
        end_status, end_msg = _handle_error_transforming(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.DEBUG):
            log.debug("Done transforming files")

        Journal().end_journal(
            Journal.transform,
            journal_id,
            end_status,
            end_msg,
            num_transformed,
        )


def _handle_error_transforming(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] transforming error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while transforming"


def _handle_error_transforming_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while transforming {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] transforming error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
