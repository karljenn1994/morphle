import json
import logging
import pathlib
from datetime import datetime
from typing import Any, Dict, List, Optional

import shortuuid

from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import (
    al3_extensions,
    find_group_by_group_name,
    find_groups_by_group_name,
    fix_policy_number,
    int_val,
    make_al3_file_name,
    make_al3_folder,
    val
)
from lib_common.constants import LOGGER
from lib_common.exceptions import AL3Exception, TaskException, XMLException
from lib_common.mailbox import Mailbox
from lib_common.repository import Repository
from lib_common.routes_support import rows_to_list
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_helpers import date_from_edi_date, date_to_string, to_annual_premium, to_dollars_and_cents, to_full_name
from lib_journal.journal import Journal
from lib_persistence import get_connection, indexer, persistence, policy
from lib_policy_dom.JSON import JSON
from lib_policy_dom.policy_dom import PolicyDOM
from lib_xml_dom.xml_dom import XmlDOM
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


@app.task
def execute(previous_task=None):
    """
    Organize inbox files into their appropriate destinations.

    This task retrieves files from the indexer and attempts to process them
    as AL3, JSON, or XML policy files. Files are copied into policy folders,
    indexed appropriately, and invalid or failed files are marked as such.

    :param previous_task: Optional reference to the previous Celery task.
    :return: Tuple (success flag, number of files organized).
    """
    journal_id = ""
    num_organized = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        fm = FileManagerFactory.create_file_manager()
        journal_id = Journal().begin_journal(Journal.organize, "Starting to organize inbox")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to organize inbox")

        entries = indexer.get_indexer_files(persistence.INDEXER_ORGANIZE)
        entries = rows_to_list(entries)
        exploded_entries = entries[:]

        for entry in entries:
            entry_id = entry["id"]
            file = entry["file_name"]
            is_num_ext = fm.splitext(file)[1].strip(".").isnumeric()

            if file.lower().endswith(al3_extensions) or is_num_ext:
                # Try to explode the AL3 file into separate files.
                result, new_entries, e = _explode_al3(Repository.mail_inbox_location, entry)

                if not result:
                    # Something went wrong exploding the file. Mark the file as failed
                    # and set the overall end status to fail.
                    exploded_entries.remove(entry)
                    end_status = _handle_error_organizing_file(journal_id, file, e)

                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)
                    continue

                if len(new_entries) > 0:
                    # It contained multiple files so add the new files to exploded entries.
                    exploded_entries.remove(entry)
                    exploded_entries += new_entries

        for entry in exploded_entries:
            file = None
            entry_id = None

            try:
                entry_id = entry["id"]
                file = entry["file_name"]
                is_num_ext = fm.splitext(file)[1].strip(".").isnumeric()

                if file.lower().endswith(al3_extensions) or is_num_ext:
                    if _organize_al3(entry_id, fm.join(Repository.mail_inbox_location, file)):
                        num_organized += 1

                elif file.lower().endswith(PolicyDOM.extensions):
                    if _organize_json(entry_id, fm.join(Repository.mail_inbox_location, file)):
                        num_organized += 1

                elif file.lower().endswith(XmlDOM.extensions):
                    # Make sure we actually processed the XML before removing it. The entire policy might
                    # have a hold on it.
                    if _organize_xml(entry_id, fm.join(Repository.mail_inbox_location, file)):
                        num_organized += 1
                else:
                    # We don't process this kind of file so remove it. The fetch puts PDFs and other
                    # attachments that will be processed when we process the XML.
                    indexer.remove_from_indexer(entry_id)

            except (AL3Exception, XMLException) as e:
                indexer.mark_indexer_failed(entry_id, e.message, code=e.code)

            except Exception as e:
                if entry_id:
                    message = getattr(e, "message", str(e))
                    indexer.mark_indexer_failed(entry_id, message)

                end_status = _handle_error_organizing_file(journal_id, file, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully organized {n} files".format(n=num_organized)
        else:
            if num_organized > 0:
                end_msg = "Failed but organized {n} files".format(n=num_organized)
            else:
                end_msg = "Failed organizing files".format(n=num_organized)

        return True, num_organized

    except Exception as e:
        end_status, end_msg = _handle_error_organizing(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.organize, journal_id, end_status, end_msg, num_organized)


def _do_insureds_match(insured_names: List[str], latest_policy: Optional[Any], optional_connection=None) -> bool:
    if not latest_policy or not latest_policy.id or not insured_names:
        return True

    # Extract insured names from SQLAlchemy rows
    active_rows = policy.read_insured_names(latest_policy.id, optional_connection=optional_connection)
    db_names: List[str] = [row.insured_name for row in active_rows]

    if len(db_names) > 0 and set(insured_names) != set(db_names):
        return False

    return True


def _organize_xml(entry_id: str, src_file_path: str) -> bool:
    """
    Organize an XML policy file into the "policies" folder.

    Moves the XML and its attachments into the appropriate policy folder,
    writing metadata and cleaning up originals. Ensures policies on hold
    are not processed.

    :param entry_id: Indexer entry id.
    :param src_file_path: Path to the XML policy file to organize.
    :return: True if successfully organized, False if skipped due to hold.
    """
    xml_dom = XmlDOM.load(src_file_path)

    # Block or unblock the entry.
    on_hold = indexer.is_policy_on_hold(xml_dom.policy_number, xml_dom.company, xml_dom.lob)
    indexer.update_block(entry_id, on_hold, "Blocked due to policy hold")

    if on_hold:
        # No further processing if we are on hold.
        return False

    fm = FileManagerFactory.create_file_manager()
    to_folder = fm.join(Repository().policies_location, xml_dom.xml_folder_name)
    fm.mkdirs(to_folder)

    to_file_name, err_msg = xml_dom.make_file_name(src_file_path, None)
    if err_msg:
        log.error("_organize_xml missing field(s)," + err_msg + " in file " + src_file_path)
        raise TaskException("Errors organizing " + src_file_path)

    purpose = xml_dom.purpose
    lob = xml_dom.lob
    effective_date = xml_dom.transaction_effective_date

    suffix = 0
    old_attachment_files = []
    copied_files = []

    try:
        for attachment in xml_dom.attachments:
            suffix += 1
            from_file_name = Mailbox.safe_name(attachment.filename)
            new_file_name, err_msg = xml_dom.make_file_name(attachment.filename, suffix)

            # Optimistically update XML
            attachment.filename = new_file_name

            src_attachment_path = fm.join(fm.dirname(src_file_path), from_file_name)
            dst_attachment_path = fm.join(to_folder, new_file_name)

            # Copy attachment
            fm.copy(src_attachment_path, dst_attachment_path)
            copied_files.append(dst_attachment_path)
            old_attachment_files.append(src_attachment_path)

            # Write .INF metadata
            ext = pathlib.Path(new_file_name).suffix
            meta_name = new_file_name[: -len(ext)] + ".INF"
            meta_data = json.dumps({
                "description": attachment.description,
                "purpose": purpose,
                "type_code": attachment.type_code,
                "lob": lob,
                "transaction_effective_date": effective_date,
            }, indent=2)
            fm.write_string(fm.join(to_folder, meta_name), meta_data)

        # All attachments succeeded → save XML
        to_file_path = fm.join(to_folder, to_file_name)
        xml_dom.save_as(to_file_path)

    except Exception:
        # Cleanup partial copies
        for f in copied_files:
            if fm.exists(f):
                fm.remove(f)
        raise

    # Cleanup originals only after success
    for old_attachment in old_attachment_files:
        if fm.exists(old_attachment):
            fm.remove(old_attachment)

    fm.remove(src_file_path)
    src_dir = fm.dirname(src_file_path)
    if not fm.listdir(src_dir):
        fm.rmdir(src_dir)

    # Remove the "organize" entry from the indexer.
    indexer.remove_from_indexer(entry_id)

    return True


def _organize_json(entry_id: str, src_file_path: str) -> bool:
    """
    Organize a JSON policy file into the "policies" folder.

    Processes the JSON into policy records, creates/updates the active policy,
    and indexes it for further tasks. Copies the file into its permanent
    destination and removes the original.

    :param src_file_path: Path to the JSON file to organize.
    :param entry_id: Indexer entry id.
    :return: True if successfully organized, False if skipped.
    """
    fm = FileManagerFactory.create_file_manager()

    card_json = JSON.load_card_json(src_file_path)
    policy_card = JSON.get_policy_card(card_json)

    destination_folder_name = JSON().make_json_folder(card_json)
    destination_folder = fm.join(Repository().policies_location, destination_folder_name)
    destination_file_name, err_msg = JSON().make_json_file_name(card_json)

    if len(err_msg) > 0:
        log.error(err_msg)
        raise TaskException("Errors organizing " + src_file_path)

    fm.mkdirs(destination_folder)
    destination_file_path = fm.join(destination_folder, destination_file_name)

    # Figure out when the file should be indexed.
    transaction_effective_date = JSON.get_transaction_effective_date(policy_card)
    transaction_effective_date_str = JSON.get_transaction_effective_date_str(policy_card)
    transaction_date = JSON.get_transaction_date(policy_card)
    policy_effective_date = JSON.get_effective_date(policy_card)
    policy_expiry_date = JSON.get_expiry_date(policy_card)
    premium = JSON.get_premium(policy_card)
    annual_premium = JSON.get_annual_premium(policy_card)
    purpose = JSON.get_purpose(policy_card)
    seq = JSON.get_sequence(policy_card)
    policy_number = JSON.get_policy_number(policy_card)
    company = JSON.get_company_code(policy_card)
    lob = JSON.get_lob(policy_card)

    # Look up the currently indexed policy.
    policy_details = policy.read_active_by_policy_number_company_lob(policy_number, company, lob)

    skip_it = False

    if policy_details is not None:
        # Make sure the policy we are dealing with is newer than the one we already have
        # indexed. If it's older, we can ignore it.
        current_transaction_effective_date_str = policy_details.transaction_effective_date

        if current_transaction_effective_date_str is not None:
            current_transaction_effective_date = datetime.strptime(str(current_transaction_effective_date_str),
                                                                   "%Y-%m-%d").date()

            # If the file we are looking at is older than the currently indexed policy, then skip it.
            if transaction_effective_date <= current_transaction_effective_date:
                skip_it = True

    # Here we need to take special precautions if the purpose of the file is SYN. A SYN request is probably
    # from a company initial data load. If we already have a file for this policy, then we should ignore the
    # SYN request. The SYN request doesn't tell us the state of the policy, so it's impossible to
    # represent the policy properly on the UI (i.e. RWL, XLN etc.).
    if purpose == "SYN":
        # See if we already have a policy file for this policy.
        if fm.exists(destination_folder):
            existing_files = list(
                pathlib.Path(destination_folder).glob(company + '_' + policy_number + '_*_' + lob + '_*.AL3'))
            if len(existing_files) > 0:
                # We have another file here already so skip.
                skip_it = True

    if "REPORT" in policy_number.upper() or "BINDER" in policy_number.upper():
        skip_it = True

    if not skip_it:
        # Anything other than personal auto and home stops here.
        if lob == "AUTO" or lob == "HABL":
            # See if this policy has a hold on it.
            on_hold = indexer.is_policy_on_hold(policy_number, company, lob)

            # Block or unblock the entry.
            indexer.update_block(entry_id, on_hold, "Blocked due to policy hold")

            if on_hold:
                # No further processing if we are on hold.
                return False

            file_name = fm.join(destination_folder_name, destination_file_name)

            if not indexer.file_name_exists(file_name):
                with get_connection() as connection:
                    active_policy = policy.read_active_by_policy_number_company_lob(
                        policy_number,
                        company,
                        lob,
                        optional_connection=connection
                    )

                    if not active_policy:
                        # No active policy - we need to create an active placeholder. If this policy
                        # sits in the indexer as a renewal, then we need that placeholder to show to the
                        # user in the meantime. Especially required for renewals. When an admin looks at
                        # renewals, the code expects there to always be a policy.
                        policy.create(policy_number, company, lob, optional_connection=connection)

                    insured_names = _collect_json_insured_names(card_json)

                    # Grab the latest version before we create the policy. We use it to get the insureds, which are
                    # then used to figure out if we need to put a hold on the policy.
                    latest_version = policy.read_version_latest(
                        policy_number,
                        company,
                        lob,
                        optional_connection=connection)

                    current_policy_id = policy.create_version(
                        insured_names,
                        policy_number,
                        company,
                        lob,
                        premium,
                        annual_premium,
                        purpose,
                        transaction_date,
                        seq,
                        transaction_effective_date_str,
                        policy_effective_date,
                        policy_expiry_date,
                        file_name,
                        optional_connection=connection)

                    # Add a new entry for transformation.
                    new_entry_id = indexer.add_to_indexer(
                        persistence.INDEXER_TRANSFORM,
                        file_name,
                        policy_id=current_policy_id,
                        process=transaction_effective_date,
                        optional_connection=connection
                    )

                    # See if this entry should be put on hold. Currently, we check for insured mismatch which
                    # might mean a divorce or marriage.
                    indexer.update_hold(
                        new_entry_id,
                        not _do_insureds_match(insured_names, latest_version, optional_connection=connection),
                        "Insured mismatch",
                        optional_connection=connection
                    )

                    connection.commit()

    # Even if we don't end up needing to index the file, we will copy the files into
    # the policy folder anyway for safe keeping.
    fm.copy(src_file_path, destination_file_path)

    # Remove the file now that it has been organized.
    fm.remove(src_file_path)
    src_dir = fm.dirname(src_file_path)

    # Clean up the folder if its empty.
    if not fm.listdir(src_dir):
        fm.rmdir(src_dir)

    # Remove the "organize" entry from the indexer.
    indexer.remove_from_indexer(entry_id)

    return True


def _organize_al3(entry_id: str, src_file_path: str) -> bool:
    """
    Organize an AL3 file into the "policies" folder.

    Converts AL3 content to JSON, extracts policy details, and decides whether
    to index the policy. Copies the file into its permanent destination and
    removes the original.

    :param entry_id: Indexer entry id.
    :param src_file_path: Path to the AL3 file to organize.
    :return: True if successfully organized, False if skipped.
    """
    fm = FileManagerFactory.create_file_manager()

    al3 = AL3ToJSON().load(src_file_path)
    al3_json = AL3ToJSON().to_json(al3)

    destination_folder_name = make_al3_folder(al3_json)
    destination_folder = fm.join(Repository().policies_location, destination_folder_name)
    destination_file_name, err_msg = make_al3_file_name(al3_json)

    if len(err_msg) > 0:
        log.error(err_msg)
        raise TaskException("Errors organizing " + src_file_path)

    fm.mkdirs(destination_folder)
    destination_file_path = fm.join(destination_folder, destination_file_name)

    # Figure out when the file should be indexed.
    two_trg = find_group_by_group_name(al3_json, "2TRG")
    five_bpi = find_group_by_group_name(al3_json, "5BPI")

    transaction_effective_date = date_from_edi_date(val(two_trg, "23", None))
    transaction_date = date_from_edi_date(val(two_trg, "20", None))
    policy_effective_date = date_from_edi_date(val(five_bpi, "06", None))
    policy_expiry_date = date_from_edi_date(val(five_bpi, "07", None))
    policy_number = fix_policy_number(val(five_bpi, "01", None))
    lob = val(five_bpi, "04", None)
    company = val(five_bpi, "03", None)
    company, _ = policy.map_company_code(company)

    premium = val(five_bpi, "11", None)
    annual_premium = None
    if premium is not None:
        premium = to_dollars_and_cents(premium)
        annual_premium = to_annual_premium(
            premium,
            policy_effective_date,
            policy_expiry_date)

    two_trg = find_group_by_group_name(al3_json, "2TRG")
    purpose = val(two_trg, "25", None)
    seq = int_val(two_trg, "19", 0)

    # Look up the currently indexed policy.
    policy_details = policy.read_active_by_policy_number_company_lob(policy_number, company, lob)

    skip_it = False

    if policy_details is not None:
        # Make sure the policy we are dealing with is newer than the one we already have
        # indexed. If it's older, we can ignore it.
        current_transaction_effective_date_str = policy_details.transaction_effective_date

        if current_transaction_effective_date_str is not None:
            current_transaction_effective_date = datetime.strptime(
                str(current_transaction_effective_date_str),
                "%Y-%m-%d").date()

            # If the file we are looking at is older than the currently indexed policy, then skip it.
            if transaction_effective_date <= current_transaction_effective_date:
                skip_it = True

    # Here we need to take special precautions if the purpose of the file is SYN. A SYN request is probably
    # from a company initial data load. If we already have a file for this policy, then we should ignore the
    # SYN request. The SYN request doesn't tell us the state of the policy, so it's impossible to
    # represent the policy properly on the UI (i.e. RWL, XLN etc.).
    if purpose == "SYN":
        # See if we already have a policy file for this policy.
        if fm.exists(destination_folder):
            existing_files = list(
                pathlib.Path(destination_folder).glob(company + '_' + policy_number + '_*_' + lob + '_*.AL3'))
            if len(existing_files) > 0:
                # We have another file here already so skip.
                skip_it = True

    if "REPORT" in policy_number.upper() or "BINDER" in policy_number.upper():
        skip_it = True

    if not skip_it:
        # Anything other than personal auto and home stops here.
        if lob == "AUTO" or lob == "HABL":
            # See if this policy has a hold on it.
            on_hold = indexer.is_policy_on_hold(policy_number, company, lob)

            # Block or unblock the entry.
            indexer.update_block(entry_id, on_hold, "Blocked due to policy hold")

            if on_hold:
                # No further processing if we are on hold.
                return False

            file_name = fm.join(destination_folder_name, destination_file_name)

            if not indexer.file_name_exists(file_name.replace(".AL3", ".JSON")):
                with get_connection() as connection:
                    active_policy = policy.read_active_by_policy_number_company_lob(
                        policy_number,
                        company,
                        lob,
                        optional_connection=connection
                    )

                    if not active_policy:
                        # No active policy - we need to create an active placeholder. If this policy
                        # sits in the indexer as a renewal, then we need that placeholder to show to the
                        # user in the meantime. Especially required for renewals. When an admin looks at
                        # renewals, the code expects there to always be a policy.
                        policy.create(policy_number, company, lob, optional_connection=connection)

                    # Lookup the insureds.
                    insured_names: list[str] = _collect_al3_insured_names(al3_json)

                    # Grab the latest version before we create the policy. We use it to get the insureds, which are
                    # then used to figure out if we need to put a hold on the policy.
                    latest_version = policy.read_version_latest(
                        policy_number,
                        company,
                        lob,
                        optional_connection=connection)

                    current_policy_id = policy.create_version(
                        insured_names,
                        policy_number,
                        company,
                        lob,
                        premium,
                        annual_premium,
                        purpose,
                        transaction_date,
                        seq,
                        date_to_string(transaction_effective_date),
                        date_to_string(policy_effective_date),
                        date_to_string(policy_expiry_date),
                        None,
                        optional_connection=connection)

                    # Add a new entry for transformation.
                    new_entry_id = indexer.add_to_indexer(
                        persistence.INDEXER_TRANSFORM,
                        file_name,
                        policy_id=current_policy_id,
                        process=transaction_effective_date,
                        optional_connection=connection
                    )

                    # See if this entry should be put on hold. Currently, we check for insured mismatch which
                    # might mean a divorce or marriage.
                    indexer.update_hold(
                        new_entry_id,
                        not _do_insureds_match(insured_names, latest_version, optional_connection=connection),
                        "Insured mismatch",
                        optional_connection=connection)

                    connection.commit()

    # Even if we don't end up needing to index the file, we will copy the files into
    # the policy folder anyway for safe keeping.
    fm.copy(src_file_path, destination_file_path)

    # Remove the file now that it has been organized.
    fm.remove(src_file_path)
    src_dir = fm.dirname(src_file_path)

    # Clean up the folder if its empty.
    if not fm.listdir(src_dir):
        fm.rmdir(src_dir)

    # Remove the "organize" entry from the indexer.
    indexer.remove_from_indexer(entry_id)

    return True


def _explode_al3(root, entry):
    """
    Explode an AL3 file into multiple files if it contains multiple records.

    If the AL3 file contains more than one record, split it into separate
    files, save them, and index them individually. Cleans up if an error occurs.

    :param root: Root directory containing the file.
    :param entry: Indexer entry dict for the AL3 file.
    :return: Tuple (success flag, exploded entries, exception).
    """
    fm = FileManagerFactory.create_file_manager()
    result = True
    exception = None
    exploded_entries = []

    entry_id = entry["id"]
    file = entry["file_name"]
    entered = entry["entered"]
    full_path = fm.join(root, file)

    sub_dir = fm.basename(str(pathlib.Path(full_path).parent))
    ext = pathlib.Path(file).suffix

    try:
        al3 = AL3ToJSON().load(full_path)
        records = AL3ToJSON().to_list(al3)

        if len(records) > 1:
            for record in records:
                new_file_name = shortuuid.uuid() + ext
                exploded_file_path = fm.join(sub_dir, new_file_name)
                AL3ToJSON().save_str(fm.join(root, exploded_file_path), record)
                mid = indexer.add_to_indexer(persistence.INDEXER_ORGANIZE, exploded_file_path)
                exploded_entries.append({
                    "id": mid,
                    "name": persistence.INDEXER_ORGANIZE,
                    "file_name": exploded_file_path,
                    "entered": entered,
                })

            AL3ToJSON().delete(full_path)
            indexer.remove_from_indexer(entry_id)

    except Exception as e:
        exception = e
        result = False

        if exploded_entries is not None:
            for exploded_entry in exploded_entries:
                fm.remove(fm.join(root, exploded_entry["file_name"]))
                indexer.remove_from_indexer(exploded_entry["id"])

    return result, exploded_entries, exception


def _collect_json_insured_names(j: Dict[str, Any]) -> List[str]:
    """
    Extract insured names from a JSON policy document.
    Removes extra spaces from each name.

    :param j: Policy JSON object.
    :return: A list of insured names.
    """
    insured_names: List[str] = []
    policy_dom = PolicyDOM().from_json(j)

    for i in policy_dom.individuals:
        if i.name:
            name = " ".join(i.name.split())
            insured_names.append(name)

    return insured_names


def _collect_al3_insured_names(al3_json: Dict[str, Any]) -> List[str]:
    """
    Extract insured and co-insured names from an AL3 JSON structure.
    Removes extra spaces from each name.

    :param al3_json: Parsed AL3 JSON as a nested dict.
    :return: A list of insured/co-insured full names.
    """
    insured_names: List[str] = []
    five_bis: Dict[str, Any] | None = find_group_by_group_name(al3_json, "5BIS")
    if five_bis:
        if raw_name := to_full_name(val(five_bis, "01", None)):
            name = " ".join(raw_name.split())
            insured_names.append(name)

        five_sngs = find_groups_by_group_name(five_bis.get("children", {}), "5SNG")

        insured_names.extend(
            " ".join(coinsured_name.split())
            for five_sng in five_sngs
            if (coinsured_name := to_full_name(val(five_sng, "03", None)))
        )
    return insured_names


def _handle_error_organizing(journal_id, e):
    """
    Handle errors occurring during the main organize process.

    Logs the error, returns a failed status and error message.

    :param journal_id: The journal ID for logging context.
    :param e: The exception that occurred.
    :return: Tuple (status, error message).
    """
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] organizing error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while organizing"


def _handle_error_organizing_file(journal_id, file, e):
    """
    Handle errors specific to a single file during organizing.

    Logs the error with file context, returns a failed status.

    :param journal_id: The journal ID for logging context.
    :param file: The file being organized when the error occurred.
    :param e: The exception that occurred.
    :return: Failed status constant.
    """
    if file is not None:
        log.error(f"[{journal_id}] failed while organizing {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] organizing error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
