import logging
from datetime import datetime

from tasks.celery_app import app
from lib_common.constants import LOGGER
from lib_journal.journal import Journal
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import indexer
from lib_al3.al3_to_json import AL3ToJSON
from lib_al3.al3_utils import al3_extensions, find_group_by_group_name, val

log = logging.getLogger(LOGGER)


def _purge_file(path, file_to_move):
    fm = FileManagerFactory.create_file_manager()

    sub_folder = fm.basename(path)
    new_folder = fm.join(Repository.purged_location, datetime.now().strftime("%Y%m%d"), sub_folder)
    new_location = fm.join(new_folder, file_to_move)

    try:
        fm.mkdirs(new_folder)
        fm.move(fm.join(path, file_to_move), new_location)
    except FileNotFoundError:
        pass

    file_name_to_purge = fm.join(path, file_to_move).replace(Repository.mail_inbox_location, "")

    if file_name_to_purge.startswith("/"):
        file_name_to_purge = file_name_to_purge[1:]

    indexer.remove_from_indexer_by_filename(file_name_to_purge)


@app.task
def execute(previous_task=None):
    """ """

    journal_id = ""
    num_purged = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    try:
        fm = FileManagerFactory.create_file_manager()

        journal_id = Journal().begin_journal(Journal.purge_inbox, "Starting to purge inbox")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to purge inbox")

        for root, dirs, files in fm.walk(Repository.mail_inbox_location):
            for file in files:
                purged = False

                try:
                    is_num_ext = fm.splitext(file)[1].strip(".").isnumeric()

                    # Not interested in broker control reports.
                    if file.startswith("Broker Control Report") or file.startswith("NA-"):
                        _purge_file(root, file)

                    elif file.lower().endswith(al3_extensions) or is_num_ext:
                        al3 = AL3ToJSON().load(fm.join(root, file))
                        al3_json = AL3ToJSON().to_json(al3)
                        purged = False

                        # For now, it's only safe to purge if there is only one record.
                        records = AL3ToJSON().to_list(al3)

                        if len(records) == 1:
                            two_trg = find_group_by_group_name(al3_json, "2TRG")
                            lob = val(two_trg, "07", None)

                            # Not currently interested in MISC or CAUTO. MISC is usually a broker control
                            # report.
                            if lob == "MISC":  # or lob == "CAUTO":
                                _purge_file(root, file)
                                purged = True

                            if not purged:
                                two_trg = find_group_by_group_name(al3_json, "2TRG")
                                lob_sub_cd = val(two_trg, "08", None)

                                # We don't need memos. This is more than likely a broker control report.
                                if lob_sub_cd == "MEM":
                                    _purge_file(root, file)
                                    purged = True

                    if purged:
                        num_purged += 1

                except Exception as e:
                    end_status = _handle_error_purging_inbox_file(journal_id, file, e)

        try:
            for root, dirs, files in fm.walk(Repository.mail_inbox_location):
                if root != Repository.mail_inbox_location:
                    if len(files) == 0:
                        fm.rmdir(root)
        except Exception as e:
            end_status = _handle_error_purging_inbox(journal_id, e)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully purged {n} files".format(n=num_purged)
        else:
            if num_purged > 0:
                end_msg = "Failed but purged {n} files".format(n=num_purged)
            else:
                end_msg = "Failed purging files".format(n=num_purged)

            # raise TaskException(
            #     end_msg,
            #     error_code=exceptions.CODE_TASK_FAILED
            # )

        return True, num_purged

    except Exception as e:
        end_status, end_msg = _handle_error_purging_inbox(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.purge_inbox, journal_id, end_status, end_msg, num_purged)


def _handle_error_purging_inbox(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] purging inbox error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while purging inbox"


def _handle_error_purging_inbox_file(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while purging inbox file {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] purging inbox error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
