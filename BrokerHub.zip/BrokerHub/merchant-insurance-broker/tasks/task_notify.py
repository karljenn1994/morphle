import logging
from datetime import datetime, timezone

from lib_common import constants, exceptions
from lib_common.authentication import generate_identity_token
from lib_common.constants import LOGGER
from lib_common.exceptions import TaskException
from lib_journal.journal import Journal
from lib_email.notify_user import notify_user
from lib_persistence import campaign, notifier, settings, user
from tasks.celery_app import app

log = logging.getLogger(LOGGER)


@app.task
def execute(_=None):
    journal_id = ""
    num_notified = 0
    end_msg = ""
    end_status = Journal.STATUS_SUCCESS

    limit = 500
    total_sent = 0
    limit_reached = False

    try:
        journal_id = Journal().begin_journal(Journal.notify, "Starting to notify clients")

        if log.isEnabledFor(logging.INFO):
            log.info("Starting to notify clients")

        notifications = notifier.get_messages_ready_to_send()

        for notification in notifications:
            if limit_reached:
                # We've reached the end of our sent limit so stop.
                break

            # Get the recipients we have not notified yet.
            recipients = notifier.get_recipients(notification.id)

            for recipient in recipients:
                # See if we have gone over our limit.
                if total_sent > limit:
                    limit_reached = True
                    break

                notifier_recipient_id = recipient.notifier_recipient_id
                message_id = None

                try:
                    # If the user's account status is 'uploaded', we need to put their account into
                    # 'invited' mode.
                    if recipient.status == 'uploaded':
                        user.invite_user(recipient)
                        recipient = notifier.get_recipient(notifier_recipient_id)

                    group_id = settings.get_setting(constants.SETTING_SENDGRID_GROUP_ID)

                    reset_code = recipient.reset_code
                    guest_token = None

                    if recipient.role == "user":
                        guest_token, _ = generate_identity_token(recipient, expires_hours=48)

                    campaign_obj = campaign.load_campaign(notification.campaign_id)
                    template_obj = notifier.get_template(notification.template_id, recipient.locale)
                    message_id = None

                    if template_obj:
                        message_id, _, _ = notify_user(
                            recipient,
                            campaign_obj,
                            template_obj,
                            token=guest_token,
                            reset_code=reset_code,
                            bypass=not bool(notification.marketing),
                            group_id=int(group_id),
                            notifier_recipient_id=notifier_recipient_id,
                            trigger_event=notification.trigger_event)
                    else:
                        log.error("TASK_NOTIFY TEMPLATE MISSING " + recipient.locale)

                    if message_id:
                        # DO NOT set status to None here, or we may end up resending.
                        notifier.update_notifier_recipient_result(
                            notifier_recipient_id,
                            "unknown",
                            message_id=message_id,
                            sent_date=datetime.now(timezone.utc))
                        num_notified += 1
                    else:
                        # No message id so something went wrong.
                        notifier.update_notifier_recipient_result(notifier_recipient_id, "failed")

                except Exception as e:
                    message = getattr(e, "message", str(e))
                    notifier.update_notifier_recipient_result(
                        notifier_recipient_id,
                        "failed",
                        message_id=message_id,
                        message=message
                    )

                    end_status = _handle_error_notifying(journal_id, e)

                finally:
                    total_sent += 1

            # We may not be done with this notification yet. If we reached our limit, then we didn't
            # reach the end of the recipient list.
            if not limit_reached:
                # Mark the notification as sent.
                notifier.move_to_sent(notification.id)

        if end_status == Journal.STATUS_SUCCESS:
            end_msg = "Successfully notified {n} client".format(n=num_notified)
        else:
            if num_notified > 0:
                end_msg = "Failed but notified {n} clients".format(n=num_notified)
            else:
                end_msg = "Failed notifying clients".format(n=num_notified)

            raise TaskException(
                end_msg,
                error_code=exceptions.CODE_TASK_FAILED
            )

        return True, num_notified

    except Exception as e:
        end_status, end_msg = _handle_error_notifying(journal_id, e)
        raise e

    finally:
        if log.isEnabledFor(logging.INFO):
            log.info(end_msg)

        Journal().end_journal(Journal.notify, journal_id, end_status, end_msg, num_notified)


def _handle_error_notifying(journal_id, e):
    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] notify error: {message}", exc_info=True)
    return Journal.STATUS_FAILED, message or "Failed while notifying"


def _handle_error_notifying_client(journal_id, file, e):
    if file is not None:
        log.error(f"[{journal_id}] failed while notifying {file}")

    message = getattr(e, "message", str(e))
    log.error(f"[{journal_id}] notifying error: {message}", exc_info=True)

    return Journal.STATUS_FAILED
