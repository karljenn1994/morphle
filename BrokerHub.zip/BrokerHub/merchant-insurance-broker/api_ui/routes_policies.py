import json
import logging

from flask import Response, redirect, request
from flask_jwt_extended import (
    create_access_token,
    get_jwt_identity,
    jwt_required,
    set_access_cookies,
    verify_jwt_in_request
)
from flask_restx import Namespace, Resource
from jwt import PyJWTError

from lib_common import constants, exceptions
from lib_common.authentication import (
    assert_admin_user,
)
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    AlreadyExistsException,
    AuthenticationException,
    AuthenticationExpiredException,
    DeleteFailedException,
    HttpException,
    InvalidArgument
)
from lib_common.repository import Repository
from lib_common.routes_support import (
    assert_not_none,
    get_friendly_locale, response_json,
    rows_to_list
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import indexer, persistence, policy, settings, user
from lib_policy_dom.JSON import JSON
from validations.issues_support import load_issues
from validations.validations_support import validate_policy

api = Namespace("broker-api/web/v1/ui/policies", description="Provides access to a user's policy.")
log = logging.getLogger(LOGGER)


@api.route("/total", methods=["GET"])
@api.doc(description="Total number of policies.")
class TotalPolicies(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of policies.
        """
        try:
            assert_admin_user()
            count = policy.read_active_count(None)
            return Response(json.dumps(count), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["GET"])
@api.doc(description="Read all policies.")
class Policies(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all policies.
        """
        try:
            assert_admin_user()

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            policy_list = policy.list_active_paged(rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(rows_to_list(policy_list), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/policy", methods=["POST"])
@api.doc(description="Create a new policy.")
class AddPolicy(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post():
        """
        Create a new policy.
        """
        try:
            assert_admin_user()

            json_data = request.json

            policy_number = json_data["policy_number"] if "policy_number" in json_data else None
            company = json_data["company"] if "company" in json_data else None
            lob = json_data["lob"] if "lob" in json_data else None

            assert_not_none(policy_number, "Missing policy number")
            assert_not_none(company, "Missing company")
            assert_not_none(lob, "Missing lob")

            policy_obj = policy.read_active_by_policy_number_company_lob(policy_number, company, lob)

            if policy_obj is not None:
                raise AlreadyExistsException("Policy already exists",
                                             error_code=exceptions.CODE_ADMIN_POLICY_ALREADY_EXISTS)

            policy.create(policy_number, company, lob)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/policy/<policy_id>", methods=["DELETE"])
@api.doc(description="Delete a policy.")
class DeletePolicy(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(policy_id):
        """
        Delete a policy.
        """
        try:
            assert_admin_user()

            if not policy.delete(policy_id):
                raise DeleteFailedException(
                    "Make sure no clients are currently assigned to this policy before deleting",
                    error_code=exceptions.CODE_ADMIN_POLICY_DELETE_WITH_CLIENTS)

            return response_json(200, True)

        except DeleteFailedException as ex:
            log.info(ex.message + " (" + policy_id + ")")
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/policy/<policy_id>", methods=["GET"])
@api.route("/policy_number/<policy_number>", methods=["GET"])
@api.route("/policy_number/<policy_number>/company/<company>/lob/<lob>", methods=["GET"])
@api.doc(description="Read a policy.")
class ReadPolicy(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(policy_id=None, policy_number=None, company=None, lob=None):
        """
        Read a policy.
        """
        try:
            assert_admin_user()
            fm = FileManagerFactory.create_file_manager()
            j = JSON()

            policy_card = None
            policy_list = []
            renewal_list = []
            users = []

            # Search for the policy.
            p = None

            if policy_id:
                p = policy.read_version_by_id(policy_id)
                if p is None:
                    raise InvalidArgument("Policy not found", error_code=exceptions.CODE_ADMIN_POLICY_DOES_NOT_EXIST)

            if not p and policy_number and company and lob:
                p = policy.read_active_by_policy_number_company_lob(policy_number, company, lob)

            if not p and policy_number and lob:
                p = policy.read_active_by_policy_number_lob(policy_number, lob)

            if not p and policy_number:
                p = policy.read_active_by_policy_number(policy_number)

            if p:
                policy_number = p.policy_number
                company = p.company
                lob = p.lob

            pdfs = []

            if policy_number and company and lob:
                pdfs = policy.list_pdfs(
                    policy_number,
                    lob,
                    company,
                    transaction_effective_date=p.transaction_effective_date)

            if p:
                policy_number = p.policy_number
                company = p.company
                lob = p.lob

                if p.file_name:
                    card_json_file = fm.join(Repository.policies_location, p.file_name)
                    card_json = JSON.load_card_json(card_json_file)
                    policy_card = JSON().get_policy_card(card_json)

                    policy_card["pdfs"] = pdfs
                    policy_card["id"] = p.id
                    policy_card["downloaded"] = True

                    # Run validations before loading the issues.
                    validate_policy(p)
                    policy_card["validations"] = load_issues(p)

                    policy_list.append(card_json)
                    edi_file = card_json_file.replace(".JSON", ".AL3")

                    if fm.exists(edi_file):
                        try:
                            policy_edi = FileManagerFactory.create_file_manager().read_string(edi_file)
                            policy_card["edi"] = policy_edi
                        except:
                            pass

                    policy_card["json"] = json.dumps(card_json)
                else:
                    # We don't have this policy downloaded yet. Make a placeholder for
                    # it so the user will see something. There might be PDFs available
                    # depending on the timing of things being downloaded.
                    _, company_name = policy.map_company_code(p.company)
                    policy_list.append([{
                        "id": p.id,
                        "downloaded": False,
                        "type": "policy",
                        "category": "folio",
                        "pdfs": pdfs,
                        "fields": {
                            "policy_number": p.policy_number,
                            "lob": p.lob,
                            "company_code": p.company,
                            "company_name": company_name
                        }
                    }])

            # Search for the renewal.
            r = None

            if policy_number and company and lob:
                r_idx = indexer.read_latest_renewal_by_number_company_lob(policy_number, company, lob)

                if r_idx:
                    r = policy.read_version_by_id(r_idx.policy_id)

            # Make sure we have a renewal, and it's different from the policy.
            if r and (not p or r.id != p.id):
                card_json_file = fm.join(Repository.policies_location, r.file_name)
                card_json = JSON.load_card_json(card_json_file)
                renewal_policy_card = j.get_policy_card(card_json)

                # renewal_policy_card["pdfs"] = policy.list_renewal_pdfs(
                #     r.policy_number,
                #     r.lob,
                #     r.company,
                #     r.file_name,
                #     r.transaction_effective_date)

                pdfs = []

                if policy_number and company and lob:
                    pdfs = policy.list_pdfs(
                        r.policy_number,
                        r.lob,
                        r.company,
                        transaction_effective_date=r.transaction_effective_date)

                renewal_policy_card["pdfs"] = pdfs

                renewal_policy_card["id"] = r.id
                renewal_policy_card["downloaded"] = True

                # Run validations before loading the issues.
                validate_policy(r)
                renewal_policy_card["validations"] = load_issues(r)

                renewal_list.append(card_json)

                edi_file = card_json_file.replace(".JSON", ".AL3")
                renewal_edi = None

                if fm.exists(edi_file):
                    renewal_edi = FileManagerFactory.create_file_manager().read_string(edi_file)

                renewal_policy_card["edi"] = renewal_edi
                renewal_policy_card["json"] = json.dumps(card_json)

                if not p and not policy_card:
                    # There is no policy yet. This can happen for a number of reasons,
                    # including not getting an initial data dump for a customer. The first
                    # thing we see might be the renewal. Here we are a placeholder card with
                    # any PDFs we might have on the renewal.
                    policy_card = {
                        "id": r.policy_id,
                        "downloaded": False,
                        "type": "policy",
                        "category": "folio",
                        "pdfs": pdfs,
                        "fields": {
                            "policy_number": policy_number,
                            "lob": lob,
                            "company_code": company,
                        }
                    }
                    policy_list.append(
                        [policy_card]
                    )

            if p:
                # Load users from policy.
                users = rows_to_list(user.lookup_users_by_policy_id(p.id, include_leads=True))
            elif r:
                # Load users from renewal.
                users = rows_to_list(user.lookup_users_by_policy_id(r.policy_id, include_leads=True))

            # Search for history.
            h = p or r

            if h and policy_card:
                history = policy.list_history(h.policy_number, h.company, h.lob, h.policy_effective_date, h.seq)

                if history:
                    policy_card["history"] = []

                    for h in history:
                        historical_card_json_file = fm.join(Repository.policies_location, h.file_name)
                        historical_card_json = JSON.load_card_json(historical_card_json_file)
                        historical_card = j.get_policy_card(historical_card_json)

                        historical_card["pdfs"] = None
                        historical_card["id"] = h.id
                        historical_card["downloaded"] = True
                        historical_card["validations"] = load_issues(h)

                        # We need the sequence on the UI for sorting; otherwise, some historical
                        # entries will be identical.
                        historical_card["sequence"] = h.seq

                        policy_card["history"].append(historical_card_json)

            if not policy_list and not renewal_list:
                raise InvalidArgument("Policy not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            slogan = settings.get_setting(constants.SETTING_BROKERAGE_SLOGAN + "_" + get_friendly_locale(
                request.headers))

            policy_report = {
                "logo": "http://logo.png",
                "name": settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME),
                "slogan": slogan,
                "address": settings.get_setting(constants.SETTING_BROKERAGE_ADDRESS),
                "hours": settings.get_setting(constants.SETTING_BROKERAGE_HOURS),
                "phone": settings.get_setting(constants.SETTING_BROKERAGE_PHONE),
                "users": users,
                "policies": policy_list,
                "renewals": renewal_list,
            }

            return Response(json.dumps(policy_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException, AuthenticationExpiredException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<policy_number>/<company>/<lob>/<file_name>", methods=["GET"])
@api.doc(description="Return a policy PDF.")
class PDF(Resource):
    @staticmethod
    def get(policy_number, company, lob, file_name):
        """
        Return a policy PDF (compressed or uncompressed).
        Behavior:
          1) Try access token from cookies
          2) If invalid/expired, try refresh token; if OK, mint new access and stream
          3) Else redirect to log in
        """
        login_url = settings.get_setting(constants.SETTING_ADMIN_UI_HOST) + "/auth/login"

        # --- 1) Try access token ---
        try:
            verify_jwt_in_request(locations=["cookies"])
            email = get_jwt_identity()
            user_obj = user.lookup_user_by_email(email)
            return PDF._serve_policy_pdf(user_obj.id, policy_number, company, lob, file_name)

        except PyJWTError as e:
            # Access token invalid/expired, try refresh
            pass
        except Exception as e:
            # Non-JWT error while verifying; still try refresh
            pass

        # --- 2) Access failed -> try refresh token ---
        try:
            verify_jwt_in_request(locations=["cookies"], refresh=True)
            email = get_jwt_identity()
            user_obj = user.lookup_user_by_email(email)

            # Mint new access token
            new_access = create_access_token(identity=user_obj.id)

            # Stream the PDF and set the new access cookie
            resp = PDF._serve_policy_pdf(user_obj.id, policy_number, company, lob, file_name)
            set_access_cookies(resp, new_access)
            return resp

        except Exception:
            # --- 3) No valid refresh -> login ---
            return redirect(login_url, code=302)

    @staticmethod
    def _serve_policy_pdf(user_id: str, policy_number: str, company: str, lob: str, file_name: str) -> Response:
        # Validate user
        user_obj = user.lookup_user_by_id(user_id)
        if user_obj is None:
            raise AuthenticationException(
                "User not found",
                error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST
            )
        if user_obj.status not in [persistence.USER_STATUS_ACTIVE, persistence.USER_STATUS_GUEST]:
            raise AuthenticationException(
                "User is not active",
                error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE
            )

        # Read (supports .pdf.gz fallback)
        pdf_bytes, encoding = policy.read_pdf(user_obj, policy_number, company, lob, file_name)
        if pdf_bytes is None:
            raise FileNotFoundError("Policy PDF not found")

        resp = Response(pdf_bytes, mimetype="application/pdf")
        if encoding == "gzip":
            resp.headers["Content-Encoding"] = "gzip"

        # Viewer-friendly & safe headers
        resp.headers["Content-Disposition"] = (
            f'inline; filename="{file_name if file_name.lower().endswith(".pdf") else file_name + ".pdf"}"'
        )
        resp.headers["Cache-Control"] = "private, no-store"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Accept-Ranges"] = "bytes"
        return resp


@api.route("/<policy_id>/user/<user_id>", methods=["PUT"])
@api.route("/<policy_id>/user/<user_id>/notify/<notify>", methods=["PUT"])
@api.doc(description="Add a user to the specified policy.")
class AddUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(policy_id, user_id, notify=None):
        """
        Add a user to the specified policy.
        """
        try:
            assert_admin_user()

            # Convert to boolean if present
            if isinstance(notify, str):
                notify = notify.lower() in ("true", "1", "yes")

            policy.map_user(policy_id, user_id, notify)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<policy_id>/user/<user_id>", methods=["DELETE"])
@api.doc(description="Delete a user from the specified policy.")
class DeleteUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(policy_id, user_id):
        """
        Delete a user from the specified policy.
        """
        try:
            assert_admin_user()

            policy.delete_user(policy_id, user_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/unmapped/total", methods=["GET"])
@api.doc(description="Total number of policies that are unmapped.")
class TotalUnmappedPolicies(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of unmapped policies.
        """
        try:
            assert_admin_user()

            count = policy.read_unmapped_count()
            return Response(json.dumps(count), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/unmapped", methods=["GET"])
@api.doc(description="List all policies that are unmapped.", security="bearer")
class UnmappedPolicies(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all unmapped policies.
        """
        try:
            assert_admin_user()

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", "transaction_effective_date")
            sort_direction = request.args.get("sort_direction", "DESC")
            search = request.args.get("search", None)
            policy_list = policy.list_unmapped_paged(rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(rows_to_list(policy_list), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/release/<policy_id>", methods=["PUT"])
@api.doc(description="Release a policy currently on hold.")
class ReleaseOnHold(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(policy_id):
        """
        Release a policy currently on hold.
        """
        try:
            assert_admin_user()

            indexer.update_hold_by_policy_id(policy_id, False)
            return Response(status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/onhold/total", methods=["GET"])
@api.doc(description="Total number of policies that are on hold.")
class TotalPoliciesOnHold(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of policies that are on hold.
        """
        try:
            assert_admin_user()

            count = indexer.read_on_hold_count()
            return Response(json.dumps(count), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/onhold", methods=["GET"])
@api.doc(description="List all policies that are on hold.", security="bearer")
class PoliciesOnHold(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all policies that are on hold.
        """
        try:
            assert_admin_user()

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", "transaction_effective_date")
            sort_direction = request.args.get("sort_direction", "DESC")
            search = request.args.get("search", None)
            policy_list = indexer.list_on_hold_paged(rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(rows_to_list(policy_list), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
