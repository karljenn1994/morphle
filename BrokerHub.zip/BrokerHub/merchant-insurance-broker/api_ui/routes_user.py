import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants, exceptions
from lib_common.authentication import assert_admin_user, get_user_id_from_cookies
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    AuthenticationException,
    HttpException,
    InvalidArgument
)
from lib_common.repository import Repository
from lib_common.routes_support import (
    assert_not_none,
    get_friendly_locale, response_json, row_to_dict, rows_to_list
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import collector, lead, persistence, policy, settings, user
from lib_policy_dom.JSON import JSON
from validations.issues_support import load_issues
from validations.validations_support import validate_policy

api = Namespace("broker-api/web/v1/ui/user", description="Provides user authentication, administration, etc.")
log = logging.getLogger(LOGGER)


@api.route("/counters", methods=["GET"])
@api.doc(description="Get counters.")
class Counters(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Get counters.
        """
        try:
            user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            counters = row_to_dict(user.get_counters(user_obj.id))
            return response_json(200, counters)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/change-password", methods=["PUT"])
@api.doc(description="Change a user's password.")
class ChangePassword(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put():
        """
        Change a user's password.
        """
        try:
            user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_INVALID_RESET_CODE)

            if user_obj.status != persistence.USER_STATUS_ACTIVE:
                raise AuthenticationException("User is not active",
                                              error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            json_data = request.json

            current_password = json_data["currentPassword"] if "currentPassword" in json_data else None
            new_password = json_data["password"] if "password" in json_data else None
            confirm_password = json_data["confirmPassword"] if "confirmPassword" in json_data else None

            assert_not_none(current_password, "Missing current password")
            assert_not_none(new_password, "Missing new password")
            assert_not_none(confirm_password, "Missing confirm password")

            if new_password != confirm_password:
                raise AuthenticationException("Passwords do not match",
                                              error_code=exceptions.CODE_ADMIN_USER_PASSWORD_MISMATCH)

            match = user.test_password_match(current_password, user_obj.password_hash, user_obj.salt)

            if not match:
                raise AuthenticationException("Authentication failed",
                                              error_code=exceptions.CODE_ADMIN_USER_AUTHENTICATION_FAILED)

            user.change_password(user_obj, new_password)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["GET"])
@api.doc(description="Read a user.")
class UserProfile(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read a user.
        """
        try:
            user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            if user_obj.status != persistence.USER_STATUS_ACTIVE:
                raise AuthenticationException("User is not active",
                                              error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            return Response(json.dumps({
                "id": user_obj.id,
                "email": user_obj.email,
                "first": user_obj.first_name,
                "last": user_obj.last_name,
                "account_name": user_obj.account_name,
                "status": user_obj.status,
                "role": user_obj.role,
                "province_code": user_obj.province,
                "postal_code": user_obj.postal_code,
                "date_of_birth": user_obj.date_of_birth,
                "locale": user_obj.locale,
                "notification_preference": user_obj.notification_preference,
            }), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["PUT"])
@api.doc(description="Update a user.")
class UpdateUserProfile(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put():
        """
        Update a user.
        """
        try:
            user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            if user_obj.status != persistence.USER_STATUS_ACTIVE:
                raise AuthenticationException("User is not active",
                                              error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            json_data = request.json

            account_name = json_data["account_name"] if "account_name" in json_data else None
            first = json_data["first_name"] if "first_name" in json_data else None
            last = json_data["last_name"] if "last_name" in json_data else None

            assert_not_none(first, "First name missing")
            assert_not_none(last, "Last name missing")

            province = json_data["province_code"] if "province_code" in json_data else None
            postal_code = json_data["postal_code"] if "postal_code" in json_data else None
            date_of_birth = json_data["date_of_birth"] if "date_of_birth" in json_data else None
            locale = json_data["locale"] if "locale" in json_data else None
            notification_preference = json_data[
                "notification_preference"] if "notification_preference" in json_data else None

            user.update_user(user_obj,
                             user_obj,
                             None,
                             account_name,
                             first,
                             last,
                             province,
                             postal_code,
                             date_of_birth,
                             locale,
                             notification_preference,
                             False)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/report/<user_id>", methods=["GET"])
@api.doc(description="Read a user's policies.")
class UserReport(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(user_id):
        """
        Read a user's policies.
        """
        try:
            fm = FileManagerFactory.create_file_manager()

            token_user_id = get_user_id_from_cookies()
            caller = user.lookup_user_by_id(token_user_id)

            if caller.id != user_id:
                # User must be admin to query someone else's policy.
                # This assertion will throw an exception if they are not an admin.
                assert_admin_user()

            # Make sure the user being queried is actually a legit user.
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            # Admins can query inactive users.
            if caller.id == user_id:
                if user_obj.status != persistence.USER_STATUS_ACTIVE \
                        and user_obj.status != persistence.USER_STATUS_GUEST:
                    raise AuthenticationException("User is not active",
                                                  error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            policies = policy.list_policies_by_user_id(user_obj.id)
            policy_list = []
            renewal_list = []
            j = JSON()

            for p in policies:
                if p.active:
                    if p.file_name is not None and len(p.file_name) > 0:
                        card_json = JSON.load_card_json(fm.join(Repository.policies_location, p.file_name))
                        pdfs = policy.list_pdfs(
                            p.policy_number, p.lob, p.company,
                            p.transaction_effective_date)
                        policy_card = j.get_policy_card(card_json)

                        policy_card["pdfs"] = pdfs
                        policy_card["id"] = p.id
                        policy_card["downloaded"] = True

                        # Run validations before loading the issues.
                        validate_policy(p)

                        policy_card["validations"] = load_issues(p)

                        history = policy.list_history(p.policy_number, p.company, p.lob, p.policy_effective_date, p.seq)

                        if history is not None:
                            policy_card["history"] = []

                            for h in history:
                                historical_card_json_file = fm.join(Repository.policies_location, h.file_name)
                                historical_card_json = JSON.load_card_json(historical_card_json_file)
                                historical_card = j.get_policy_card(historical_card_json)

                                historical_card["pdfs"] = None
                                historical_card["id"] = h.id
                                historical_card["downloaded"] = True
                                historical_card["validations"] = load_issues(h)

                                # We need the sequence on the UI for sorting; otherwise, some historical
                                # entries will be identical.
                                historical_card["sequence"] = h.seq

                                policy_card["history"].append(historical_card_json)
                    else:
                        card_json = [{
                            "id": p.id,
                            "downloaded": False,
                            "type": "policy",
                            "category": "folio",
                            "fields": {
                                "policy_number": p.policy_number,
                                "lob": p.lob,
                                "company_code": p.company,
                            }
                        }]

                    policy_list.append(card_json)

                r = policy.read_renewal(p.policy_number, p.company, p.lob)

                if r is not None:
                    # Load the renewal JSON file.
                    card_json = JSON.load_card_json(fm.join(Repository.policies_location, r.file_name))
                    policy_card = j.get_policy_card(card_json)

                    # policy_card["pdfs"] = policy.list_renewal_pdfs(
                    #     r.policy_number,
                    #     r.lob,
                    #     r.company,
                    #     r.file_name,
                    #     r.transaction_effective_date)

                    pdfs = []

                    if r.policy_number and r.company and r.lob:
                        pdfs = policy.list_pdfs(
                            r.policy_number,
                            r.lob,
                            r.company,
                            transaction_effective_date=r.transaction_effective_date)

                    policy_card["pdfs"] = pdfs

                    policy_card["id"] = r.id
                    policy_card["downloaded"] = True

                    # Run validations before loading the issues.
                    validate_policy(r)

                    policy_card["validations"] = load_issues(r)

                    renewal_list.append(card_json)

            # Make sure the user being queried is actually a legit user.
            user_lead = lead.lookup_user_lead(user_obj.id)
            auto_list = rows_to_list(lead.list_auto_leads(user_obj.id))
            prop_list = rows_to_list(lead.list_property_leads(user_obj.id))
            leads_list = auto_list + prop_list
            leads_obj = None

            if leads_list is not None and len(leads_list) > 0:
                leads_obj = {
                    "status": user_lead.status,
                    "received_date": user_lead.received_date,
                    "modified_date": user_lead.modified_date,
                    "list": leads_list,
                }

            cards_list = rows_to_list(collector.list_collected_properties(user_obj.id, "life"))
            cards_list += rows_to_list(collector.list_collected_autos(user_obj.id, "life"))
            cards_list += rows_to_list(lead.list_loyalty_cards(user_obj.id))

            slogan = settings.get_setting(constants.SETTING_BROKERAGE_SLOGAN + "_" + get_friendly_locale(
                request.headers))

            policy_report = {
                "logo": "http://logo.png",
                "name": settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME),
                "slogan": slogan,
                "address": settings.get_setting(constants.SETTING_BROKERAGE_ADDRESS),
                "hours": settings.get_setting(constants.SETTING_BROKERAGE_HOURS),
                "phone": settings.get_setting(constants.SETTING_BROKERAGE_PHONE),
                "policies": policy_list,
                "renewals": renewal_list,
                "users": row_to_dict(user_obj),
                "leads": leads_obj,
                "cards": cards_list,
            }

            return Response(json.dumps(policy_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/user/<user_id>/policy/<policy_id>", methods=["GET"])
@api.doc(description="Read a user's policy.")
class UserPolicy(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(user_id, policy_id):
        """
        Read a user's policies.
        """
        try:
            fm = FileManagerFactory.create_file_manager()

            token_user_id = get_user_id_from_cookies()
            caller = user.lookup_user_by_id(token_user_id)

            if caller.id != user_id:
                # User must be admin to query someone else's policy.
                # This assertion will throw an exception if they are not an admin.
                assert_admin_user()

            # Make sure the user being queried is actually a legit user.
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            # Admins can query inactive users.
            if caller.id == user_id:
                if user_obj.status != persistence.USER_STATUS_ACTIVE \
                        and user_obj.status != persistence.USER_STATUS_GUEST:
                    raise AuthenticationException("User is not active",
                                                  error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            p = policy.read_version_by_id_user_id(policy_id, user_id)

            if p is None:
                raise InvalidArgument("Policy not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            if p.file_name is not None and len(p.file_name) > 0:
                card_json = JSON.load_card_json(fm.join(Repository.policies_location, p.file_name))
                policy_card = JSON().get_policy_card(card_json)

                policy_card["id"] = p.id
                policy_card["downloaded"] = True
            else:
                card_json = [{
                    "id": p.id,
                    "downloaded": False,
                    "type": "policy",
                    "category": "folio",
                    "fields": {
                        "policy_number": p.policy_number,
                        "lob": p.lob,
                        "company_code": p.company,
                    }
                }]

            return Response(json.dumps(card_json, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<user_id>/policy/<policy_id>", methods=["PUT"])
@api.route("/<user_id>/policy/<policy_id>/notify/<notify>", methods=["PUT"])
@api.doc(description="Add a policy to the specified user.")
class AddPolicy(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(user_id, policy_id, notify=None):
        """
        Add a policy to the specified user.
        """
        try:
            assert_admin_user()

            # Convert to boolean if present
            if isinstance(notify, str):
                notify = notify.lower() in ("true", "1", "yes")

            user.add_policy(user_id, policy_id, notify=notify)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


# @api.route("/add/policy_number/<policy_number>", methods=["PUT"])
# @api.route("/add/policy_number/<policy_number>/notify/<notify>", methods=["PUT"])
# @api.doc(description="Search and add a policy to the current user.")
# class SearchAddPolicy(Resource):
#     @staticmethod
#     @jwt_required(locations=["cookies"])
#     def put(policy_number, notify=None):
#         """
#         Search and add a policy to the current user.
#         """
#         try:
#             # Convert to boolean if present
#             if isinstance(notify, str):
#                 notify = notify.lower() in ("true", "1", "yes")
#
#             user_id = get_user_id_from_cookies()
#             user_obj = user.lookup_user_by_id(user_id)
#
#             if user_obj is None:
#                 raise InvalidArgument("User not found", error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)
#
#             if user_obj.status != persistence.USER_STATUS_ACTIVE:
#                 raise AuthenticationException("User is not active",
#                                               error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)
#
#             if user_obj.province is None or user_obj.last_name is None or user_obj.date_of_birth is None:
#                 return Response(json.dumps((False, False)), status=200, mimetype="application/json")
#
#             policy_ids = policy.list_active_ids(policy_number,
#                                                 None,
#                                                 user_obj.province,
#                                                 user_obj.date_of_birth,
#                                                 None,
#                                                 user_obj.last_name)
#
#             if len(policy_ids) == 0:
#                 return Response(json.dumps((True, False)), status=200, mimetype="application/json")
#
#             for policy_id in policy_ids:
#                 user.add_policy(user_obj.id, policy_id, notify=notify)
#
#             return Response(json.dumps((True, True)), status=200, mimetype="application/json")
#         except (HttpException, InvalidArgument, AuthenticationException) as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": ex.message,
#                 "code": ex.code
#             })
#         except Exception as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": str(ex)
#             })


@api.route("/<user_id>/policy/<policy_id>", methods=["DELETE"])
@api.doc(description="Delete a policy from the specified user.")
class DeleteUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(policy_id, user_id):
        """
        Delete a policy from the specified user.
        """
        try:
            assert_admin_user()

            user.remove_policy(user_id, policy_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
