import logging

import requests
from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants, exceptions
from lib_common.authentication import generate_vendor_user_token, get_user_id_from_cookies
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.routes_support import assert_not_none, response_json
from lib_persistence import settings, user

api = Namespace("broker-api/web/v1/ui/pass", description="Apple related routes.")
log = logging.getLogger(LOGGER)


@api.route("/google/liability/create", methods=["POST"])
@api.doc(description="Build a Google pass for 'proof of insurance'.")
class BuildGoogleLiabilityPass(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post():
        """
        Build a Google pass for "proof of insurance".
        """
        try:
            token_user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(token_user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "User not found",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST
                )

            json_data = request.json
            cards = json_data.get("cards")
            assert_not_none(cards, "Cards missing")
            pass_endpoint = settings.get_setting(constants.SETTING_LIFES_WALLET_PASS_API_URL)
            assert_not_none(pass_endpoint, "Pass endpoint not configured")

            vendor_user_token = generate_vendor_user_token(user_obj)

            # Build a brokerage token to authenticate the request.
            resp = requests.post(
                pass_endpoint + "/google/liability/create/" + settings.get_setting(constants.SETTING_BROKERAGE_ID),
                json=json_data,
                headers={"Authorization": "Bearer " + vendor_user_token}
            )

            if resp.status_code != 200:
                raise AuthenticationException(
                    "Unable to create google pass",
                    error_code=exceptions.CODE_INVALID_ARGUMENT
                )

            return Response(
                resp.content,
                status=200,
                mimetype='application/vnd.google.pkpass'
            )

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/apple/liability/create", methods=["POST"])
@api.doc(description="Build an apple pass for 'proof of insurance'.")
class BuildAppleLiabilityPass(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post():
        """
        Build an apple pass for "proof of insurance".
        """
        try:
            token_user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(token_user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            json_data = request.json
            cards = json_data.get("cards")
            assert_not_none(cards, "Cards missing")
            pass_endpoint = settings.get_setting(constants.SETTING_LIFES_WALLET_PASS_API_URL)
            assert_not_none(pass_endpoint, "Apple endpoint not configured")

            apple_token = generate_vendor_user_token(user_obj)

            # Build a brokerage token to authenticate the request.
            resp = requests.post(
                pass_endpoint + "/apple/liability/create/" + settings.get_setting(constants.SETTING_BROKERAGE_ID),
                json=json_data,
                headers={"Authorization": "Bearer " + apple_token}
            )

            if resp.status_code != 200:
                raise AuthenticationException(
                    "Unable to create apple pass",
                    error_code=exceptions.CODE_INVALID_ARGUMENT
                )

            return Response(
                resp.content,
                status=200,
                mimetype='application/json'
            )

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
