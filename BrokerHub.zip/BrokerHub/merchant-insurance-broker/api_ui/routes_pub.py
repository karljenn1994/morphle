import json
import logging
import mimetypes
import os

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants
from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.routes_support import response_json
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import settings

api = Namespace("broker-api/web/v1/ui/pub", description="Provides access to pub files.")
log = logging.getLogger(LOGGER)


@api.route("/<file_name>", methods=["GET"])
@api.doc(description="Return a file.")
class GetPubFile(Resource):
    @staticmethod
    def get(file_name):
        """
        Safely serve a static image file from the public directory.

        HOW IT WORKS:
        -----------------
        - Allows only known-safe image file extensions.
        - Builds the path using FileManager to ensure it's relative to the base system folder.
        - Resolves the path using `get_absolute_path` to enforce path containment.
        - Returns file content with MIME type, or a generic access-denied error.

        SECURITY:
        -----------------
        - Prevents path traversal via FileManager's `get_absolute_path`.
        - Denies access to unsupported extensions.
        - Returns generic error messages on failure.

        :param file_name: Name of the image file to serve (e.g., "logo.png").
        :return: Flask Response with file content or access-denied error.
        """
        try:
            allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}
            ext = os.path.splitext(file_name)[1].lower()
            if ext not in allowed_extensions:
                raise HttpException("Access denied")

            fm = FileManagerFactory.create_file_manager()
            relative_path = fm.join("pub", file_name)
            absolute_path = fm.get_absolute_path(relative_path)

            mime_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
            with open(absolute_path, "rb") as f:
                content = f.read()

            return Response(content, status=200, mimetype=mime_type)

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })


@api.route("/<template_id>", methods=["POST"])
@api.doc(description="Upload an image.")
class UploadImage(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(template_id):
        """
        Securely upload an image to a template folder.

        HOW IT WORKS:
        -----------------
        - Validates `template_id` to prevent directory traversal.
        - Checks uploaded file extensions against allowed image types.
        - Creates the `pub/{template_id}` folder if missing.
        - Saves the file and returns a public image URL.

        SECURITY:
        -----------------
        - Blocks uploads of non-image files.
        - Prevents path manipulation via `template_id` or `file.filename`.
        - Logs and blocks suspicious uploads.

        :param template_id: Folder to upload the image into.
        :return: JSON response with public image URL or access-denied error.
        """
        try:
            assert_admin_user()

            allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}

            fm = FileManagerFactory.create_file_manager()
            system_folder = settings.get_setting(constants.SETTING_SYSTEM_FOLDER)
            pub_url = settings.get_setting(constants.SETTING_PUB_URL)

            # Basic path validation
            if "/" in template_id or ".." in template_id:
                raise HttpException("Access denied")

            file_name = ''
            for name in request.files:
                file = request.files[name]
                ext = os.path.splitext(file.filename)[1].lower()

                if ext not in allowed_extensions:
                    raise HttpException("Access denied")

                if "/" in file.filename or ".." in file.filename:
                    raise HttpException("Access denied")

                template_folder = fm.join("pub", template_id)
                fm.mkdirs(template_folder)
                path = fm.join(system_folder, template_folder)
                file_name = file.filename
                file_path = fm.join(path, file_name)

                file.save(file_path)

            return Response(json.dumps({
                "imageUrl": pub_url + "/" + template_id + "/" + file_name
            }), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })


@api.route("/<template_id>/<file_name>", methods=["GET"])
@api.doc(description="Return a file in the template folder.")
class GetPubTemplateFile(Resource):
    @staticmethod
    def get(template_id, file_name):
        """
        Safely serve an image file from a specific template folder in the public directory.

        HOW IT WORKS:
        -----------------
        - Builds a relative path using FileManager's join.
        - Resolves the full path using FileManager's `get_absolute_path`, which ensures it's inside base_path.
        - Validates that the file extension is an allowed image type.
        - Returns file content or a generic access-denied error.

        SECURITY:
        -----------------
        - Path traversal is blocked by `get_absolute_path` (even encoded ../ etc.).
        - Symlinks pointing outside are denied.
        - Returns generic error messages only.

        :param template_id: Template folder (e.g. "welcome").
        :param file_name: Image file (e.g. "logo.png").
        :return: Flask Response or JSON error.
        """
        try:
            allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}
            ext = os.path.splitext(file_name)[1].lower()
            if ext not in allowed_extensions:
                raise HttpException("Access denied")

            fm = FileManagerFactory.create_file_manager()
            relative_path = fm.join("pub", template_id, file_name)

            # This ensures final absolute path is under base_path (traversal-safe)
            absolute_path = fm.get_absolute_path(relative_path)

            mime_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
            with open(absolute_path, "rb") as f:
                content = f.read()

            return Response(content, status=200, mimetype=mime_type)

        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })


@api.route("/claims/<claim_id>/<file_name>", methods=["GET"])
@api.doc(description="Return a claim file.")
class GetClaimFile(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(claim_id, file_name):
        """
        Securely serve a file associated with a claim.

        HOW IT WORKS:
        -----------------
        - Builds a relative path using FileManager.
        - Uses `get_absolute_path` to prevent path traversal.
        - Restricts to allowed file types (images + JSON).
        - Returns file content or generic access-denied.

        SECURITY:
        -----------------
        - Prevents traversal attacks (e.g., encoded `../`).
        - Validates final absolute path is under the claims root.
        - Returns generic error messages with no path info.

        :param claim_id: ID of the claim folder (e.g. "abc123").
        :param file_name: File to return (e.g. "accident.jpg").
        :return: Flask Response with file content or JSON error.
        """
        try:
            assert_admin_user()

            allowed_extensions = {'.json', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'}
            ext = os.path.splitext(file_name)[1].lower()
            if ext not in allowed_extensions:
                raise HttpException("Access denied")

            fm = FileManagerFactory.create_file_manager()

            # Build and resolve the relative path
            relative_path = fm.join("claims", claim_id, file_name)
            absolute_path = fm.get_absolute_path(relative_path)

            mime_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
            content = fm.read_file(relative_path)

            return Response(content, status=200, mimetype=mime_type)

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": "Access denied.",
                "code": "ACCESS_DENIED"
            })
