import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_email.notify_user import notify_user
from lib_common.routes_support import response_json, row_to_dict, rows_to_list
from lib_persistence import campaign, notifier, policy, user

api = Namespace("broker-api/web/v1/ui/notifier", description="Provides routes for managing notifications.")
log = logging.getLogger(LOGGER)


@api.route("/<mailbox>/total", methods=["GET"])
@api.doc(description="List total notifications in the mailbox")
class TotalNotifications(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(mailbox):
        """
        List total notifications in the mailbox.
        """
        try:
            assert_admin_user()
            drafts = notifier.list_messages(mailbox, None, None, None, None, None)
            return Response(json.dumps(len(drafts)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<mailbox>", methods=["GET"])
@api.doc(description="Returns a list of messages in the mailbox.")
class PendingMessages(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(mailbox):
        """
        Returns a list of messages in the mailbox.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", None)
            search = request.args.get("search", None)
            messages = rows_to_list(notifier.list_messages(mailbox, rows_per_page, page, sort, sort_direction, search))
            return Response(json.dumps(messages, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/notification/<notification_id>", methods=["GET"])
@api.doc(description="Load a notification.")
class LoadNotification(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notification_id):
        """
        Load a notification.
        """
        try:
            assert_admin_user()
            n = notifier.get_notification_by_id(notification_id)
            return Response(json.dumps(row_to_dict(n), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<notifier_id>", methods=["DELETE"])
@api.doc(description="Deletes a notification.")
class DeleteNotification(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(notifier_id):
        """
        Deletes a notification.
        """
        try:
            assert_admin_user()
            notifier.delete_notification(notifier_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/approve/<notifier_id>", methods=["GET"])
@api.doc(description="Approve the specified draft notification.")
class Approve(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notifier_id):
        """
        Approve the specified draft notification.
        """
        try:
            assert_admin_user()
            notifier.move_to_outbox(notifier_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/draft/<notifier_id>", methods=["GET"])
@api.doc(description="Move a notification to draft.")
class MoveToDraft(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notifier_id):
        """
        Move a notification to draft.
        """
        try:
            assert_admin_user()
            notifier.move_to_draft(notifier_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/recipients/total/<notifier_id>", methods=["GET"])
@api.doc(description="List total recipients for the notification.")
class TotalRecipients(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notifier_id):
        """
        List total recipients for the notification.
        """
        try:
            assert_admin_user()
            total = notifier.count_recipients(notifier_id)
            return Response(json.dumps(total), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/recipients/<notifier_id>", methods=["GET"])
@api.doc(description="List recipients for the notification.")
class ListRecipients(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notifier_id):
        """
        List recipients for the notification.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)

            recipients = notifier.list_recipients(notifier_id, rows_per_page, page, sort, sort_direction, search)
            recipients = rows_to_list(recipients)
            return Response(json.dumps(recipients, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/recipient/<recipient_id>", methods=["DELETE"])
@api.doc(description="Delete a recipient.")
class DeleteUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(recipient_id):
        """
        Delete a recipient.
        """
        try:
            assert_admin_user()
            notifier.delete_recipient(recipient_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/test/notifier/<notifier_id>/notifier_recipient/<notifier_recipient_id>", methods=["GET"])
@api.doc(description="Test a notification.")
class TestNotifier(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notifier_id, notifier_recipient_id):
        """
        Test a notification.
        """
        try:
            assert_admin_user()

            # Get the recipients we have not notified yet.
            recipient = notifier.get_recipient(notifier_recipient_id)

            email_subject = None
            email_body = None

            try:
                notifier_obj = notifier.get_notification_by_id(notifier_id)
                campaign_obj = campaign.load_campaign(notifier_obj.campaign_id)
                template_obj = notifier.get_template(campaign_obj.template_id, recipient.locale)

                if template_obj is not None:
                    _, email_subject, email_body = notify_user(
                        recipient,
                        campaign_obj,
                        template_obj,
                        token=None,
                        reset_code=None,
                        bypass=True,
                        group_id=None,
                        notifier_recipient_id=notifier_recipient_id,
                        trigger_event='TEST',
                        dry_run=True)
                else:
                    log.error("TASK_NOTIFY TEMPLATE MISSING " + recipient.locale)

            except Exception:
                log.error("TASK_NOTIFY TEMPLATE MISSING ", exc_info=True)

            return Response(json.dumps({
                'subject': email_subject,
                'body': email_body,
            }), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/report", methods=["GET"])
@api.doc(description="Returns a notification report for a user or policy.")
class NotificationReport(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Returns a notification report for a user or a policy.
        """
        try:
            assert_admin_user()

            policy_id = request.args.get("policy_id") or None
            user_id = request.args.get("user_id") or None

            if not policy_id and not user_id:
                raise InvalidArgument("Either policy_id or user_id must be provided")

            policy_entries = []
            all_users = {}

            if user_id:
                # Fetch all active policies linked to the user
                policies = policy.list_policies_by_user_id(user_id)

            else:
                # Single policy context
                p = policy.read_version_by_id(policy_id)
                policies = [p] if p else []

            for p in policies:
                if not p or not p.active:
                    continue

                # Get users linked to this policy
                policy_users = user.lookup_users_by_policy_id(p.id)

                user_objs = [row_to_dict(u) for u in policy_users]

                # Deduplicate users globally
                for u in user_objs:
                    all_users[u["id"]] = u

                policy_entry = {
                    "id": p.id,
                    "policy_number": p.policy_number,
                    "company": p.company,
                    "lob": p.lob,
                    "purpose": p.purpose,
                    "clients": [
                        {
                            "id": u["id"],
                            "email": u["email"],
                            "account_name": u["account_name"],
                            "status": u["status"]
                        }
                        for u in user_objs
                    ]
                }

                policy_entries.append(policy_entry)

            # Get available client campaigns (if applicable)
            campaigns = campaign.list_campaigns_paged(campaign_types=['client'])
            campaign_list = [
                {
                    "id": c.id,
                    "name": c.name
                } for c in campaigns
            ]

            report = {
                "policies": policy_entries,
                "clients": [
                    {
                        "id": u["id"],
                        "email": u["email"],
                        "account_name": u["account_name"],
                        "status": u["status"]
                    }
                    for u in all_users.values()
                ],
                "campaigns": campaign_list
            }

            return Response(json.dumps(report, default=str), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/notify/<notify>/user/<user_id>/policy/<policy_id>", methods=["PUT"])
@api.route("/<policy_id>/user/<user_id>/notify/<notify>", methods=["PUT"])
@api.doc(description="Add a user to the specified policy.")
class ToggleNotify(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(policy_id, user_id, notify=None):
        """
        Add a user to the specified policy.
        """
        try:
            assert_admin_user()

            # Convert to boolean if present
            if isinstance(notify, str):
                notify = notify.lower() in ("true", "1", "yes")

            policy.update_notify(policy_id, user_id, notify)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
