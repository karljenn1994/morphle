import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_journal.journal import Journal
from lib_common.routes_support import assert_not_none, response_json
from lib_persistence import task
from tasks.celery import (
    backup,
    campaign,
    collect,
    import_email,
    import_policies,
    import_users,
    indexer,
    notify,
    notify_schedule,
    scan,
    scan_schedule,
    update_task_schedule
)

api = Namespace("broker-api/web/v1/ui/tasks", description="Provides task management functions.")
log = logging.getLogger(LOGGER)


@api.route("/<task_name>", methods=["GET"])
@api.doc(description="Returns task details.")
class GetTask(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(task_name):
        """
        Returns task details.
        """
        try:
            assert_admin_user()
            details = task.get_task(task_name)
            status = task.get_task_status(task_name)
            if status is not None:
                details['run_status'] = status['status']
                details['run_status_timestamp'] = status['status_timestamp']
                details['run_last_successful'] = status['last_successful_run']
                details['journal'] = Journal.read_last_run(task_name)
            return Response(json.dumps(details, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/run", methods=["PUT"])
@api.doc(description="Run a task.")
class RunTask(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put():
        """
        Run a task.
        """
        try:
            assert_admin_user()

            json_data = request.json

            name = json_data["name"] if "name" in json_data else None
            assert_not_none(name, "Missing task name")

            if name == "indexer":
                indexer.delay()
            elif name == "collect":
                collect.delay()
            elif name == "campaign":
                campaign.delay()
            elif name == "backup":
                backup.delay()
            elif name == "import_policies":
                import_policies.delay()
            elif name == "import_users":
                import_users.delay()
            elif name == "import_email":
                import_email.delay()
            elif name == "notify":
                notify.delay()
            elif name == "notify_schedule":
                notify_schedule.delay()
            elif name == "scan":
                scan.delay()
            elif name == "scan_schedule":
                scan_schedule.delay()
            else:
                return Response(json.dumps(False), status=200, mimetype="application/json")

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["PUT"])
@api.doc(description="Update a task.")
class UpdateTask(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put():
        """
        Update a task.
        """
        try:
            assert_admin_user()

            json_data = request.json

            task_name = json_data["name"] if "name" in json_data else None
            status = json_data["status"] if "status" in json_data else None
            minute = json_data["minute"] if "minute" in json_data else None
            hour = json_data["hour"] if "hour" in json_data else None
            days_of_week = json_data["days_of_week"] if "days_of_week" in json_data else None
            months_of_year = json_data["months_of_year"] if "months_of_year" in json_data else None

            assert_not_none(hour, "Missing task minute")
            assert_not_none(hour, "Missing task hour")
            assert_not_none(task_name, "Missing task name")
            assert_not_none(status, "Missing task status")
            assert_not_none(days_of_week, "Missing days of week")
            assert_not_none(months_of_year, "Missing months of year")

            update_task_schedule(task_name, status, minute, hour, days_of_week, months_of_year)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<task_name>/status", methods=["GET"])
@api.doc(description="Returns task status, last updated time, and last successful run.")
class GetTaskStatus(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(task_name):
        """
        Returns task status details.
        """
        try:
            assert_admin_user()
            status_info = task.get_task_status(task_name)
            if not status_info:
                return response_json(404, {
                    "message": f"No status found for task: {task_name}"
                })

            return Response(json.dumps(status_info, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
