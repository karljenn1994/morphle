import json
import logging

from flask import Response, redirect, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource
from jwt.exceptions import ExpiredSignatureError

from lib_common import constants, exceptions
from lib_common.authentication import (
    assert_admin_user,
    get_user_id_from_cookies,
)
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    AuthenticationException,
    AuthenticationExpiredException,
    HttpException,
    InvalidArgument
)
from lib_common.repository import Repository
from lib_common.routes_support import (
    get_friendly_locale, response_json,
    rows_to_list
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import indexer, persistence, policy, settings, user, validator
from lib_policy_dom.JSON import JSON
from validations.issues_support import load_issues
from validations.validations_support import validate_policy

api = Namespace("broker-api/web/v1/ui/renewals", description="Provides access to renewals.")
log = logging.getLogger(LOGGER)


@api.route("/total", methods=["GET"])
@api.doc(description="Total number of renewals.")
class TotalRenewals(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of renewals.
        """
        try:
            assert_admin_user()

            change_percent = request.args.get('change_percent', type=float)
            count = indexer.count_renewals(change_percent)

            return Response(json.dumps(count), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["GET"])
@api.doc(description="Read all renewals.")
class Renewals(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all renewals.
        """
        try:
            assert_admin_user()
            change_percent = request.args.get('change_percent', type=float)
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            issues = request.args.getlist("issue")

            policy_list = indexer.page_renewals(
                rows_per_page,
                page,
                sort,
                sort_direction,
                search,
                issues,
                change_percent)
            return Response(json.dumps(policy_list, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/policy/<renewal_policy_id>", methods=["GET"])
@api.doc(description="Read a renewal.")
class ReadRenewal(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(renewal_policy_id):
        """
        Read a renewal.
        """
        try:
            assert_admin_user()
            fm = FileManagerFactory.create_file_manager()
            j = JSON()

            policy_list = []
            renewal_list = []

            # Read the renewal.
            r = policy.read_version_by_id(renewal_policy_id)
            if not r:
                raise InvalidArgument("Renewal not found", error_code=exceptions.CODE_ADMIN_POLICY_DOES_NOT_EXIST)

            card_json_file = fm.join(Repository.policies_location, r.file_name)
            card_json = JSON.load_card_json(card_json_file)
            renewal_policy_card = j.get_policy_card(card_json)

            renewal_policy_card["pdfs"] = policy.list_renewal_pdfs(
                r.policy_number,
                r.lob,
                r.company,
                r.file_name,
                r.transaction_effective_date)
            renewal_policy_card["id"] = r.id
            renewal_policy_card["downloaded"] = True

            # Run validations before loading the issues.
            validate_policy(r)
            renewal_policy_card["validations"] = load_issues(r)

            renewal_list.append(card_json)

            edi_file = card_json_file.replace(".JSON", ".AL3")
            renewal_edi = None

            if fm.exists(edi_file):
                renewal_edi = FileManagerFactory.create_file_manager().read_string(edi_file)

            renewal_policy_card["edi"] = renewal_edi
            renewal_policy_card["json"] = json.dumps(card_json)

            # Load the active policy - there *ALWAYS* should be one - it might be a placeholder.
            p = policy.read_active_by_policy_number_company_lob(r.policy_number, r.company, r.lob)
            if not p:
                raise InvalidArgument("Policy not found", error_code=exceptions.CODE_ADMIN_POLICY_DOES_NOT_EXIST)

            pdfs = []

            if p.policy_number and p.company and p.lob:
                pdfs = policy.list_pdfs(p.policy_number, p.lob, p.company, p.transaction_effective_date)

            if p.file_name:
                card_json_file = fm.join(Repository.policies_location, p.file_name)
                card_json = JSON.load_card_json(card_json_file)
                policy_card = JSON().get_policy_card(card_json)

                policy_card["pdfs"] = pdfs
                policy_card["id"] = p.id
                policy_card["downloaded"] = True

                # Run validations before loading the issues.
                validate_policy(p)
                policy_card["validations"] = load_issues(p)

                policy_list.append(card_json)
                edi_file = card_json_file.replace(".JSON", ".AL3")

                if fm.exists(edi_file):
                    try:
                        policy_edi = FileManagerFactory.create_file_manager().read_string(edi_file)
                        policy_card["edi"] = policy_edi
                    except:
                        pass

                policy_card["json"] = json.dumps(card_json)
            else:
                # We don't have this policy downloaded yet. Make a placeholder for
                # it so the user will see something. There might be PDFs available
                # depending on the timing of things being downloaded.
                _, company_name = policy.map_company_code(p.company)
                policy_card = {
                    "id": p.id,
                    "downloaded": False,
                    "type": "policy",
                    "category": "folio",
                    "pdfs": pdfs,
                    "fields": {
                        "policy_number": p.policy_number,
                        "lob": p.lob,
                        "company_code": p.company,
                        "company_name": company_name
                    }
                }
                policy_list.append(
                    [policy_card]
                )

            # Load users from policy.
            users = rows_to_list(user.lookup_users_by_policy_id(p.id, include_leads=True))

            history = policy.list_history(p.policy_number, p.company, p.lob, p.policy_effective_date, p.seq)

            if history:
                policy_card["history"] = []

                for h in history:
                    historical_card_json_file = fm.join(Repository.policies_location, h.file_name)
                    historical_card_json = JSON.load_card_json(historical_card_json_file)
                    historical_card = j.get_policy_card(historical_card_json)

                    historical_card["pdfs"] = None
                    historical_card["id"] = h.id
                    historical_card["downloaded"] = True
                    historical_card["validations"] = load_issues(h)

                    # We need the sequence on the UI for sorting; otherwise, some historical
                    # entries will be identical.
                    historical_card["sequence"] = h.seq

                    policy_card["history"].append(historical_card_json)

            if not policy_list and not renewal_list:
                raise InvalidArgument("Policy not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            slogan = settings.get_setting(constants.SETTING_BROKERAGE_SLOGAN + "_" + get_friendly_locale(
                request.headers))

            policy_report = {
                "logo": "http://logo.png",
                "name": settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME),
                "slogan": slogan,
                "address": settings.get_setting(constants.SETTING_BROKERAGE_ADDRESS),
                "hours": settings.get_setting(constants.SETTING_BROKERAGE_HOURS),
                "phone": settings.get_setting(constants.SETTING_BROKERAGE_PHONE),
                "users": users,
                "policies": policy_list,
                "renewals": renewal_list,
            }

            return Response(json.dumps(policy_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException, AuthenticationExpiredException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<policy_number>/<company>/<lob>/<file_name>", methods=["GET"])
@api.doc(description="Return a policy PDF.")
class PDF(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(policy_number, lob, company, file_name):
        """
        Return a policy PDF (compressed or uncompressed).
        """
        try:
            user_id = get_user_id_from_cookies()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            if user_obj.status not in [persistence.USER_STATUS_ACTIVE, persistence.USER_STATUS_GUEST]:
                raise AuthenticationException("User is not active",
                                              error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            # Read compressed or uncompressed PDF
            pdf_bytes, encoding = policy.read_pdf(user_obj, policy_number, company, lob, file_name)

            if pdf_bytes is None:
                raise FileNotFoundError("Policy PDF not found")

            response = Response(pdf_bytes, mimetype="application/pdf")

            if encoding == "gzip":
                response.headers["Content-Encoding"] = "gzip"

            return response

        except ExpiredSignatureError:
            login_url = settings.get_setting(constants.SETTING_ADMIN_UI_HOST) + "/auth/login"
            return redirect(login_url)

        except AuthenticationExpiredException as ex:
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })

        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<policy_id>/user/<user_id>", methods=["PUT"])
@api.route("/<policy_id>/user/<user_id>/notify/<notify>", methods=["PUT"])
@api.doc(description="Add a user to the specified policy.")
class AddUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(policy_id, user_id, notify=None):
        """
        Add a user to the specified policy.
        """
        try:
            assert_admin_user()

            # Convert "notify" to boolean if present
            if isinstance(notify, str):
                notify = notify.lower() in ("true", "1", "yes")

            policy.map_user(policy_id, user_id, notify)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/<policy_id>/user/<user_id>", methods=["DELETE"])
@api.doc(description="Delete a user from the specified policy.")
class DeleteUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(policy_id, user_id):
        """
        Delete a user from the specified policy.
        """
        try:
            assert_admin_user()
            policy.delete_user(policy_id, user_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/rules/total", methods=["GET"])
@api.doc(description="Total number of renewal validation rules.")
class TotalRenewals(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of renewal validation rules.
        """
        try:
            assert_admin_user()
            count = validator.count_validation_rules(
                [validator.VALIDATION_TYPE_RENEWAL_AUTO,
                 validator.VALIDATION_TYPE_RENEWAL_HABL])
            return Response(json.dumps(count), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/rules", methods=["GET"])
@api.doc(description="Read all renewal validation rules.")
class Rules(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all renewals.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', default=None)
            page = request.args.get('page', default=None)
            sort = request.args.get("sort", "description")
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)

            rows = validator.list_validation_rules(
                [validator.VALIDATION_TYPE_RENEWAL_AUTO, validator.VALIDATION_TYPE_RENEWAL_HABL],
                rows_per_page,
                page,
                sort,
                sort_direction,
                search)

            return Response(json.dumps(rows_to_list(rows), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
