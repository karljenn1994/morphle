import json
import logging

from flask import Response, jsonify, make_response, request
from flask_jwt_extended import jwt_required, set_access_cookies, set_refresh_cookies
from flask_restx import Namespace, Resource

from lib_common import exceptions
from lib_common.authentication import assert_admin_user, authenticate_form_user_token, generate_ui_guest_token_pair
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, CampaignException, HttpException, InvalidArgument
from lib_common.repository import Repository
from lib_common.routes_support import (
    assert_not_none, response_json, row_to_dict, rows_to_list
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import get_connection, form, settings, user

api = Namespace("broker-api/web/v1/ui/forms", description="Provides access to forms.")
log = logging.getLogger(LOGGER)


@api.route("/<form_type>/total", methods=["GET"])
@api.doc(description="Total number of forms.")
class TotalForms(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_type):
        """
        Total number of forms.
        """
        try:
            assert_admin_user()
            form_list = form.list_forms(form_type, None, None, None, None, None)
            return Response(json.dumps(len(form_list)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<form_type>", methods=["GET"])
@api.doc(description="List forms.")
class ListForms(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_type):
        """
        List forms.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            form_list = form.list_forms(form_type, rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(form_list, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/form_id/<form_id>", methods=["GET"])
@api.doc(description="Read a form.")
class GetForm(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_id):
        """
        Read a form.
        """
        try:
            assert_admin_user()

            f = form.lookup_form_by_id(form_id)

            if f is None:
                raise InvalidArgument("Form not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            return Response(json.dumps(row_to_dict(f)), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/form_id/<form_id>", methods=["POST"])
@api.doc(description="Save a form.")
class SaveForm(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(form_id):
        """
        Save a form.
        """
        try:
            assert_admin_user()
            json_data = request.json

            form_type = json_data["type"] if "type" in json_data else None
            name = json_data["name"] if "name" in json_data else None
            description = json_data["description"] if "description" in json_data else None
            form_data = json_data["form"] if "form" in json_data else None

            assert_not_none(name, "Name missing")
            assert_not_none(description, "Description missing")
            assert_not_none(form_data, "Form missing")

            # Insert/Update the form data.
            form.upsert_form(form_id,
                             form_type,
                             name,
                             description,
                             json.dumps(form_data))

            return Response(json.dumps(True), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/form_id/<form_id>", methods=["DELETE"])
@api.doc(description="Delete a form.")
class DeleteForm(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(form_id):
        """
        Delete a form.
        """
        try:
            assert_admin_user()
            form.delete_form(form_id)
            return response_json(200, True)
        except CampaignException as ex:
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/form_id/<form_id>/total", methods=["GET"])
@api.doc(description="Total number of form results.")
class TotalData(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_id):
        """
        Total number of form results.
        """
        try:
            assert_admin_user()
            form_list = form.list_form_data(form_id, None, None, None, None, None)
            return Response(json.dumps(len(form_list)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/results/form_id/<form_id>", methods=["GET"])
@api.doc(description="List form results.")
class ListData(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_id):
        """
        List form results.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            form_list = form.list_form_data(form_id, rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(rows_to_list(form_list), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/form_id/<form_id>/user_id/<user_id>", methods=["GET"])
@api.doc(description="Read a form instance by id.")
class GetFormInstanceById(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_id, user_id):
        """
        Read a form instance by id.
        """
        try:
            assert_admin_user()

            f = form.lookup_form_instance(form_id, user_id)

            if f is None:
                raise InvalidArgument("Form not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            return Response(json.dumps(row_to_dict(f), default=str), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/token/<token>", methods=["POST"])
@api.doc(description="Save a form.")
class SaveFormData(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(token):
        """
        Save a form.
        """
        try:
            user_id, form_id, policy_id, _ = authenticate_form_user_token(token)
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "Form not available",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            form_data = request.json

            # Insert/Update the form data.
            form.upsert_form_data(form_id, user_id, policy_id, json.dumps(form_data))

            return Response(json.dumps(True), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/form_id/<form_id>/user_id/<user_id>", methods=["DELETE"])
@api.doc(description="Delete a claim.")
class DeleteFormData(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(form_id, user_id):
        """
        Delete form data.
        """
        try:
            assert_admin_user()
            form.delete_form_data(form_id, user_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/token/<token>", methods=["GET"])
@api.doc(description="Read a form instance by token.")
class GetFormInstanceByToken(Resource):
    @staticmethod
    def get(token):
        """
        Read a form instance by token.
        """
        try:
            user_id, form_id, policy_id, _ = authenticate_form_user_token(token)
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "Form not available",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            f = form.lookup_form_instance(form_id, user_id)

            if f is None:
                raise InvalidArgument("Form not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            access_token, refresh_token, claims = generate_ui_guest_token_pair(user_obj)
            response = make_response(jsonify(row_to_dict(f)))
            set_access_cookies(response, access_token)
            set_refresh_cookies(response, refresh_token)
            return make_response(response, 200)

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/form_id/<form_id>/user_id/<user_id>", methods=["GET"])
@api.doc(description="Read a form instance by id.")
class GetFormInstanceById(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(form_id, user_id):
        """
        Read a form instance by id.
        """
        try:
            assert_admin_user()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "Form not available",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            f = form.lookup_form_instance(form_id, user_id)

            if f is None:
                raise InvalidArgument("Form not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            return Response(json.dumps(row_to_dict(f)), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})