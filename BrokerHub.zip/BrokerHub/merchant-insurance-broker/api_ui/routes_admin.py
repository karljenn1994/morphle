import logging
from datetime import datetime

from flask import request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants, exceptions
from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    AlreadyExistsException,
    AuthenticationException,
    HttpException,
    InvalidArgument
)
from lib_common.routes_support import (
    assert_not_none,
    response_json,
    row_to_dict,
    rows_to_list
)
from lib_email.notify_user import notify_one_recipient, notify_recipients, notify_user
from lib_persistence import admin, campaign, get_connection, indexer, notifier, settings, user
from lib_persistence.campaign import build_regarding

api = Namespace("broker-api/web/v1/ui/admin", description="Provides user authentication, administration, etc.")
log = logging.getLogger(LOGGER)


# @api.route("/push/<user_id>", methods=["POST"])
# @api.doc(description="Push a message to a user.")
# class MessageUser(Resource):
#     @staticmethod
#     def post(user_id):
#         """
#         Push a message to a user.
#         """
#         try:
#             assert_admin_user()
#
#             user_obj = user.lookup_user_by_id(user_id)
#
#             if user_obj is None:
#                 raise AuthenticationException("User not found",
#                                               error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)
#
#             json_data = request.json
#             title = json_data["title"] if "title" in json_data else None
#             body = json_data["body"] if "body" in json_data else None
#             assert_not_none(title, "Message title is missing")
#             assert_not_none(body, "Message body is missing")
#
#             push_url = settings.get_setting(constants.SETTING_LIFES_WALLET_MESSAGING_API_URL)
#
#             if push_url is None or len(push_url) <= 0:
#                 return
#
#             push_endpoint = settings.get_setting(constants.SETTING_LIFES_WALLET_MESSAGING_API_URL) \
#                             + "/push/" \
#                             + settings.get_setting(constants.SETTING_BROKERAGE_ID) \
#                             + "/" \
#                             + user_id
#
#             if push_endpoint is not None and len(push_endpoint) > 0:
#                 # Build a brokerage token to authenticate the request.
#                 push_token = generate_push_token()
#
#                 if push_token is None:
#                     return
#
#                 response_from_push = requests.post(
#                     push_endpoint,
#                     json={
#                         "title": title,
#                         "body": body,
#                     },
#                     headers={
#                         "Authorization": "Bearer " + push_token
#                     }, )
#
#                 if response_from_push.status_code != 200:
#                     return
#
#             return response_json(200, {})
#         except (HttpException, InvalidArgument, AuthenticationException) as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": ex.message,
#                 "code": ex.code
#             })
#         except Exception as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": str(ex)
#             })


@api.route("/users/total", methods=["GET"])
@api.doc(description="List users.")
class ListUsers(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        List users.
        """
        try:
            assert_admin_user()
            role = request.args.get('role')
            users = user.list_users(None, None, None, None, None, role, None)
            return response_json(200, len(users))
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/users", methods=["GET"])
@api.doc(description="List users.")
class ListUsers(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        List users.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            role = request.args.get("role", None)
            status = request.args.get("status", None)

            users = user.list_users(rows_per_page, page, sort, sort_direction, search, role, status)

            return response_json(200, rows_to_list(users))
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/user_id/<user_id>", methods=["GET"])
@api.doc(description="Read a user.")
class UserProfile(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(user_id):
        """
        Read a user.
        """
        try:
            assert_admin_user()
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "User not found",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            return response_json(200, {
                "id": user_obj.id,
                "email": user_obj.email,
                "first": user_obj.first_name,
                "last": user_obj.last_name,
                "account_name": user_obj.account_name,
                "status": user_obj.status,
                "connected": user_obj.connected,
                "role": user_obj.role,
                "province_code": user_obj.province,
                "postal_code": user_obj.postal_code,
                "date_of_birth": user_obj.date_of_birth,
                "locale": user_obj.locale,
            })
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/invite/<user_id>", methods=["GET"])
@api.doc(description="Invite a user.")
class InviteUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(user_id):
        """
        Invite a user.
        """
        try:
            assert_admin_user()
            recipient = user.lookup_user_by_id(user_id)

            if recipient is None:
                raise InvalidArgument("User not found", error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            with get_connection() as connection:
                campaign_obj = campaign.lookup_client_campaign_active(
                    "Invitation",
                    permanent=True,
                    optional_connection=connection)

                if campaign_obj is not None:
                    notifier_id = notifier.create_notification(
                        campaign_obj.id,
                        datetime.now(),
                        optional_connection=connection)

                    notification_obj = notifier.get_notification_by_id(
                        notifier_id,
                        optional_connection=connection)

                    if notification_obj is not None:
                        re = build_regarding(campaign_obj, recipient)
                        notifier.add_recipient(
                            recipient.id,
                            notifier_id,
                            campaign_obj.id,
                            re,
                            optional_connection=connection)
                        total_notified = notify_recipients(
                            notification_obj,
                            optional_connection=connection)
                        connection.commit()

                        if total_notified > 0:
                            return response_json(200, True)

            return response_json(400, {"message": "Invitation failed"})
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/resend_notification/<notifier_recipient_id>", methods=["GET"])
@api.doc(description="Resend a notification.")
class ResendNotification(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(notifier_recipient_id):
        """
        Resend a notification to a single recipient identified by notifier_recipient_id.
        Ensures the latest message_id is stored on the recipient so provider callbacks
        (e.g., SendGrid events) update this attempt.
        """
        try:
            assert_admin_user()
            recipient = notifier.get_recipient(notifier_recipient_id)

            if recipient is None:
                raise InvalidArgument(
                    "Notification not found",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST
                )

            with get_connection() as connection:
                notification_obj = notifier.get_notification_by_id(
                    recipient.notifier_id,
                    optional_connection=connection
                )
                if notification_obj is None:
                    raise InvalidArgument(
                        "Notification not found",
                        error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST
                    )

                campaign_obj = campaign.load_campaign(
                    notification_obj.campaign_id,
                    optional_connection=connection
                )

                success, message_id = notify_one_recipient(
                    notification_obj,
                    recipient,
                    optional_connection=connection,
                    campaign_obj=campaign_obj
                )

                # Explicitly (re)store the latest message_id so webhooks correlate to THIS resend.
                if success and message_id:
                    notifier.update_notifier_recipient_result(
                        recipient.notifier_recipient_id,
                        "unknown",  # final delivery state comes from provider webhooks
                        message_id=message_id,
                        optional_connection=connection
                    )

                connection.commit()

                if success:
                    return response_json(200, {"ok": True, "message_id": message_id})

            return response_json(400, {"message": "Invitation failed"})

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            status = 404 if isinstance(ex, InvalidArgument) else 400
            return response_json(status, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/user/<user_id>", methods=["DELETE"])
@api.doc(description="Delete a user.")
class DeleteUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(user_id):
        """
        Delete a user.
        """
        try:
            user_obj = assert_admin_user()

            if user_obj.id == user_id:
                raise InvalidArgument("Cannot delete yourself", error_code=exceptions.CODE_ADMIN_CANNOT_DELETE_YOURSELF)

            user.delete_user(user_id)
            return response_json(200, True)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/user", methods=["POST"])
@api.route("/user/notify/<notify>", methods=["POST"])
@api.doc(description="Add a user.")
class AddUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(notify: None):
        """
        Add a user.
        """
        try:
            assert_admin_user()

            # Convert to boolean if present
            if isinstance(notify, str):
                notify = notify.lower() in ("true", "1", "yes")

            json_data = request.json

            # Basic user details.
            email = json_data["email"] if "email" in json_data else None
            account_name = json_data["account_name"] if "account_name" in json_data else None
            first_name = json_data["first"] if "first" in json_data else None
            last_name = json_data["last"] if "last" in json_data else None

            # Optional policy to add to the user. This is helpful for use with the
            # Chrome extension. We may be adding what we think is a new Epic user only
            # to find out they exist but are not mapped to the policy.
            policy_id = json_data["policy_id"] if "policy_id" in json_data else None

            # Role details.
            is_admin = json_data["is_admin"] if "is_admin" in json_data else False

            # Settings.
            invite = json_data["invite"] if "invite" in json_data else False

            assert_not_none(email, "Missing email")

            if account_name is None:
                assert_not_none(first_name, "Missing first name")
                assert_not_none(last_name, "Missing last name")
                account_name = " ".join([first_name, last_name])

            user_obj = user.lookup_user_by_email(email)

            # We might be adding a policy to an existing user here. This functionality is
            # for use with the Chrome extension.
            if user_obj and policy_id is None:
                raise AlreadyExistsException("User already exists",
                                             error_code=exceptions.CODE_ADMIN_USER_ALREADY_EXISTS)

            if user_obj:
                user_id = user_obj.id
            else:
                user_id, invite_code = user.add_user(email, account_name, first_name, last_name, is_admin)

                if is_admin or invite:
                    # Create a guest token and send a new guest link.
                    user_obj = user.lookup_user_by_id(user_id)

                    # Invite the user. This will change the status to "invited" and set a reset code they can use to
                    # set a password on their account.
                    user.invite_user(user_obj, reset_code=invite_code)

                    notify_user(user_obj,
                                None,
                                campaign.lookup_template("Invitation", locale=user_obj.locale, permanent=True),
                                reset_code=invite_code,
                                bypass=True)

            if user_id and policy_id:
                user.add_policy(user_id, policy_id, notify=notify)

            return response_json(200, True)
        except (HttpException, InvalidArgument, AuthenticationException, AlreadyExistsException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/user", methods=["PUT"])
@api.doc(description="Update a user.")
class UpdateUser(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put():
        """
        Update a user.
        """
        try:
            auth_user = assert_admin_user()
            json_data = request.json

            user_id = json_data["user_id"] if "user_id" in json_data else None
            email = json_data["email"] if "email" in json_data else None
            account_name = json_data["account_name"] if "account_name" in json_data else None
            first_name = json_data["first"] if "first" in json_data else None
            last_name = json_data["last"] if "last" in json_data else None
            locale = json_data["locale"] if "locale" in json_data else None
            notification_preference = json_data[
                "notification_preference"] if "notification_preference" in json_data else None
            is_admin = json_data["is_admin"] if "is_admin" in json_data else None

            assert_not_none(user_id, "Missing user id")
            assert_not_none(email, "Missing email address")
            assert_not_none(is_admin, "Missing admin role")

            if account_name is None:
                assert_not_none(first_name, "Missing first name")
                assert_not_none(last_name, "Missing last name")

            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException("User not found", error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            user.update_user(auth_user,
                             user_obj,
                             email,
                             account_name,
                             first_name,
                             last_name,
                             None,
                             None,
                             None,
                             locale,
                             notification_preference,
                             False)

            return response_json(200, True)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/counters", methods=["GET"])
@api.doc(description="Get counters.")
class Counters(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Get counters.
        """
        try:
            user_obj = assert_admin_user()
            counters = row_to_dict(admin.get_counters(user_obj.id))
            return response_json(200, counters)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/companies", methods=["GET"])
@api.doc(description="List companies.")
class Companies(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        List companies.
        """
        try:
            assert_admin_user()
            companies = rows_to_list(indexer.list_companies())
            return response_json(200, companies)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
