import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants, exceptions
from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.repository import Repository
from lib_common.routes_support import response_json
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import quote, settings

api = Namespace("broker-api/web/v1/ui/quotes", description="Provides access to quotes.")
log = logging.getLogger(LOGGER)


@api.route("/total", methods=["GET"])
@api.doc(description="Total number of quotes.")
class TotalQuotes(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of quotes.
        """
        try:
            assert_admin_user()
            quote_list = quote.list_quotes(None, None, None, None, None)
            return Response(json.dumps(len(quote_list)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("", methods=["GET"])
@api.doc(description="Read all quotes.")
class Quotes(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all quotes.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            quote_list = quote.list_quotes(rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(quote_list, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/quote/<quote_id>", methods=["GET"])
@api.doc(description="Read a quote.")
class UserQuote(Resource):
    @staticmethod
    def load_quote_data(file_name):
        if file_name is None:
            return None

        fm = FileManagerFactory.create_file_manager()
        quote_path = fm.join(Repository.quotes_location, file_name)
        quote_data = FileManagerFactory.create_file_manager().read_string(quote_path)
        return json.loads(quote_data)

    @staticmethod
    def list_quote_images(quote_id):
        if quote_id is None:
            return None

        file_names = []
        fm = FileManagerFactory.create_file_manager()
        quote_abs_path = fm.join(Repository.quotes_location, quote_id)

        for img in fm.listdir(quote_abs_path):
            # check if the image ends with png
            if img.endswith(".jpg"):
                file_names.append(img)

        return file_names

    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(quote_id):
        """
        Read a quote.
        """
        try:
            assert_admin_user()
            q = quote.lookup_quote_by_id(quote_id)

            if q is None:
                raise InvalidArgument("Quote not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            quote_report = {
                "status": q.status,
                "company": q.company,
                "lob": q.lob,
                "file_name": q.file_name,
                "received_date": q.received_date,
                "modified_date": q.modified_date,
                "email": q.email,
                "phone": q.phone,
                "quote": UserQuote.load_quote_data(q.file_name),
                "images": UserQuote.list_quote_images(quote_id),
            }

            return Response(json.dumps(quote_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/quote/pdf/<quote_id>/<file_name>", methods=["GET"])
@api.doc(description="Return a quote PDF.")
class QuotePDF(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(quote_id, file_name):
        """
        Return a quote PDF.
        """
        try:
            assert_admin_user()
            pdf = quote.get_quote_pdf(quote_id, file_name)
            return Response(pdf, mimetype="application/pdf")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<status>/<notifier_id>", methods=["GET"])
@api.doc(description="Update a quote's status.")
class UpdateStatus(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(status, notifier_id):
        """
        Update a quote's status.
        """
        try:
            assert_admin_user()
            quote.update_status(notifier_id, status)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<quote_id>", methods=["DELETE"])
@api.doc(description="Delete a quote.")
class DeleteQuote(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(quote_id):
        """
        Delete a quote.
        """
        try:
            assert_admin_user()

            fm = FileManagerFactory.create_file_manager()
            quote_abs_path = fm.join(Repository.quotes_location, quote_id)

            if fm.exists(quote_abs_path):
                fm.rmtree(quote_abs_path)

            quote.delete_quote(quote_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})
