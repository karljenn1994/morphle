import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument, ValidationException
from lib_common.routes_support import assert_not_none, response_json, row_to_dict, rows_to_list
from lib_persistence import indexer, validator

api = Namespace("broker-api/web/v1/ui/validators", description="Provides validator management functions.")
log = logging.getLogger(LOGGER)


@api.route("/lists", methods=["GET"])
@api.doc(description="Load lists used by the validator UI.")
class LoadValidation(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Load lists used by the validator UI.
        """
        try:
            assert_admin_user()

            resp = {
                "companies": rows_to_list(indexer.list_companies()),
            }

            validator_type = request.args.get('type', default=None)
            if validator_type is not None:
                resp["validations"] = rows_to_list(
                    validator.list_validations(validator_type, None, None, None, None, None))

            return Response(json.dumps(resp), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validation/<validation_id>/rules", methods=["GET"])
@api.doc(description="List validation rules")
class ListValidationRules(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(validation_id):
        """
        List validation rules.
        """
        try:
            assert_admin_user()

            rules = validator.list_validation_rules_by_validation_id(validation_id)

            return Response(json.dumps(rows_to_list(rules)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validation/<validation_type>/rule_templates", methods=["GET"])
@api.doc(description="List validation rule templates.")
class ListValidationRules(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(validation_type):
        """
        List validation rule templates.
        """
        try:
            assert_admin_user()

            templates = validator.list_validation_rule_templates(validation_type)

            return Response(json.dumps(rows_to_list(templates)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validations", methods=["GET"])
@api.doc(description="List validations.")
class ListValidations(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        List validations.
        """
        try:
            assert_admin_user()

            validator_type = request.args.get('type', default=None)

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)

            tasks = validator.list_validations(validator_type, rows_per_page, page, sort, sort_direction, search)

            return Response(json.dumps(rows_to_list(tasks)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validation/<validation_id>", methods=["GET"])
@api.doc(description="Load validation.")
class LoadValidation(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(validation_id):
        """
        Load validation.
        """
        try:
            assert_admin_user()

            validation = validator.read_validations_by_id(validation_id)
            rules = validator.list_validation_rules_by_validation_id(validation.id)

            return Response(json.dumps({
                "id": validation.id,
                "type": validation.type,
                "name": validation.name,
                "description": validation.description,
                "rules": rows_to_list(rules)
            }), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validation/<validation_id>", methods=["POST"])
@api.doc(description="Insert/Update validation.")
class UpsertValidations(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(validation_id):
        """
        Insert/Update validation.
        """
        try:
            assert_admin_user()
            json_data = request.json

            name = json_data["name"] if "name" in json_data else None
            description = json_data["description"] if "description" in json_data else None
            validation_type = json_data["validation_type"] if "validation_type" in json_data else None
            rules = json_data["rules"] if "rules" in json_data else None

            assert_not_none(name, "validation name missing")
            assert_not_none(validation_type, "validation type missing")
            assert_not_none(rules, "Rules missing")

            validator.upsert_validations(validation_id, validation_type, name, description, rules)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validation/<validation_id>", methods=["DELETE"])
@api.doc(description="Delete validation.")
class DeleteValidation(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(validation_id):
        """
        Delete validation.
        """
        try:
            assert_admin_user()

            validator.delete_validations(validation_id)

            return response_json(200, True)
        except ValidationException as ex:
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validator/<validator_id>", methods=["GET"])
@api.doc(description="Load a validator.")
class LoadValidator(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(validator_id):
        """
        Load a validator.
        """
        try:
            assert_admin_user()
            v = validator.read_validator_by_id(validator_id)
            return Response(json.dumps(row_to_dict(v)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["GET"])
@api.doc(description="List validations.")
class ListValidators(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        List validations.
        """
        try:
            assert_admin_user()

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)

            validators = validator.list_validators(rows_per_page, page, sort, sort_direction, search)

            return Response(json.dumps(rows_to_list(validators)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validator/<validator_id>", methods=["POST"])
@api.doc(description="Insert a validator.")
class PostValidator(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(validator_id):
        """
        Insert a validator.
        """
        try:
            assert_admin_user()
            json_data = request.json

            active = json_data["active"] if "active" in json_data else False
            validator_type = json_data["validator_type"] if "validator_type" in json_data else None
            name = json_data["name"] if "name" in json_data else None
            description = json_data["description"] if "description" in json_data else None
            validation_id = json_data["validation_id"] if "validation_id" in json_data else None
            trigger = json_data["trigger"] if "trigger" in json_data else None
            rules = json_data["rules"] if "rules" in json_data else None

            assert_not_none(active, "Missing field active")
            assert_not_none(validator_type, "Missing field validator_type")
            assert_not_none(name, "Missing field name")
            assert_not_none(validation_id, "Missing field validation_id")

            validator_id = validator.upsert_validator(
                validator_id,
                active,
                validator_type,
                name,
                description,
                validation_id,
                trigger,
                json.dumps(rules))

            return Response(json.dumps(validator_id), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validator/<validator_id>", methods=["PUT"])
@api.doc(description="Update a validator.")
class PutValidator(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(validator_id):
        """
        Update a validator.
        """
        try:
            assert_admin_user()
            json_data = request.json

            active = json_data["active"] if "active" in json_data else False
            validator_type = json_data["validator_type"] if "validator_type" in json_data else None
            validation_id = json_data["validation_id"] if "validation_id" in json_data else None
            name = json_data["name"] if "name" in json_data else None
            description = json_data["description"] if "description" in json_data else None
            trigger = json_data["trigger"] if "trigger" in json_data else None
            rules = json_data["rules"] if "rules" in json_data else None

            assert_not_none(active, "Missing field active")
            assert_not_none(validator_type, "Missing field validator_type")
            assert_not_none(name, "Missing field name")
            assert_not_none(validation_id, "Missing field validation_id")

            validator.update_validator(validator_id, active, validator_type, name, description, validation_id,
                                       trigger,
                                       json.dumps(rules) if rules is not None else None)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/validator/<validator_id>", methods=["DELETE"])
@api.doc(description="Delete a validator.")
class DeleteValidator(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(validator_id):
        """
        Delete a validator.
        """
        try:
            assert_admin_user()

            validator.delete_validator(validator_id)

            return response_json(200, True)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })

# @api.route("/validator/<validator_id>/results", methods=["GET"])
# @api.doc(description="Load validator results.")
# class LoadValidator(Resource):
#     @staticmethod
#     def get(validator_id):
#         """
#         Load validator results.
#         """
#         try:
#             assert_admin_user()
#
#             return Response(json.dumps({}), status=200, mimetype="application/json")
#         except (HttpException, InvalidArgument, AuthenticationException) as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": ex.message,
#                 "code": ex.code
#             })
#         except Exception as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": str(ex)
#             })
#
#
# @api.route("/validator/<validator_id>/run", methods=["GET"])
# @api.doc(description="Execute a validator.")
# class RunValidator(Resource):
#     @staticmethod
#     def get(validator_id):
#         """
#         Run or dry run a validator.
#         """
#         try:
#             assert_admin_user()
#
#             dryrun = request.args.get("dryrun", default=True, type=lambda v: v.lower() == v.lower() == 'true')
#             validator.execute(validator_id, dry_run=dryrun)
#
#             return Response(json.dumps({}), status=200, mimetype="application/json")
#         except (HttpException, InvalidArgument, AuthenticationException) as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": ex.message,
#                 "code": ex.code
#             })
#         except Exception as ex:
#             log.exception(ex, stack_info=True)
#             return response_json(400, {
#                 "message": str(ex)
#             })
