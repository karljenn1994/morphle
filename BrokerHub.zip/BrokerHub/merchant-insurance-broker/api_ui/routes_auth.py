import logging

from flask import jsonify, make_response, request
from flask_jwt_extended import (
    get_jwt,
    get_jwt_identity,
    jwt_required,
    set_access_cookies,
    set_refresh_cookies, unset_jwt_cookies
)
from flask_restx import Namespace, Resource

from lib_common import constants, exceptions
from lib_common.authentication import (
    authenticate_identity_token,
    generate_identity_token,
    generate_ui_access_token,
    generate_ui_guest_token_pair,
    generate_ui_token_pair,
    get_user_id_from_token
)
from lib_common.constants import LOGGER
from lib_email.emailer import Emailer
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_email.notify_user import notify_user
from lib_common.routes_support import (
    assert_not_none, respond
)
from lib_persistence import campaign, persistence, settings, user

api = Namespace("broker-api/web/v1/ui/auth", description="Provides user authentication, administration, etc.")
log = logging.getLogger(LOGGER)


@api.route("/sign-in", methods=["POST"])
@api.doc(description="Sign in and receive cookies.")
class SignIn(Resource):
    @staticmethod
    def post():
        """
        Sign in and receive a JWT token.
        """
        try:
            json_data = request.json
            email = json_data["email"] if "email" in json_data else None
            password = json_data["password"] if "password" in json_data else None

            assert_not_none(email, "Missing email")
            assert_not_none(password, "Missing password")

            user_obj = user.lookup_user_by_email(email)

            if user_obj is None:
                raise AuthenticationException(
                    "Sign in failed",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            if user_obj.status == persistence.USER_STATUS_ACTIVE or user_obj.status == persistence.USER_STATUS_PENDING:
                match = user.test_password_match(password, user_obj.password_hash, user_obj.salt)

                if not match:
                    raise AuthenticationException(
                        "Sign in failed",
                        error_code=exceptions.CODE_ADMIN_USER_AUTHENTICATION_FAILED)

                access_token, refresh_token, claims = generate_ui_token_pair(user_obj)
                response = jsonify(claims)
                set_access_cookies(response, access_token)
                set_refresh_cookies(response, refresh_token)
                return make_response(response)

            elif user_obj.status == persistence.USER_STATUS_UNCONFIRMED:
                # Send a new confirmation email in case they lost the signup email.
                admin_ui_host = settings.get_setting(constants.SETTING_ADMIN_UI_HOST)
                confirm_url = admin_ui_host + "/auth/confirm/" + user_obj.confirm_code
                from_email = settings.get_setting(constants.SETTING_SENDGRID_FROM_EMAIL)
                reply_email = settings.get_setting(constants.SETTING_SENDGRID_REPLY_EMAIL)
                Emailer({}, None, None).send_email(
                    from_email,
                    email,
                    reply_email=reply_email,
                    subject="Please confirm",
                    body=confirm_url,
                    bypass=True
                )
                raise AuthenticationException(
                    "User has not been confirmed",
                    error_code=exceptions.CODE_ADMIN_USER_STATUS_UNCONFIRMED)

            elif user_obj.status == persistence.USER_STATUS_GUEST:
                raise AuthenticationException(
                    "Sign in failed",
                    error_code=exceptions.CODE_ADMIN_USER_STATUS_IS_GUEST)

            elif user_obj.status == persistence.USER_STATUS_DISABLED:
                raise AuthenticationException(
                    "Sign in failed",
                    error_code=exceptions.CODE_ADMIN_USER_ACCOUNT_DISABLED)

            elif user_obj.status == persistence.USER_STATUS_FORGOT:
                notify_user(user_obj, None, campaign.lookup_template("Forgot", locale=user_obj.locale, permanent=True),
                            reset_code=user_obj.reset_code, bypass=True)
                raise AuthenticationException(
                    "Check your email to set your password",
                    error_code=exceptions.CODE_ADMIN_USER_IN_RESET_MODE)

            elif user_obj.status == persistence.USER_STATUS_INVITED:
                notify_user(user_obj,
                            None,
                            campaign.lookup_template("Invitation", locale=user_obj.locale, permanent=True),
                            reset_code=user_obj.reset_code,
                            bypass=True)
                raise AuthenticationException(
                    "Check your email to set your password",
                    error_code=exceptions.CODE_ADMIN_USER_IN_RESET_MODE)

            elif user_obj.status == persistence.USER_STATUS_UPLOADED:
                raise AuthenticationException(
                    "Sign in failed",
                    error_code=exceptions.CODE_ADMIN_USER_STATUS_IS_UPLOADED)
            else:
                raise AuthenticationException(
                    "Sign in failed",
                    error_code=exceptions.CODE_ADMIN_USER_AUTHENTICATION_FAILED)

        except AuthenticationException as ex:
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/sign-out", methods=["GET"])
@api.doc(description="Sign out.")
class SignOut(Resource):
    @staticmethod
    def get():
        """
        Sign out.
        """
        response = make_response(jsonify(True))
        unset_jwt_cookies(response)
        return response


@api.route("/claims", methods=["GET"])
@api.doc(description="Returns the JWT claims.")
class Update(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Returns the JWT claims.
        """
        try:
            claims = get_jwt()
            response = make_response(jsonify(claims))
            return response
        except AuthenticationException as ex:
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            r = make_response(jsonify({"message": str(ex)}), 400)
            return r


@api.route("/refresh", methods=["POST"])
@api.doc(description="Refresh token using expired access token.")
class Refresh(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"], refresh=True)
    def post():
        """
        Refresh token using an expired access token from cookies.
        """
        try:
            email = get_jwt_identity()
            user_obj = user.lookup_user_by_email(email)

            if user_obj is None:
                raise AuthenticationException(
                    "refresh failed",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST
                )

            # Generate new access token.
            new_access_token, claims = generate_ui_access_token(user_obj)
            response = make_response(jsonify(claims))
            set_access_cookies(response, new_access_token)

        except AuthenticationException as ex:
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)

        return response


@api.route("/sign-in-using-token", methods=["POST"])
@api.doc(description="Sign using a JWT token.")
class SignInWithToken(Resource):
    @staticmethod
    def post():
        """
        Sign using a JWT token.
        """
        try:
            json_data = request.json
            token = json_data["token"] if "token" in json_data else None

            assert_not_none(token, "Missing token")

            user_id, expires = authenticate_identity_token(token)
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "User does not exist",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            if user_obj.status == persistence.USER_STATUS_DISABLED:
                raise AuthenticationException(
                    "User is disabled",
                    error_code=exceptions.CODE_ADMIN_USER_ACCOUNT_DISABLED)

            if user_obj.status != persistence.USER_STATUS_ACTIVE:
                user.update_status(user_obj, persistence.USER_STATUS_GUEST)

            access_token, refresh_token, claims = generate_ui_guest_token_pair(user_obj)
            response = make_response(jsonify(claims))
            set_access_cookies(response, access_token)
            set_refresh_cookies(response, refresh_token)
            return make_response(response, 200)

        except AuthenticationException as ex:
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/resend-identity-token", methods=["POST"])
@api.doc(description="Resend an identity token to the user's email.")
class ResendIdentityToken(Resource):
    @staticmethod
    def post():
        """
        Resend an identity token to the user's email.
        """
        try:
            json_data = request.json
            identity_token = json_data["identity_token"] if "identity_token" in json_data else None

            assert_not_none(identity_token, "Missing token")

            user_id = get_user_id_from_token(identity_token)
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "Resend failed",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            # Create an identity token and send a new identity link.
            token, _ = generate_identity_token(user_obj, expires_hours=48)
            notify_user(user_obj, None,
                        campaign.lookup_template(
                            "Invitation",
                            locale=user_obj.locale,
                            permanent=True),
                        token=token,
                        reset_code=user_obj.reset_code,
                        bypass=True)

            return make_response(jsonify({}), 200)

        except AuthenticationException as ex:
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/forgot", methods=["PUT"])
@api.doc(description="Start the forgot password process.")
class Forgot(Resource):
    @staticmethod
    def put():
        """
        Start the forgot password process.
        """
        try:
            json_data = request.json
            email = json_data["email"] if "email" in json_data else None
            assert_not_none(email, "Email missing")
            user_obj = user.lookup_user_by_email(email)

            if user_obj is None:
                return respond(
                    status_code=400,
                    error="Forgot password failed because user " + email + " was not not found",
                    message="Forgot password failed",
                    code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            if user_obj.status != 'active':
                return respond(
                    status_code=400,
                    error="User is not active",
                    message="Forgot password failed",
                    code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

            # Generate a reset code for the user.
            user.forgot_user(user_obj)

            # Lookup the user again to pick up the reset code.
            user_obj = user.lookup_user_by_id(user_obj.id)

            notify_user(
                user_obj,
                None,
                campaign.lookup_template(
                    "Forgot",
                    locale=user_obj.locale,
                    permanent=True),
                reset_code=user_obj.reset_code,
                bypass=True)

            return make_response(jsonify(True), 200)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/reset", methods=["PUT"])
@api.doc(description="Reset a user's password.")
class Reset(Resource):
    @staticmethod
    def put():
        """
        Reset a user's password.
        """
        try:
            json_data = request.json

            reset_code = json_data["reset_code"] if "reset_code" in json_data else None
            password = json_data["password"] if "password" in json_data else None

            assert_not_none(reset_code, "Reset code missing")
            assert_not_none(password, "Password missing")

            user_obj = user.lookup_user_by_reset_code(reset_code)

            if user_obj is None:
                raise AuthenticationException("User not found",
                                              error_code=exceptions.CODE_ADMIN_USER_INVALID_RESET_CODE)

            if user_obj.status != persistence.USER_STATUS_GUEST \
                    and user_obj.status != persistence.USER_STATUS_FORGOT \
                    and user_obj.status != persistence.USER_STATUS_INVITED \
                    and user_obj.status != persistence.USER_STATUS_UPLOADED:
                raise AuthenticationException("User cannot be reset",
                                              error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_FORGOT)

            user.change_password(user_obj, password)

            # Lookup the user again to pick up the change.
            user_obj = user.lookup_user_by_id(user_obj.id)

            access_token, refresh_token, claims = generate_ui_token_pair(user_obj)
            response = jsonify(claims)
            set_access_cookies(response, access_token)
            set_refresh_cookies(response, refresh_token)
            return make_response(response, 200)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/validate/identity_token/<identity_token>/reset_code/<reset_code>", methods=["GET"])
@api.doc(description="Validate a user's identity token and reset code.")
class ValidateTokenAndResetCode(Resource):
    @staticmethod
    def get(identity_token=None, reset_code=None):
        """
        Validate a user's token and reset code.
        """
        token_valid = False
        reset_code_valid = False

        try:
            if identity_token is not None:
                try:
                    authenticate_identity_token(identity_token)
                    token_valid = True
                except Exception as ex:
                    pass

            if reset_code is not None:
                user_obj = user.lookup_user_by_reset_code(reset_code)

                if user_obj is not None \
                        and (user_obj.status == persistence.USER_STATUS_FORGOT
                             or user_obj.status == persistence.USER_STATUS_GUEST
                             or user_obj.status == persistence.USER_STATUS_INVITED
                             or user_obj.status == persistence.USER_STATUS_UPLOADED):
                    reset_code_valid = True

            return make_response(jsonify({"token_valid": token_valid, "reset_code_valid": reset_code_valid, }), 200)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/validate/reset_code/<reset_code>", methods=["GET"])
@api.doc(description="Validate a user's reset code.")
class ValidateResetCode(Resource):
    @staticmethod
    def get(reset_code):
        """
        Validate a user's reset code.
        """
        try:
            user_obj = user.lookup_user_by_reset_code(reset_code)

            if user_obj is None:
                return make_response(jsonify(False), 200)

            if user_obj.status != persistence.USER_STATUS_FORGOT \
                    and user_obj.status != persistence.USER_STATUS_INVITED \
                    and user_obj.status != persistence.USER_STATUS_UPLOADED:
                raise AuthenticationException(
                    "User cannot be reset",
                    error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_FORGOT)

            return make_response(jsonify(True), 200)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)
