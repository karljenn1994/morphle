import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import exceptions
from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.repository import Repository
from lib_common.routes_support import response_json
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import claim

api = Namespace("broker-api/web/v1/ui/claims", description="Provides access to claims.")
log = logging.getLogger(LOGGER)


@api.route("/total", methods=["GET"])
@api.doc(description="Total number of claims.")
class TotalClaims(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of claims.
        """
        try:
            assert_admin_user()
            claim_list = claim.list_claims(None, None, None, None, None)
            return Response(json.dumps(len(claim_list)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("", methods=["GET"])
@api.doc(description="Read all claims.")
class Claims(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all claims.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            claim_list = claim.list_claims(rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(claim_list, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/claim/<claim_id>", methods=["GET"])
@api.doc(description="Read a claim.")
class UserClaim(Resource):
    @staticmethod
    def load_claim_data(file_name):
        if file_name is None:
            return None

        fm = FileManagerFactory.create_file_manager()
        claim_path = fm.join(Repository.claims_location, file_name)
        claim_data = FileManagerFactory.create_file_manager().read_string(claim_path)
        return json.loads(claim_data)

    @staticmethod
    def list_claim_images(claim_id):
        if claim_id is None:
            return None

        file_names = []
        fm = FileManagerFactory.create_file_manager()
        claim_abs_path = fm.join(Repository.claims_location, claim_id)

        for img in fm.listdir(claim_abs_path):
            # check if the image ends with png
            if img.endswith(".jpg"):
                file_names.append(img)

        return file_names

    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(claim_id):
        """
        Read a claim.
        """
        try:
            assert_admin_user()
            c = claim.lookup_claim_by_id(claim_id)

            if c is None:
                raise InvalidArgument("Claim not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            claim_report = {
                "status": c.status,
                "company": c.company,
                "lob": c.lob,
                "file_name": c.file_name,
                "received_date": c.received_date,
                "modified_date": c.modified_date,
                "email": c.email,
                "phone": c.phone,
                "claim": UserClaim.load_claim_data(c.file_name),
                "images": UserClaim.list_claim_images(claim_id),
            }

            return Response(json.dumps(claim_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/claim/pdf/<claim_id>/<file_name>", methods=["GET"])
@api.doc(description="Return a claim PDF.")
class ClaimPDF(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(claim_id, file_name):
        """
        Return a claim PDF.
        """
        try:
            assert_admin_user()
            pdf = claim.get_claim_pdf(claim_id, file_name)
            return Response(pdf, mimetype="application/pdf")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<status>/<notifier_id>", methods=["GET"])
@api.doc(description="Update a claim's status.")
class UpdateClaimStatus(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(status, notifier_id):
        """
        Update a claim's status.
        """
        try:
            assert_admin_user()
            claim.update_status(notifier_id, status)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<claim_id>", methods=["DELETE"])
@api.doc(description="Delete a claim.")
class DeleteClaim(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(claim_id):
        """
        Delete a claim.
        """
        try:
            assert_admin_user()
            fm = FileManagerFactory.create_file_manager()
            claim_abs_path = fm.join(Repository.claims_location, claim_id)

            if fm.exists(claim_abs_path):
                fm.rmtree(claim_abs_path)

            claim.delete_claim(claim_id)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})
