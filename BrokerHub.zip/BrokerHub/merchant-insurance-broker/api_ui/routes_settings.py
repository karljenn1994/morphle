import json
import logging

from flask import Response, request
from flask_jwt_extended import get_jwt_identity, jwt_required, verify_jwt_in_request
from flask_restx import Namespace, Resource
from jwt.exceptions import ExpiredSignatureError  # from PyJWT

from lib_common import constants
from lib_common.authentication import assert_admin_user, get_user_id_from_cookies
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.routes_support import response_json
from lib_vault.vault import Vault
from lib_persistence import settings, user
from lib_persistence.settings import update_settings

api = Namespace("broker-api/web/v1/ui/settings", description="Provides settings.")
log = logging.getLogger(LOGGER)


@api.route("", methods=["GET"])
@api.doc(description="Returns settings.")
class ListSettings(Resource):
    @staticmethod
    def get():
        """
        Returns settings.
        """
        try:
            expired = False
            current_user = None

            # 1) Try to parse the cookie JWT (optional=True means “no token OK”).
            try:
                verify_jwt_in_request(locations=["cookies"], optional=True)
                current_user = get_jwt_identity()
            except ExpiredSignatureError:
                # A token was present but is expired.
                expired = True
            except:
                pass

            # 2) Build the settings payload
            if current_user is None:
                settings_list = settings.get_public_settings()
            else:
                user_id = get_user_id_from_cookies()
                user_obj = user.lookup_user_by_id(user_id)
                if user_obj and user_obj.role == "admin":
                    settings_list = settings.get_settings()
                    settings_list[constants.SETTING_CSIONET_USER] = Vault().get(constants.SETTING_CSIONET_USER)
                    settings_list[constants.SETTING_CSIONET_PASSWORD] = Vault().get(constants.SETTING_CSIONET_PASSWORD)
                else:
                    settings_list = settings.get_user_settings()

            # 3) Choose status: 419 if expired, otherwise 200
            status_code = 419 if expired else 200
            return Response(
                json.dumps(settings_list),
                status=status_code,
                mimetype="application/json",
            )

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("", methods=["PUT"])
@api.doc(description="Updates settings.")
class UpdateSettings(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put():
        """
        Updates settings.
        """
        try:
            assert_admin_user()

            settings_map = request.json

            csionet_user = settings_map[constants.SETTING_CSIONET_USER]
            csionet_password = settings_map[constants.SETTING_CSIONET_PASSWORD]

            # Don't write CSIO mailbox credentials to the database.
            del settings_map[constants.SETTING_CSIONET_USER]
            del settings_map[constants.SETTING_CSIONET_PASSWORD]

            update_settings(settings_map)

            # Write CSIO mailbox credentials to vault.
            Vault().put(constants.SETTING_CSIONET_USER, csionet_user)
            Vault().put(constants.SETTING_CSIONET_PASSWORD, csionet_password)
            Vault().write()

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
