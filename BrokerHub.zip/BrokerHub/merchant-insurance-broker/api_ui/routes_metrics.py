import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.routes_support import response_json, row_to_dict, rows_to_list
from lib_common.authentication import assert_admin_user
from lib_persistence import metrics, user

api = Namespace("broker-api/web/v1/ui/metrics", description="Provides admin metrics.")
log = logging.getLogger(LOGGER)


@api.route("/users/total", methods=["GET"])
@api.doc(description="Count users.")
class ListUsers(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Count users.
        """
        try:
            assert_admin_user()
            role = request.args.get('role')
            users = user.list_users(None, None, None, None, role, None)
            return Response(json.dumps(len(users)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/dashboard", methods=["GET"])
@api.doc(description="Get dashboard metrics.")
class DashboardMetrics(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Get dashboard metrics.
        """
        try:
            assert_admin_user()
            metrics_obj = row_to_dict(metrics.get_dashboard_metrics())
            policy_errors = rows_to_list(metrics.get_dashboard_policy_errors())
            return Response(
                json.dumps({
                    "counters": metrics_obj, "policy_errors": policy_errors},
                    default=str),
                status=200,
                mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})
