import json
import logging

from flask import Response, jsonify, make_response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants, exceptions
from lib_common.authentication import (
    assert_admin_role, assert_extension_token, generate_extension_token
)
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    AuthenticationException,
    AuthenticationExpiredException,
    HttpException,
    InvalidArgument
)
from lib_common.repository import Repository
from lib_common.routes_support import (
    assert_not_none, get_friendly_locale, response_json, rows_to_list
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import indexer, policy, settings, user
from lib_policy_dom.JSON import JSON
from validations.issues_support import load_issues

api = Namespace("broker-api/web/v1/ui/auth/ext", description="Provides extension authentication")
log = logging.getLogger(LOGGER)


@api.route("/sign-in", methods=["POST"])
@api.doc(description="Sign in and receive a JWT token.")
class SignInExt(Resource):
    @staticmethod
    def post():
        """
        Sign in and receive a JWT token for use with the chrome extension.
        """
        try:
            json_data = request.json
            email = json_data["email"] if "email" in json_data else None
            password = json_data["password"] if "password" in json_data else None

            assert_not_none(email, "Missing email")
            assert_not_none(password, "Missing password")

            user_obj = user.lookup_user_by_email(email)
            assert_admin_role(user_obj)
            match = user.test_password_match(password, user_obj.password_hash, user_obj.salt)

            if not match:
                raise AuthenticationException(
                    "Sign in failed",
                    error_code=exceptions.CODE_ADMIN_USER_AUTHENTICATION_FAILED)

            token, claims = generate_extension_token(user_obj)
            response = jsonify(token)

            return make_response(response)
        except AuthenticationException as ex:
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except (HttpException, InvalidArgument) as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": ex.message, "code": ex.code}), 400)
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return make_response(jsonify({"message": str(ex)}), 400)


@api.route("/policy/<policy_id>", methods=["GET"])
@api.route("/policy_number/<policy_number>", methods=["GET"])
@api.route("/policy_number/<policy_number>/company/<company>/lob/<lob>", methods=["GET"])
@api.doc(description="Read a policy.")
class ReadPolicy(Resource):
    @staticmethod
    @jwt_required(locations=['headers'])
    def get(policy_id=None, policy_number=None, company=None, lob=None):
        """
        Read a user's policies.
        """
        try:
            assert_extension_token()

            fm = FileManagerFactory.create_file_manager()
            j = JSON()

            policy_card = None
            policy_list = []
            renewal_list = []
            users = []

            # Search for the policy.
            p = None

            if not p and policy_id:
                p = policy.read_version_by_id(policy_id)
                if p is None:
                    raise InvalidArgument("Policy not found", error_code=exceptions.CODE_ADMIN_POLICY_DOES_NOT_EXIST)

            if not p and policy_number and company and lob:
                p = policy.read_active_by_policy_number_company_lob(policy_number, company, lob)

            if not p and policy_number and lob:
                p = policy.read_active_by_policy_number_lob(policy_number, lob)

            if not p and policy_number:
                p = policy.read_active_by_policy_number(policy_number)

            if p:
                policy_number = p.policy_number
                company = p.company
                lob = p.lob

            pdfs = []

            if policy_number and company and lob:
                pdfs = policy.list_pdfs(policy_number, lob, company)

            if p:
                policy_number = p.policy_number
                company = p.company
                lob = p.lob

                if p.active and p.file_name is not None and len(p.file_name) > 0:
                    card_json_file = fm.join(Repository.policies_location, p.file_name)
                    card_json = JSON.load_card_json(card_json_file)
                    policy_card = JSON().get_policy_card(card_json)
                    policy_card["pdfs"] = pdfs
                    policy_card["id"] = p.id
                    policy_card["downloaded"] = True
                    policy_card["validations"] = load_issues(p)

                    policy_list.append(card_json)
                    edi_file = card_json_file.replace(".JSON", ".AL3")

                    if fm.exists(edi_file):
                        try:
                            policy_edi = FileManagerFactory.create_file_manager().read_string(edi_file)
                            policy_card["edi"] = policy_edi
                        except:
                            pass

                    policy_card["json"] = json.dumps(card_json)
                else:
                    # We don't have this policy downloaded yet. Make a placeholder for
                    # it so the user will see something. There might be PDFs available
                    # depending on the timing of things being downloaded.
                    policy_card = [{
                        "id": p.id,
                        "downloaded": False,
                        "type": "policy",
                        "category": "folio",
                        "pdfs": pdfs,
                        "fields": {
                            "policy_number": p.policy_number,
                            "lob": p.lob,
                            "company_code": p.company,
                        }
                    }]

                    policy_list.append(policy_card)

            # Search for the renewal.
            r = None

            if policy_number and company and lob:
                r = indexer.read_latest_renewal_by_number_company_lob(policy_number, company, lob)

            if r is not None:
                card_json_file = fm.join(Repository.policies_location, r.file_name)
                card_json = JSON.load_card_json(card_json_file)
                renewal_policy_card = j.get_policy_card(card_json)
                renewal_policy_card["pdfs"] = policy.list_renewal_pdfs(
                    r.policy_number,
                    r.lob,
                    r.company,
                    r.file_name,
                    r.transaction_effective_date)
                renewal_policy_card["id"] = r.policy_id
                renewal_policy_card["downloaded"] = True
                renewal_policy_card["validations"] = load_issues(r)

                renewal_list.append(card_json)

                edi_file = card_json_file.replace(".JSON", ".AL3")
                renewal_edi = None

                if fm.exists(edi_file):
                    renewal_edi = FileManagerFactory.create_file_manager().read_string(edi_file)

                renewal_policy_card["edi"] = renewal_edi
                renewal_policy_card["json"] = json.dumps(card_json)

                if not p and not policy_card:
                    # There is no policy yet. This can happen for a number of reasons
                    # including not getting an initial data dump for a customer. The first
                    # thing we see might be the renewal. Here we are a placeholder card with
                    # any PDFs we might have on the renewal.
                    policy_card = {
                        "id": r.policy_id,
                        "downloaded": False,
                        "type": "policy",
                        "category": "folio",
                        "pdfs": pdfs,
                        "fields": {
                            "policy_number": policy_number,
                            "lob": lob,
                            "company_code": company,
                        }
                    }
                    policy_list.append(
                        [policy_card]
                    )

            if p:
                # Load users from policy.
                users = rows_to_list(user.lookup_users_by_policy_id(p.id, include_leads=True))
            elif r:
                # Load users from renewal.
                users = rows_to_list(user.lookup_users_by_policy_id(r.policy_id, include_leads=True))

            # Search for history.
            h = p or r

            if h and policy_card:
                history = policy.list_history(h.policy_number, h.company, h.lob, h.policy_effective_date, h.seq)

                if history:
                    policy_card["history"] = []

                    for h in history:
                        historical_card_json_file = fm.join(Repository.policies_location, h.file_name)
                        historical_card_json = JSON.load_card_json(historical_card_json_file)
                        historical_card = j.get_policy_card(historical_card_json)
                        historical_card["pdfs"] = None
                        historical_card["id"] = h.id
                        historical_card["downloaded"] = True
                        historical_card["validations"] = load_issues(h)

                        # We need the sequence on the UI for sorting, otherwise, some historical
                        # entries will be identical.
                        historical_card["sequence"] = h.seq

                        policy_card["history"].append(historical_card_json)

            if not policy_list and not renewal_list:
                raise InvalidArgument("Policy not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            slogan = settings.get_setting(constants.SETTING_BROKERAGE_SLOGAN + "_" + get_friendly_locale(
                request.headers))

            policy_report = {
                "logo": "http://logo.png",
                "name": settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME),
                "slogan": slogan,
                "address": settings.get_setting(constants.SETTING_BROKERAGE_ADDRESS),
                "hours": settings.get_setting(constants.SETTING_BROKERAGE_HOURS),
                "phone": settings.get_setting(constants.SETTING_BROKERAGE_PHONE),
                "users": users,
                "policies": policy_list,
                "renewals": renewal_list,
            }

            return Response(json.dumps(policy_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException, AuthenticationExpiredException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
