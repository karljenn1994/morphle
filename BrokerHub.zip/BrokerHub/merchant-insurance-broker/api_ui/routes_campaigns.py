import json
import logging

from django.utils.safestring import mark_safe
from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common import constants
from lib_common.authentication import assert_admin_user
from lib_common.constants import LOGGER
from lib_email.emailer import Emailer
from lib_common.exceptions import AuthenticationException, CampaignException, HttpException, InvalidArgument
from lib_email.notify_user import notify_recipients
from lib_common.routes_support import assert_not_none, response_json, row_to_dict, rows_to_list
from lib_persistence import campaign, get_connection, indexer, notifier, settings

api = Namespace("broker-api/web/v1/ui/campaigns", description="Provides campaign management functions.")
log = logging.getLogger(LOGGER)


@api.route("/templates", methods=["GET"])
@api.doc(description="List templates.")
class ListTemplates(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        List available campaign templates.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts optional query parameters for pagination, sorting, and filtering:
            - `type`: List of campaign types to include.
            - `rows_per_page`, `page`: For pagination.
            - `sort`, `sort_direction`: To control sorting.
            - `search`: Filter by name or description.

        Uses the `campaign.list_templates` function to retrieve results.

        :return: A JSON list of template records.
        """
        try:
            assert_admin_user()

            campaign_types = request.args.getlist("type")
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)

            tasks = campaign.list_templates(campaign_types, rows_per_page, page, sort, sort_direction, search)

            return Response(json.dumps(rows_to_list(tasks)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/template/<template_id>", methods=["GET"])
@api.doc(description="Load template.")
class LoadTemplate(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(template_id):
        """
        Load a template and its localized contents.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Fetches template metadata by ID.
        - Loads all localized versions (subject/body) of the template.

        :param template_id: Unique ID of the template to load.
        :return: Template metadata and contents as JSON.
        """
        try:
            assert_admin_user()

            template = campaign.load_template(template_id)
            template_contents = campaign.load_template_contents(template_id)

            contents = []
            for content in template_contents:
                contents.append({
                    "locale": content.locale,
                    "subject": content.subject,
                    "body": content.body.decode("utf-8")
                })

            return Response(json.dumps({
                "id": template.id,
                "type": template.type,
                "name": template.name,
                "description": template.description,
                "contents": json.dumps(contents),
            }), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/template/<template_id>", methods=["POST"])
@api.doc(description="Insert/Update a template.")
class PostTemplate(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(template_id):
        """
        Insert or update a campaign template and its contents.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts JSON body with:
            - `name`: Template name (required)
            - `description`: Template description (optional)
            - `template_type`: Type/category of template (required)
            - `contents`: JSON-encoded list of localized content (required)
        - Writes metadata and content to the database in a transaction.

        :param template_id: ID of the template to insert or update.
        :return: True on success.
        """
        try:
            assert_admin_user()
            json_data = request.json

            name = json_data.get("name")
            description = json_data.get("description")
            template_type = json_data.get("template_type")
            contents = json_data.get("contents")

            assert_not_none(name, "Template name missing")
            assert_not_none(template_type, "Template type missing")
            assert_not_none(contents, "Template content missing")

            with get_connection() as connection:
                campaign.upsert_template(template_id, template_type, name, description, optional_connection=connection)
                campaign.upsert_template_contents(template_id, json.loads(contents), optional_connection=connection)
                connection.commit()

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/total", methods=["GET"])
@api.doc(description="Total campaigns.")
class TotalCampaigns(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Return the total number of campaigns.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts optional query parameters:
            - `type`: list of campaign types to include.
            - `active`: boolean string to filter active/inactive campaigns.
        - Calls `campaign.read_campaign_count()` with filters.

        :return: Integer total of matching campaigns.
        """
        try:
            assert_admin_user()

            campaign_types = request.args.getlist("type")

            active_param = request.args.get("active")
            active = None
            if active_param is not None:
                active = active_param.lower() in ["true", "1", "yes"]

            total = campaign.read_campaign_count(campaign_types, active=active)
            return Response(json.dumps(total), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("", methods=["GET"])
@api.doc(description="List campaigns.")
class ListCampaigns(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Return a paginated list of campaigns.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts query parameters:
            - `rows_per_page`, `page`: for pagination.
            - `sort`, `sort_direction`: for ordering results.
            - `search`: filter campaigns by search term.
            - `type`: list of campaign types to include.
            - `active`: filter by active status (true/false).
        - Uses `campaign.list_campaigns_paged()` to fetch results.

        :return: JSON list of campaign objects.
        """
        try:
            assert_admin_user()

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", 'trigger_event')
            sort_direction = request.args.get("sort_direction", "DESC")
            search = request.args.get("search", None)
            campaign_types = request.args.getlist("type")

            active_param = request.args.get("active")
            active = None
            if active_param is not None:
                active = active_param.lower() in ["true", "1", "yes"]

            campaigns = campaign.list_campaigns_paged(
                rows_per_page,
                page,
                sort,
                sort_direction,
                search,
                campaign_types=campaign_types,
                active=active
            )

            return Response(json.dumps(rows_to_list(campaigns)), status=200, mimetype="application/json")

        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/campaign/<campaign_id>", methods=["GET"])
@api.doc(description="Load a campaign.")
class LoadCampaign(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(campaign_id):
        """
        Load metadata for a specific campaign.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts a campaign ID as a path parameter.
        - Calls `campaign.load_campaign()` to retrieve metadata for the campaign.
        - Uses `row_to_dict()` to convert the DB row to JSON-compatible dict.

        :param campaign_id: Unique identifier for the campaign.
        :return: JSON object representing the campaign metadata.
        """
        try:
            assert_admin_user()

            campaign_obj = campaign.load_campaign(campaign_id)

            return Response(json.dumps(row_to_dict(campaign_obj)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/campaign/<campaign_id>/results", methods=["GET"])
@api.doc(description="Load campaign results.")
class LoadCampaignResults(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(campaign_id):
        """
        Load campaign email performance results.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts a campaign ID as a path parameter.
        - Calls `campaign.load_campaign_results()` to fetch delivery and engagement metrics.

        Metrics returned:
        - total_email_delivered
        - total_email_not_delivered
        - total_email_bounced
        - total_email_views
        - total_email_clicked

        :param campaign_id: Unique identifier of the campaign.
        :return: JSON object with delivery and engagement statistics.
        """
        try:
            assert_admin_user()

            campaign_results_obj = campaign.load_campaign_results(campaign_id)

            return Response(json.dumps({
                "total_email_delivered": campaign_results_obj.total_email_delivered,
                "total_email_not_delivered": campaign_results_obj.total_email_not_delivered,
                "total_email_bounced": campaign_results_obj.total_email_bounced,
                "total_email_views": campaign_results_obj.total_email_views,
                "total_email_clicked": campaign_results_obj.total_email_clicked,
            }), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/lists", methods=["GET"])
@api.doc(description="Load lists used by the campaign UI.")
class LoadLists(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Load support lists used by the campaign UI.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Returns:
            - List of companies from the indexer.
            - List of predefined user statuses.
            - Optionally (if `type` provided):
              - Templates for that type.
              - Forms for that type.

        Query Parameters:
        - type: (optional) campaign type to filter associated templates and forms.

        :return: JSON object containing companies, user statuses, and optionally templates/forms.
        """
        try:
            assert_admin_user()

            resp = {
                "companies": rows_to_list(indexer.list_companies()),
                "user_statuses": [
                    {"status": "uploaded", "description": "New"},
                    {"status": "invited", "description": "Invited"},
                    {"status": "active", "description": "Active"}
                ]
            }

            campaign_type = request.args.get('type', default=None)
            if campaign_type is not None:
                resp["templates"] = rows_to_list(campaign.list_templates([campaign_type], None, None, None, None, None))
                resp["forms"] = rows_to_list(campaign.list_forms(campaign_type, None, None, None, None, None))

            return Response(json.dumps(resp), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/template/<template_id>", methods=["DELETE"])
@api.doc(description="Delete a template.")
class DeleteTemplate(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(template_id):
        """
        Delete a campaign template by ID.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts a template ID as a path parameter.
        - Calls `campaign.delete_template()` to perform the deletion.
        - Handles known and general exceptions accordingly.

        :param template_id: Unique identifier for the template to delete.
        :return: JSON true response if successful, else error response.
        """
        try:
            assert_admin_user()

            campaign.delete_template(template_id)

            return response_json(200, True)
        except CampaignException as ex:
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/campaign/<campaign_id>", methods=["POST"])
@api.doc(description="Insert/Update a campaign.")
class PostCampaign(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def post(campaign_id):
        """
        Insert or update a campaign configuration.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts JSON body containing:
            - Required: active, approval, marketing, campaign_type, name, template_id
            - Optional: description, reply_to, form_id, scheduled, trigger, rules
        - Validates required fields.
        - Calls `campaign.upsert_campaign()` to write/update the record.

        :param campaign_id: ID of the campaign to update or insert.
        :return: JSON true response on success.
        """
        try:
            assert_admin_user()
            json_data = request.json

            active = json_data["active"] if "active" in json_data else False
            approval = json_data["approval"] if "approval" in json_data else False
            marketing = json_data["marketing"] if "marketing" in json_data else False
            campaign_type = json_data["campaign_type"] if "campaign_type" in json_data else None
            template_id = json_data["template_id"] if "template_id" in json_data else None
            form_id = json_data["form_id"] if "form_id" in json_data else None
            name = json_data["name"] if "name" in json_data else None
            description = json_data["description"] if "description" in json_data else None
            reply_to = json_data["reply_to"] if "reply_to" in json_data else None
            scheduled = json_data["scheduled"] if "scheduled" in json_data else False
            trigger = json_data["trigger"] if "trigger" in json_data else None
            rules = json_data["rules"] if "rules" in json_data else None

            assert_not_none(active, "Missing field active")
            assert_not_none(approval, "Missing field approval")
            assert_not_none(marketing, "Missing field marketing")
            assert_not_none(campaign_type, "Missing field campaign_type")
            assert_not_none(name, "Missing field name")
            assert_not_none(template_id, "Missing field template_id")

            campaign.upsert_campaign(
                campaign_id,
                active,
                approval,
                marketing,
                campaign_type,
                name,
                description,
                reply_to,
                template_id,
                form_id,
                scheduled,
                trigger,
                json.dumps(rules) if rules is not None else None)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/campaign/<campaign_id>", methods=["DELETE"])
@api.doc(description="Delete a campaign.")
class DeleteCampaign(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def delete(campaign_id):
        """
        Delete a campaign.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts a campaign ID as a path parameter.
        - Calls `campaign.delete_campaign()` to remove the campaign record.
        - Logs and handles known and generic errors.

        :param campaign_id: Unique identifier of the campaign to delete.
        :return: JSON true response if successful, else error response.
        """
        try:
            assert_admin_user()

            campaign.delete_campaign(campaign_id)

            return response_json(200, True)
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/campaign/<campaign_id>/run", methods=["GET"])
@api.route("/campaign/<campaign_id>/user_id/<user_id>/run", methods=["GET"])
@api.route("/campaign/<campaign_id>/policy_id/<policy_id>/run", methods=["GET"])
@api.route("/campaign/<campaign_id>/policy_id/<policy_id>/user_id/<user_id>/run", methods=["GET"])
@api.doc(description="Execute a campaign.")
class RunCampaign(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(campaign_id, policy_id=None, user_id=None):
        """
        Run or dry-run a campaign for all, a specific user, or a specific policy.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts campaign ID and optionally a user ID and/or policy ID.
        - Supports dry-run mode (`dryrun=true`) to simulate the campaign execution without notifications.
        - Supports notify mode (`notify_now=true`) to immediately notify users if campaign does not require approval.
        - If notify_now is true and campaign does not require approval, calls `notify_recipients()`.

        Query Parameters:
        - dryrun: If true (default), do not send notifications.
        - notify_now: If true, immediately notify recipients (if allowed).

        :param campaign_id: Campaign to execute.
        :param policy_id: (Optional) Filter to a specific policy.
        :param user_id: (Optional) Filter to a specific user.
        :return: JSON object with total and newly added recipients.
        """
        try:
            assert_admin_user()
            dryrun = request.args.get("dryrun", default=True, type=lambda v: v.lower() == 'true')
            notify_now = request.args.get("notify_now", default=False, type=lambda v: v.lower() == 'true')
            total_recipients, total_new_recipients, recipients, notifier_id = campaign.execute_campaign(
                campaign_id,
                policy_id=policy_id,
                user_id=user_id,
                dry_run=dryrun,
                notify_now=notify_now)

            if notify_now and notifier_id:
                n = notifier.get_notification_by_id(notifier_id)
                if n:
                    c = campaign.load_campaign(campaign_id)
                    if not c.approval:
                        notify_recipients(n)

            return Response(json.dumps({
                "total_recipients": total_recipients,
                "total_new_recipients": total_new_recipients
            }), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/send-test-email/<email>", methods=["PUT"])
@api.doc(description="Send a test email.")
class SendTestEmail(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def put(email):
        """
        Send a test email using the provided subject, body, and template type.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts `subject`, `body`, and `type` in request JSON.
        - Builds a mock context for the email template (client and brokerage info).
        - If type is `policy`, includes mock policy context.
        - Uses the configured SendGrid sender, reply-to, and group ID settings.

        :param email: Email address to send the test message to.
        :return: True if email was sent successfully.
        """
        try:
            user_obj = assert_admin_user()
            json_data = request.json

            subject = json_data["subject"] if "subject" in json_data else None
            body = json_data["body"] if "body" in json_data else None
            template_type = json_data["type"] if "type" in json_data else None

            assert_not_none(subject, "Subject missing")
            assert_not_none(body, "Body missing")
            assert_not_none(template_type, "Type missing")

            context = {
                "client": {
                    "account_name": user_obj.account_name.title(),
                    "first_name": user_obj.first_name.title(),
                    "last_name": user_obj.last_name.title(),
                    "url": mark_safe(settings.get_setting(constants.SETTING_ADMIN_UI_HOST) + "/auth/login"),
                },
                "brokerage": {
                    "url": mark_safe(settings.get_setting(constants.SETTING_BROKERAGE_WEBSITE_URL)),
                    "contact_url": mark_safe(settings.get_setting(constants.SETTING_BROKERAGE_CONTACT_URL)),
                },
            }

            if template_type == "policy":
                context["policy"] = {
                    "number": "123456",
                    "company": "Insure Co",
                    "lob": "auto",
                    "transaction_effective_date": "2025-01-01",
                    "policy_effective_date": "2025-02-01",
                    "policy_expiry_date": "2026-02-01",
                }

            from_email = settings.get_setting(constants.SETTING_SENDGRID_FROM_EMAIL)
            reply_email = settings.get_setting(constants.SETTING_SENDGRID_REPLY_EMAIL)
            group_id = settings.get_setting(constants.SETTING_SENDGRID_GROUP_ID)
            Emailer(context, body, subject).send_email(
                from_email,
                email,
                reply_email=reply_email,
                group_id=int(group_id),
                bypass=False
            )

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/campaign/<campaign_id>/recipients/total", methods=["GET"])
@api.doc(description="Total number of campaign email recipients.")
class TotalRecipients(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(campaign_id):
        """
        Return the total number of email recipients for a campaign.

        HOW IT WORKS:
        -----------------
        - Requires admin authentication.
        - Accepts a campaign ID as a path parameter.
        - Calls `campaign.list_recipients()` with no filters to retrieve all recipients.
        - Returns the length of the resulting list.

        :param campaign_id: ID of the campaign.
        :return: Integer count of total recipients.
        """
        try:
            assert_admin_user()
            recipient_list = campaign.list_recipients(campaign_id, None, None, None, None, None)
            return Response(json.dumps(len(recipient_list)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/campaign/<campaign_id>/recipients", methods=["GET"])
@api.doc(description="List campaign email recipients.")
class ListRecipients(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(campaign_id):
        """
        List campaign email recipients.
        """
        try:
            assert_admin_user()

            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", 'sent_date')
            sort_direction = request.args.get("sort_direction", "DESC")
            search = request.args.get("search", None)

            campaigns = campaign.list_recipients(
                campaign_id,
                rows_per_page,
                page,
                sort,
                sort_direction,
                search
            )

            return Response(json.dumps(rows_to_list(campaigns), default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
            })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
