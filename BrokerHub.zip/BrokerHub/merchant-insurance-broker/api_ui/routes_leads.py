import json
import logging

from flask import Response, request
from flask_jwt_extended import jwt_required
from flask_restx import Namespace, Resource

from lib_common.routes_support import response_json
from lib_common.authentication import assert_admin_user
from lib_common import exceptions
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_persistence import lead

api = Namespace("broker-api/web/v1/ui/leads", description="Provides access to leads.")
log = logging.getLogger(LOGGER)


@api.route("/total", methods=["GET"])
@api.doc(description="Total number of leads.")
class TotalLeads(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Total number of leads.
        """
        try:
            assert_admin_user()
            lead_list = lead.list_leads(None, None, None, None, None)
            return Response(json.dumps(len(lead_list)), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("", methods=["GET"])
@api.doc(description="Read all leads.")
class Leads(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get():
        """
        Read all leads.
        """
        try:
            assert_admin_user()
            rows_per_page = request.args.get('rows_per_page', type=int)
            page = request.args.get('page', type=int)
            sort = request.args.get("sort", None)
            sort_direction = request.args.get("sort_direction", "ASC")
            search = request.args.get("search", None)
            lead_list = lead.list_leads(rows_per_page, page, sort, sort_direction, search)
            return Response(json.dumps(lead_list, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/lead/<lead_id>", methods=["GET"])
@api.doc(description="Read a lead.")
class UserLead(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(lead_id):
        """
        Read a lead.
        """
        try:
            assert_admin_user()
            lead_obj = lead.lookup_lead_by_id(lead_id)

            if lead_obj is None:
                raise InvalidArgument("lead not found", error_code=exceptions.CODE_INVALID_ARGUMENT)

            lead_report = {
                "status": lead_obj.status,
                "lead_type": lead_obj.lead_type,
                "received_date": lead_obj.received_date,
                "modified_date": lead_obj.modified_date,
                "email": lead_obj.email,
                "phone": lead_obj.phone,
            }

            return Response(json.dumps(lead_report, default=str), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})


@api.route("/<status>/<user_id>", methods=["GET"])
@api.doc(description="Change a lead's status.")
class UpdateStatus(Resource):
    @staticmethod
    @jwt_required(locations=["cookies"])
    def get(status, user_id):
        """
        Change a lead's status.
        """
        try:
            assert_admin_user()
            lead.update_status(user_id, status)
            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": ex.message, "code": ex.code})
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})
