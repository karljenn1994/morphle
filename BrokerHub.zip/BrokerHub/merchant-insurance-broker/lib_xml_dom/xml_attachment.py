import xml.etree.ElementTree as et
from typing import Optional

from lib_xml_dom.xml_dom import csio_ns_map


class XmlAttachment:
    """Wrapper around a <FileAttachmentInfo> element."""

    def __init__(self, element: et.Element):
        self._element = element

    def _get(self, tag: str) -> Optional[str]:
        el = self._element.find(f".//{tag}", csio_ns_map)
        return el.text.strip() if el is not None and el.text else None

    def _set(self, tag: str, value: Optional[str]) -> None:
        el = self._element.find(f".//{tag}", csio_ns_map)
        if el is not None:
            el.text = value.strip() if value else ""

    @property
    def description(self) -> Optional[str]:
        return self._get("AttachmentDesc")

    @description.setter
    def description(self, value: Optional[str]) -> None:
        self._set("AttachmentDesc", value)

    @property
    def type_code(self) -> Optional[str]:
        return self._get("AttachmentTypeCd")

    @type_code.setter
    def type_code(self, value: Optional[str]) -> None:
        self._set("AttachmentTypeCd", value)

    @property
    def mime_content_type(self) -> Optional[str]:
        return self._get("MIMEContentTypeCd")

    @mime_content_type.setter
    def mime_content_type(self, value: Optional[str]) -> None:
        self._set("MIMEContentTypeCd", value)

    @property
    def mime_encoding(self) -> Optional[str]:
        return self._get("MIMEEncodingTypeCd")

    @mime_encoding.setter
    def mime_encoding(self, value: Optional[str]) -> None:
        self._set("MIMEEncodingTypeCd", value)

    @property
    def filename(self) -> Optional[str]:
        return self._get("AttachmentFilename")

    @filename.setter
    def filename(self, value: Optional[str]) -> None:
        self._set("AttachmentFilename", value)

    @property
    def status_code(self) -> Optional[str]:
        return self._get("AttachmentStatusCd")

    @status_code.setter
    def status_code(self, value: Optional[str]) -> None:
        self._set("AttachmentStatusCd", value)

    @property
    def document_copy_type(self) -> Optional[str]:
        return self._get("DocumentCopyTypeCd")

    @document_copy_type.setter
    def document_copy_type(self, value: Optional[str]) -> None:
        self._set("DocumentCopyTypeCd", value)

    def __repr__(self) -> str:
        return f"<XmlAttachment filename={self.filename!r} type={self.type_code!r}>"
