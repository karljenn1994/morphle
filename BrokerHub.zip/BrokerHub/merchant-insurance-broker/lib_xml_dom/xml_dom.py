import xml.etree.ElementTree as et
from io import BytesIO
from typing import Optional, List

from lib_al3.al3_utils import fix_policy_number
from lib_common.exceptions import (
    CODE_XML_MISSING_COMPANY_NAME,
    CODE_XML_MISSING_POLICY_NUMBER,
    XMLException,
)
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import policy

csio_ns_map = {
    "": "http://www.ACORD.org/standards/PC_Surety/ACORD1/xml/",
    "csio": "http://www.CSIO.org/standards/PC_Surety/CSIO1/xml/",
}

acord_ns_map = {
    "acord": "http://www.ACORD.org/standards/PC_Surety/ACORD1/xml/",
    "csio": "http://www.CSIO.org/standards/PC_Surety/CSIO1/xml/",
}

xml_extensions = (".xml",)


class XmlAttachment:
    """
    Wrapper around a <FileAttachmentInfo> element.

    Provides strongly typed property access to the key child fields.
    Changes are applied directly to the underlying XML element and will
    persist when the owning XmlDOM is saved.
    """

    def __init__(self, element: et.Element):
        self._element = element

    def _get(self, tag: str) -> Optional[str]:
        el = self._element.find(f".//{tag}", csio_ns_map)
        return el.text.strip() if el is not None and el.text else None

    def _set(self, tag: str, value: Optional[str]) -> None:
        el = self._element.find(f".//{tag}", csio_ns_map)
        if el is not None:
            el.text = value.strip() if value else ""

    @property
    def description(self) -> Optional[str]:
        """Attachment description (AttachmentDesc)."""
        return self._get("AttachmentDesc")

    @description.setter
    def description(self, value: Optional[str]) -> None:
        self._set("AttachmentDesc", value)

    @property
    def type_code(self) -> Optional[str]:
        """Attachment type code (AttachmentTypeCd)."""
        return self._get("AttachmentTypeCd")

    @type_code.setter
    def type_code(self, value: Optional[str]) -> None:
        self._set("AttachmentTypeCd", value)

    @property
    def mime_content_type(self) -> Optional[str]:
        """MIME content type (MIMEContentTypeCd), e.g. application/pdf."""
        return self._get("MIMEContentTypeCd")

    @mime_content_type.setter
    def mime_content_type(self, value: Optional[str]) -> None:
        self._set("MIMEContentTypeCd", value)

    @property
    def mime_encoding(self) -> Optional[str]:
        """MIME encoding type (MIMEEncodingTypeCd), e.g. BASE64."""
        return self._get("MIMEEncodingTypeCd")

    @mime_encoding.setter
    def mime_encoding(self, value: Optional[str]) -> None:
        self._set("MIMEEncodingTypeCd", value)

    @property
    def filename(self) -> Optional[str]:
        """Attachment filename (AttachmentFilename)."""
        return self._get("AttachmentFilename")

    @filename.setter
    def filename(self, value: Optional[str]) -> None:
        self._set("AttachmentFilename", value)

    @property
    def status_code(self) -> Optional[str]:
        """Attachment status code (AttachmentStatusCd)."""
        return self._get("AttachmentStatusCd")

    @status_code.setter
    def status_code(self, value: Optional[str]) -> None:
        self._set("AttachmentStatusCd", value)

    @property
    def document_copy_type(self) -> Optional[str]:
        """Document copy type (DocumentCopyTypeCd)."""
        return self._get("DocumentCopyTypeCd")

    @document_copy_type.setter
    def document_copy_type(self, value: Optional[str]) -> None:
        self._set("DocumentCopyTypeCd", value)

    def __repr__(self) -> str:
        return f"<XmlAttachment filename={self.filename!r} type={self.type_code!r}>"


class XmlDOM:
    """Domain-specific wrapper for XML policy documents in CSIO/ACORD format."""

    extensions = (".xml",)

    def __init__(self, root: et.Element, file_path: Optional[str] = None):
        self.root = root
        self._file_path = file_path

    @staticmethod
    def load(file_name: str) -> "XmlDOM":
        fm = FileManagerFactory.create_file_manager()
        data = fm.read_file(file_name)
        tree = et.parse(BytesIO(data))
        return XmlDOM(tree.getroot(), file_path=file_name)

    def save(self) -> None:
        if not self._file_path:
            raise ValueError("Cannot save: no original file path available")
        fm = FileManagerFactory.create_file_manager()
        tree = et.ElementTree(self.root)
        fm.write_xml(self._file_path, tree)

    def save_as(self, file_path: str) -> None:
        fm = FileManagerFactory.create_file_manager()
        tree = et.ElementTree(self.root)
        fm.write_xml(file_path, tree)

    def _text(self, path: str, ns: Optional[dict] = None) -> Optional[str]:
        """
        Return the text for the first matching element in the given namespace map.
        Normalizes by stripping csio:/acord: prefixes from values.
        """
        if ns is None:
            ns = csio_ns_map
        nodes = self.root.findall(path, ns)
        if nodes and nodes[0].text:
            return nodes[0].text.strip().replace("csio:", "").replace("acord:", "")
        return None

    @property
    def policy_number(self) -> Optional[str]:
        policy_no = (
            self._text(".//PolicyNumber")
            or self._text(".//csio:PolicyNumber")
            or self._text(".//acord:PolicyNumber", acord_ns_map)
        )
        return fix_policy_number(policy_no) if policy_no else None

    @property
    def company(self) -> Optional[str]:
        company = (
            self._text(".//CompanyCd")
            or self._text(".//csio:CompanyCd")
            or self._text(".//acord:CompanyCd", acord_ns_map)
        )
        if company:
            company, _ = policy.map_company_code(company)
        return company

    @property
    def lob(self) -> Optional[str]:
        return (
            self._text(".//LOBCd")
            or self._text(".//csio:LOBCd")
            or self._text(".//acord:LOBCd", acord_ns_map)
        )

    @property
    def purpose(self) -> Optional[str]:
        return (
            self._text(".//BusinessPurposeTypeCd")
            or self._text(".//csio:BusinessPurposeTypeCd")
            or self._text(".//acord:BusinessPurposeTypeCd", acord_ns_map)
        )

    @property
    def transaction_effective_date(self) -> Optional[str]:
        effective_date = (
            self._text(".//TransactionEffectiveDt")
            or self._text(".//csio:TransactionEffectiveDt")
            or self._text(".//acord:TransactionEffectiveDt", acord_ns_map)
        )
        return effective_date.split("T")[0] if effective_date else None

    @property
    def transaction_response_date(self) -> Optional[str]:
        response_date = (
            self._text(".//TransactionResponseDt")
            or self._text(".//csio:TransactionResponseDt")
            or self._text(".//acord:TransactionResponseDt", acord_ns_map)
        )
        return response_date.split("T")[0] if response_date else None

    @property
    def effective_date(self) -> Optional[str]:
        effective_date = (
            self._text(".//EffectiveDt")
            or self._text(".//csio:EffectiveDt")
            or self._text(".//acord:EffectiveDt", acord_ns_map)
        )
        return effective_date.split("T")[0] if effective_date else None

    @property
    def expiry_date(self) -> Optional[str]:
        expiry_date = (
            self._text(".//ExpirationDt")
            or self._text(".//csio:ExpirationDt")
            or self._text(".//acord:ExpirationDt", acord_ns_map)
        )
        return expiry_date.split("T")[0] if expiry_date else None

    @property
    def attachments(self) -> List[XmlAttachment]:
        return [XmlAttachment(el) for el in self.root.findall(".//FileAttachmentInfo", csio_ns_map)]

    @property
    def xml_folder_name(self) -> str:
        policy_no = self.policy_number
        company = self.company

        if not policy_no or policy_no == "N/A":
            raise XMLException("Missing policy number in XML", error_code=CODE_XML_MISSING_POLICY_NUMBER)
        if not company:
            raise XMLException("Missing company name in XML", error_code=CODE_XML_MISSING_COMPANY_NAME)

        fm = FileManagerFactory.create_file_manager()
        return fm.join(company.upper(), policy_no.upper())

    def make_file_name(self, original_file_name: str, suffix: Optional[int] = None) -> tuple[Optional[str], str]:
        """
        Construct a normalized file name from key XML fields.

        Args:
            original_file_name: The original input file name (used for extension).
            suffix: Optional numeric suffix to append.

        Returns:
            (file_name, err_msg)
              - file_name: Generated name if all required fields present, else None.
              - err_msg: Comma-separated missing fields (empty if none).
        """
        rq_uid = (
                self._text(".//RqUID")
                or self._text(".//csio:RqUID")
                or self._text(".//acord:RqUID", acord_ns_map)
        )

        policy_no = self.policy_number
        company = self.company
        lob = self.lob
        tx_response_date = self.transaction_response_date
        policy_effective_date = self.effective_date
        purpose = self.purpose
        seq = (
                self._text(".//TransactionSeqNumber")
                or self._text(".//csio:TransactionSeqNumber")
                or self._text(".//acord:TransactionSeqNumber", acord_ns_map)
        )

        missing: list[str] = []
        if not rq_uid: missing.append("rquid")
        if not policy_no: missing.append("policy")
        if not company: missing.append("company")
        if not lob: missing.append("lob")
        if not tx_response_date: missing.append("transaction response date")
        if not policy_effective_date: missing.append("policy effective date")
        if not purpose: missing.append("purpose")
        if not seq: seq = "0000"

        if missing:
            return None, ", ".join(missing)

        policy_no = fix_policy_number(policy_no)
        company, _ = policy.map_company_code(company)
        tx_response_date = tx_response_date.replace("-", "")
        policy_effective_date = policy_effective_date.replace("-", "")
        rq_uid = rq_uid.replace("-", "")

        fm = FileManagerFactory.create_file_manager()
        _, ext = fm.splitext(original_file_name)

        file_name = (
            f"{company.upper()}_{tx_response_date}_{policy_effective_date}_{seq}_{policy_no}_{lob}_{purpose}_{rq_uid}"
            f"{'_' + str(suffix) if suffix is not None else ''}{ext}"
        ).upper()

        return file_name, ""
