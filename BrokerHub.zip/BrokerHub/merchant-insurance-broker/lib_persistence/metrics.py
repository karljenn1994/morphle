from sqlalchemy import text

from lib_common import constants
from lib_persistence import get_connection, settings


def get_dashboard_metrics(optional_connection=None):
    """
    Return a single row of dashboard metrics for system and user monitoring.

    HOW IT WORKS:
    -----------------
    - Gathers various counts about users, policies, renewals, quotes, and leads.
    - Uses multiple sub-selects to calculate:
        • Total users (non-admin)
        • Active users (non-admin)
        • Active but not connected users
        • Guest users (non-admin)
        • Guest not connected users
        • Total connected users
        • Total active policies
        • Total downloaded policies (policies with file_name)
        • Total inactive policies (active policies mapped to non-active users)
        • Total active policies (active policies mapped to active or guest users or connected users)
        • Total unmapped policies (no user mapping)
        • Total failed indexer records
        • Total renewals
        • Total renewals above the premium change threshold
        • Total quotes
        • New quotes
        • Total user leads

    :param optional_connection: Optional existing DB connection.
    :return: Single row object with all metric fields as attributes.
    """
    change_threshold = settings.get_setting(constants.SETTING_RENEWALS_PREMIUM_CHANGE_PERCENT_THRESHOLD)

    with get_connection(optional_connection) as connection:
        return connection.execute(text(
            """
            SELECT
                -- User counts
                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT u.id
                      FROM user u
                      JOIN user_role ur ON ur.user_id = u.id
                      LEFT JOIN user_policy up ON up.user_id = u.id
                      LEFT JOIN policy p ON p.id = up.policy_id
                     WHERE ur.role != 'admin'
                       AND p.xln = 0
                       AND p.purge = 0
                       AND p.policy_expiry_date >= CURDATE()
                       AND p.file_name IS NOT NULL
                ) AS total_user_ids) AS total_users,

                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT u.id
                      FROM user u
                      JOIN user_role ur ON ur.user_id = u.id
                      LEFT JOIN user_policy up ON up.user_id = u.id
                      LEFT JOIN policy p ON p.id = up.policy_id
                     WHERE u.status = 'active'
                       AND ur.role != 'admin'
                       AND p.xln = 0
                       AND p.purge = 0
                       AND p.policy_expiry_date >= CURDATE()
                       AND p.file_name IS NOT NULL
                ) AS active_user_ids) AS active_users,

                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT u.id
                      FROM user u
                      JOIN user_role ur ON ur.user_id = u.id
                      LEFT JOIN user_policy up ON up.user_id = u.id
                      LEFT JOIN policy p ON p.id = up.policy_id
                     WHERE u.status = 'active'
                       AND ur.role != 'admin'
                       AND u.connected = 0
                       AND p.xln = 0                       
                       AND p.purge = 0
                       AND p.policy_expiry_date >= CURDATE()
                       AND p.file_name IS NOT NULL
                ) AS active_nc_user_ids) AS active_not_connected_users,

                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT u.id
                      FROM user u
                      JOIN user_role ur ON ur.user_id = u.id
                      LEFT JOIN user_policy up ON up.user_id = u.id
                      LEFT JOIN policy p ON p.id = up.policy_id
                     WHERE u.status = 'guest'
                       AND ur.role != 'admin'
                       AND p.xln = 0
                       AND p.purge = 0
                       AND p.policy_expiry_date >= CURDATE()
                       AND p.file_name IS NOT NULL
                ) AS guest_user_ids) AS guest_users,

                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT u.id
                      FROM user u
                      JOIN user_role ur ON ur.user_id = u.id
                      LEFT JOIN user_policy up ON up.user_id = u.id
                      LEFT JOIN policy p ON p.id = up.policy_id
                     WHERE u.status = 'guest'
                       AND ur.role != 'admin'
                       AND u.connected = 0
                       AND p.xln = 0
                       AND p.purge = 0
                       AND p.policy_expiry_date >= CURDATE()
                       AND p.file_name IS NOT NULL
                ) AS guest_nc_user_ids) AS guest_not_connected_users,

                (SELECT COUNT(*) FROM user u WHERE u.connected = 1) AS connected_users,

                -- Policy counts
                
               (SELECT COUNT(*) 
                   FROM policy p 
                  WHERE p.active = 1 
                    AND p.xln = 0                    
                    AND p.purge = 0
                    AND p.policy_expiry_date >= CURDATE()
                    AND p.file_name IS NOT NULL) AS total_downloaded_policies,

                (SELECT COUNT(DISTINCT p.id)
                   FROM policy p
                   JOIN user_policy up ON p.id = up.policy_id
                   JOIN user u ON up.user_id = u.id
                  WHERE p.active = 1
                    AND p.xln = 0
                    AND p.purge = 0
                    AND p.policy_expiry_date >= CURDATE()
                    AND p.file_name IS NOT NULL
                    AND (u.status IN ('active', 'guest') OR u.connected = 1)
                ) AS total_active_policies,

                (SELECT COUNT(DISTINCT p.id) AS total_inactive_policies
                   FROM policy p
                   JOIN user_policy up ON p.id = up.policy_id
                   JOIN user u ON u.id = up.user_id
                  WHERE p.active = 1
                    AND p.xln = 0
                    AND p.purge = 0
                    AND p.policy_expiry_date >= CURDATE()
                    AND p.file_name IS NOT NULL
                    AND p.id NOT IN (
                        SELECT p2.id
                          FROM policy p2
                          JOIN user_policy up2 ON p2.id = up2.policy_id
                          JOIN user u2 ON u2.id = up2.user_id
                         WHERE p2.active = 1
                           AND p2.xln = 0
                           AND p2.purge = 0
                           AND p2.policy_expiry_date >= CURDATE()
                           AND p2.file_name IS NOT NULL
                           AND (u2.status IN ('active', 'guest') OR u2.connected = 1)
                   )
                ) AS total_inactive_policies,

                (SELECT COUNT(DISTINCT p.id)
                   FROM policy p
                   LEFT JOIN user_policy up ON up.policy_id = p.id
                  WHERE p.active = 1
                    AND p.xln=0
                    AND p.purge = 0
                    AND p.policy_expiry_date >= CURDATE()
                    AND p.file_name IS NOT NULL
                    AND up.policy_id IS NULL
                ) AS total_unmapped_policies,

                -- Indexer & renewals
                (SELECT COUNT(*) 
                   FROM indexer i 
                  WHERE i.failed = 1) AS total_policy_errors,

                (SELECT COUNT(*) AS total_renewals
                   FROM indexer i
                   JOIN policy p ON p.id = i.policy_id
                  WHERE i.failed = 0
                    AND i.name = 'index'
                    AND i.latest = 1
                    AND i.in_renewal_chain = 1) AS total_renewals, 

                :change_threshold AS renewals_threshold,

                (SELECT COUNT(*) AS renewals_above_threshold
                   FROM policy px
                   JOIN indexer i ON px.id = i.policy_id
                   JOIN policy pa ON pa.policy_number = px.policy_number 
                                 AND pa.company = px.company 
                                 AND pa.lob = px.lob 
                                 AND pa.id != px.id
                  WHERE i.latest = 1
                    AND i.in_renewal_chain = 1
                    AND pa.active = 1
                    AND pa.xln = 0
                    AND pa.purge = 0
                    AND pa.policy_expiry_date >= CURDATE()
                    AND px.annual_premium IS NOT NULL
                    AND pa.annual_premium IS NOT NULL
                    AND ABS((px.annual_premium - pa.annual_premium) / pa.annual_premium * 100) > :change_threshold
                ) AS renewals_above_threshold,

                -- Quotes & leads
                (SELECT COUNT(*) FROM quote) AS total_quotes,

                (SELECT COUNT(*) FROM quote WHERE status = 'received') AS new_quotes,

                (SELECT COUNT(*) FROM user_lead) AS total_leads;
            """
        ).bindparams(
            change_threshold=change_threshold
        )).first()


def get_dashboard_policy_errors(optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text(
            """
            SELECT id, entered, process, name, message, code, file_name
              FROM indexer
             WHERE failed=1
             ORDER BY entered ASC
           """
        )).all()
