INDEXER_ORGANIZE = "organize"
INDEXER_TRANSFORM = "transform"
INDEXER_INDEX = "index"
INDEXER_NOTIFY = "notify"
INDEXER_NOTIFY_SCHEDULE = "notify_schedule"
INDEXER_SCAN = "scan"
INDEXER_SCAN_SCHEDULE = "scan_schedule"

USER_STATUS_ACTIVE = "active"
USER_STATUS_GUEST = "guest"
USER_STATUS_PENDING = "pending"
USER_STATUS_FORGOT = "forgot"
USER_STATUS_INVITED = "invited"
USER_STATUS_UPLOADED = "uploaded"
USER_STATUS_UNCONFIRMED = "unconfirmed"
USER_STATUS_DISABLED = "disabled"

ROLE_USER = "user"
ROLE_ADMIN = "admin"


def not_empty(val):
    if isinstance(val, str):
        return val is not None and len(val) > 0
    elif isinstance(val, list):
        return len(val) > 0
    else:
        return val is not None


def str_from_date(dt):
    if dt is not None:
        return str(dt)
    return None


def _equal_not_none(first, second):
    return first is not None and second is not None and first == second


def _in_not_none(partial, full):
    return partial is not None and full is not None and partial in full
