import uuid
from datetime import datetime

from sqlalchemy import text

from lib_persistence import get_connection


def schedule_collection(user_id, optional_connection=None):
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            INSERT INTO collector (id, user_id, scheduled_date) 
            VALUES (:id, :user_id, :scheduled_date)
            """
        ).bindparams(
            id=mid,
            user_id=user_id,
            scheduled_date=datetime.now().date(),
        ))

        if optional_connection is None:
            connection.commit()

    return mid


def get_ready_to_collect(optional_connection=None):
    with get_connection(optional_connection) as connection:
        # See what users are ready to be collected.
        return connection.execute(text("""
            SELECT c.id, c.user_id, u.email
              FROM collector c, user u
             WHERE c.failed != 1
               AND u.id=c.user_id
              """)).all()


def mark_collected(collect_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM collector
            WHERE id=:collect_id
           """
        ).bindparams(
            collect_id=collect_id
        ))

        if optional_connection is None:
            connection.commit()


def mark_collector_failed(collect_id, message=None, code=None, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             UPDATE collector
                SET failed=1, 
                    message=:message, 
                    code=:code
            WHERE id=:collect_id
           """
        ).bindparams(
            collect_id=collect_id,
            message=message,
            code=code
        ))

        if optional_connection is None:
            connection.commit()


def delete_collections(user_id, source, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            DELETE 
              FROM collector_property
             WHERE user_id=:user_id
               AND source=:source
            """
        ).bindparams(
            user_id=user_id,
            source=source
        ))

        connection.execute(text(
            """
            DELETE 
              FROM collector_auto
             WHERE user_id=:user_id
               AND source=:source
            """
        ).bindparams(
            user_id=user_id,
            source=source
        ))

        connection.execute(text(
            """
            DELETE
              FROM collector_card
             WHERE user_id=:user_id
               AND source=:source
            """
        ).bindparams(
            user_id=user_id,
            source=source
        ))

        if optional_connection is None:
            connection.commit()


def insert_vehicle(user_id,
                   source,
                   vehicle_year=None,
                   vehicle_make=None,
                   vehicle_model=None,
                   vehicle_vin=None,
                   optional_connection=None):
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            INSERT INTO collector_auto (id, user_id, source, collected_date, vehicle_year, vehicle_make, 
            vehicle_model, vehicle_vin) 
            VALUES (:id, :user_id, :source, :collected_date, :vehicle_year, :vehicle_make, :vehicle_model, :vehicle_vin)
            """
        ).bindparams(
            id=mid,
            source=source,
            collected_date=datetime.now().date(),
            user_id=user_id,
            vehicle_year=vehicle_year,
            vehicle_make=vehicle_make,
            vehicle_model=vehicle_model,
            vehicle_vin=vehicle_vin
        ))

        if optional_connection is None:
            connection.commit()

    return mid


def insert_property(user_id,
                    source,
                    address=None,
                    city=None,
                    province=None,
                    postal_code=None,
                    optional_connection=None):
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            INSERT INTO collector_property (id, user_id, source, collected_date, address, city, province, postal_code) 
            VALUES (:id, :user_id, :source, :collected_date, :address, :city, :province, :postal_code)
            """
        ).bindparams(
            id=mid,
            user_id=user_id,
            source=source,
            collected_date=datetime.now().date(),
            address=address,
            city=city,
            province=province,
            postal_code=postal_code,
        ))

        if optional_connection is None:
            connection.commit()

    return mid


def insert_card(user_id, source, name, card_type, optional_connection=None):
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            INSERT INTO collector_card (id, user_id, source, collected_date, name, type)
            VALUES (:id, :user_id, :source, :collected_date, :name, :card_type)
            """
        ).bindparams(
            id=mid,
            user_id=user_id,
            source=source,
            collected_date=datetime.now().date(),
            name=name,
            card_type=card_type,
        ))

        if optional_connection is None:
            connection.commit()

    return mid


def list_collected_autos(user_id, source, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *, 'auto' as type
              FROM collector_auto
             WHERE user_id=:user_id                
               AND source=:source
              """).bindparams(
            user_id=user_id,
            source=source
        )).all()


def list_collected_properties(user_id, source, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *, 'property' as type
              FROM collector_property
             WHERE user_id=:user_id                
               AND source=:source
              """).bindparams(
            user_id=user_id,
            source=source
        )).all()
