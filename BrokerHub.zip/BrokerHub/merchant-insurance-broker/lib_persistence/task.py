from datetime import datetime

import pytz
from sqlalchemy import text

from lib_common.routes_support import row_to_dict, rows_to_list
from lib_persistence import get_connection


def get_task(task_name, optional_connection=None):
    with get_connection(optional_connection) as connection:
        row = connection.execute(text("""
            (SELECT 
                pt.name,
                cs.minute,
                cs.hour,
                cs.day_of_week,
                cs.day_of_month,
                cs.month_of_year,
                CASE pt.enabled
                    WHEN 1 THEN 'enabled'
                    WHEN 0 THEN 'disabled'
                END AS status
            FROM
                celery_periodictask pt,
                celery_crontabschedule cs
            WHERE
                pt.name = :task_name
                    AND cs.id = pt.schedule_id) 
            UNION ALL 
            (SELECT '0', '0', '0', '0', '0', '0', 'disabled') LIMIT 1
            """).bindparams(task_name=task_name)).first()
        return {
            'name': task_name,
            'status': row.status,
            'minute': row.minute,
            'hour': row.hour,
            'days_of_week': row.day_of_week.split(","),
            'days_of_month': row.day_of_month.split(","),
            'months_of_year': row.month_of_year.split(","),
        }


def update_task_status(task_name, status, status_timestamp=None, last_successful_run=None, optional_connection=None):
    """Update or insert a task's status in the task_status table."""
    with get_connection(optional_connection) as connection:
        # Validate status
        valid_statuses = {'running', 'succeeded', 'failed', 'inactive'}
        if status not in valid_statuses:
            raise ValueError(f"Invalid status: {status}. Must be one of {valid_statuses}")

        # Prepare parameters
        params = {
            'task_name': task_name[:25],  # Truncate to 25 chars to match schema
            'status': status,
            'status_timestamp': status_timestamp or datetime.now(pytz.UTC),
            'last_successful_run': last_successful_run
        }

        connection.execute(text("""
            INSERT INTO task_status (task_name, status, status_timestamp, last_successful_run)
            VALUES (:task_name, :status, :status_timestamp, :last_successful_run)
            ON DUPLICATE KEY UPDATE
                status = :status,
                status_timestamp = :status_timestamp,
                last_successful_run = COALESCE(:last_successful_run, last_successful_run)
        """).bindparams(**params))

        if optional_connection is None:
            connection.commit()


def list_task_statuses(optional_connection=None):
    """Retrieve all task statuses for UI display."""
    with get_connection(optional_connection) as connection:
        result = connection.execute(text("""
            SELECT task_name, status, status_timestamp, last_successful_run
            FROM task_status
            ORDER BY task_name
        """))
        rows = result.all()
    return rows_to_list(rows)


def get_task_status(task_name, optional_connection=None):
    """Retrieve the status of a specific task."""
    with get_connection(optional_connection) as connection:
        result = connection.execute(text("""
            SELECT 
                task_name, 
                status, 
                status_timestamp, 
                last_successful_run, 
                (SELECT COUNT(*) 
                   FROM indexer
                   WHERE name=:task_name
                     AND failed=1) as errors
              FROM task_status
             WHERE task_name = :task_name
        """), {'task_name': task_name[:25]})
        row = result.fetchone()
        return row_to_dict(row) if row else None
