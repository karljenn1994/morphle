from sqlalchemy import text

from lib_persistence import get_connection


def get_company_contact(company_code, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM company_contact cc
             WHERE cc.code=:company_code
        """).bindparams(
            company_code=company_code
        )).first()
