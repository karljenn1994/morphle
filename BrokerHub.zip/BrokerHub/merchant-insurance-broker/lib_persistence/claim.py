import os
from datetime import datetime

from sqlalchemy import text

from lib_common.repository import Repository
from lib_common.routes_support import rows_to_list
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import get_connection


def insert_claim(claim_id, user_id, email, phone, policy_number, company, lob, claim_path, optional_connection=None):
    with get_connection(optional_connection) as connection:
        now = datetime.now().date()
        sql = text(
            """
             INSERT 
               INTO claim(id, user_id, email, phone, status, received_date, modified_date, 
                          policy_number, company, lob, file_name)
             VALUES(:id, :user_id, :email, :phone, :status, :received_date, :modified_date, 
                    :policy_number, :company, :lob, :file_name)
           """
        ).bindparams(
            id=claim_id,
            user_id=user_id,
            email=email,
            phone=phone,
            status="received",
            received_date=now,
            modified_date=now,
            policy_number=policy_number,
            company=company,
            lob=lob,
            file_name=claim_path,
        )
        connection.execute(sql)

        if optional_connection is None:
            connection.commit()


def list_claims(rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT *
              FROM claim
        """

        if search is not None:
            sql += """
               WHERE (
               status LIKE :search 
               OR company LIKE :search 
               OR lob LIKE :search
               OR email LIKE :search
               OR phone LIKE :search)
            """

        if sort is not None and sort_direction is not None:
            # For some reason, you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        rows = result.all()

    return rows_to_list(rows)


def lookup_claim_by_id(claim_id, optional_connection=None):
    if claim_id is None:
        return None

    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
              SELECT q.*
                 FROM claim q
                WHERE q.id=:claim_id
            """).bindparams(
            claim_id=claim_id
        )).first()


def update_status(claim_id, status, optional_connection=None):
    with get_connection(optional_connection) as connection:
        sql = text(
            """
             UPDATE claim
                SET modified_date=NOW(),
                    status=:status
              WHERE id=:claim_id
           """
        ).bindparams(claim_id=claim_id, status=status)

        connection.execute(sql)

        if optional_connection is None:
            connection.commit()


def get_claim_pdf(claim_id, file_name):
    if claim_id is None:
        return None

    fm = FileManagerFactory.create_file_manager()
    full_path = fm.join(Repository().claims_location, claim_id, file_name)
    return FileManagerFactory.create_file_manager().read_file(full_path)


def list_claim_pdfs(token, claim_id, optional_connection=None):
    if claim_id is None:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT q.file_name
              FROM claim as q
             WHERE q.id=:claim_id
             ORDER BY q.received_date DESC
            """
        ).bindparams(claim_id=claim_id)

        result = connection.execute(sql)
        row = result.first()
        file_names = []

        if row is not None:
            for file_name in row:
                if token is not None:
                    download_link = "broker-api/web/v1/ui/claims/claim/pdf/" + token + "/" + file_name
                    file_names.append({"download_link": download_link})

    return file_names


def delete_claim(claim_id, optional_connection=None):
    if claim_id is None:
        return None

    with get_connection(optional_connection) as connection:
        sql = text("""
             DELETE
               FROM claim
              WHERE id=:claim_id
           """).bindparams(claim_id=claim_id)

        connection.execute(sql)

        if optional_connection is None:
            connection.commit()
