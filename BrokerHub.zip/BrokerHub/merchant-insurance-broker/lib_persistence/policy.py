import json
import logging
import uuid
from datetime import datetime

from dateutil import parser
from sqlalchemy import text

from lib_al3.al3_codes import al3_code_display
from lib_common.constants import LOGGER
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import get_connection, indexer

log = logging.getLogger(LOGGER)


def update_company_name(policy_card):
    """
    Safely update the 'company_name' in a policy card using the mapped company code.

    :param policy_card: Dict containing at least `fields["company_code"]`.
    :return: None
    """
    try:
        fields = policy_card.get("fields", {})
        company_code = fields.get("company_code")

        if company_code:
            _, company_name = map_company_code(company_code)
            fields["company_name"] = company_name
    except Exception as e:
        log.warning(f"Could not fix company name for policy card: {e}")


def map_company_code(company_code, allow_none=False, optional_connection=None):
    """
    Map an input company code to its official company code and name.

    CONNECTION:
    -----------------
    - Uses `optional_connection` if provided; otherwise opens its own connection.

    :param company_code: The input company code or alias.
    :param allow_none: If True, allow a full `(None, None)` result when no match is found.
                       If False (default), fallback to `(company_code, "")`.
    :param optional_connection: Optional existing DB connection to use.
    :return: Tuple `(code, name)` → official company code and name.
    """
    with get_connection(optional_connection) as connection:
        sql = text(
            """
             SELECT DISTINCT(c.code), c.name
               FROM company c
               LEFT OUTER JOIN company_code cc ON c.code = cc.code
              WHERE c.code = :code OR cc.company_code = :code
            """
        ).bindparams(
            code=company_code,
        )

        results = connection.execute(sql)
        row = results.first()

        if row is None:
            if not allow_none:
                return company_code, ""
            else:
                return None, None

        return row.code, row.name


def map_company_name(company_name, optional_connection=None):
    """
    Attempt to map a raw company name string to an official company code and name.

    NOTE:
    -----------------
    - Only returns the *first* match found; if multiple companies match, results may vary.
    - If `company_name` contains no recognizable code or alias, returns `(None, "")`.
    - Relies on the consistency of codes appearing as clear substrings in the raw name.

    :param company_name: The raw company name or string to search for matches.
    :param optional_connection: Optional existing DB connection to use.
    :return: Tuple `(code, name)` → matched company code and name, or `(None, "")` if not found.
    """
    company_name = company_name.upper()
    with get_connection(optional_connection) as connection:
        row = connection.execute(text(
            """
                SELECT c.code, c.name
                  FROM company c
                  LEFT OUTER JOIN company_code cc ON c.code = cc.code
                 WHERE INSTR(:company_name, cc.code) > 0
                    OR INSTR(:company_name, c.code) > 0
                 GROUP BY c.code, c.name;
            """
        ).bindparams(
            company_name=company_name,
        )).first()

        if row is None:
            return None, ""

        return row.code, row.name


def is_multi_line(policy_number, company, lob, optional_connection=None):
    """
    Determine if a policy belongs to a user who has multiple policies
    with the same company but different lines of business (LOB).

    :param policy_number: The policy number to check.
    :param company: The insurance company.
    :param lob: The line of business for the target policy.
    :param optional_connection: Optional existing DB connection to use.
    :return: True if the policy is part of a multi-line relationship, else False.
    """
    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
            SELECT p2.lob
              FROM user_policy up1
             INNER JOIN policy p1 ON up1.policy_id = p1.id,
                  user_policy up2
             INNER JOIN policy p2 ON up2.policy_id = p2.id
             WHERE p1.policy_number = :policy_number
               AND p1.company = :company
               AND p1.lob = :lob
               AND up2.user_id = up1.user_id
               AND p2.company = :company
            """
        ).bindparams(policy_number=policy_number, company=company, lob=lob)).all()

        if rows is None or len(rows) <= 1:
            return False

        arr = []
        for row in rows:
            arr.append(row.lob)

        arr = list(dict.fromkeys(arr))  # Remove duplicates

        return len(arr) > 1


def create(policy_number, company, lob, optional_connection=None):
    """
    Create a new `policy` record with minimal required fields.

    :param policy_number: The unique policy number.
    :param company: The company code.
    :param lob: The line of business.
    :param optional_connection: (Optional) An existing DB connection to use.
    :return: The newly generated policy ID.
    """
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        sql = text(
            """
             INSERT
               INTO policy (id, active, policy_number, company, lob)
             VALUES(:id, :active, :policy_number, :company, :lob)
           """
        ).bindparams(
            id=mid,
            active=1,
            policy_number=policy_number,
            company=company,
            lob=lob
        )

        connection.execute(sql)

        if not optional_connection:
            connection.commit()

    return mid


def update_active_version(policy_id, optional_connection=None):
    """
    Mark a specific policy version as active and clean up related references.

    :param policy_id: The ID of the policy version to mark as active.
    :param optional_connection: Optional DB connection to run within a larger transaction.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        policy = read_version_by_id(policy_id, optional_connection=connection)

        # Get the currently active version.
        old_version = read_active_by_policy_number_company_lob(
            policy.policy_number,
            policy.company,
            policy.lob,
            optional_connection=connection)
        old_version_id = old_version.id if old_version is not None else None

        # Remove the active flag for all versions.
        connection.execute(text("""
              UPDATE policy
                 SET active=0                 
               WHERE policy_number=:policy_number
                 AND company=:company
                 AND lob=:lob
            """).bindparams(
            policy_number=policy.policy_number,
            company=policy.company,
            lob=policy.lob))

        # Mark this policy as active.
        connection.execute(text("""
              UPDATE policy
                 SET active=1, last_update=:last_update
               WHERE id=:policy_id
            """).bindparams(
            policy_id=policy_id,
            last_update=datetime.now()
        ))

        if old_version_id is not None:
            # Fetch user_id values that are safe to update.
            result = connection.execute(text(
                """
                SELECT up.user_id
                  FROM user_policy up
                 WHERE up.policy_id=:old_version_id
                   AND NOT EXISTS (
                    SELECT 1
                      FROM user_policy up2
                     WHERE up2.user_id=up.user_id
                       AND up2.policy_id=:policy_id
                )
                """
            ).bindparams(
                old_version_id=old_version_id,
                policy_id=policy_id
            )).fetchall()

            # Update each safe row.
            for row in result:
                user_id = row.user_id
                connection.execute(text(
                    """
                    UPDATE user_policy
                       SET policy_id=:policy_id
                     WHERE policy_id=:old_version_id
                       AND user_id=:user_id
                    """
                ).bindparams(
                    policy_id=policy_id,
                    old_version_id=old_version_id,
                    user_id=user_id
                ))

            connection.execute(text(
                """
                DELETE 
                  FROM user_policy
                 WHERE policy_id=:old_version_id
                """
            ).bindparams(
                old_version_id=old_version_id
            ))

            # Delete insured rows tied to older versions. We don't need these anymore to figure out whether
            # a new record should be put on hold.
            connection.execute(text(
                """
                DELETE FROM policy_insured
                 WHERE policy_id IN (
                       SELECT p.id
                         FROM policy p
                        WHERE p.policy_number = :policy_number
                          AND p.company = :company
                          AND p.lob = :lob
                          AND p.transaction_effective_date < :transaction_effective_date
                 )
                """
            ).bindparams(
                policy_number=policy.policy_number,
                company=policy.company,
                lob=policy.lob,
                transaction_effective_date=policy.transaction_effective_date
            ))

        if not optional_connection:
            connection.commit()


def create_version(
        insured_names,
        policy_number,
        company,
        lob,
        premium,
        annual_premium,
        purpose,
        transaction_date,
        sequence,
        transaction_effective_date,
        policy_effective_date,
        policy_expiry_date,
        file_name,
        optional_connection=None):
    """
    Create a new version of a policy if it does not already exist.

    :param insured_names: The names of the policy insureds.
    :param policy_number: The unique policy number.
    :param company: The insurance company code.
    :param lob: The line of business.
    :param premium: The premium amount for this version.
    :param annual_premium: The full term premium amount for this version.
    :param purpose: The purpose/type of this version (e.g., `RWL`, `PCH`, `END`, `XLN`).
    :param transaction_date: The date the transaction was processed.
    :param sequence: The transaction sequence number.
    :param transaction_effective_date: The date the transaction takes effect.
    :param policy_effective_date: The effective date of the policy coverage.
    :param policy_expiry_date: The expiry date of the policy coverage.
    :param file_name: The file name or source of this version.
    :param optional_connection: (Optional) An existing DB connection to use.
    :return: The ID of the existing or newly created policy version.
    """
    with get_connection(optional_connection) as connection:
        existing_version = read_version(
            policy_number,
            company,
            lob,
            purpose,
            transaction_effective_date,
            sequence,
            optional_connection=connection)
        policy_id = existing_version.id if existing_version is not None else None

        if not policy_id:
            # Insert the policy.
            policy_id = str(uuid.uuid4())

            connection.execute(text(
                """
                 INSERT 
                   INTO policy (id, active, policy_number, company, lob, 
                                premium, annual_premium, purpose, 
                                transaction_date, seq, transaction_effective_date, 
                                policy_effective_date, policy_expiry_date, 
                                file_name, xln, last_update, created)
                 VALUES (:policy_id, :active, :policy_number, :company, :lob, 
                         :premium, :annual_premium, :purpose, 
                         :transaction_date, :seq, :transaction_effective_date, 
                         :policy_effective_date, :policy_expiry_date,
                         :file_name, :xln, :last_update, :created)
               """
            ).bindparams(
                policy_id=policy_id,
                active=0,
                policy_number=policy_number,
                company=company,
                lob=lob,
                premium=premium,
                annual_premium=annual_premium,
                purpose=purpose,
                transaction_date=transaction_date,
                seq=sequence,
                transaction_effective_date=transaction_effective_date,
                policy_effective_date=policy_effective_date,
                policy_expiry_date=policy_expiry_date,
                file_name=file_name,
                xln=purpose == 'XLN',
                last_update=datetime.now(),
                created=datetime.now()
            ))

            for insured_name in insured_names:
                connection.execute(text(
                    """
                     INSERT IGNORE
                       INTO policy_insured (policy_id, insured_name)
                     VALUES (:policy_id, :insured_name)
                   """
                ).bindparams(
                    policy_id=policy_id,
                    insured_name=insured_name
                ))

        if not optional_connection:
            connection.commit()

    return policy_id


def list_policy_by_policy_number_lob(policy_number, lob, optional_connection=None):
    """
    List all unique companies for a given policy number and line of business (LOB).

    :param policy_number: The unique policy number.
    :param lob: The line of business.
    :param optional_connection: (Optional) Existing DB connection.
    :return: A list of rows with `policy_number`, `company`, and `lob`.
    """
    with get_connection(optional_connection) as connection:
        rows = connection.execute(text("""
            SELECT p.policy_number, p.company, p.lob
              FROM policy p
             WHERE p.policy_number = :policy_number
               AND p.lob = :lob
             GROUP BY p.policy_number, p.company, p.lob
        """).bindparams(
            policy_number=policy_number,
            lob=lob
        )).all()

    return rows


def list_active_paged(rows_per_page=None,
                      page=None,
                      sort=None,
                      sort_direction=None,
                      search=None,
                      optional_connection=None):
    """
    Retrieve a paged list of active policy records with user and issue summary counts.

    :param rows_per_page: Max rows per page.
    :param page: Page index (0-based).
    :param sort: Column to sort by (e.g. `p.policy_number`).
    :param sort_direction: Sort direction (`ASC` or `DESC`).
    :param search: Optional search string to match against policy fields.
    :param optional_connection: (Optional) Existing DB connection.
    :return: List of rows with `policy.*` plus `connected` and `errors` counts.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT p.*,
                   COALESCE(up_summary.connected, 0) AS connected,
                   COALESCE(pi_summary.errors, 0) AS errors
              FROM policy p
              LEFT JOIN (
                  SELECT policy_id, COUNT(DISTINCT user_id) AS connected
                    FROM user_policy
                   GROUP BY policy_id
              ) AS up_summary ON up_summary.policy_id = p.id
              LEFT JOIN (
                  SELECT policy_id, SUM(count) AS errors
                    FROM policy_issue
                   GROUP BY policy_id
              ) AS pi_summary ON pi_summary.policy_id = p.id
             WHERE p.active = 1
        """

        if search is not None:
            sql += """
               AND (p.policy_number LIKE :search 
               OR p.company LIKE :search
               OR p.lob LIKE :search
               OR p.purpose LIKE :search)
            """

        if sort is not None and sort_direction is not None:
            sql += " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            if rows_per_page is None:
                rows_per_page = 10
            sql += " LIMIT :limit OFFSET :offset"

        sql = text(sql)

        params = {}
        if search is not None:
            params['search'] = f"%{search}%"
        if page is not None:
            params['limit'] = rows_per_page
            params['offset'] = page * rows_per_page

        result = connection.execute(sql, params)
        rows = result.all()

    return rows


def list_all_active(optional_connection=None):
    """
    Retrieve all active policy records.

    :param optional_connection: (Optional) Existing DB connection.
    :return: List of rows with all columns from the `policy` table.
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
            SELECT p.*   
              FROM policy p
             WHERE active = 1
        """)
        result = connection.execute(sql)
        rows = result.all()
    return rows


def list_active_by_user_id(user_id, in_effect=False, optional_connection=None):
    """
    Retrieve all active policy records linked to a specific user.

    :param user_id: The unique ID of the user to look up.
    :param in_effect: If True, limit results to policies whose effective date window includes today.
    :param optional_connection: (Optional) Existing DB connection.
    :return: List of rows from the `policy` table matching the user and filters.
    """
    if user_id is None:
        return None

    with get_connection(optional_connection) as connection:
        sql = """
              SELECT p.*
                FROM policy p, user_policy up
               WHERE up.user_id = :user_id
                 AND p.id = up.policy_id
                 AND p.active = 1
            """

        if in_effect:
            sql += " AND NOW() >= p.transaction_effective_date AND NOW() <= p.policy_expiry_date"

        sql += " ORDER BY p.transaction_effective_date, p.policy_number DESC"

        sql = text(sql).bindparams(
            user_id=user_id,
        )

        result = connection.execute(sql)
        rows = result.all()

    return rows


def list_unmapped_paged(
        rows_per_page=None,
        page=None,
        sort=None,
        sort_direction=None,
        search=None,
        optional_connection=None):
    """
    Get a paged list of active policies that are not mapped to any user.

    :param rows_per_page: Max rows per page.
    :param page: Page number (0-based).
    :param sort: Column name to sort by.
    :param sort_direction: Sort order (`ASC` or `DESC`).
    :param search: Optional search filter.
    :param optional_connection: Optional DB connection.
    :return: List of unmapped `policy` rows.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT p.*
              FROM policy p
              LEFT JOIN user_policy up ON p.id = up.policy_id
             WHERE p.active = 1
               AND p.xln=0
               AND p.purge=0
               AND p.policy_expiry_date >= CURDATE()
               AND up.policy_id IS NULL
        """

        if search is not None:
            sql += """
               AND (p.policy_number LIKE :search 
                OR p.company LIKE :search
                OR p.lob LIKE :search
                OR p.purpose LIKE :search)
            """

        if sort is not None and sort_direction is not None:
            sql += " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            if rows_per_page is None:
                rows_per_page = 10
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        bind_params = {}

        if search is not None:
            bind_params["search"] = f"%{search}%"
        if page is not None:
            bind_params["offset"] = page * rows_per_page

        result = connection.execute(sql, bind_params)
        rows = result.all()

    return rows


def list_pdfs(policy_number, lob, company, transaction_effective_date=None, optional_connection=None):
    """
    Retrieve a list of PDF policy documents and their metadata for a given policy.

    :param policy_number: The policy number.
    :param lob: The line of business.
    :param company: The company code.
    :param transaction_effective_date: If provided, used to mark PDFs as `current` if their date >= this value.
    :param optional_connection: (Optional) Existing DB connection.
    :return: A list of dicts, each describing a PDF document with display name, dates, download link, and metadata.
    """
    if policy_number is None or lob is None or company is None:
        return None

    fm = FileManagerFactory.create_file_manager()

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT policies.file_name FROM
                (SELECT p.policy_number, p.file_name, p.transaction_effective_date
                   FROM policy p
                  WHERE p.lob=:lob
                    AND p.policy_number=:policy_number
                    AND p.company=:company
               ORDER BY p.transaction_effective_date DESC) as policies
            GROUP BY policies.policy_number, policies.file_name, policies.transaction_effective_date
            ORDER BY policies.transaction_effective_date DESC
            """
        ).bindparams(
            policy_number=policy_number, lob=lob, company=company
        )

        result = connection.execute(sql)
        row = result.first()
        file_names = []

        if row and row.file_name:
            file_name = row.file_name
            dir_name = fm.join(Repository().policies_location, fm.dirname(file_name))
            file_map = {}
            base_to_file = {}

            # Step 1: Collect and deduplicate PDF files (prefer .pdf.gz)
            for root, dirs, files in fm.walk(dir_name):
                for file in files:
                    lower = file.lower()
                    if not (lower.endswith(".pdf") or lower.endswith(".pdf.gz")):
                        continue
                    if policy_number.lower() not in lower:
                        continue

                    base = file.replace(".pdf.gz", "").replace(".pdf", "")
                    existing = base_to_file.get(base)

                    if existing is None or (existing.endswith(".pdf") and file.endswith(".pdf.gz")):
                        base_to_file[base] = file

            # Step 2: Process each deduplicated file
            for base, file in base_to_file.items():
                try:
                    dt = parser.parse(file.lower().split("_")[1])
                except Exception:
                    continue

                inf_file_name = file.replace(".PDF.gz", "").replace(".PDF", "") + ".INF"
                inf_path = fm.join(dir_name, inf_file_name)

                description = ""
                purpose = ""
                type_code = ""
                inf_lob = ""
                effective_date = None

                if fm.exists(inf_path):
                    try:
                        inf_str = fm.read_string(inf_path)
                        inf_json = json.loads(inf_str)
                        description = inf_json.get("description", "")
                        purpose = inf_json.get("purpose", "")
                        type_code = inf_json.get("type_code", "")
                        inf_lob = inf_json.get("lob", "")
                        effective_date = inf_json.get("transaction_effective_date")
                    except Exception:
                        pass

                if effective_date:
                    try:
                        effective_date = effective_date.split("T")[0]
                        effective_date = datetime.strptime(effective_date, "%Y-%m-%d").date()
                    except Exception:
                        effective_date = None
                if effective_date is None:
                    try:
                        effective_date = base.split("_")[2]
                        effective_date = effective_date.split("T")[0]
                        effective_date = datetime.strptime(effective_date, "%Y%m%d").date()
                    except Exception:
                        pass

                if inf_lob and inf_lob != lob:
                    continue

                # Skip if this INF indicates an MPOI Notice
                if description.strip().startswith("OK - MPOI Notice"):
                    continue

                entry = (*read_display_name(file, purpose, type_code),
                         policy_number,
                         company,
                         lob,
                         file,
                         description,
                         effective_date)

                file_map.setdefault(dt, []).append(entry)

            # Step 3: Sort and prepare response
            file_map = dict(sorted(file_map.items(), key=lambda x: x[0], reverse=True))

            for pdf_effective_date_time in file_map:
                for entry in file_map[pdf_effective_date_time]:
                    download_link = f"broker-api/web/v1/ui/policies/{entry[2]}/{entry[3]}/{entry[4]}/{entry[5]}"
                    current = False

                    if transaction_effective_date is not None and pdf_effective_date_time is not None:
                        if pdf_effective_date_time.date() >= transaction_effective_date:
                            current = True

                    file_names.append({
                        "display_name": entry[0],
                        "display_date": entry[1],
                        "policy_number": entry[2],
                        "company": entry[3],
                        "lob": entry[4],
                        "file_name": entry[5],
                        "description": entry[6],
                        "download_link": download_link,
                        "current": current,
                    })

    return file_names


def list_renewal_pdfs(policy_number, lob, company, file_name, transaction_effective_date=None):
    """
    Retrieve a list of PDF policy documents for a renewal.

    :param policy_number: The policy number.
    :param lob: The line of business.
    :param company: The company code.
    :param file_name: The base file name to find the directory.
    :param transaction_effective_date: If provided, flags files as `current` if their date >= this.
    :return: List of dicts describing each PDF and its metadata.
    """
    if file_name is None:
        return None

    fm = FileManagerFactory.create_file_manager()
    file_names = []
    dir_name = fm.join(Repository.policies_location, fm.dirname(file_name))
    file_map = {}
    base_to_file = {}

    # Step 1: Deduplicate .PDF/.PDF.gz files by base name
    for root, dirs, files in fm.walk(dir_name):
        for file in files:
            lower = file.lower()
            if not (lower.endswith(".PDF") or lower.endswith(".PDF.gz")):
                continue
            if policy_number.lower() not in lower:
                continue

            base = file.replace(".PDF.gz", "").replace(".PDF", "")
            existing = base_to_file.get(base)

            if existing is None or (existing.endswith(".PDF") and file.endswith(".PDF.gz")):
                base_to_file[base] = file

    # Step 2: Process selected files
    for base, file in base_to_file.items():
        try:
            dt = parser.parse(file.lower().split("_")[1])
        except Exception:
            continue

        inf_file_name = file.replace(".pdf.gz", "").replace(".pdf", "") + ".INF"
        inf_path = fm.join(dir_name, inf_file_name)

        original_file_name = ""
        description = ""
        purpose = ""
        type_code = ""
        inf_lob = ""

        if fm.exists(inf_path):
            try:
                inf_str = fm.read_string(inf_path)
                inf_json = json.loads(inf_str)
                description = inf_json.get("description", "")
                purpose = inf_json.get("purpose", "")
                type_code = inf_json.get("type_code", "")
                inf_lob = inf_json.get("lob", "")
            except Exception:
                pass

        if inf_lob and inf_lob != lob:
            continue

        # Skip if this INF indicates an MPOI Notice
        if description.strip().startswith("OK - MPOI Notice"):
            continue

        entry = (*read_display_name(file, purpose, type_code),
                 policy_number,
                 company,
                 lob,
                 file,
                 original_file_name,
                 description)

        file_map.setdefault(dt, []).append(entry)

    # Step 3: Sort and build result
    file_map = dict(sorted(file_map.items(), key=lambda x: x[0], reverse=True))

    for pdf_effective_date_time in file_map:
        for entry in file_map[pdf_effective_date_time]:
            download_link = f"broker-api/web/v1/ui/policies/{entry[2]}/{entry[3]}/{entry[4]}/{entry[5]}"
            current = False

            if transaction_effective_date is not None and pdf_effective_date_time is not None:
                if pdf_effective_date_time.date() >= transaction_effective_date:
                    current = True

            file_names.append({
                "display_name": entry[0],
                "display_date": entry[1],
                "policy_number": entry[2],
                "company": entry[3],
                "lob": entry[4],
                "file_name": entry[5],
                "original_file_name": entry[6],
                "description": entry[7],
                "download_link": download_link,
                "current": current,
            })

    return file_names


def list_policies_by_user_id(user_id, optional_connection=None):
    """
    Retrieve all policies linked to a specific user, ordered by relevance.

    :param user_id: The unique ID of the user.
    :param optional_connection: (Optional) Existing DB connection.
    :return: List of `policy` rows linked to the user, ordered by expiry, XLN, and effective date.
    """
    if user_id is None:
        return None

    with get_connection(optional_connection) as connection:
        sql = """
              SELECT p.*
                FROM policy p, user_policy up
               WHERE up.user_id = :user_id
                 AND p.id = up.policy_id
            """

        # Order by expiry date first so expired policies don't show up ahead of active
        # policies on the policy page.
        sql += """
            ORDER BY 
              p.xln, p.policy_expiry_date DESC, p.transaction_effective_date DESC
        """

        sql = text(sql).bindparams(
            user_id=user_id,
        )

        result = connection.execute(sql)
        rows = result.all()

    return rows


def list_history(policy_number, company, lob, policy_effective_date, seq, optional_connection=None):
    """
    Get all older policy versions for the same policy_number, company, and lob.

    :param policy_number: The policy number.
    :param company: The company code.
    :param lob: The line of business.
    :param policy_effective_date: Cutoff date for history.
     :param seq: Cutoff sequence for history.
    :param optional_connection: Optional DB connection.
    :return: List of historical `policy` rows.
    """
    if policy_number is None or company is None or lob is None:
        return None

    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
             SELECT *
               FROM policy
              WHERE policy_number=:policy_number
                AND company=:company
                AND lob=:lob
                AND (policy_effective_date<:policy_effective_date 
                   OR (policy_effective_date=:policy_effective_date AND seq<:seq))
              ORDER BY policy_effective_date DESC, seq DESC
            """
        ).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob,
            policy_effective_date=policy_effective_date,
            seq=seq
        )).all()

    return rows


def update_file_name(policy_id, file_name, optional_connection=None):
    """
    Update the stored `file_name` for a specific policy.

    :param policy_id: The policy ID to update.
    :param file_name: The new file name to store.
    :param optional_connection: Optional DB connection.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        sql = text(
            """
             UPDATE policy
                SET file_name=:file_name
              WHERE id=:policy_id
            """
        ).bindparams(
            policy_id=policy_id,
            file_name=file_name
        )

        connection.execute(sql)

        if not optional_connection:
            connection.commit()


def map_user(policy_id, user_id, notify=False, optional_connection=None):
    """
    Link a user to a policy.

    :param policy_id: The policy ID to link.
    :param user_id: The user ID to link.
    :param notify: NOtify this user.
    :param optional_connection: Optional DB connection.
    :return: None
    """
    if notify is None:
        notify = False

    with get_connection(optional_connection) as connection:
        sql = text("""
            INSERT IGNORE INTO user_policy (user_id, policy_id, notify)
            VALUES (:user_id, :policy_id, :notify)
        """).bindparams(user_id=user_id, policy_id=policy_id, notify=notify)

        connection.execute(sql)

        if not optional_connection:
            connection.commit()


def update_notify(policy_id, user_id, notify=False, optional_connection=None):
    """
    Update the `notify` flag for a specific user-policy relationship.

    :param policy_id: ID of the policy to update.
    :param user_id: ID of the user linked to the policy.
    :param notify: Boolean indicating whether notifications should be enabled (True) or disabled (False).
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: True if the update was attempted, or False if input was invalid.
    """
    if policy_id is None or user_id is None or notify is None:
        return False

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
              UPDATE user_policy
                 SET notify=:notify                 
               WHERE policy_id=:policy_id
                 AND user_id=:user_id
            """).bindparams(
            notify=notify,
            policy_id=policy_id,
            user_id=user_id))

        if not optional_connection:
            connection.commit()

    return True


def read_pdf(user_obj, policy_number, company, lob, file_name, optional_connection=None):
    """
    Retrieve the actual PDF file contents for a policy, supporting both `.pdf` and `.pdf.gz` files.

    :param user_obj: Authenticated user object (must have `.role` and `.id`)
    :param policy_number: Policy number string
    :param company: Company code string
    :param lob: Line of business string
    :param file_name: Name of the PDF or PDF.GZ file to retrieve
    :param optional_connection: Optional SQLAlchemy connection (used for reuse/transaction)

    :return: Tuple (file_contents: bytes, encoding: str | None)
             - `encoding` is `"gzip"` if the file was read in compressed form
             - `(None, None)` if not found or not authorized
    """
    if user_obj is None or policy_number is None or lob is None or company is None or file_name is None:
        return None, None

    fm = FileManagerFactory.create_file_manager()

    with get_connection(optional_connection) as connection:
        if user_obj.role == "admin":
            sql = text(
                """
                SELECT p.*
                  FROM policy p
                 WHERE p.policy_number=:policy_number
                   AND p.lob=:lob
                   AND p.company=:company
                """
            ).bindparams(
                policy_number=policy_number,
                lob=lob,
                company=company,
            )
        else:
            sql = text(
                """
                SELECT p.*
                  FROM policy p, user_policy up
                 WHERE up.user_id=:user_id
                   AND up.policy_id=p.id
                   AND p.policy_number=:policy_number
                   AND p.lob=:lob
                   AND p.company=:company
                """
            ).bindparams(
                user_id=user_obj.id,
                policy_number=policy_number,
                lob=lob,
                company=company,
            )

        result = connection.execute(sql)
        row = result.first()

        if row is not None:
            full_path = fm.join(Repository.policies_location, company, policy_number, file_name)

            if file_name.lower().endswith(".gz"):
                if fm.exists(full_path):
                    return fm.read_file(full_path), "gzip"
            else:
                gz_path = full_path + ".gz"
                if fm.exists(gz_path):
                    return fm.read_file(gz_path), "gzip"
                elif fm.exists(full_path):
                    return fm.read_file(full_path), None

    return None, None


def read_active_count(search, optional_connection=None):
    """
    Count the number of active policy records, optionally filtered by search.

    :param search: Optional search text.
    :param optional_connection: Optional DB connection.
    :return: Integer count of matching active policies.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT COUNT(p.id) as count
              FROM policy p
             WHERE p.active=1
        """

        if search is not None:
            sql += """
               (p.policy_number LIKE :search 
               OR p.company LIKE :search
               OR p.lob LIKE :search
               OR p.purpose LIKE :search)
            """

        sql = text(sql)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        result = connection.execute(sql)
        row = result.first()

    return row.count


def read_unmapped_count(search=None, optional_connection=None):
    """
    Count the number of active policy records that are not mapped to any user.

    :param search: Optional search filter.
    :param optional_connection: Optional DB connection.
    :return: Integer count of unmapped active policies.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT COUNT(p.id) as count
              FROM policy p
              LEFT JOIN user_policy up ON p.id = up.policy_id
             WHERE p.active = 1
               AND p.xln=0
               AND p.purge=0
               AND p.policy_expiry_date >= CURDATE()               
               AND up.policy_id IS NULL
        """

        if search is not None:
            sql += """
               AND (p.policy_number LIKE :search 
                OR p.company LIKE :search
                OR p.lob LIKE :search
                OR p.purpose LIKE :search)
            """

        sql = text(sql)

        bind_params = {}
        if search is not None:
            bind_params["search"] = "%" + search + "%"

        result = connection.execute(sql, bind_params)
        row = result.first()

    return row.count


def delete_user(policy_id, user_id, optional_connection=None):
    """
    Remove a user-to-policy mapping.

    :param policy_id: The policy ID.
    :param user_id: The user ID.
    :param optional_connection: Optional DB connection.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
            DELETE FROM user_policy
             WHERE user_id = :user_id
               AND policy_id = :policy_id
        """).bindparams(user_id=user_id, policy_id=policy_id)

        connection.execute(sql)

        if not optional_connection:
            connection.commit()


def delete_expired(optional_connection=None):
    """
    Delete policies (and related data) that expired over 2 months ago.

    :param optional_connection: Optional DB connection.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        sql = text(
            """
             SELECT id
               FROM policy
              WHERE policy_expiry_date < DATE_SUB(NOW(), INTERVAL 2 MONTH)
            """
        )
        results = connection.execute(sql)
        rows = results.all()

        for row in rows:
            policy_id = row.id

            sql = text(
                """
                 DELETE
                   FROM policy_issue
                  WHERE policy_id=:policy_id
               """
            ).bindparams(
                policy_id=policy_id,
            )

            connection.execute(sql)

            sql = text(
                """
                 DELETE
                   FROM policy_insured
                  WHERE policy_id=:policy_id
               """
            ).bindparams(
                policy_id=policy_id,
            )

            connection.execute(sql)

            sql = text(
                """
                 DELETE
                   FROM policy
                  WHERE id=:policy_id
               """
            ).bindparams(
                policy_id=policy_id,
            )

            connection.execute(sql)

            if not optional_connection:
                connection.commit()


def delete_by_file(file_name, optional_connection=None):
    """
    Delete a policy (and its related info) by file name.

    :param file_name: The source file name.
    :param optional_connection: Optional DB connection.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        row = connection.execute(text(
            """
            SELECT * 
              FROM policy
             WHERE file_name=:file_name
            """
        ).bindparams(file_name=file_name)).one()

        connection.execute(text(
            """
             DELETE
               FROM policy
              WHERE id=:policy_id
           """
        ).bindparams(policy_id=row.id))

        connection.execute(text(
            """
             DELETE
               FROM policy_insured
              WHERE policy_id=:policy_id
           """
        ).bindparams(policy_id=row.id))

        connection.execute(text(
            """
             DELETE
               FROM policy_issue
              WHERE policy_id=:policy_id
           """
        ).bindparams(policy_id=row.id))

        if not optional_connection:
            connection.commit()


def delete(policy_id, all_versions=True, optional_connection=None):
    """
    Delete a policy and related data.

    :param policy_id: The policy ID.
    :param all_versions: If True, delete all versions. If False, delete only one.
    :param optional_connection: Optional DB connection.
    :return: True if deleted; False if blocked due to user mappings.
    """
    with get_connection(optional_connection) as connection:
        # Make sure no users are mapped to this policy.
        sql = text(
            """
            SELECT * 
              FROM user_policy
             WHERE policy_id=:policy_id
            """
        ).bindparams(policy_id=policy_id)

        result = connection.execute(sql)
        results = result.all()

        if results is not None and len(results) > 0:
            return False

        policy_ids = []

        if not all_versions:
            policy_ids.append(policy_id)
        else:
            policy_obj = connection.execute(text(
                """
                SELECT * 
                  FROM policy
                 WHERE id=:policy_id
                """
            ).bindparams(policy_id=policy_id)).first()

            results = connection.execute(text(
                """
                SELECT * 
                  FROM policy
                 WHERE policy_number=:policy_number
                   AND company=:company
                   AND lob=:lob
                """
            ).bindparams(
                policy_number=policy_obj.policy_number,
                company=policy_obj.company,
                lob=policy_obj.lob
            )).all()

            for row in results:
                policy_ids.append(row.id)

        connection.execute(text(
            """
             DELETE
               FROM policy
              WHERE id in :policy_ids
           """
        ).bindparams(policy_ids=policy_ids))

        connection.execute(text(
            """
             DELETE
               FROM policy_insured
              WHERE policy_id in :policy_ids
           """
        ).bindparams(policy_ids=policy_ids))

        connection.execute(text(
            """
             DELETE
               FROM policy_issue
              WHERE policy_id in :policy_ids
           """
        ).bindparams(policy_ids=policy_ids))

        if not optional_connection:
            connection.commit()

    return True


def read_active_by_policy_number_company(policy_number, company, optional_connection=None):
    """
    Get the active policy version for a policy_number and company.

    :param policy_number: The policy number.
    :param company: The company code.
    :param optional_connection: Optional DB connection.
    :return: The active `policy` row or None.
    """
    if policy_number is None or len(policy_number) <= 0:
        return None

    if company is None or len(company) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT p.*
              FROM policy p
             WHERE p.policy_number=:policy_number
               AND p.company=:company
               AND p.active=1
            """
        ).bindparams(
            policy_number=policy_number,
            company=company,
        )

        result = connection.execute(sql)
        row = result.first()

        if row is None:
            return None

        return row


def read_active_by_policy_number_company_lob(policy_number, company, lob, optional_connection=None):
    """
    Get the active policy version for a policy_number, company, and lob.

    :param policy_number: The policy number.
    :param company: The company code.
    :param lob: The line of business.
    :param optional_connection: Optional DB connection.
    :return: The active `policy` row or None.
    """
    if policy_number is None or len(policy_number) <= 0:
        return None

    if lob is None or len(lob) <= 0:
        return None

    if company is None or len(company) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT p.*
              FROM policy p
             WHERE p.policy_number=:policy_number
               AND p.lob=:lob
               AND p.company=:company
               AND p.active=1
            """
        ).bindparams(
            policy_number=policy_number,
            lob=lob,
            company=company,
        )

        result = connection.execute(sql)
        row = result.first()

        if row is None:
            return None

        return row


def read_active_by_policy_number(policy_number, optional_connection=None):
    """
    Get the active policy version for a policy_number.

    :param policy_number: The policy number.
    :param optional_connection: Optional DB connection.
    :return: The active `policy` row or None.
    """
    if policy_number is None or len(policy_number) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT p.*
              FROM policy p
             WHERE p.policy_number=:policy_number
               AND p.active=1
            """
        ).bindparams(
            policy_number=policy_number,
        )

        result = connection.execute(sql)
        row = result.first()

        if row is None:
            return None

        return row


def read_active_by_policy_number_lob(policy_number, lob, optional_connection=None):
    """
    Get the active policy version for a policy_number and lob.

    :param policy_number: The policy number.
    :param lob: The line of business.
    :param optional_connection: Optional DB connection.
    :return: The active `policy` row or None.
    """
    if policy_number is None or len(policy_number) <= 0 or lob is None or len(lob) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT p.*
              FROM policy p
             WHERE p.policy_number=:policy_number
               AND p.lob=:lob
               AND p.active=1
            """
        ).bindparams(
            policy_number=policy_number,
            lob=lob,
        )

        result = connection.execute(sql)
        row = result.first()

        if row is None:
            return None

        return row


def read_display_name(file_name, purpose, type_code):
    """
    Build a display name for a PDF file based on its parts.

    :param file_name: The file name.
    :param purpose: The AL3 code or purpose string.
    :param type_code: Additional type code.
    :return: (display name, formatted date)
    """
    file_name = file_name.split(".")[0]
    parts = file_name.split("_")

    if len(parts) >= 6:
        date = parts[1]
        dt = datetime.strptime(date, '%Y%m%d')
        date = dt.strftime('%b %d, %Y')

        if purpose in al3_code_display:
            purpose = al3_code_display[purpose]

        return purpose.lower().title(), date

    return file_name, ""


def read_insured_names(policy_id, optional_connection=None):
    if not policy_id:
        return None

    with get_connection(optional_connection) as connection:
        return connection.execute(
            text(
                """
                SELECT *
                  FROM policy_insured
                 WHERE policy_id=:policy_id
                """
            ).bindparams(policy_id=policy_id)
        ).all()


def read_active_files_by_user_id(user_id, optional_connection=None):
    """
    Get all file names for policies linked to a user that are active.

    :param user_id: The user ID.
    :param optional_connection: Optional DB connection.
    :return: List of file names.
    """
    policy_files = []

    if user_id is None or len(user_id) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT p.*
              FROM policy p, user_policy up
             WHERE up.user_id=:user_id
               AND p.id=up.policy_id
               AND p.active=1
            """
        ).bindparams(
            user_id=user_id,
        )

        result = connection.execute(sql)
        rows = result.all()

        for row in rows:
            policy_files.append(row.file_name)

    return policy_files


def resolve_chain_purpose(policy_obj):
    """
    Determine the effective purpose of a policy in the context of a renewal chain.

    :param policy_obj: A policy object with at least id, purpose, policy_number, company, lob,
    transaction_effective_date, seq
    :return: The effective purpose as a string ('RWL', 'PCH', etc.)
    """
    if not policy_obj:
        return None

    # Check if this policy version is even in the indexer
    indexer_row = indexer.read_by_policy_id(policy_obj.id)
    if not indexer_row or indexer_row.failed or indexer_row.name != "index":
        return policy_obj.purpose

    # If it is itself a renewal, return 'RWL'
    if policy_obj.purpose == "RWL":
        return "RWL"

    # Check if it sits on top of an earlier renewal
    with get_connection() as connection:
        result = connection.execute(text(
            """
            SELECT 1
              FROM indexer i
              JOIN policy p ON p.id = i.policy_id
             WHERE i.name = 'index'
               AND i.failed = 0
               AND p.purpose = 'RWL'
               AND p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
               AND (
                    p.transaction_effective_date < :te
                    OR (
                        p.transaction_effective_date = :te
                        AND p.seq < :seq
                    )
               )
             LIMIT 1
            """
        ).bindparams(
            policy_number=policy_obj.policy_number,
            company=policy_obj.company,
            lob=policy_obj.lob,
            te=policy_obj.transaction_effective_date,
            seq=policy_obj.seq
        )).first()

    if result:
        return "RWL"

    return policy_obj.purpose


def read_renewal(policy_number, company, lob, optional_connection=None):
    """
    Determine whether the latest policy in the indexer should be considered part of a renewal chain.

    IMPORTANT:
    -----------------
    This function ensures that a policy is only considered part of a renewal chain if:
      - It is a renewal itself, OR
      - It sits on top of an earlier renewal version that is also in the indexer (i.e., not failed or removed).

    In other words: *being part of a renewal chain means the renewal context is still active in the indexer.*

    :param policy_number: The policy number to check.
    :param company: The company code.
    :param lob: The line of business.
    :param optional_connection: Optional existing DB connection.
    :return: The latest indexer + policy row (as a dict-like object) if part of an active renewal chain, else None.
    """
    if policy_number is None or company is None or lob is None:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
             SELECT p.id, i.latest, i.name, i.file_name, i.policy_id, 
                    i.latest, i.code, i.message, i.entered, i.process, 
                    p.policy_number, p.company, p.lob, p.purpose, p.premium, p.annual_premium, p.seq, 
                    p.transaction_date, p.transaction_effective_date, 
                    p.policy_effective_date, p.policy_expiry_date 
              FROM indexer i
              JOIN policy p ON p.id = i.policy_id
             WHERE i.name = 'index'
               AND i.failed = 0
               AND i.latest = 1
               AND p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
               AND (
                    p.purpose = 'RWL'
                    OR EXISTS (
                        SELECT 1 
                          FROM indexer i2
                          JOIN policy p2 ON p2.id = i2.policy_id
                         WHERE i2.name = 'index'
                           AND i2.failed = 0
                           AND p2.purpose = 'RWL'
                           AND p2.policy_number = p.policy_number
                           AND p2.company = p.company
                           AND p2.lob = p.lob
                           AND (
                                p2.transaction_effective_date < p.transaction_effective_date
                                OR (
                                    p2.transaction_effective_date = p.transaction_effective_date
                                    AND p2.seq < p.seq
                                )
                           )
                    )
               )
             LIMIT 1
            """
        ).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob,
        )

        result = connection.execute(sql)
        row = result.first()

        return row


def read_version(policy_number, company, lob, purpose, transaction_date, seq, optional_connection=None):
    """
    Retrieve a specific policy version by its unique identifying fields.

    :param policy_number: The policy number.
    :param company: The company code.
    :param lob: The line of business.
    :param purpose: The version’s purpose (e.g., RWL, PCH).
    :param transaction_date: The transaction date.
    :param seq: The sequence number.
    :param optional_connection: Optional DB connection.
    :return: The matching `policy` row or None.
    """
    if not policy_number or not lob or not company or not purpose or not transaction_date or not seq:
        return None

    with get_connection(optional_connection) as connection:
        sql = text(
            """
            SELECT p.*
              FROM policy p
             WHERE p.policy_number=:policy_number
               AND p.lob=:lob
               AND p.company=:company
               AND p.purpose=:purpose
               AND p.transaction_date=:transaction_date
               AND p.seq=:seq
            """
        ).bindparams(
            policy_number=policy_number,
            lob=lob,
            company=company,
            purpose=purpose,
            transaction_date=transaction_date,
            seq=seq)

        result = connection.execute(sql)
        row = result.first()

        if row is None:
            return None

        return row


def read_version_latest(policy_number, company, lob, optional_connection=None):
    """
    Get the most recent version for a given policy_number, company, and lob.

    :param policy_number: The policy number.
    :param company: The company code.
    :param lob: The line of business.
    :param optional_connection: Optional DB connection.
    :return: The latest `policy` row or None.
    """
    if not policy_number or not lob or not company:
        return None

    with get_connection(optional_connection) as connection:
        row = connection.execute(
            text(
                """
                SELECT p.*
                  FROM policy p
                 WHERE p.policy_number=:policy_number
                   AND p.lob=:lob
                   AND p.company=:company
                 ORDER BY p.transaction_effective_date DESC, p.seq DESC
                 LIMIT 1
                """
            ).bindparams(
                policy_number=policy_number,
                lob=lob,
                company=company)
        ).first()

        return row if row else None


def read_version_previous(policy_id, optional_connection=None):
    """
    Get the immediate previous version for a given policy ID.

    :param policy_id: The ID of the current version.
    :param optional_connection: Optional DB connection.
    :return: The previous `policy` row or None.
    """
    with get_connection(optional_connection) as connection:
        # Look up the target row first
        row = connection.execute(
            text("""
                SELECT policy_number, company, lob, transaction_effective_date, seq
                FROM policy
                WHERE id = :policy_id
            """).bindparams(policy_id=policy_id)
        ).first()

        if not row:
            return None

        policy_number = row.policy_number
        company = row.company
        lob = row.lob
        transaction_effective_date = row.transaction_effective_date
        seq = row.seq

        prev_row = connection.execute(
            text("""
                SELECT *
                FROM policy
                WHERE policy_number = :policy_number
                  AND company = :company
                  AND lob = :lob
                  AND (
                    transaction_effective_date < :transaction_effective_date
                    OR (
                      transaction_effective_date = :transaction_effective_date
                      AND seq < :seq
                    )
                  )
                ORDER BY transaction_effective_date DESC, seq DESC
                LIMIT 1
            """).bindparams(
                policy_number=policy_number,
                company=company,
                lob=lob,
                transaction_effective_date=transaction_effective_date,
                seq=seq
            )
        ).first()

        return prev_row if prev_row else None


def read_version_by_id(policy_id, optional_connection=None):
    """
    Retrieve a `policy` version by its unique ID.

    :param policy_id: The policy ID.
    :param optional_connection: Optional DB connection.
    :return: The `policy` row or None.
    """
    if policy_id is None:
        return None

    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
              SELECT p.*
                 FROM policy p
                WHERE p.id=:policy_id
            """).bindparams(policy_id=policy_id)).first()


def read_version_by_id_user_id(policy_id, user_id, optional_connection=None):
    """
    Retrieve a policy version by ID but ensure it’s mapped to a user.

    :param policy_id: The policy ID.
    :param user_id: The user ID.
    :param optional_connection: Optional DB connection.
    :return: The `policy` row or None.
    """
    if policy_id is None:
        return None

    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
              SELECT p.*
                 FROM policy p
                INNER JOIN user_policy up 
                        ON p.id=up.policy_id 
                       AND up.user_id=:user_id
                WHERE p.id=:policy_id
            """).bindparams(
            policy_id=policy_id,
            user_id=user_id)
        ).first()
