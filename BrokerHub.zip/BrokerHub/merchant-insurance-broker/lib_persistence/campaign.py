import json
from datetime import datetime

import dateparser
from sqlalchemy.sql import text

from lib_common import constants, exceptions
from lib_common.exceptions import CampaignException, CampaignInactiveException, MissingCampaignException
from lib_persistence import get_connection, notifier, policy, settings, user


def list_templates(campaign_types, rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    """
    Retrieve a list of campaign templates with optional filtering, sorting, and pagination.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign_template` table and selects key fields (`id`, `type`, `name`, `description`, `permanent`).
    - Filters:
        - If `campaign_types` is provided, applies a `type IN (...)` clause.
        - If `search` is provided, filters where `name` or `description` contains the search string.
    - Sorting:
        - If `sort` and `sort_direction` are provided, adds an ORDER BY clause using them directly.
        - Otherwise, sorts by `permanent`.
    - Pagination:
        - If `page` is provided, applies LIMIT and OFFSET based on `rows_per_page` and `page`.

    :param campaign_types: List of campaign types to filter on, or None to include all.
    :param rows_per_page: Number of results to return per page. Defaults to 10 if not provided.
    :param page: Page number (0-based) used to calculate OFFSET. If None, pagination is not applied.
    :param sort: Column name to sort by (e.g., "name", "type").
    :param sort_direction: Sort direction, typically "ASC" or "DESC".
    :param search: Optional keyword to search for in `name` and `description` fields.
    :param optional_connection: Optional existing database connection. If not provided, a new one is created.

    :return: A list of rows representing the selected campaign templates.
    """
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT id, type, name, description, permanent
              FROM campaign_template
              """

        where = ""

        if campaign_types:
            where += " type in :campaign_types"

        if search:
            sql += """
                (name LIKE :search
                  OR description LIKE :search)
            """

        if where:
            sql += " WHERE " + where

        if sort is not None and sort_direction:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction
        else:
            sql = sql + " ORDER BY permanent"

        if page:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if campaign_types:
            sql = sql.bindparams(campaign_types=campaign_types)

        if search:
            sql = sql.bindparams(search="%" + search + "%")

        if page:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def list_forms(campaign_type, rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    """
    Retrieve a list of campaign forms with optional filtering, sorting, and pagination.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign_form` table, selecting `id`, `type`, `name`, and `description`.
    - Filters:
        - If `campaign_type` is provided, applies a `type = :campaign_type` filter.
        - If `search` is provided, matches `name` or `description` using SQL LIKE.
    - Sorting:
        - If both `sort` and `sort_direction` are provided, applies an ORDER BY clause.
        - These values are inserted directly into the SQL string (cannot be bound).
    - Pagination:
        - If `page` is provided, applies LIMIT and OFFSET based on `rows_per_page` and `page`.

    :param campaign_type: Optional campaign type to filter on.
    :param rows_per_page: Number of results to return per page. Defaults to 10 if None.
    :param page: Page number (0-based). If None, pagination is not applied.
    :param sort: Column name to sort by (e.g., "name", "type").
    :param sort_direction: Sort direction ("ASC" or "DESC").
    :param search: Optional keyword to filter by name or description.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of rows representing matching campaign forms.
    """
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT id, type, name, description
              FROM campaign_form
              """

        where = ""

        if campaign_type:
            where += " type=:campaign_type"

        if search:
            sql += """
                (name LIKE :search
                  OR description LIKE :search)
            """

        if where:
            sql += " WHERE " + where

        if sort is not None and sort_direction:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if campaign_type:
            sql = sql.bindparams(campaign_type=campaign_type)

        if search:
            sql = sql.bindparams(search="%" + search + "%")

        if page:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def list_recipients(campaign_id, rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    """
    Retrieve a list of recipients for a given campaign, including user and notification activity details.

    HOW IT WORKS:
    -----------------
    - Joins data from multiple tables:
        - `notifier_recipient` (`nr`) for tracking recipient delivery and engagement.
        - `notifier` (`n`) to get the sent date and link to the campaign.
        - `user` (`u`) and `user_info` (`ui`) for user identity and metadata.
    - Filters:
        - Always filters by `campaign_id`.
        - Optionally filters by `search` keyword, matching against email, account name, or status.
    - Sorting:
        - If `sort` and `sort_direction` are provided, applies an ORDER BY clause using them directly.
    - Pagination:
        - If `page` is provided, applies LIMIT and OFFSET based on `rows_per_page` and `page`.

    :param campaign_id: ID of the campaign whose recipients should be listed.
    :param rows_per_page: Number of results to return per page. Defaults to 10 if None.
    :param page: Page number (0-based). If None, pagination is not applied.
    :param sort: Column name to sort by (e.g., "email", "sent_date", "status").
    :param sort_direction: Sort direction ("ASC" or "DESC").
    :param search: Optional keyword to search against email, account name, or status.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of rows representing matching recipients, including delivery and engagement data.
    """
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT 
                u.id AS user_id,
                u.email, 
                ui.account_name,
                n.sent_date,
                nr.id as notifier_recipient_id,
                nr.status, 
                nr.opens_count, 
                nr.clicks_count
            FROM notifier_recipient nr
            INNER JOIN notifier n
                ON nr.notifier_id = n.id
            INNER JOIN user u
                ON nr.user_id = u.id
            INNER JOIN user_info ui
                ON u.id = ui.user_id    
              """

        where_clause = ["""
            n.campaign_id = :campaign_id
        """]

        if search:
            where_clause.append("""
                (u.email LIKE :search
                  OR ui.account_name LIKE :search
                  OR nr.status LIKE :search)
            """)

        # Apply WHERE clause if any filters exist.
        sql += " WHERE " + " AND ".join(where_clause)

        if sort is not None and sort_direction:
            # For some reason, you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if campaign_id:
            sql = sql.bindparams(campaign_id=campaign_id)

        if search:
            sql = sql.bindparams(search="%" + search + "%")

        if page:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def lookup_template(name, permanent=False, locale='en', optional_connection=None):
    """
    Retrieve a campaign template and its localized content by name.

    HOW IT WORKS:
    -----------------
    - Performs a JOIN between `campaign_template` (`ct`) and `campaign_template_content` (`cc`)
      using the template ID and requested locale.
    - First attempts to find a template with the given `name`, `permanent` status, and specified `locale`.
    - If no match is found, falls back to look for the same template using the `'en'` (English) locale.
    - Returns the first matching result with combined fields from both `campaign_template` and
      `campaign_template_content`.

    :param name: Name of the template to look up.
    :param permanent: Boolean flag indicating whether to search only permanent templates. Defaults to False.
    :param locale: Desired locale code (e.g., 'en', 'fr'). Defaults to 'en'.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: A single row (or None) representing the matched template and its localized content.
    """
    with get_connection(optional_connection) as connection:
        t = connection.execute(text("""
            SELECT ct.*, cc.*
              FROM campaign_template ct
             INNER JOIN campaign_template_content cc 
                ON ct.id=cc.template_id AND locale=:locale
             WHERE ct.name=:name
               AND ct.permanent=:permanent
              """).bindparams(
            name=name,
            permanent=permanent,
            locale=locale if locale is not None else 'en'
        )).first()

        if t is None:
            t = connection.execute(text("""
                SELECT ct.*, cc.*
                  FROM campaign_template ct
                 INNER JOIN campaign_template_content cc 
                    ON ct.id=cc.template_id AND locale=:locale
                 WHERE ct.name=:name
                   AND ct.permanent=:permanent
                  """).bindparams(
                name=name,
                permanent=permanent,
                locale='en'
            )).first()

        return t


def load_template(template_id, optional_connection=None):
    """
    Retrieve a single campaign template by its ID.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign_template` table for a row with the given `template_id`.
    - Expects exactly one result and will raise an exception if none or multiple are found.
    - Returns all fields from the `campaign_template` table.

    :param template_id: ID of the template to retrieve.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: A single row representing the campaign template.
    :raises sqlalchemy.exc.NoResultFound: If no template with the given ID exists.
    :raises sqlalchemy.exc.MultipleResultsFound: If more than one row is returned.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT ct.*
              FROM campaign_template ct
             WHERE ct.id=:template_id
              """).bindparams(
            template_id=template_id,
        )).one()


def load_template_contents(template_id, optional_connection=None):
    """
    Retrieve all localized content entries for a given campaign template.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign_template_content` table for all rows matching the given `template_id`.
    - Each row represents content for a different locale associated with the template.
    - Returns all matching rows.

    :param template_id: ID of the campaign template whose contents should be retrieved.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of rows representing the localized content for the specified template.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT cc.*
              FROM campaign_template_content cc 
             WHERE cc.template_id=:template_id
              """).bindparams(
            template_id=template_id,
        )).all()


def upsert_template(template_id, template_type, name, description, optional_connection=None):
    """
    Insert or update a campaign template record.

    HOW IT WORKS:
    -----------------
    - Attempts to insert a new row into the `campaign_template` table with the given values.
    - If a row with the same `id` already exists, it updates the `type`, `name`, and `description` fields.
    - Sets `permanent = 0` on insert.
    - Commits the transaction if no connection was passed in (i.e., the function opened its own).

    This ensures that a template with the given ID exists and is updated with the latest values.

    :param template_id: ID of the template to insert or update.
    :param template_type: Type/category of the template (e.g., "email", "sms").
    :param name: Display name of the template.
    :param description: Optional description or summary of the template.
    :param optional_connection: Optional existing DB connection. If None, a new one is created and committed.

    :return: None
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT
               INTO campaign_template (id, type, name, description, permanent)
             VALUES (:template_id, :template_type, :name, :description, 0)
                 ON DUPLICATE KEY 
             UPDATE type=:template_type,
                    name=:name,
                    description=:description
           """
        ).bindparams(
            template_id=template_id,
            template_type=template_type,
            name=name,
            description=description,
        ))

        if optional_connection is None:
            connection.commit()


def upsert_template_contents(template_id, contents, optional_connection=None):
    """
    Replace all localized content entries for a given campaign template.

    HOW IT WORKS:
    -----------------
    - Deletes all existing rows in `campaign_template_content` for the given `template_id`.
    - Iterates over the provided `contents` list and inserts or updates each content entry.
    - Each content entry is expected to be a dictionary with keys: `locale`, `subject`, and `body`.
    - Uses helper functions `_delete_template_contents` and `_upsert_template_content` to perform DB operations.
    - Commits the transaction if no connection was passed in (i.e., the function opened its own).

    This ensures that the template's content is fully replaced by the new set of localized entries.

    :param template_id: ID of the campaign template whose content is being updated.
    :param contents: List of dictionaries, each representing localized content:
                     { "locale": str, "subject": str, "body": str }
    :param optional_connection: Optional existing DB connection. If None, a new one is created and committed.

    :return: None
    """
    with get_connection(optional_connection) as connection:
        _delete_template_contents(connection, template_id)
        for content in contents:
            _upsert_template_content(connection, template_id, content["locale"], content["subject"], content["body"])

        if optional_connection is None:
            connection.commit()


def _upsert_template_content(connection, template_id, locale, subject, body):
    """
    Insert or update a localized content entry for a campaign template.

    HOW IT WORKS:
    -----------------
    - Attempts to insert a row into the `campaign_template_content` table using the given `template_id` and `locale`.
    - If a row with the same `template_id` and `locale` already exists, updates the `subject` and `body`.
    - Uses `ON DUPLICATE KEY UPDATE` to handle insert vs update logic.

    :param connection: Active database connection to use.
    :param template_id: ID of the template this content belongs to.
    :param locale: Locale code for the content (e.g., 'en', 'fr').
    :param subject: Subject line of the template content.
    :param body: Body of the template content.

    :return: None
    """
    connection.execute(text(
        """
         INSERT
           INTO campaign_template_content (template_id, locale, subject, body)
         VALUES (:template_id, :locale, :subject, :body)
             ON DUPLICATE KEY 
         UPDATE subject=:subject,
                body=:body
       """
    ).bindparams(
        template_id=template_id,
        subject=subject,
        body=body,
        locale=locale
    ))


def delete_template(template_id, optional_connection=None):
    """
    Delete a campaign template and its localized content, if it is not in use.

    HOW IT WORKS:
    -----------------
    - Checks if any existing campaign is using the template (`campaign.template_id = :template_id`).
        - If found, raises a `CampaignException` with a specific error code and message.
    - If the template is not in use:
        - Deletes the template from `campaign_template`, but only if it is *not* marked as permanent.
        - If the template row is deleted, also deletes all related rows from `campaign_template_content`.
    - Commits the transaction if the function opened its own connection.

    This ensures that templates cannot be deleted if they are still referenced by active campaigns,
    and that associated content is cleaned up only if the template itself was removed.

    :param template_id: ID of the template to delete.
    :param optional_connection: Optional existing DB connection. If None, a new one is created and committed.

    :raises CampaignException: If the template is currently in use by a campaign.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
             SELECT *
               FROM campaign
              WHERE template_id=:template_id
           """
        ).bindparams(
            template_id=template_id)
        ).first()

        if rows:
            raise CampaignException("Template is in use.", error_code=exceptions.CODE_ADMIN_CAMPAIGN_TEMPLATE_IN_USE)

        result = connection.execute(text(
            """
             DELETE
               FROM campaign_template
              WHERE id=:template_id
                AND permanent <> 1
           """
        ).bindparams(
            template_id=template_id)
        )

        if result.rowcount > 0:
            connection.execute(text(
                """
                 DELETE
                   FROM campaign_template_content
                  WHERE template_id=:template_id
               """
            ).bindparams(
                template_id=template_id)
            )

        if optional_connection is None:
            connection.commit()


def _delete_template_contents(connection, template_id):
    """
    Delete all localized content entries for a given campaign template.

    HOW IT WORKS:
    -----------------
    - Deletes all rows from `campaign_template_content` where `template_id` matches the given ID.
    - Intended to be used as a helper function during template updates or deletion.

    :param connection: Active database connection to use.
    :param template_id: ID of the campaign template whose contents should be deleted.

    :return: None
    """
    connection.execute(text(
        """
         DELETE
           FROM campaign_template_content
          WHERE template_id=:template_id
       """
    ).bindparams(
        template_id=template_id)
    )


def execute_campaign(campaign_id,
                     policy_id=None,
                     user_id=None,
                     dry_run=False,
                     notify_now=False,
                     optional_connection=None):
    """
    Execute a campaign by generating a notification and assigning recipients.

    HOW IT WORKS:
    -----------------
    - Loads the campaign object using the provided `campaign_id`.
        - Raises `MissingCampaignException` if not found.
        - Raises `CampaignInactiveException` if the campaign is not active.
    - Determines the list of recipients:
        - If `user_id` is provided, targets that specific user only.
        - Otherwise, runs recipient rules based on campaign type, rules, and trigger event.
    - Checks for an existing draft (`pending`) notification for the campaign and today’s date.
        - If none exists and `dry_run` is False, creates a new notification.
    - For each recipient:
        - Builds a "regarding" context object for the campaign.
        - Adds the recipient to the notification (unless `dry_run` is True).
        - Tracks how many recipients were newly added (vs already present).

    This function does not send the notification—it only prepares and stages it.

    :param campaign_id: ID of the campaign to execute.
    :param user_id: Optional user ID to target a single recipient instead of applying rules.
    :param policy_id: Optional policy ID to target a single policy instead of applying rules.
    :param dry_run: If True, simulate execution without creating notifications or adding recipients.
    :param notify_now: If True, make sure the notification is sent out immediately (don't wait for task_notify).
    :param optional_connection: Optional existing DB connection. If None, new connections are opened as needed.

    :return: Tuple of (existing_recipients_count, new_recipients_count, list_of_new_recipient_objects)
    """
    with get_connection(optional_connection) as connection:
        notifier_id = None
        recipients_added = []
        campaign_obj = load_campaign(campaign_id, optional_connection=connection)

        if campaign_obj is None:
            raise MissingCampaignException("Campaign not found", error_code=exceptions.CODE_ADMIN_CAMPAIGN_MISSING)

        if not campaign_obj.active:
            raise CampaignInactiveException("Campaign is not active",
                                            error_code=exceptions.CODE_ADMIN_CAMPAIGN_INACTIVE)

        # Get a list of campaign recipients.
        if user_id and policy_id:
            recipients = [lookup_recipient_by_policy_id_user_id(policy_id, user_id, optional_connection=connection)]
        elif not user_id and policy_id:
            recipients = lookup_recipients_by_policy_id(policy_id, optional_connection=connection)
        elif user_id:
            recipients = [user.lookup_user_by_id(user_id, optional_connection=connection)]
        else:
            recipients = lookup_recipients_by_type_rules(
                campaign_obj.type,
                campaign_obj.rules,
                campaign_obj.trigger_event,
                optional_connection=connection)

        if recipients:
            # Look to see if we already have a draft notification.
            now = datetime.now().date()
            notifier_id = None

            if not notify_now:
                notifier_id = notifier.get_pending_notification(
                    campaign_obj.id,
                    now,
                    optional_connection=connection)

            if notifier_id is None and not dry_run:
                # Create a notification.
                notifier_id = notifier.create_notification(
                    campaign_obj.id,
                    now,
                    optional_connection=connection)

            # Add the recipients to the notification.
            for recipient in recipients:
                policy_obj = None

                if policy_id:
                    policy_obj = policy.read_version_by_id(policy_id, optional_connection=connection)

                re = build_regarding(
                    campaign_obj,
                    recipient,
                    transaction_effective_date=policy_obj.transaction_effective_date if policy_obj else None,
                    policy_effective_date=policy_obj.policy_effective_date if policy_obj else None,
                    policy_expiry_date=policy_obj.policy_effective_date if policy_obj else None,
                )

                mid = notifier.add_recipient(
                    recipient.id,
                    notifier_id,
                    campaign_obj.id,
                    re,
                    dry_run=dry_run,
                    optional_connection=connection)

                if mid:
                    recipients_added.append(recipient)

        total_recipients = len(recipients) if recipients is not None else 0
        total_new_recipients = len(recipients_added)
        existing_recipients = total_recipients - total_new_recipients

        if optional_connection is None:
            connection.commit()

        return existing_recipients, total_new_recipients, recipients_added, notifier_id


def build_regarding(
        campaign_obj,
        recipient,
        transaction_effective_date=None,
        policy_effective_date=None,
        policy_expiry_date=None,
):
    """
    Construct a "regarding" context object for a campaign recipient, based on campaign type.

    HOW IT WORKS:
    -----------------
    - Only applies to campaigns of type `"policy"`.
    - Builds and returns a dictionary containing key policy-related fields from the recipient,
      along with any optional effective/expiry dates provided.
    - For other campaign types, returns `None`.

    This object is typically attached to a notification to provide context for the recipient,
    such as which policy the message relates to.

    :param campaign_obj: The campaign being executed.
    :param recipient: The recipient object (must have company, policy_number, lob).
    :param transaction_effective_date: Optional date the transaction takes effect.
    :param policy_effective_date: Optional start date of the policy.
    :param policy_expiry_date: Optional end date of the policy.

    :return: A dictionary with policy-related context, or None if not applicable.
    """
    re = None

    if campaign_obj.type == "policy":
        re = {
            "company": recipient.company,
            "policy_number": recipient.policy_number,
            "lob": recipient.lob,
            "transaction_effective_date": transaction_effective_date,
            "policy_effective_date": policy_effective_date,
            "policy_expiry_date": policy_expiry_date,
        }

    return re


def list_campaigns_all(optional_connection=None):
    """
    Retrieve a list of all campaigns, ordered by trigger event.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign` table and selects all columns (`c.*`).
    - Orders the results by the `trigger_event` field.
    - Returns all campaign rows.

    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of campaign rows, ordered by trigger event.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT c.*
              FROM campaign c
             ORDER BY c.trigger_event         
            """)).all()


def list_campaigns_active(optional_connection=None):
    """
    Retrieve a list of all active campaigns.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign` table for rows where `active = 1`.
    - Returns all matching campaign rows.

    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of active campaign rows.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT c.*
              FROM campaign c
             WHERE c.active=1           
            """)).all()


def read_campaign_by_id(campaign_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT c.*
              FROM campaign c
             WHERE c.id = :campaign_id
            """).bindparams(
            campaign_id=campaign_id)
        ).first()


def read_campaign_count(
        campaign_types=None,
        optional_connection=None,
        active=None,
):
    """
    Count the total number of campaigns, with optional filtering by type and active status.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign` table and returns the total count of matching rows.
    - If `campaign_types` is provided, filters to campaigns whose `type` is in the given list.
    - If `active` is provided (True/False), filters by active status.
    - Builds the WHERE clause dynamically based on filters.
    - Binds parameters safely using SQLAlchemy's parameter dictionary.

    :param campaign_types: Optional list of campaign types to filter by.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.
    :param active: Optional boolean to filter by campaign active status. If None, no filter is applied.

    :return: Integer count of matching campaigns.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT count(*) as total
            FROM campaign c
        """

        where_clause = []

        if campaign_types:
            where_clause.append("c.type IN :campaign_types")

        if active is not None:
            where_clause.append("c.active = :active")

        if where_clause:
            sql += " WHERE " + " AND ".join(where_clause)

        sql = text(sql)

        params = {}
        if campaign_types:
            params['campaign_types'] = campaign_types
        if active is not None:
            params['active'] = active

        return connection.execute(sql, params).first().total


def list_campaigns_paged(
        rows_per_page=10,
        page=None,
        sort='trigger_event',
        sort_direction='DESC',
        search=None,
        optional_connection=None,
        campaign_types=None,
        active=None,
):
    """
    Retrieve a paginated list of campaigns with optional filtering, sorting, and search.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign` table and returns a list of campaigns, along with a subquery-calculated
      `total_sent` count indicating how many recipients were sent notifications for each campaign.
    - Filters:
        - If `search` is provided, filters campaigns where `name` or `description` matches the keyword.
        - If `campaign_types` is provided, filters by campaign type.
        - If `active` is provided (True/False), filters by active status.
    - Sorting:
        - Sorts by the specified column and direction. Defaults to `trigger_event DESC`.
    - Pagination:
        - Applies LIMIT and OFFSET if `page` is provided.
    - Uses SQLAlchemy parameter binding for all dynamic inputs except sort direction and column.

    :param rows_per_page: Number of campaigns to return per page. Defaults to 10.
    :param page: Page number (0-based). If None, pagination is not applied.
    :param sort: Column name to sort by (e.g., "name", "trigger_event"). Default is "trigger_event".
    :param sort_direction: Sort direction ("ASC" or "DESC"). Default is "DESC".
    :param search: Optional search term to match against campaign name or description.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.
    :param campaign_types: Optional list of campaign types to filter by.
    :param active: Optional boolean to filter by campaign active status. If None, no filter is applied.

    :return: List of campaign rows, each with an additional `total_sent` field.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT c.*,
            (SELECT COUNT(nr.user_id)
               FROM notifier_recipient nr
              INNER JOIN notifier n on nr.notifier_id=n.id
              INNER JOIN campaign c2 on n.campaign_id=c.id
              WHERE c2.id = c.id AND n.mailbox='sent') as total_sent   
            FROM campaign c
        """

        where_clause = []

        if search:
            where_clause.append("""
                (c.name LIKE :search 
                OR c.description LIKE :search)
            """)

        if campaign_types:
            where_clause.append("c.type IN :campaign_types")

        if active is not None:
            where_clause.append("c.active = :active")

        if where_clause:
            sql += " WHERE " + " AND ".join(where_clause)

        if sort and sort_direction:
            sql += f" ORDER BY {sort} {sort_direction}"

        if page is not None:
            sql += " LIMIT :limit OFFSET :offset"

        sql = text(sql)

        params = {}
        if search:
            params['search'] = f"%{search}%"
        if campaign_types:
            params['campaign_types'] = campaign_types
        if active is not None:
            params['active'] = active
        if page is not None:
            params['offset'] = page * rows_per_page
            params['limit'] = rows_per_page

        result = connection.execute(sql, params)
        return result.all()


def load_campaign(campaign_id, optional_connection=None):
    """
    Retrieve a single campaign by its ID.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign` table for a row with the given `campaign_id`.
    - Expects exactly one result and will raise an exception if none or multiple rows are found.
    - Returns all columns from the `campaign` table.

    :param campaign_id: ID of the campaign to retrieve.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: A single row representing the campaign.
    :raises sqlalchemy.exc.NoResultFound: If no campaign with the given ID exists.
    :raises sqlalchemy.exc.MultipleResultsFound: If more than one row is returned.
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
            SELECT *
              FROM campaign
             WHERE id=:campaign_id
              """).bindparams(campaign_id=campaign_id)
        result = connection.execute(sql)
        return result.one()


def load_campaign_results(campaign_id, optional_connection=None):
    """
    Retrieve summarized email delivery and engagement statistics for a campaign.

    HOW IT WORKS:
    -----------------
    - Aggregates data from the `notifier_recipient` table for all recipients tied to notifications
      belonging to the specified `campaign_id`.
    - Joins `notifier_recipient` (`nr`) to `notifier` (`n`) via `notifier_id`.
    - Computes totals using conditional `SUM()` logic:
        - `total_email_delivered`: Recipients with status = 'delivered'.
        - `total_email_not_delivered`: Recipients with status ≠ 'delivered'.
        - `total_email_bounced`: Recipients with status = 'bounce'.
        - `total_email_views`: Recipients with `opens_count > 0`.
        - `total_email_clicked`: Recipients with `clicks_count > 0`.
    - All totals are explicitly cast as signed integers for clarity and consistency.

    :param campaign_id: ID of the campaign whose results should be summarized.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: A single row containing the five aggregated metrics as named fields.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
        SELECT
            CAST(SUM(CASE WHEN nr.status = 'delivered' THEN 1 ELSE 0 END) AS SIGNED) AS total_email_delivered,
            CAST(SUM(CASE WHEN nr.status != 'delivered' THEN 1 ELSE 0 END) AS SIGNED) AS total_email_not_delivered,
            CAST(SUM(CASE WHEN nr.status = 'bounce' THEN 1 ELSE 0 END) AS SIGNED) AS total_email_bounced,
            CAST(SUM(CASE WHEN nr.opens_count > 0 THEN 1 ELSE 0 END) AS SIGNED) AS total_email_views,
            CAST(SUM(CASE WHEN nr.clicks_count > 0 THEN 1 ELSE 0 END) AS SIGNED) AS total_email_clicked
        FROM
            notifier_recipient nr
        JOIN
            notifier n ON nr.notifier_id = n.id
        WHERE
            n.campaign_id =:campaign_id;   
              """).bindparams(
            campaign_id=campaign_id
        )).one()


def lookup_client_campaign_active(name, permanent=False, optional_connection=None):
    """
    Retrieve an active, client-type campaign by name.

    HOW IT WORKS:
    -----------------
    - Queries the `campaign` table for a campaign that meets all the following criteria:
        - `type = 'client'`
        - `active = 1`
        - Matches the given `name`
        - Matches the given `permanent` flag
    - Returns the first matching row, or None if no match is found.

    :param name: Name of the campaign to look up.
    :param permanent: Whether to limit the search to permanent campaigns. Defaults to False.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: A single campaign row if found, otherwise None.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT c.*
              FROM campaign c
             WHERE c.type='client'
               AND c.active=1
               AND c.permanent=:permanent
               AND c.name=:name
              """).bindparams(
            name=name,
            permanent=permanent
        )).first()


def lookup_policy_campaign_active(
        trigger,
        company,
        lob,
        user_status,
        province,
        premium_change_percent=None,
        optional_connection=None):
    """
    Look up the most relevant active policy-type campaign matching a set of recipient attributes.

    HOW IT WORKS:
    -----------------
    - Filters for campaigns that are:
        - Type = `'policy'`
        - Active
        - Matching the given `trigger_event`
    - Each campaign's `rules` field (stored as JSON) is evaluated against the provided parameters:
        - `company`, `lob`, `user_status`, and `province` must be included in the corresponding rule array
          if that rule is defined.
    - If a campaign fails any applicable rule, it is excluded (`match_score = 0`).
    - Campaigns that pass all applicable rules are assigned a `match_score`, with more specific rules
      (e.g., `companies`, `lobs`) contributing a higher score.
    - If `premium_change_percent` is provided:
        - Campaigns with `apply_change_threshold = true` will only match if the change percent is
          less than or equal to the configured threshold.
    - Returns the highest scoring matching campaign (or `None` if none match).

    :param trigger: The trigger event that initiated the campaign (e.g., "RENEWAL"). Will be uppercased.
    :param company: The company code for the policy. Will be uppercased.
    :param lob: The line of business code for the policy. Will be uppercased.
    :param user_status: The recipient's user status (e.g., "client", "prospect").
    :param province: The recipient's province (e.g., "ON", "NB").
    :param premium_change_percent: Optional float representing percent change in premium.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: The best-matching campaign row, or None if no campaign matches.
    """
    trigger = trigger.upper() if trigger is not None else None
    company = company.upper() if company is not None else None
    lob = lob.upper() if lob is not None else None
    change_threshold = settings.get_setting(constants.SETTING_RENEWALS_REPORT_THRESHOLD)

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT * FROM (
                SELECT c.*,
                   (CASE 
                        WHEN JSON_EXTRACT(c.rules, '$.companies') IS NOT NULL
                         AND JSON_CONTAINS(JSON_EXTRACT(c.rules, '$.companies'), JSON_QUOTE(:company)) = 0
                        THEN 0
                        WHEN JSON_EXTRACT(c.rules, '$.lob') IS NOT NULL
                         AND JSON_CONTAINS(JSON_EXTRACT(c.rules, '$.lob'), JSON_QUOTE(:lob)) = 0
                        THEN 0
                        WHEN JSON_EXTRACT(c.rules, '$.user_statuses') IS NOT NULL
                         AND JSON_CONTAINS(JSON_EXTRACT(c.rules, '$.user_statuses'), JSON_QUOTE(:user_status)) = 0
                        THEN 0
                        WHEN JSON_EXTRACT(c.rules, '$.provinces') IS NOT NULL
                         AND JSON_CONTAINS(JSON_EXTRACT(c.rules, '$.provinces'), JSON_QUOTE(:province)) = 0
                        THEN 0        
                        ELSE 1 +
                            (CASE WHEN JSON_EXTRACT(c.rules, '$.companies') IS NOT NULL THEN 100 ELSE 0 END +
                             CASE WHEN JSON_EXTRACT(c.rules, '$.lobs') IS NOT NULL THEN 50 ELSE 0 END +
                             CASE WHEN JSON_EXTRACT(c.rules, '$.user_statuses') IS NOT NULL THEN 1 ELSE 0 END +
                             CASE WHEN JSON_EXTRACT(c.rules, '$.provinces') IS NOT NULL THEN 1 ELSE 0 END)
                    END) AS match_score
                  FROM campaign c
                 WHERE c.type='policy'
                   AND c.active=1
                   AND c.trigger_event=:trigger
        """

        if premium_change_percent is not None and change_threshold is not None:
            sql += """
                AND (JSON_EXTRACT(c.rules, '$.apply_change_threshold') IS NULL
                     OR JSON_EXTRACT(c.rules, '$.apply_change_threshold')=FALSE  
                     OR :premium_change_percent <= :change_threshold)
            """

        sql += """
            ) AS sorted_campaigns
            WHERE match_score > 0
            ORDER BY match_score DESC
        """

        sql = text(sql).bindparams(
            trigger=trigger,
            company=company,
            lob=lob,
            user_status=user_status,
            province=province
        )

        if premium_change_percent is not None and change_threshold:
            sql = sql.bindparams(
                premium_change_percent=premium_change_percent,
                change_threshold=change_threshold
            )

        return connection.execute(sql).first()


def lookup_policy_recipients_by_policy_id(policy_id, optional_connection=None):
    """
    Retrieve all recipients (users) associated with a specific policy.

    HOW IT WORKS:
    -----------------
    - Joins the following tables:
        - `user` (`u`): Core user account details.
        - `user_info` (`ui`): Additional user metadata.
        - `user_policy` (`up`): Many-to-many join between users and policies.
        - `policy` (`p`): The policy associated with the given ID.
    - Filters to only users linked to the specified `policy_id` via `user_policy`.
    - Returns detailed user and policy information for all matching recipients.

    :param policy_id: ID of the policy for which to retrieve associated recipients.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of rows with user, user_info, and policy details for each recipient.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT u.id, u.email, u.status, u.connected, ui.*, p.policy_number, p.company, p.lob, p.purpose
              FROM user as u, user_policy up, user_info ui, policy p
             WHERE up.policy_id=:policy_id
               AND u.id=up.user_id
               AND ui.user_id=u.id
               AND p.id=up.policy_id
            """).bindparams(
            policy_id=policy_id
        )).all()


def lookup_policy_recipients_by_policy_number_company_lob(policy_number, company, lob, optional_connection=None):
    """
    Retrieve all users associated with a specific policy identified by number, company, and LOB.

    HOW IT WORKS:
    -----------------
    - Joins the following tables:
        - `user` (`u`): Core user account info.
        - `user_info` (`ui`): Extended user metadata.
        - `user_policy` (`up`): Association between users and policies.
        - `policy` (`p`): Filters by policy number, company, and LOB.
    - Groups results by user ID to avoid duplicates.
    - Uses `MAX()` to pull consistent policy details per user (in case of joins to multiple matching records).
    - Returns one row per user with full user info and basic policy context.

    :param policy_number: The policy number to match.
    :param company: The company code to match.
    :param lob: The line of business code to match.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of users associated with the specified policy.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT u.id, u.email, u.status, u.connected, ui.*, 
                   MAX(p.policy_number) AS policy_number,
                   MAX(p.company) AS company,
                   MAX(p.lob) AS lob,
                   MAX(p.purpose) AS purpose
              FROM user AS u
              JOIN user_policy up ON u.id = up.user_id
              JOIN policy p ON p.id = up.policy_id
              JOIN user_info ui ON ui.user_id = u.id
             WHERE p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
             GROUP BY u.id
        """).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob
        )).all()


def lookup_recipient_by_policy_id_user_id(policy_id, user_id, optional_connection=None):
    """
    Retrieve recipient/user information for a given user and policy UUID,
    joining by policy number, company, and line of business.

    HOW IT WORKS:
    -----------------
    - Takes a UUID (`policy_id`) and resolves it to `policy_number`, `company`, and `lob`.
    - Joins the `user`, `user_policy`, `user_info`, and `policy` tables.
    - Filters by the given `user_id` and matching policy metadata.

    :param user_id: ID of the user (integer)
    :param policy_id: UUID of the policy (from `policy.id`)
    :param optional_connection: Optional DB connection

    :return: List of matching rows with joined user and policy data
    """
    with get_connection(optional_connection) as connection:
        # Step 1: Resolve the policy UUID to its key metadata
        result = connection.execute(text("""
            SELECT policy_number, company, lob
              FROM policy
             WHERE id = :policy_id
        """).bindparams(policy_id=policy_id)).fetchone()

        if not result:
            return []

        policy_number, company, lob = result

        # Step 2: Use metadata to look up the recipient
        return connection.execute(text("""
            SELECT u.id, u.email, u.status, u.connected, ui.*, 
                   p.policy_number, p.company, p.lob, p.purpose
              FROM user AS u
              JOIN user_policy up ON u.id = up.user_id
              JOIN user_info ui ON ui.user_id = u.id
              JOIN policy p ON p.id = up.policy_id
             WHERE u.id = :user_id
               AND p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
        """).bindparams(
            user_id=user_id,
            policy_number=policy_number,
            company=company,
            lob=lob
        )).first()


def lookup_recipients_by_policy_id(policy_id, optional_connection=None):
    """
    Retrieve all recipients/users for a given policy UUID,
    matched by policy number, company, and line of business.

    HOW IT WORKS:
    -----------------
    - Resolves the policy UUID (`policy_id`) to `policy_number`, `company`, and `lob`.
    - Joins the `user`, `user_policy`, `user_info`, and `policy` tables.
    - Returns all users who are associated with a matching policy.

    :param policy_id: UUID of the policy (from `policy.id`)
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of matching rows with joined user and policy data
    """
    with get_connection(optional_connection) as connection:
        # Step 1: Resolve the policy UUID to its key metadata
        result = connection.execute(text("""
            SELECT policy_number, company, lob
              FROM policy
             WHERE id = :policy_id
        """).bindparams(policy_id=policy_id)).fetchone()

        if not result:
            return []

        policy_number, company, lob = result

        # Step 2: Use metadata to look up all recipients
        return connection.execute(text("""
            SELECT u.id, u.email, u.status, u.connected, ui.*, 
                   p.policy_number, p.company, p.lob, p.purpose
              FROM user AS u
              JOIN user_policy up ON u.id = up.user_id
              JOIN user_info ui ON ui.user_id = u.id
              JOIN policy p ON p.id = up.policy_id
             WHERE p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
        """).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob
        )).all()


def lookup_recipients_by_type_rules(
        campaign_type,
        rules,
        trigger,
        optional_connection=None):
    """
    Determine and retrieve the list of recipients for a campaign based on its type, rules, and trigger event.

    HOW IT WORKS:
    -----------------
    - Determines recipient lookup strategy based on `campaign_type` and whether a `trigger` is present:
        - If `campaign_type` is `'policy'`:
            - If no `trigger` is provided, the campaign is assumed to apply to *all* relevant policies,
              and recipients are selected using `lookup_policy_recipients_by_rules`.
            - If a `trigger` is present, the campaign is event-driven, and recipients are selected using
              `lookup_indexer_recipients_by_rules`.
        - If `campaign_type` is anything else (e.g., `'client'`), uses `lookup_client_recipients_by_rules`.
    - Returns the resulting list of recipient user objects.

    :param campaign_type: Type of the campaign (e.g., "policy", "client").
    :param rules: Campaign rules as a dictionary (e.g., companies, provinces, statuses).
    :param trigger: Optional trigger event (e.g., "RENEWAL") indicating campaign context.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of recipient user objects, or None if `campaign_type` is not specified.
    """
    if campaign_type is None:
        return None

    if campaign_type == 'policy':
        if not trigger:
            # Policy is not triggered, so we apply this campaign potentially to all policies.
            return lookup_policy_recipients_by_rules(
                rules,
                optional_connection=optional_connection)
        else:
            # Policy is triggered, so we apply this campaign to policies in the indexer.
            return lookup_indexer_recipients_by_rules(
                rules,
                optional_connection=optional_connection)
    else:
        return lookup_client_recipients_by_rules(
            rules,
            optional_connection=optional_connection)


def lookup_policy_recipients_by_rules(rules, optional_connection=None):
    """
    Retrieve users associated with policies that match a given set of campaign rules.

    HOW IT WORKS:
    -----------------
    - Accepts a `rules` object (either a dict or JSON string) that may include filters:
        - `companies`: List of company codes.
        - `lobs`: List of lines of business.
        - `user_statuses`: List of user status values.
        - `provinces`: List of province codes.
    - Joins the following tables:
        - `user` (`u`): User accounts.
        - `user_info` (`ui`): User metadata (used for province).
        - `user_policy` (`up`): Association between users and policies.
        - `policy` (`p`): Filters to policies with a non-null `file_name`.
    - Builds a WHERE clause dynamically based on which rule filters are present.
    - Uses `DISTINCT` to avoid duplicate users across multiple matching policies.

    :param rules: A dictionary or JSON string containing optional filter criteria.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of user rows that match the given policy-based rules.
    """
    if rules and isinstance(rules, str):
        rules = json.loads(rules)

    companies = rules.get('companies')
    lobs = rules.get('lobs')
    user_statuses = rules.get('user_statuses')
    provinces = rules.get('provinces')

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT DISTINCT u.id, u.email, u.status, u.connected, 
                            p.policy_number, p.company, p.lob, p.purpose
              FROM user u
              JOIN user_info ui ON ui.user_id = u.id
              JOIN user_policy up ON up.user_id = u.id
              JOIN policy p ON up.policy_id = p.id
             WHERE p.file_name IS NOT NULL
        """

        where_clause = []
        params = {}

        if companies:
            where_clause.append("p.company IN :companies")
            params["companies"] = tuple(companies)

        if lobs:
            where_clause.append("p.lob IN :lobs")
            params["lobs"] = tuple(lobs)

        if user_statuses:
            where_clause.append("u.status IN :user_statuses")
            params["user_statuses"] = tuple(user_statuses)

        if provinces:
            where_clause.append("ui.province IN :provinces")
            params["provinces"] = tuple(provinces)

        if where_clause:
            sql += " AND " + " AND ".join(where_clause)

        return connection.execute(text(sql), params).all()


def lookup_indexer_recipients_by_rules(rules, optional_connection=None):
    """
    Retrieve users associated with active policies that are present in the indexer and match a given set of rules.

    HOW IT WORKS:
    -----------------
    - Accepts a `rules` object (dict or JSON string) that may include filters:
     - `companies`: List of company codes.
     - `lobs`: List of lines of business.
     - `user_statuses`: List of user status values.
     - `provinces`: List of province codes.
    - Performs multiple joins:
     - `user` (`u`) → `user_policy` → `policy` (`p`) → `policy` alias (`pi`) → `indexer` (`i`)
     - `user_info` (`ui`) for province filtering
    - Filters to:
     - Only active policies (`p.active = 1`)
     - Only policies present in the `indexer` table (via matching `pi.id`)
    - Builds WHERE clause dynamically based on available rule filters.
    - Uses `DISTINCT` to avoid returning duplicate users.

    This is used for trigger-based (e.g., renewal) campaigns, ensuring only indexed policy records are considered.

    :param rules: A dictionary or JSON string containing optional filter criteria.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of user rows associated with matching indexed policies.
    """
    if rules is not None and isinstance(rules, str):
        rules = json.loads(rules)

    companies = rules.get('companies')
    lobs = rules.get('lobs')
    user_statuses = rules.get('user_statuses')
    provinces = rules.get('provinces')

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT DISTINCT u.id, u.email, u.status, u.connected, 
                            p.policy_number, p.company, p.lob, p.purpose
              FROM user u
              JOIN user_policy up ON u.id = up.user_id
              JOIN policy p ON up.policy_id = p.id 
                           AND p.active = 1
              JOIN policy pi ON p.company = pi.company 
                            AND p.policy_number = pi.policy_number 
                            AND p.lob = pi.lob
              JOIN indexer i ON i.policy_id = pi.id
              JOIN user_info ui ON u.id = ui.user_id
        """

        where_clause = []
        params = {}

        if companies:
            where_clause.append("p.company IN :companies")
            params["companies"] = tuple(companies)

        if lobs:
            where_clause.append("p.lob IN :lobs")
            params["lobs"] = tuple(lobs)

        if user_statuses:
            where_clause.append("u.status IN :user_statuses")
            params["user_statuses"] = tuple(user_statuses)

        if provinces:
            where_clause.append("ui.province IN :provinces")
            params["provinces"] = tuple(provinces)

        if where_clause:
            sql += " WHERE " + " AND ".join(where_clause)

        return connection.execute(text(sql), params).all()


def lookup_client_recipients_by_rules(rules, optional_connection=None):
    """
    Retrieve client-type users who match a given set of rule-based filters.

    HOW IT WORKS:
    -----------------
    - Accepts a `rules` object (either a dictionary or JSON string) that may include:
        - `companies`: List of company codes.
        - `lobs`: List of lines of business.
        - `user_statuses`: List of user status values.
        - `provinces`: List of province codes.
        - `policy_required`: If True, only users with at least one policy (`p.file_name IS NOT NULL`) are included.
        - `date_type` = 'date_of_birth' and `date_days`: Filters users whose birthdate matches the current
           date ± offset.
    - Joins:
        - `user` (`u`)
        - `user_info` (`ui`) for metadata and province/date of birth
        - `user_policy` and `policy` (left joins) to allow optional filtering by policy data
    - If `date_of_birth` filtering is active, matches users whose birthdate (month and day) match the computed date.
    - Uses dynamic WHERE clause construction and parameter binding for safety.
    - Groups results by user ID to ensure uniqueness.

    :param rules: Dictionary or JSON string containing optional filters and targeting logic.
    :param optional_connection: Optional existing DB connection. If None, a new one is created.

    :return: List of user IDs matching the specified rules.
    """
    if rules and isinstance(rules, str):
        rules = json.loads(rules)

    companies = rules.get('companies')
    lobs = rules.get('lobs')
    user_statuses = rules.get('user_statuses')
    provinces = rules.get('provinces')
    policy_required = rules.get('policy_required', False)
    policy_not_expired = rules.get('policy_not_expired', False)
    policy_not_cancelled = rules.get('policy_not_cancelled', False)

    date_type = rules.get('date_type')
    date_days = rules.get('date_days')
    date_of_birth = None

    if date_type == 'date_of_birth' and date_days:
        date_of_birth = dateparser.parse(date_days).date()

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT DISTINCT u.id
              FROM user u
              JOIN user_info ui ON ui.user_id = u.id
              LEFT JOIN user_policy up ON up.user_id = u.id
              LEFT JOIN policy p ON up.policy_id = p.id
        """

        where_clause = []
        params = {}

        if date_of_birth:
            where_clause.append(
                "DAY(ui.date_of_birth) = DAY(:date_of_birth) AND MONTH(ui.date_of_birth) = MONTH(:date_of_birth)"
            )
            params["date_of_birth"] = date_of_birth

        if policy_required:
            where_clause.append("(p.active=1 AND p.file_name IS NOT NULL)")

        if policy_not_expired:
            where_clause.append("(p.active=1 AND p.policy_expiry_date >= CURRENT_DATE)")

        if policy_not_cancelled:
            where_clause.append("(p.active=1 AND p.xln=0)")

        if companies:
            where_clause.append("p.company IN :companies")
            params["companies"] = tuple(companies)

        if lobs:
            where_clause.append("p.lob IN :lobs")
            params["lobs"] = tuple(lobs)

        if user_statuses:
            where_clause.append("u.status IN :user_statuses")
            params["user_statuses"] = tuple(user_statuses)

        if provinces:
            where_clause.append("ui.province IN :provinces")
            params["provinces"] = tuple(provinces)

        if where_clause:
            sql += " WHERE " + " AND ".join(where_clause)

        return connection.execute(text(sql), params).all()


def upsert_campaign(
        campaign_id,
        active,
        approval,
        marketing,
        campaign_type,
        name,
        description,
        reply_to,
        template_id,
        form_id,
        scheduled,
        trigger,
        rules,
        optional_connection=None):
    """
    Insert or update a campaign record.

    HOW IT WORKS:
    -----------------
    - Attempts to insert a new row into the `campaign` table using the provided fields.
    - If a campaign with the same `id` already exists, updates its fields with the provided values.
    - Uses MySQL's `ON DUPLICATE KEY UPDATE` clause for upsert behavior.
    - Commits the transaction if no external connection was passed in.

    Fields handled:
    - `active`, `approval`, `marketing`: Boolean flags indicating campaign state and visibility.
    - `type`: Type of campaign (e.g., 'client', 'policy').
    - `name`, `description`: Campaign metadata.
    - `reply_to`: Email address used as reply-to.
    - `template_id`, `form_id`: Links to associated campaign template and form.
    - `scheduled`: Boolean indicating whether the campaign runs on a schedule.
    - `trigger_event`: Optional event that triggers the campaign (e.g., 'RENEWAL').
    - `rules`: JSON-encoded string defining targeting criteria.

    :param campaign_id: Unique ID of the campaign.
    :param active: Whether the campaign is currently active.
    :param approval: Whether the campaign requires or has received approval.
    :param marketing: Whether this is a marketing campaign.
    :param campaign_type: Type of campaign (e.g., 'client', 'policy').
    :param name: The display name of the campaign.
    :param description: Optional campaign description.
    :param reply_to: Email address used as the reply-to in notifications.
    :param template_id: ID of the associated template.
    :param form_id: ID of the associated form (if any).
    :param scheduled: Whether the campaign is scheduled to run periodically.
    :param trigger: Optional trigger event name.
    :param rules: JSON string defining the campaign's targeting rules.
    :param optional_connection: Optional existing DB connection. If None, a new one is created and committed.

    :return: None
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT
               INTO campaign (
                    id, active, approval, marketing, type, name, description, reply_to,
                    template_id, form_id, scheduled, trigger_event, rules)
             VALUES (:campaign_id, :active, :approval, :marketing, 
                     :campaign_type, :name, :description, :reply_to, :template_id, :form_id,
                     :scheduled, :trigger, :rules)
                 ON DUPLICATE KEY UPDATE 
                    active=:active,
                    approval=:approval,
                    marketing=:marketing,
                    name=:name,
                    description=:description,
                    reply_to=:reply_to,
                    template_id=:template_id,
                    form_id=:form_id,
                    scheduled=:scheduled,
                    trigger_event=:trigger,
                    rules=:rules
           """
        ).bindparams(
            campaign_id=campaign_id,
            active=active,
            approval=approval,
            marketing=marketing,
            campaign_type=campaign_type,
            name=name,
            description=description,
            reply_to=reply_to,
            template_id=template_id,
            form_id=form_id,
            scheduled=scheduled,
            trigger=trigger,
            rules=rules
        ))

        if optional_connection is None:
            connection.commit()


def delete_campaign(campaign_id, optional_connection=None):
    """
    Delete a campaign if it has no associated notifications.

    HOW IT WORKS:
    -----------------
    - Attempts to delete the campaign row from the `campaign` table by `campaign_id`.
    - After deletion, checks the `notifier` table to see if any notifications still reference the campaign.
        - If found, raises a `CampaignException` indicating the campaign is still in use.
    - Commits the transaction if the function created its own connection.

    **Important:** The campaign is deleted *before* checking for outstanding notifications,
    which assumes a constraint or cascade behavior, prevents orphaned references. If not, this check
    may need to happen first.

    :param campaign_id: ID of the campaign to delete.
    :param optional_connection: Optional existing DB connection. If None, a new one is created and committed.

    :raises CampaignException: If any notifications are found, that still reference the campaign.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM campaign
              WHERE id=:campaign_id
           """
        ).bindparams(
            campaign_id=campaign_id
        ))

        rows = connection.execute(text(
            """
             SELECT *
               FROM notifier
              WHERE campaign_id=:campaign_id
           """
        ).bindparams(
            campaign_id=campaign_id)
        ).first()

        if rows:
            raise CampaignException(
                "Campaign has outstanding notifications.",
                error_code=exceptions.CODE_ADMIN_CAMPAIGN_IN_USE
            )

        if optional_connection is None:
            connection.commit()
