import logging
import os
from contextlib import contextmanager

import sqlalchemy as db
from sqlalchemy import MetaData

from lib_common import constants
from lib_common.constants import LOGGER
from lib_vault.vault import Vault

log = logging.getLogger(LOGGER)
meta = MetaData()

_db_engine = None


def initialize_persistence(force=False):
    """
    Initialize and return the global database engine for use in the application.

    HOW IT WORKS:
    -----------------
    - If the global `_db_engine` has not been initialized yet, or `force=True` is passed,
      retrieves database credentials from Vault and creates a new SQLAlchemy engine.
    - The connection string is assembled using:
        - `SETTING_DB_USER`
        - `SETTING_DB_PASSWORD`
        - `SETTING_DB_HOST`
        - `SETTING_DB_NAME`
    - The resulting engine uses a pooled connection configuration:
        - `pool_pre_ping=True` ensures dead connections are detected and recycled.
        - `pool_recycle=3600` refreshes connections hourly to avoid timeout issues.
        - `pool_size=50`, `max_overflow=50` define the connection pool behavior.
    - Logs the initialization event, including the current process ID.

    :param force: If True, forces reinitialization of the engine even if one already exists.
    :return: A SQLAlchemy engine connected to the configured MySQL database.
    """
    global _db_engine
    if _db_engine is None or force:
        vault = Vault()  # Uses pre-initialized Vault singleton
        db_user = vault.get(constants.SETTING_DB_USER)
        db_password = vault.get(constants.SETTING_DB_PASSWORD)
        db_host = vault.get(constants.SETTING_DB_HOST)
        db_name = vault.get(constants.SETTING_DB_NAME)

        db_conn_str = f"mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}"
        _db_engine = db.create_engine(
            db_conn_str,
            pool_pre_ping=True,
            pool_recycle=3600,
            pool_size=50,
            max_overflow=50,
        )
        log.info(f"Persistence initialized for process {os.getpid()}: {_db_engine}")
    return _db_engine


def get_db_engine():
    """
    Return the global SQLAlchemy database engine, initializing it if necessary.

    HOW IT WORKS:
    -----------------
    - Checks if the global `_db_engine` has been initialized.
        - If not, calls `initialize_persistence()` to create it using Vault-provided credentials.
    - Returns the shared engine instance for use throughout the application.

    :return: The global SQLAlchemy engine instance.
    """
    global _db_engine
    if _db_engine is None:
        initialize_persistence()
    return _db_engine


@contextmanager
def get_connection(optional_connection=None):
    """
    Context manager that yields a database connection.

    HOW IT WORKS:
    -----------------
    - If an existing `optional_connection` is provided, yields it directly.
    - Otherwise, opens a new connection from the global SQLAlchemy engine and yields it
      within a context that automatically handles closing.
    - Intended to simplify connection handling across persistence functions and ensure
      consistency whether a connection is passed in or not.

    :param optional_connection: An existing SQLAlchemy connection object, or None to create a new one.
    :yield: A usable SQLAlchemy connection.
    """
    if optional_connection is None:
        with get_db_engine().connect() as conn:
            yield conn
    else:
        yield optional_connection
