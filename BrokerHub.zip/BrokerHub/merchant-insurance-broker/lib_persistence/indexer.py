import uuid
from datetime import datetime
from typing import List, Optional, Union

from sqlalchemy import text

from lib_common import constants
from lib_common.routes_support import rows_to_list
from lib_persistence import get_connection, persistence, settings


def update_hold_by_policy_id(policy_id: str, hold: bool, msg: Optional[str] = None, optional_connection=None):
    """
    Update an indexer operation hold by policy id.

    :param policy_id: Policy id used to locate the indexer entry to update.
    :param hold: On hold or not.
    :param msg: Message to set if entry is going on hold.
    :param optional_connection: Optional existing DB connection to use.
    :return: None
    """
    if not policy_id:
        return

    message = msg if msg and hold else None

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
            UPDATE indexer
               SET hold=:hold,
                   message=:message
             WHERE policy_id=:policy_id
        """), {
            "policy_id": policy_id,
            "hold": hold,
            "message": message
        })

        if not optional_connection:
            connection.commit()


def update_hold(indexer_id: str, hold: bool, msg: Optional[str] = None, optional_connection=None):
    """
    Update an indexer operation hold.

    :param indexer_id: Entry to update.
    :param hold: On hold or not.
    :param msg: Message to set if entry is going on hold.
    :param optional_connection: Optional existing DB connection to use.
    :return: None
    """
    if not indexer_id:
        return

    message = msg if msg and hold else None

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
            UPDATE indexer
               SET hold=:hold,
                   message=:message
             WHERE id=:indexer_id
        """), {
            "indexer_id": indexer_id,
            "hold": hold,
            "message": message
        })

        if not optional_connection:
            connection.commit()


def update_block(indexer_id: str, block: bool, msg: Optional[str] = None, optional_connection=None):
    """
    Block/Unblock an indexer operation.

    :param indexer_id: Entry id to block.
    :param block: Blocked or not.
    :param msg: Message to set if entry is going on hold.
    :param optional_connection: Optional existing DB connection to use.
    :return: None
    """
    if not indexer_id:
        return

    message = msg if msg and block else None

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
            UPDATE indexer
               SET block=:block,
                   message=:message
             WHERE id=:indexer_id
        """), {
            "indexer_id": indexer_id,
            "block": block,
            "message": message
        })

        if not optional_connection:
            connection.commit()


def is_policy_on_hold(policy_number: str, company: str, lob: str, optional_connection=None) -> bool:
    """
    Check whether a policy is marked as on hold in the indexer.

    Args:
        policy_number: The policy number to check.
        company: The company code.
        lob: The line of business code.
        optional_connection: Optional SQLAlchemy connection/engine; if not provided,
                             a new one will be obtained via get_connection().

    Returns:
        True if the policy is on hold, False otherwise.
    """
    if not (policy_number and company and lob):
        return False

    with get_connection(optional_connection) as connection:
        return connection.execute(
            text("""
                SELECT 1
                  FROM indexer i, policy p
                 WHERE i.policy_id = p.id
                   AND p.policy_number = :policy_number
                   AND p.company = :company
                   AND p.lob = :lob
                   AND i.hold = 1
                 LIMIT 1
            """), {
                "policy_number": policy_number,
                "company": company,
                "lob": lob
            }).scalar() is not None


def file_name_exists(file_name):
    """
    Check whether a specific file name already exists in the indexer table.

    :param file_name: The exact file name to check for in the indexer table.
    :return: True if the file name exists, False if it does not.
    """
    with get_connection() as connection:
        return connection.execute(text("""
                SELECT file_name
                  FROM indexer
                 WHERE file_name=:file_name
           """).bindparams(
            file_name=file_name,
        )).rowcount > 0


def read_by_policy_id(policy_id, optional_connection=None):
    """
    Retrieve the indexer row for a specific policy ID.

    :param policy_id: The ID of the policy to look up.
    :param optional_connection: Optional existing DB connection.
    :return: A row (RowProxy or Row) from the indexer table, or None if not found.
    """
    if policy_id is None:
        return None

    with get_connection(optional_connection) as connection:
        sql = text("""
            SELECT *
              FROM indexer
             WHERE policy_id = :policy_id
             LIMIT 1
        """)

        result = connection.execute(sql, {"policy_id": policy_id})
        return result.first()


def read_latest_renewal_by_number_company_lob(policy_number, company, lob, optional_connection=None):
    """
    Find the most recent renewal-related policy for a given (policy_number, company, lob),
    but only if it is part of a renewal chain (either a renewal itself or chained to one).

    :param policy_number: The policy number to find.
    :param company: The company for the policy.
    :param lob: The line of business for the policy.
    :param optional_connection: Optional existing DB connection.
    :return: The latest renewal-related indexer + policy row, or None if not part of a renewal chain.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT 
                i.id, i.latest, i.name, i.file_name, i.policy_id, i.code, i.message, i.entered, i.process,
                p.policy_number, p.company, p.lob, p.purpose, p.premium, p.annual_premium, p.seq, 
                p.transaction_date, p.transaction_effective_date, p.policy_effective_date, p.policy_expiry_date 
              FROM indexer i
              JOIN policy p ON p.id = i.policy_id
             WHERE i.latest = 1
               AND i.name = 'index'
               AND i.failed = 0
               AND p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
               AND i.in_renewal_chain = 1
             ORDER BY p.transaction_date DESC, p.seq DESC
             LIMIT 1
        """

        return connection.execute(
            text(sql).bindparams(
                policy_number=policy_number,
                company=company,
                lob=lob
            )
        ).first()


def add_to_indexer(indexer_name,
                   file_name,
                   policy_id=None,
                   process=None,
                   optional_connection=None):
    """
    Insert a new entry into the `indexer` table for tracking a file or policy task.

    :param indexer_name: The type or name of the indexer batch/job.
    :param file_name: The file name to track.
    :param policy_id: (Optional) The policy ID this file/task is linked to.
    :param process: (Optional) A future process date/time. If None, the task is ready immediately.
    :param optional_connection: (Optional) An existing DB connection. If not provided, a new one is opened and
    committed.
    :return: The ID of the new indexer record.
    """
    with get_connection(optional_connection) as connection:
        mid = uuid.uuid1().hex

        # Insert the new entry.
        connection.execute(text("""
             INSERT INTO indexer (
                id, 
                name,
                failed, 
                file_name, 
                policy_id,
                entered,
                process
                )
             VALUES (
                :id,
                :indexer_name,
                0,
                :file_name,
                :policy_id,
                :entered,
                :process
                )
        """).bindparams(
            id=mid,
            indexer_name=indexer_name,
            file_name=file_name,
            policy_id=policy_id,
            entered=datetime.now(),
            process=process
        ))

        if indexer_name == persistence.INDEXER_INDEX:
            mark_latest(policy_id, optional_connection=connection)

        if not optional_connection:
            connection.commit()

    return mid


def update_name(row_id, name, policy_id=None, optional_connection=None):
    """
    Update the `name` field of a specific indexer row by its ID.

    NOTE:
    -----------------
    - `mark_latest` is only triggered when the new `name` is exactly `persistence.INDEXER_INDEX`
      and a valid `policy_id` is provided.

    :param row_id: The unique ID of the indexer row to update.
    :param name: The new `name` value to assign.
    :param policy_id: (Optional) The policy ID to pass to `mark_latest` if applicable.
    :param optional_connection: (Optional) An existing DB connection. If not provided, a new one is opened and
    committed.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE indexer
                SET name = :name
              WHERE id = :row_id
        """).bindparams(
            row_id=row_id,
            name=name)
        )

        if name == persistence.INDEXER_INDEX and policy_id is not None:
            mark_latest(policy_id, optional_connection=connection)

        if not optional_connection:
            connection.commit()


def update_file_name(row_id, file_name, optional_connection=None):
    """
    Update the `file_name` of a specific indexer row by its ID.

    NOTE:
    -----------------
    - This change is permanent and may affect how the row is processed or referenced.
    - Ensure the new `file_name` is unique if your workflows rely on unique file names.

    :param row_id: The unique ID of the indexer row to update.
    :param file_name: The new file name to assign.
    :param optional_connection: (Optional) An existing DB connection. If not provided, a new one is opened and
    committed.

    :return: None
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE indexer
                SET file_name = :file_name
              WHERE id = :row_id
        """).bindparams(
            row_id=row_id,
            file_name=file_name)
        )

        if not optional_connection:
            connection.commit()


def mark_latest(policy_id, optional_connection=None):
    """
    Mark the most recent indexer entry for a policy as the latest version,
    and update the `in_renewal_chain` flag on policies in that group.

    :param policy_id: The unique ID of the policy to update.
    :param optional_connection: An optional DB connection to use for consistency in batch operations.
    :return: None
    """
    if policy_id is None:
        return

    with get_connection(optional_connection) as connection:
        # Lookup the identifying info for this policy group.
        p = connection.execute(text("""
             SELECT policy_number, company, lob
               FROM policy
              WHERE id = :policy_id
        """).bindparams(policy_id=policy_id)).first()

        if p is None:
            return

        # Clear latest flag for all entries in the same policy group.
        connection.execute(text("""
             UPDATE indexer
                SET latest = 0
              WHERE name = 'index'
                AND policy_id IN (
                    SELECT id
                      FROM policy
                     WHERE policy_number = :policy_number
                       AND company = :company
                       AND lob = :lob
                )
        """).bindparams(
            policy_number=p.policy_number,
            company=p.company,
            lob=p.lob
        ))

        # Find the most recent version for this policy group.
        row = connection.execute(text("""
             SELECT i.id
               FROM indexer i, policy p
              WHERE i.name = 'index'
                AND i.policy_id = p.id
                AND p.policy_number = :policy_number
                AND p.company = :company
                AND p.lob = :lob
              ORDER BY p.transaction_date DESC, seq DESC
              LIMIT 1
        """).bindparams(
            policy_number=p.policy_number,
            company=p.company,
            lob=p.lob
        )).first()

        if row is not None:
            # Mark the most recent entry as latest.
            connection.execute(text("""
                UPDATE indexer
                   SET latest = 1
                 WHERE id = :id
            """).bindparams(id=row.id))

        update_renewal_chain_flag(p.policy_number, p.company, p.lob, optional_connection=connection)

        # Final commit (only if we're managing the connection here).
        if optional_connection is None:
            connection.commit()


def mark_latest_by_policy_company_lob(policy_number, company, lob, optional_connection=None):
    """
    Mark the most recent indexer entry as the latest for a given policy group,
    and update the `in_renewal_chain` flag based on renewal chain logic.

    :param policy_number: The policy number that identifies the policy group.
    :param company: The company code for the policy.
    :param lob: The line of business for the policy.
    :param optional_connection: An optional DB connection to use for consistency in batch operations.
    :return: None
    """
    if policy_number is None or company is None or lob is None:
        return

    with get_connection(optional_connection) as connection:
        # Clear all latest flags for the group
        connection.execute(text("""
             UPDATE indexer
                SET latest = 0
              WHERE name = 'index' 
                AND policy_id IN (
                    SELECT p.id
                      FROM policy p
                     WHERE p.policy_number = :policy_number
                       AND p.company = :company
                       AND p.lob = :lob         
                ) 
        """).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob
        ))

        # Find the most recent version for this policy group
        row = connection.execute(text("""
             SELECT i.id
               FROM indexer i, policy p
              WHERE i.name = 'index'
                AND i.policy_id = p.id
                AND p.policy_number = :policy_number
                AND p.company = :company
                AND p.lob = :lob
              ORDER BY p.transaction_date DESC, seq DESC
              LIMIT 1
        """).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob
        )).first()

        if row is not None:
            # Mark as latest
            connection.execute(text("""
                UPDATE indexer
                   SET latest = 1
                 WHERE id = :id
            """).bindparams(id=row.id))

        update_renewal_chain_flag(policy_number, company, lob, optional_connection=connection)

        # Final commit (only if we're managing the connection here).
        if optional_connection is None:
            connection.commit()


def update_renewal_chain_flag(policy_number, company, lob, optional_connection=None):
    """
    Set the `in_renewal_chain` flag in the indexer table for all relevant versions
    of a given (policy_number, company, lob) group.
    """
    with get_connection(optional_connection) as connection:
        # Step 1: Clear all flags for this group
        connection.execute(text("""
            UPDATE indexer i
              JOIN policy p ON p.id = i.policy_id
               SET i.in_renewal_chain = 0
             WHERE p.policy_number = :policy_number
               AND p.company = :company
               AND p.lob = :lob
        """).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob
        ))

        # Step 2: Get IDs of indexer rows to flag
        result = connection.execute(text("""
            SELECT idx.id
              FROM policy pr_inner
              JOIN indexer idx ON pr_inner.id = idx.policy_id
             WHERE idx.name = 'index'
               AND idx.failed = 0
               AND pr_inner.policy_number = :policy_number
               AND pr_inner.company = :company
               AND pr_inner.lob = :lob
               AND (
                    pr_inner.purpose = 'RWL'
                 OR EXISTS (
                      SELECT 1
                        FROM policy p2
                        JOIN indexer idx2 ON p2.id = idx2.policy_id
                       WHERE idx2.name = 'index'
                         AND idx2.failed = 0
                         AND p2.purpose = 'RWL'
                         AND p2.policy_number = pr_inner.policy_number
                         AND p2.company = pr_inner.company
                         AND p2.lob = pr_inner.lob
                         AND (
                              p2.transaction_effective_date < pr_inner.transaction_effective_date
                           OR (
                                p2.transaction_effective_date = pr_inner.transaction_effective_date
                            AND p2.seq <= pr_inner.seq
                           )
                         )
                         AND p2.id != pr_inner.id
                 )
               )
        """).bindparams(
            policy_number=policy_number,
            company=company,
            lob=lob
        ))

        ids_to_update = [row[0] for row in result.fetchall()]

        # Step 3: Update only those indexer rows
        if ids_to_update:
            connection.execute(
                text("UPDATE indexer SET in_renewal_chain = 1 WHERE id IN :ids")
                .bindparams(ids=tuple(ids_to_update))
            )

        if optional_connection is None:
            connection.commit()


def get_indexer_files(
        indexer_name: Union[str, List[str]],
        ignore_process_date: bool = True,
        optional_connection=None,
):
    """
    Retrieve indexer records by one or more names, optionally filtering on process date.

    :param indexer_name: A string or list of indexer job/task names to retrieve.
    :param ignore_process_date: If True, ignore `process` timestamps; if False, filter for only ready tasks.
    :param optional_connection: Optional DB connection for transactional consistency.
    :return: A list of rows with indexer and policy details.
    """
    # Normalize to list
    names = [indexer_name] if isinstance(indexer_name, str) else list(indexer_name)

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT i.id, i.latest, i.in_renewal_chain, i.name, i.file_name, i.policy_id, i.entered, i.process, 
                   p.policy_number, p.company, p.lob, p.purpose, p.premium, p.annual_premium, p.seq, 
                   p.transaction_date, p.transaction_effective_date, 
                   p.policy_effective_date, p.policy_expiry_date
              FROM indexer i
              LEFT OUTER JOIN policy p
                ON i.policy_id = p.id
             WHERE i.name IN :indexer_names
               AND i.failed = 0
        """

        if not ignore_process_date:
            sql += " AND (i.process IS NULL OR i.process < NOW())"

        sql += " ORDER BY i.process ASC, p.seq ASC"

        result = connection.execute(
            text(sql).bindparams(indexer_names=tuple(names))
        )
        return result.all()


def get_indexer_files_between_dates(start_date, end_date, optional_connection=None):
    """
    Retrieve all indexer records that were entered within a specified date range.

    :param start_date: Start of the date range (inclusive).
    :param end_date: End of the date range (inclusive).
    :param optional_connection: Optional DB connection for transactional consistency.
    :return: A list of dictionaries describing each indexer entry in the date range.
    """
    with get_connection(optional_connection) as connection:
        rows = connection.execute(text("""
             SELECT id, name, file_name, entered, process
               FROM indexer
              WHERE entered >= :start_date
                AND entered <= :end_date
              ORDER BY entered ASC
           """).bindparams(
            start_date=start_date,
            end_date=end_date
        )).all()

        return [{
            "id": r.id,
            "name": r.name,
            "file_name": r.file_name,
            "entered": r.entered,
            "process": r.process,
        } for r in rows]


def get_failed_indexer_files(optional_connection=None):
    """
    Retrieve all indexer records that have been marked as failed.

    :param optional_connection: Optional DB connection for transactional consistency.
    :return: A list of dictionaries, each describing a failed indexer record.
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
             SELECT id, name, file_name, message, entered, process
               FROM indexer
              WHERE failed = 1
           """)

        result = connection.execute(sql)

        return [{
            "id": r.id,
            "name": r.name,
            "file_name": r.file_name,
            "message": r.message,
            "entered": r.entered,
            "process": r.process,
        } for r in result]


def mark_indexer_failed(row_id, message=None, code=None, optional_connection=None):
    """
    Mark a specific indexer row as failed, optionally recording an error code and message.

    NOTE:
    -----------------
    - If `message` is longer than 255 characters, it will be truncated.
    - The `row_id` must match an existing indexer row.

    :param row_id: The unique ID of the indexer row to mark as failed.
    :param message: Optional error message explaining the failure (truncated to 255 chars).
    :param code: Optional numeric or status code describing the error.
    :param optional_connection: Optional DB connection to reuse in a transaction.
    :return: None
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
             UPDATE indexer
                SET failed = 1,
                    code = :code,
                    message = :message
              WHERE id = :row_id
           """).bindparams(
            row_id=row_id,
            code=code,
            message=message[:255] if message is not None else None
        )

        connection.execute(sql)

        if not optional_connection:
            connection.commit()


def remove_from_indexer_by_filename(file_name, recalculate_flags=True, optional_connection=None):
    """
    Remove all indexer rows matching the given file name.

    If `recalculate_flags=True`, updates 'latest' and 'in_renewal_chain' flags
    for each affected (policy_number, company, lob) group — if the policy exists.

    :param file_name: The name of the file to remove from indexer.
    :param recalculate_flags: Whether to recompute latest/chain flags after deletion.
    :param optional_connection: Optional DB connection to reuse in a transaction.
    """
    with get_connection(optional_connection) as connection:
        # Step 1: Find affected policy groups (even if some are missing)
        sql_get_affected = """
            SELECT DISTINCT p.policy_number, p.company, p.lob
              FROM indexer i
         LEFT JOIN policy p ON p.id = i.policy_id
             WHERE i.file_name = :file_name
        """
        affected = connection.execute(text(sql_get_affected), {"file_name": file_name}).fetchall()

        # Step 2: Delete matching indexer rows
        sql_delete = "DELETE FROM indexer WHERE file_name = :file_name"
        connection.execute(text(sql_delete), {"file_name": file_name})

        # Step 3: Optionally update flags for valid policy groups
        if recalculate_flags:
            for row in affected:
                if row.policy_number and row.company and row.lob:
                    mark_latest_by_policy_company_lob(
                        row.policy_number,
                        row.company,
                        row.lob,
                        optional_connection=connection)

        if not optional_connection:
            connection.commit()


def remove_from_indexer(indexer_id, recalculate_flags=False, optional_connection=None):
    """
    Remove a single row from the indexer table by its ID.

    If `recalculate_flags=True`, and the related policy exists, it will also
    reassign 'latest=1' and recalculate 'in_renewal_chain' for the affected
    (policy_number, company, lob) group.

    :param indexer_id: The ID of the indexer row to remove.
    :param recalculate_flags: Whether to recalculate `latest` and `in_renewal_chain` flags.
    :param optional_connection: Optional DB connection to reuse.
    """
    with get_connection(optional_connection) as connection:
        # Step 1: Lookup policy group (may not exist)
        sql_lookup = """
            SELECT p.policy_number, p.company, p.lob
              FROM indexer i
         LEFT JOIN policy p ON p.id = i.policy_id
             WHERE i.id = :indexer_id
        """
        row = connection.execute(text(sql_lookup), {"indexer_id": indexer_id}).first()

        # Step 2: Delete the indexer row
        sql_delete = "DELETE FROM indexer WHERE id = :indexer_id"
        connection.execute(text(sql_delete), {"indexer_id": indexer_id})

        # Step 3: Recalculate flags if we have a policy context
        if recalculate_flags and row and row.policy_number and row.company and row.lob:
            mark_latest_by_policy_company_lob(row.policy_number, row.company, row.lob, optional_connection=connection)

        if not optional_connection:
            connection.commit()


def read_on_hold_count(search=None, optional_connection=None):
    """
    Count the number of policy records that are on hold.

    :param search: Optional search filter.
    :param optional_connection: Optional DB connection.
    :return: Integer count of unmapped active policies.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT COUNT(p.id) as count
              FROM policy p, indexer i
             WHERE p.id = i.policy_id
               AND i.hold = 1
        """

        if search is not None:
            sql += """
               AND (p.policy_number LIKE :search 
                OR p.company LIKE :search
                OR p.lob LIKE :search
                OR p.purpose LIKE :search)
            """

        sql = text(sql)

        bind_params = {}
        if search is not None:
            bind_params["search"] = "%" + search + "%"

        result = connection.execute(sql, bind_params)
        row = result.first()

    return row.count


def count_renewals(min_premium_change_percent=None, optional_connection=None):
    """
    Count the number of distinct active renewal chains.

    This includes:
    - Policies marked in `indexer.in_renewal_chain = 1` (i.e., they are renewals or chained to one).
    - Only considers the `latest = 1` record for each policy group.
    - Optionally filters by % premium change vs the current active policy.
    - Returns count of grouped (policy_number, company, lob) combinations.

    :param min_premium_change_percent: Optional threshold for premium change filtering.
    :param optional_connection: Optional DB connection to reuse.
    :return: Number of matching renewal policy groups.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT COUNT(*) AS count
              FROM (
                SELECT pr.policy_number, pr.company, pr.lob
                  FROM indexer i
                  JOIN policy pr ON pr.id = i.policy_id
             LEFT JOIN policy pa 
                    ON pa.policy_number = pr.policy_number
                   AND pa.company = pr.company
                   AND pa.lob = pr.lob
                   AND pa.active = 1
                 WHERE i.latest = 1
                   AND i.name = 'index'
                   AND i.failed = 0
                   AND i.in_renewal_chain = 1
        """

        if min_premium_change_percent is not None:
            sql += """
                   AND pa.annual_premium IS NOT NULL
                   AND (
                     CASE
                       WHEN pr.annual_premium = pa.annual_premium THEN 0
                       WHEN pr.annual_premium > pa.annual_premium THEN (pr.annual_premium - 
                       pa.annual_premium) / pa.annual_premium * 100
                       WHEN pr.annual_premium < pa.annual_premium THEN -((pa.annual_premium - 
                       pr.annual_premium) / pa.annual_premium * 100)
                     END
                   ) > :min_change_percent
            """

        sql += """
                GROUP BY pr.policy_number, pr.company, pr.lob
              ) AS grouped
        """

        stmt = text(sql)
        if min_premium_change_percent is not None:
            stmt = stmt.bindparams(min_change_percent=min_premium_change_percent)

        result = connection.execute(stmt)
        row = result.first()

    return row.count if row else 0


def page_renewals(
        rows_per_page,
        page,
        sort,
        sort_direction,
        search,
        issues,
        min_premium_change_percent=None,
        optional_connection=None,
):
    """
    Retrieve a paginated list of 'renewals' for display.

    PARAMETERS:
    -----------------
    :param rows_per_page: Max number of results to return.
    :param page: Page number (0-based).
    :param sort: Column to sort by (must be a valid SQL column).
    :param sort_direction: 'ASC' or 'DESC'.
    :param search: Free-text search on policy_number, company, lob.
    :param issues: Optional list of issue codes to filter by.
    :param min_premium_change_percent: Optional minimum percent threshold.
    :param optional_connection: Optional existing DB connection.

    RETURNS:
    -----------------
    - A list of result rows (as dictionaries), filtered and sorted according to the given options.
    """
    change_threshold = settings.get_setting(constants.SETTING_RENEWALS_PREMIUM_CHANGE_PERCENT_THRESHOLD)

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT DISTINCT 
                   pr.id AS id,
                   pr.policy_number, 
                   pr.company, 
                   pr.lob,
                   pa.premium AS premium,
                   pa.annual_premium AS annual_premium,
                   pr.premium AS premium_renewal,
                   pr.annual_premium AS annual_premium_renewal,
                   (pr.annual_premium - pa.annual_premium) AS premium_change,
                   pr.transaction_effective_date AS renewal_date,
                   :change_threshold AS change_threshold,
                   CASE
                     WHEN pr.annual_premium = pa.annual_premium THEN 0
                     WHEN pr.annual_premium > pa.annual_premium THEN (pr.annual_premium - 
                     pa.annual_premium) / pa.annual_premium * 100
                     WHEN pr.annual_premium < pa.annual_premium THEN -((pa.annual_premium - 
                     pr.annual_premium) / pa.annual_premium * 100)
                   END AS premium_change_percent
              FROM indexer i
              JOIN policy pr ON pr.id = i.policy_id
              LEFT OUTER JOIN policy pa 
                ON pa.policy_number = pr.policy_number
               AND pa.company = pr.company
               AND pa.lob = pr.lob
               AND pa.active = 1
             WHERE i.latest = 1
               AND i.name = 'index'
               AND i.failed = 0
               AND i.in_renewal_chain = 1
        """

        if issues:
            sql += """
               AND EXISTS (
                   SELECT 1 
                     FROM policy_issue pi 
                    WHERE pi.policy_id = pr.id 
                      AND pi.code IN :issues
               )
            """

        if search:
            sql += """
               AND (
                    pr.policy_number LIKE :search 
                 OR pr.company LIKE :search
                 OR pr.lob LIKE :search
               )
            """

        if min_premium_change_percent is not None:
            sql += """
               AND (
                 CASE
                   WHEN pr.annual_premium = pa.annual_premium THEN 0
                   WHEN pr.annual_premium > pa.annual_premium THEN (pr.annual_premium - 
                   pa.annual_premium) / pa.annual_premium * 100
                   WHEN pr.annual_premium < pa.annual_premium THEN -((pa.annual_premium - 
                   pr.annual_premium) / pa.annual_premium * 100)
                 END
               ) > :min_change_percent
            """

        if sort and sort_direction:
            sql += f" ORDER BY {sort} {sort_direction}"

        if page is not None and rows_per_page is not None:
            sql += " LIMIT :limit OFFSET :offset"

        stmt = text(sql).bindparams(change_threshold=change_threshold)

        if issues:
            stmt = stmt.bindparams(issues=issues)

        if search:
            stmt = stmt.bindparams(search="%" + search + "%")

        if min_premium_change_percent is not None:
            stmt = stmt.bindparams(min_change_percent=min_premium_change_percent)

        if page is not None and rows_per_page is not None:
            stmt = stmt.bindparams(limit=rows_per_page, offset=page * rows_per_page)

        result = connection.execute(stmt)
        rows = result.all()

    return rows_to_list(rows)


def list_on_hold_paged(
        rows_per_page=None,
        page=None,
        sort=None,
        sort_direction=None,
        search=None,
        optional_connection=None):
    """
    Get a paged list of policies that are on hold.

    :param rows_per_page: Max rows per page.
    :param page: Page number (0-based).
    :param sort: Column name to sort by.
    :param sort_direction: Sort order (`ASC` or `DESC`).
    :param search: Optional search filter.
    :param optional_connection: Optional DB connection.
    :return: List of on hold `policy` rows.
    """
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT p.*, i.message
              FROM policy p, indexer i
             WHERE p.id = i.policy_id
               AND i.hold = 1
        """

        if search is not None:
            sql += """
               AND (p.policy_number LIKE :search 
                OR p.company LIKE :search
                OR p.lob LIKE :search
                OR p.purpose LIKE :search)
            """

        if sort is not None and sort_direction is not None:
            sql += " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            if rows_per_page is None:
                rows_per_page = 10
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        bind_params = {}

        if search is not None:
            bind_params["search"] = f"%{search}%"
        if page is not None:
            bind_params["offset"] = page * rows_per_page

        result = connection.execute(sql, bind_params)
        rows = result.all()

    return rows


def list_renewals_report_from_date(start_date, optional_connection=None):
    """
    Generate a report of renewal-related policies (latest in chain), showing premium changes above threshold.

    :param start_date: Only include latest renewal-related policies entered on or after this date.
    :param optional_connection: Optional DB connection for transactional control.
    :return: List of renewal-related rows with large premium changes.
    """
    change_threshold = settings.get_setting(constants.SETTING_RENEWALS_REPORT_THRESHOLD)

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT *
              FROM (
                SELECT 
                    i.entered,
                    i.process,
                    pa.*,
                    pr.premium AS premium_renewal,
                    pr.annual_premium AS annual_premium_renewal,
                    pr.transaction_effective_date AS renewal_date,
                    (pr.annual_premium - pa.annual_premium) AS premium_change,
                    CASE
                      WHEN pr.annual_premium = pa.annual_premium THEN 0
                      WHEN pr.annual_premium > pa.annual_premium THEN (pr.annual_premium - 
                      pa.annual_premium) / pa.annual_premium * 100
                      WHEN pr.annual_premium < pa.annual_premium THEN -((pa.annual_premium - 
                      pr.annual_premium) / pa.annual_premium * 100)
                    END AS premium_change_percent
                  FROM indexer i
                  JOIN policy pr ON pr.id = i.policy_id
             LEFT JOIN policy pa 
                    ON pa.policy_number = pr.policy_number
                   AND pa.company = pr.company
                   AND pa.lob = pr.lob
                   AND pa.active = 1
                 WHERE i.name = 'index'
                   AND i.failed = 0
                   AND i.latest = 1
                   AND i.in_renewal_chain = 1
                   AND i.entered >= :start_date
                 ORDER BY i.entered DESC
              ) AS renewals
             WHERE premium_change_percent > :change_threshold
        """

        stmt = text(sql).bindparams(
            change_threshold=change_threshold,
            start_date=start_date
        )

        result = connection.execute(stmt)
        rows = result.all()

    return rows_to_list(rows)


def list_companies(optional_connection=None):
    """
    Retrieve a list of all companies from the `company` table.

    This is typically used to populate dropdowns, filters, or administrative views
    where all companies need to be displayed.

    :param optional_connection: Optional DB connection for transactional control.
    :return: A list of (code, name) tuples for all companies.
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
            SELECT code, name
              FROM company
             ORDER BY code
        """)

        result = connection.execute(sql)
        return result.all()
