import json
import uuid

from sqlalchemy import text

from lib_common import exceptions
from lib_common.exceptions import ValidationException
from lib_persistence import get_connection

VALIDATION_TYPE_RENEWAL_AUTO = 'renewal_auto'
VALIDATION_TYPE_RENEWAL_HABL = 'renewal_habl'
VALIDATION_TYPE_RENEWAL = 'renewal'
VALIDATION_TYPE_POLICY = 'policy'


def create_issue(policy_id, code, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT
               INTO policy_issue (policy_id, code, count)
             VALUES (:policy_id, :code, :count)
             ON DUPLICATE KEY UPDATE count=count+1;
           """
        ).bindparams(
            policy_id=policy_id,
            code=code,
            count=1,
        ))

        if optional_connection is None:
            connection.commit()


def upsert_validations(validation_id, validation_type, name, description, rules, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT
               INTO validation (id, type, name, description)
             VALUES (:validation_id, :validation_type, :name, :description)
                 ON DUPLICATE KEY
             UPDATE name=:name,
                    description=:description,
                    type=:validation_type
           """
        ).bindparams(
            validation_id=validation_id,
            validation_type=validation_type,
            name=name,
            description=description,
        ))

        connection.execute(text(
            """
             DELETE
               FROM validation_rule
              WHERE validation_id=:validation_id
           """
        ).bindparams(
            validation_id=validation_id
        ))

        for rule in rules:
            rid = uuid.uuid1().hex
            connection.execute(text(
                """
                 INSERT
                   INTO validation_rule (
                     id, validation_id, enabled, description, func, type, cfg, severity, code, message
                   )
                 VALUES (
                     :id, :validation_id, :enabled, :description, :func, :type, :cfg, :severity, :code, :message
                 )
               """
            ).bindparams(
                id=rid,
                validation_id=validation_id,
                enabled=rule['enabled'],
                description=rule['description'],
                func=rule['func'],
                type=rule['type'],
                cfg=json.dumps(rule['cfg']),
                severity=rule['severity'],
                code=rule['code'],
                message=rule['message'],
            ))

        if optional_connection is None:
            connection.commit()


def upsert_validator(validator_id,
                     active,
                     validator_type,
                     name,
                     description,
                     validation_id,
                     trigger,
                     rules,
                     optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT
               INTO validator (id, active, type, name, description, validation_id, trigger_event, rules)
             VALUES (:validator_id, :active, :validator_type, :name, :description, :validation_id, :trigger, :rules)
             ON DUPLICATE KEY
             UPDATE active=:active,
                    type=:validator_type,
                    name=:name,
                    description=:description,
                    validation_id=:validation_id,
                    trigger_event=:trigger,
                    rules=:rules
           """
        ).bindparams(
            validator_id=validator_id,
            active=active,
            validator_type=validator_type,
            name=name,
            description=description,
            validation_id=validation_id,
            trigger=trigger,
            rules=rules
        ))

        if optional_connection is None:
            connection.commit()


def read_validator_by_id(validator_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM validator
             WHERE id=:validator_id
              """).bindparams(
            validator_id=validator_id
        )).one()


def read_validator_by_type_trigger_company_lob(validator_type, trigger, company, lob, optional_connection=None):
    trigger = trigger.upper() if trigger is not None else None
    company = company.upper() if company is not None else None
    lob = lob.upper() if lob is not None else None

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT v.*
              FROM validator v
             WHERE v.active=1
               AND v.type=:validator_type
               AND v.trigger_event=:trigger
              """

        if company is not None:
            sql += """
                AND JSON_EXTRACT(v.rules, '$.companies') IS NOT NULL
                AND JSON_CONTAINS(JSON_EXTRACT(v.rules, '$.companies'), JSON_QUOTE(:company)) = 0
            """

        sql = text(sql).bindparams(
            validator_type=validator_type,
            trigger=trigger
        )

        if company is not None:
            sql = sql.bindparams(company='"' + company + '"')

        result = connection.execute(sql)
        validator = result.first()

        if validator is None:
            return None

        return validator


def read_validations_by_id(validation_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM validation
             WHERE id=:validation_id
              """).bindparams(
            validation_id=validation_id
        )).one()


def read_validations_by_name(name, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM validation
             WHERE name=:name
              """).bindparams(
            name=name
        )).first()


def list_validation_rules_by_validation_id(validation_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM validation_rule
             WHERE validation_id=:validation_id
             ORDER BY description
              """).bindparams(
            validation_id=validation_id
        )).all()


def list_validation_rule_templates(validation_type, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM validation_rule_template
             WHERE validation_type=:validation_type
             ORDER BY description
              """).bindparams(
            validation_type=validation_type
        )).all()


def list_validators(rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT v.*
               FROM validator v        
              """

        if search is not None:
            sql += """
               WHERE (c.name LIKE :search 
                  OR c.name LIKE :search
                  OR c.description LIKE :search)
            """

        if sort is not None and sort_direction is not None:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def list_validations(validator_type, rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT id, type, name, description
              FROM validation
              """

        where = ""

        if validator_type is not None:
            where += " type=:validator_type"

        if search is not None:
            where = "AND".join([where, "(name LIKE :search OR description LIKE :search)"])

        if len(where) > 0:
            sql += " WHERE " + where

        if sort is not None and sort_direction is not None:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if validator_type is not None:
            sql = sql.bindparams(validator_type=validator_type)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def count_validation_rules(validator_types, optional_connection=None):
    with get_connection(optional_connection) as connection:
        row = connection.execute(text("""
            SELECT COUNT(vvr.id) as count
              FROM validation_rule vvr
             INNER JOIN validation as vv 
                ON vvr.validation_id=vv.id
             WHERE vv.type IN :validator_types
        """).bindparams(
            validator_types=validator_types
        )).first()

    return row.count


def list_validation_rules(validator_types,
                          rows_per_page,
                          page,
                          sort="description",
                          sort_direction="ASC",
                          search=None,
                          optional_connection=None):
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT vvr.*
              FROM validation_rule vvr
             INNER JOIN validation as vv 
                ON vvr.validation_id=vv.id
             WHERE vv.type in :validator_types
              """

        if search is not None:
            sql += " AND (vvr.description LIKE :search)"

        if sort is not None and sort_direction is not None:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql).bindparams(validator_types=validator_types)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def delete_validator(validator_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM validator
              WHERE id=:validator_id
           """
        ).bindparams(
            validator_id=validator_id
        ))

        if optional_connection is None:
            connection.commit()


def delete_validations(validation_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        row = connection.execute(text(
            """
             SELECT *
               FROM validator
              WHERE validation_id=:validation_id
           """
        ).bindparams(
            validation_id=validation_id
        )).first()

        if row is not None:
            raise ValidationException("Validations are in use.", error_code=exceptions.CODE_ADMIN_VALIDATIONS_IN_USE)

        connection.execute(text(
            """
             DELETE
               FROM validation
              WHERE id=:validation_id
           """
        ).bindparams(
            validation_id=validation_id
        ))

        connection.execute(text(
            """
             DELETE
               FROM validation_rule
              WHERE validation_id=:validation_id
           """
        ).bindparams(
            validation_id=validation_id
        ))

        if optional_connection is None:
            connection.commit()


def delete_issues(policy_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM policy_issue
              WHERE policy_id=:policy_id
           """
        ).bindparams(
            policy_id=policy_id
        ))

        if optional_connection is None:
            connection.commit()
