from sqlalchemy import text

from lib_persistence import get_connection


def lookup_vehicle_by_vin(vin, optional_connection=None):
    # We need digits 1-8 + 10+11 to perform lookup
    vin_lookup = vin[0:8] + vin[9:11]

    # First lookup based on VIN to get VICC Code
    with get_connection(optional_connection) as connection:
        row = connection.execute(text(
            """
            SELECT *
              FROM vin_vicc 
             WHERE VIN=:vin_lookup
            """
        ).bindparams(
            vin_lookup=vin_lookup
        )).first()

        if row is None:
            return

        vicc_code = row.VICC_CODE
        vicc_ext = row.EXT_VICC
        year = row.MODEL_YEAR

        # Second use VICC code to find other fields
        row = connection.execute(text(
            """
            SELECT * 
              FROM vicc
             WHERE VICC_CODE=:vicc_code
            """
        ).bindparams(
            vicc_code=vicc_code
        )).first()

        if row is None:
            return

        return row.MAKE, row.MODEL, year, vicc_code, vicc_ext, row.ABS, row.FUELTYPE, row.BODYTYPE


def lookup_vehicle_by_year_make_model(year, make, model, optional_connection=None):
    with get_connection(optional_connection) as connection:
        row = connection.execute(text(
            """
            SELECT *
              FROM vicc 
             WHERE MODEL_YEAR=:year
               AND MAKE=:make
               AND MODEL=:model
            """
        ).bindparams(
            year=year,
            make=make,
            model=model,
        )).first()

        if row is None:
            return

    return make, model, year, row.VICC_CODE, row.EXT_VICC, row.ABS, row.FUELTYPE, row.BODYTYPE
