import logging

from lib_common import constants

log = logging.getLogger(constants.LOGGER)


def db_transaction_required(func):
    """
    Decorator that ...

    :param func: Delegated function (route).
    :return: The result from the delegated function.
    :raises: ...
    """

    def wrapper_connection(*args, **kwargs):
        connection = args[0]
        savepoint = connection.begin_nested()

        try:
            result = func(*args, **kwargs)
            savepoint.commit()
        except Exception as e:
            log.error("User cannot access the requested account on route: ")
            log.exception(e, stack_info=True)
            savepoint.rollback()
            raise

        return result

    return wrapper_connection


required = db_transaction_required
