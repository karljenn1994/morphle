from sqlalchemy import text

from lib_common import constants
from lib_persistence import get_connection


def get_setting(name, default=None, optional_connection=None):
    with get_connection(optional_connection) as connection:
        sql = text("SELECT * from settings where name=:name").bindparams(name=name)
        results = connection.execute(sql)
        row = results.first()

        if row is None:
            return default

        return row.value


def get_int_setting(name, default=0):
    s = get_setting(name, default=default)
    try:
        s = int(s)
    except:
        s = default
    return s


def get_bool_setting(name, default=False):
    s = get_setting(name, default=default)
    try:
        # Already a bool
        if isinstance(s, bool):
            return s
        # Int-style values
        if isinstance(s, int):
            return s != 0
        # String-style values
        val = str(s).strip().lower()
        if val in ("1", "true", "yes", "y", "on"):
            return True
        if val in ("0", "false", "no", "n", "off"):
            return False
    except Exception:
        pass
    return default


def get_settings(optional_connection=None):
    with get_connection(optional_connection) as connection:
        sql = text("SELECT * from settings")
        results = connection.execute(sql)
        rows = results.all()

        settings = {}

        for row in rows:
            settings[row.name] = row.value

        return settings


def get_user_settings(optional_connection=None):
    with get_connection(optional_connection) as connection:
        sql = text("SELECT * from settings")
        results = connection.execute(sql)
        rows = results.all()

        settings = {}

        for row in rows:
            if row.name == constants.SETTING_BROKERAGE_COMPANY_NAME:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_PUB_URL:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_IDLE_TIMEOUT:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_SYSTEM_DOMAIN:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_SYSTEM_SUPPORTED_LOCALES:
                settings[row.name] = row.value

        return settings


def get_public_settings(optional_connection=None):
    with get_connection(optional_connection) as connection:
        sql = text("SELECT * from settings")
        results = connection.execute(sql)
        rows = results.all()

        settings = {}

        for row in rows:
            if row.name == constants.SETTING_BROKERAGE_COMPANY_NAME:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_PUB_URL:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_IDLE_TIMEOUT:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_SYSTEM_DOMAIN:
                settings[row.name] = row.value
            elif row.name == constants.SETTING_SYSTEM_SUPPORTED_LOCALES:
                settings[row.name] = row.value

        return settings


def update_settings(settings_map, optional_connection=None):
    for name, value in settings_map.items():
        with get_connection(optional_connection) as connection:
            sql = text("""
                 INSERT 
                   INTO settings (name, value)
                 VALUES (:name, :value)
                 ON DUPLICATE KEY UPDATE value=:value;  
               """).bindparams(name=name, value=value)

            connection.execute(sql)

            if optional_connection is None:
                connection.commit()
