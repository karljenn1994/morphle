import uuid
from datetime import datetime

from sqlalchemy import text

from lib_common.routes_support import rows_to_list
from lib_persistence import get_connection


def lookup_user_lead(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM user_lead
             WHERE user_id=:user_id
        """).bindparams(
            user_id=user_id
        )).first()


def list_loyalty_cards(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT c.*
              FROM collector_card as c
             WHERE c.user_id=:user_id
        """).bindparams(
            user_id=user_id
        )).all()


def list_auto_leads(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT ul.*, cl.collector_type, cl.lead_type, 
                   ca.vehicle_year, ca.vehicle_make, ca.vehicle_model, ca.vehicle_vin
              FROM user_lead ul
              LEFT OUTER JOIN user u
                ON ul.user_id=u.id
             INNER JOIN collector_lead cl
                ON ul.user_id=cl.user_id
               AND cl.collector_type='auto'
              LEFT OUTER JOIN collector_auto ca
                ON cl.collector_id=ca.id
             WHERE ul.user_id=:user_id
        """).bindparams(
            user_id=user_id
        )).all()


def list_property_leads(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT ul.*, cl.collector_type, cl.lead_type, 
                   cp.address, cp.city, cp.province, cp.postal_code
              FROM user_lead ul
              LEFT OUTER JOIN user u
                ON ul.user_id=u.id
             INNER JOIN collector_lead cl
                ON ul.user_id=cl.user_id
               AND cl.collector_type='property'
              LEFT OUTER JOIN collector_property cp
                ON cl.collector_id=cp.id
             WHERE ul.user_id=:user_id                
        """).bindparams(
            user_id=user_id
        )).all()


def create_lead(user_id, collector_id, collector_type, lead_type, optional_connection=None):
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        now = datetime.now().date()

        connection.execute(text(
            """
            INSERT INTO user_lead (user_id, status, received_date, modified_date) 
            VALUES (:user_id, 'received', :received_date, :modified_date)
                ON DUPLICATE KEY UPDATE received_date=:received_date
            """
        ).bindparams(
            user_id=user_id,
            received_date=now,
            modified_date=now,
        ))

        connection.execute(text(
            """
            INSERT INTO collector_lead (id, user_id, collector_id, collector_type, lead_type) 
            VALUES (:id, :user_id, :collector_id, :collector_type, :lead_type)
            """
        ).bindparams(
            id=mid,
            user_id=user_id,
            collector_id=collector_id,
            collector_type=collector_type,
            lead_type=lead_type,
        ))

        if optional_connection is None:
            connection.commit()


def delete_leads(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            DELETE 
              FROM user_lead
             WHERE user_id=:user_id
            """
        ).bindparams(user_id=user_id))

        connection.execute(text(
            """
            DELETE 
              FROM collector_lead
             WHERE user_id=:user_id
            """
        ).bindparams(user_id=user_id))

        if optional_connection is None:
            connection.commit()


def list_leads(rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT u.id, u.email, ul.status, ui.account_name, ul.received_date, 
                   COUNT(ca.id)as total_auto_leads, COUNT(cp.id) as total_property_leads
              FROM user u
              INNER JOIN user_info ui
                 ON u.id=ui.user_id
              INNER JOIN user_lead ul 
                 ON u.id=ul.user_id
               LEFT OUTER JOIN collector_lead cl
                 ON u.id=cl.user_id 
               LEFT OUTER JOIN collector_auto ca
                 ON cl.collector_id=ca.id
               LEFT OUTER JOIN collector_property cp
                 ON cl.collector_id=cp.id
              WHERE ul.user_id = u.id
        """

        if search is not None:
            sql += """
               AND (ui.account_name LIKE :search
                OR ul.status LIKE :search)
            """

        sql = sql + " GROUP BY id"

        if sort is not None and sort_direction is not None:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        rows = result.all()

    return rows_to_list(rows)


def lookup_lead_by_id(lead_id, optional_connection=None):
    if lead_id is None:
        return None

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
              SELECT cl.*
                 FROM collector_lead cl
                WHERE cl.id=:lead_id
            """).bindparams(
            lead_id=lead_id
        )).first()


def update_status(user_id, status, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             UPDATE user_lead
                SET modified_date=NOW(),
                    status=:status
              WHERE user_id=:user_id
           """
        ).bindparams(
            user_id=user_id, status=status
        ))

        if optional_connection is None:
            connection.commit()
