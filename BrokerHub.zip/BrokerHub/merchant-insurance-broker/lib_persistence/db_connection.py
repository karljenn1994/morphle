def db_connection_required(func):
    """
    Decorator that ...

    :param func: Delegated function (route).
    :return: The result from the delegated function.
    :raises: ...
    """

    def wrapper_connection(*args, **kwargs):
        comp = args[0]
        conn = comp.lambda_connection().connect()

        try:
            result = func(conn, *args, **kwargs)
        finally:
            conn.close()

        return result

    return wrapper_connection


required = db_connection_required
