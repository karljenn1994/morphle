import csv
import hashlib
import os
import uuid
from datetime import datetime, timezone

from sqlalchemy import bindparam

from lib_persistence import get_connection, persistence


def create_secure_password(password):
    salt = os.urandom(16)
    iterations = 100_000
    hash_value = hashlib.pbkdf2_hmac("sha256", password.encode('utf-8'), salt, iterations)
    password_hash = salt + hash_value
    return password_hash


def test_password_match(password, password_hash, salt):
    iterations = 100_000
    hash_value = hashlib.pbkdf2_hmac("sha256", password.encode('utf-8'), salt, iterations)
    return hash_value == password_hash


def get_counters(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT COUNT(i.id) AS total_renewals 
              FROM indexer i, policy p, user u, user_policy as up
             WHERE u.id=:user_id
               AND up.user_id=u.id
               AND p.id=up.policy_id
               AND p.purpose='RWL'
               AND i.policy_id=p.id
        """).bindparams(user_id=user_id)).first()


def lookup_user_id_by_id(user_id, optional_connection=None):
    if user_id is None or len(user_id) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        row = connection.execute(text("""
            SELECT u.id
              FROM user u
             WHERE u.id=:user_id
            """).bindparams(
            user_id=user_id)
        ).first()

        if row is None:
            return None

    return row.id


def lookup_user_id_by_email(email, optional_connection=None):
    if email is None or len(email) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        row = connection.execute(text("""
            SELECT u.id
              FROM user u
             WHERE u.email=:email    
            """).bindparams(
            email=email)
        ).first()

        if not row:
            return None

    return row.id


def lookup_user_id_by_verification_code(email, verification_code, optional_connection=None):
    with get_connection(optional_connection) as connection:
        row = connection.execute(
            text("""
                SELECT ue.user_id, ue.code_expires
                  FROM user_email AS ue
                 WHERE ue.email=:email
                   AND ue.code=:verification_code
            """).bindparams(
                email=email,
                verification_code=verification_code
            )
        ).first()

        if not row:
            return None

        # Convert DB naive datetime → aware UTC datetime
        code_expires = row.code_expires.replace(tzinfo=timezone.utc)

        # Ensure the code hasn't expired
        if code_expires < datetime.now(timezone.utc):
            return None

    return row.user_id


def lookup_user_by_id(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT user.id, user.email, user.password_hash, user.salt, user.hash_algo, user.iterations, 
                   user.status, user.connected, user.confirm_code, user.reset_code, ur.role, user_info.*
              FROM user_role as ur, user as user
              LEFT OUTER JOIN user_info as user_info ON user_info.user_id=user.id
             WHERE user.id=:id
               AND ur.user_id=user.id
            """).bindparams(id=user_id)).first()


def lookup_user_by_email(email, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT user.id, user.email, user.password_hash, user.salt, user.hash_algo, user.iterations, 
                   user.status, user.confirm_code, user.reset_code, ur.role, user_info.*
              FROM user_role as ur, user as user
              LEFT OUTER JOIN user_info as user_info ON user_info.user_id=user.id
             WHERE user.email=:email
              AND ur.user_id=user.id
            """).bindparams(email=email)).first()


def lookup_user_by_reset_code(reset_code, optional_connection=None):
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT user.id, user_info.account_name, user_info.first_name, user_info.last_name, user.email, 
                   user.password_hash, user.salt, user.hash_algo, user.iterations, 
                   user.status, user.confirm_code, user.reset_code, ur.role          
              FROM user_role as ur, user as user
              LEFT OUTER JOIN user_info as user_info ON user_info.user_id=user.id
             WHERE reset_code=:reset_code
              AND ur.user_id=user.id
            """).bindparams(reset_code=reset_code)).first()


def lookup_users_by_policy_id(policy_id, include_leads=False, optional_connection=None):
    with get_connection(optional_connection) as connection:
        sql = """
            SELECT u.*, ui.*, up.notify
        """

        if include_leads:
            sql += """
                , (SELECT COUNT(1) AS leads_received 
                     FROM user_lead leads_received 
                    WHERE leads_received.status='received' AND leads_received.user_id=u.id) AS leads_received
            """

        sql += """
              FROM user as u, user_policy up, user_info ui
             WHERE up.policy_id=:policy_id
               AND u.id=up.user_id
               AND ui.user_id=u.id
            """

        return connection.execute(text(sql).bindparams(
            policy_id=policy_id
        )).all()


def register_user(first, last, email, password, optional_connection=None):
    user = lookup_user_by_email(email, optional_connection=optional_connection)

    if user is not None:
        return None

    # Hash the user's password
    password_hash = create_secure_password(password)
    salt, key = password_hash[:16], password_hash[16:]

    confirm_code = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        mid = uuid.uuid1().hex
        connection.execute(text("""
             INSERT 
               INTO user (id, email, password_hash, salt, hash_algo, iterations, status, confirm_code)
             VALUES (:id, :email, :password_hash, :salt, :hash_algo, :iterations, 
                    :user_status, :confirm_code)
           """).bindparams(
            id=mid, email=email,
            password_hash=key,
            salt=salt,
            hash_algo="PBKDF2",
            iterations=100_000,
            user_status=persistence.USER_STATUS_UNCONFIRMED,
            confirm_code=confirm_code)
        )

        connection.execute(text("""
             INSERT 
               INTO user_info (user_id, first_name, last_name)
             VALUES (:user_id, :first_name, :last_name)
           """).bindparams(
            user_id=mid,
            first_name=first,
            last_name=last)
        )

        connection.execute(text("""
             INSERT 
               INTO user_email (user_id, email)
             VALUES (:user_id, :email)
           """).bindparams(
            user_id=mid,
            email=email)
        )

        connection.execute(text("""
             INSERT 
               INTO user_role (user_id, role)
             VALUES (:user_id, :role)
           """).bindparams(
            user_id=mid,
            role="pending")
        )

        if optional_connection is None:
            connection.commit()

    return confirm_code


def update_status(user, status, optional_connection=None):
    if user is None:
        return False

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE user
                SET status=:status
              WHERE id=:user_id
           """).bindparams(
            user_id=user.id,
            status=status)
        )

        if optional_connection is None:
            connection.commit()


def confirm_user(user, optional_connection=None):
    if user is None:
        return False

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE user
                SET status=:status, confirm_code=:confirm_code
              WHERE id=:user_id
           """).bindparams(
            user_id=user.id,
            status=persistence.USER_STATUS_PENDING,
            confirm_code=None)
        )

        if optional_connection is None:
            connection.commit()


def forgot_user(user, optional_connection=None):
    if user is None:
        return False

    with get_connection(optional_connection) as connection:
        reset_code = uuid.uuid1().hex
        connection.execute(text("""
             UPDATE user
                SET reset_code=:reset_code,
                    status=:status
              WHERE id=:user_id
           """).bindparams(
            user_id=user.id,
            reset_code=reset_code,
            status=persistence.USER_STATUS_FORGOT)
        )

        if optional_connection is None:
            connection.commit()

    return reset_code


def invite_user(user, reset_code=None, optional_connection=None):
    if user is None:
        return False

    with get_connection(optional_connection) as connection:
        reset_code = uuid.uuid1().hex if reset_code is None else reset_code
        connection.execute(text("""
             UPDATE user
                SET reset_code=:reset_code,
                    status=:status
              WHERE id=:user_id
           """).bindparams(
            user_id=user.id,
            reset_code=reset_code,
            status=persistence.USER_STATUS_INVITED)
        )

        if optional_connection is None:
            connection.commit()

    return reset_code


def change_password(user, password, optional_connection=None):
    if user is None:
        return False

    with get_connection(optional_connection) as connection:
        # Hash the user's password
        password_hash = create_secure_password(password)
        salt, key = password_hash[:16], password_hash[16:]

        connection.execute(text("""
             UPDATE user
                SET status=:status,
                    password_hash=:password_hash,
                    salt=:salt,
                    hash_algo=:hash_algo,
                    iterations=:iterations,
                    reset_code=:reset_code,
                    confirm_code=:confirm_code
              WHERE id=:user_id
           """).bindparams(
            user_id=user.id,
            status=persistence.USER_STATUS_ACTIVE,
            password_hash=key,
            salt=salt,
            hash_algo="PBKDF2",
            iterations=100_000,
            reset_code=None,
            confirm_code=None)
        )

        if optional_connection is None:
            connection.commit()

    return True


def add_user(email, account_name, first, last, is_admin, optional_connection=None):
    invite_code = uuid.uuid1().hex
    user_status = "invited" if is_admin else "uploaded"

    with get_connection(optional_connection) as connection:
        mid = uuid.uuid1().hex
        connection.execute(text("""
             INSERT 
               INTO user (id, email, status, reset_code)
             VALUES (:id, :email, :user_status, :reset_code)
           """).bindparams(
            id=mid,
            email=email,
            user_status=user_status,
            reset_code=invite_code)
        )
        connection.execute(text("""
             INSERT 
               INTO user_info (user_id, first_name, last_name, account_name)
             VALUES (:user_id, :first_name, :last_name, :account_name)
           """).bindparams(
            user_id=mid,
            first_name=first,
            last_name=last,
            account_name=account_name)
        )

        connection.execute(text("""
             INSERT 
               INTO user_email (user_id, email)
             VALUES (:user_id, :email)
           """).bindparams(
            user_id=mid,
            email=email)
        )

        if is_admin:
            connection.execute(text("""
                 INSERT 
                   INTO user_role (user_id, role)
                 VALUES (:user_id, :role)
               """).bindparams(
                user_id=mid,
                role="admin")
            )
        else:
            connection.execute(text("""
                 INSERT 
                   INTO user_role (user_id, role)
                 VALUES (:user_id, :role)
               """).bindparams(
                user_id=mid,
                role="user")
            )

        if optional_connection is None:
            connection.commit()

    return mid, invite_code


def update_user(auth_user,
                user,
                email=None,
                account_name=None,
                first_name=None,
                last_name=None,
                province=None,
                postal_code=None,
                date_of_birth=None,
                locale=None,
                notification_preference=None,
                is_admin=False,
                optional_connection=None):
    if user is None:
        return False

    if account_name is None:
        account_name = " ".join([first_name, last_name])

    with get_connection(optional_connection) as connection:
        if email:
            _update_email(user.id, email, optional_connection=connection)

        _upsert_user_info(
            connection,
            user.id,
            account_name=account_name,
            first_name=first_name,
            last_name=last_name,
            province=province,
            postal_code=postal_code,
            date_of_birth=date_of_birth,
            locale=locale,
            notification_preference=notification_preference,
        )

        # Can't change your own roles.
        if auth_user.id != user.id:
            connection.execute(text("""
                     DELETE
                       FROM user_role
                      WHERE user_id=:user_id
                   """).bindparams(
                user_id=user.id)
            )

            if is_admin:
                connection.execute(text("""
                         INSERT 
                           INTO user_role (user_id, role)
                         VALUES (:user_id, :role)
                       """).bindparams(
                    user_id=user.id,
                    role="admin")
                )

            else:
                connection.execute(text("""
                         INSERT 
                           INTO user_role (user_id, role)
                         VALUES (:user_id, :role)
                       """).bindparams(
                    user_id=user.id,
                    role="user")
                )

        if optional_connection is None:
            connection.commit()

    return True


def upsert_user_info(
        user_id,
        account_name=None,
        first_name=None,
        last_name=None,
        date_of_birth=None,
        province=None,
        postal_code=None,
        drivers_licence_number=None,
        locale=None,
        notification_preference=None,
        optional_connection=None):
    with get_connection(optional_connection) as connection:
        _upsert_user_info(connection,
                          user_id,
                          account_name,
                          first_name,
                          last_name,
                          date_of_birth,
                          province,
                          postal_code,
                          drivers_licence_number,
                          locale,
                          notification_preference)

        if optional_connection is None:
            connection.commit()


def upsert_alternative_email(user_id: str,
                             email: str,
                             verified: bool = False,
                             code: str = None,
                             code_expires: datetime = None,
                             optional_connection=None):
    """
    Insert or update an alternative email for a user.

    - If (user_id, email) does not exist, inserts a new record.
    - If it already exists, updates verified and code.
    """
    if not user_id or not email:
        return

    # Normalize expiry to naive UTC before insert
    if code_expires is not None:
        if code_expires.tzinfo is None:
            raise ValueError("code_expires must be timezone-aware (UTC)")
        code_expires = code_expires.astimezone(timezone.utc).replace(tzinfo=None)

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            INSERT INTO user_email (user_id, email, verified, code, code_expires)
            VALUES (:user_id, :email, :verified, :code, :code_expires)
            ON DUPLICATE KEY UPDATE
              verified = VALUES(verified),
              code = VALUES(code),
              code_expires = VALUES(code_expires)
            """
        ).bindparams(
            user_id=user_id,
            email=email,
            verified=verified,
            code=code,
            code_expires=code_expires,
        ))

        if optional_connection is None:
            connection.commit()


def _upsert_user_info(connection,
                      user_id,
                      account_name=None,
                      first_name=None,
                      last_name=None,
                      date_of_birth=None,
                      province=None,
                      postal_code=None,
                      drivers_licence_number=None,
                      locale=None,
                      notification_preference=None):
    result = connection.execute(text("""
        SELECT 1 
          FROM user_info 
         WHERE user_id=:user_id
        """).bindparams(
        user_id=user_id)
    )
    exists = result.first()

    if not exists:
        _insert_user_info(
            connection,
            user_id,
            account_name,
            first_name,
            last_name,
            date_of_birth,
            province,
            postal_code,
            drivers_licence_number,
            locale if locale else 'en',
            notification_preference if notification_preference else 'email',
        )
    else:
        _update_user_info(
            connection,
            user_id,
            account_name,
            first_name,
            last_name,
            date_of_birth,
            province,
            postal_code,
            drivers_licence_number,
            locale,
            notification_preference)


def _insert_user_info(connection,
                      user_id,
                      account_name=None,
                      first_name=None,
                      last_name=None,
                      date_of_birth=None,
                      province=None,
                      postal_code=None,
                      drivers_licence_number=None,
                      locale=None,
                      notification_preference=None):
    if postal_code is not None:
        postal_code = postal_code.replace(" ", "")

    connection.execute(text("""
            INSERT 
              INTO user_info (user_id, account_name, first_name, last_name, date_of_birth, province, 
                              postal_code, drivers_licence_number, locale, notification_preference)
            VALUES (:user_id, :account_name, :first_name, :last_name, :date_of_birth, :province, :postal_code, 
                    :drivers_licence_number, :locale, :notification_preference) 
        """).bindparams(
        user_id=user_id,
        account_name=account_name,
        first_name=first_name,
        last_name=last_name,
        date_of_birth=date_of_birth,
        province=province,
        postal_code=postal_code,
        drivers_licence_number=drivers_licence_number,
        locale=locale,
        notification_preference=notification_preference)
    )


def _update_user_info(connection,
                      user_id,
                      account_name=None,
                      first_name=None,
                      last_name=None,
                      date_of_birth=None,
                      province=None,
                      postal_code=None,
                      drivers_licence_number=None,
                      locale=None,
                      notification_preference=None):
    set_clause = []

    if account_name is not None:
        set_clause.append("account_name=:account_name")

    if first_name is not None:
        set_clause.append("first_name=:first_name")

    if last_name is not None:
        set_clause.append("last_name=:last_name")

    if date_of_birth is not None:
        set_clause.append("date_of_birth=:date_of_birth")

    if province is not None:
        set_clause.append("province=:province")

    if postal_code is not None:
        set_clause.append("postal_code=:postal_code")

    if drivers_licence_number is not None:
        set_clause.append("drivers_licence_number=:drivers_licence_number")

    if locale is not None:
        set_clause.append("locale=:locale")

    if notification_preference is not None:
        set_clause.append("notification_preference=:notification_preference")

    set_clause = ",".join(set_clause)

    if len(set_clause) > 0:
        sql = text("""
        UPDATE user_info
           SET
        """ + set_clause + " WHERE user_id=:user_id")

        sql = sql.bindparams(user_id=user_id)

        if account_name is not None:
            sql = sql.bindparams(account_name=account_name)

        if first_name is not None:
            sql = sql.bindparams(first_name=first_name)

        if last_name is not None:
            sql = sql.bindparams(last_name=last_name)

        if date_of_birth is not None:
            sql = sql.bindparams(date_of_birth=date_of_birth)

        if province is not None:
            sql = sql.bindparams(province=province)

        if postal_code is not None:
            sql = sql.bindparams(postal_code=postal_code.replace(" ", ""))

        if drivers_licence_number is not None:
            sql = sql.bindparams(drivers_licence_number=drivers_licence_number)

        if locale is not None:
            sql = sql.bindparams(locale=locale)

        if notification_preference is not None:
            sql = sql.bindparams(notification_preference=notification_preference)

        connection.execute(sql)


def list_users(
        rows_per_page=10,
        page=0,
        sort="leads",
        sort_direction="ASC",
        search=None,
        role=None,
        status=None,
        optional_connection=None):
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT u.id, ui.account_name, ui.first_name, ui.last_name, u.email, u.status, u.connected,
                COUNT(DISTINCT p.id) as total_policies, 
                COUNT(DISTINCT p.file_name) as total_indexed_policies,
                COUNT(DISTINCT cl.id) as leads
              FROM  user_role as ur,  user as u
              LEFT OUTER JOIN collector_lead as cl ON cl.user_id=u.id			
              LEFT OUTER JOIN user_info as ui ON ui.user_id=u.id
              LEFT OUTER JOIN user_policy as up ON up.user_id=u.id
              LEFT OUTER JOIN policy as p ON up.policy_id=p.id
             WHERE ur.user_id=u.id
            """

        if search is not None:
            sql += """
               AND (ui.account_name LIKE :search 
               OR ui.first_name LIKE :search 
               OR ui.last_name LIKE :search
               OR u.email LIKE :search)
            """

        if role is not None:
            sql += " AND ur.role=:role"

        if status is not None:
            sql += " AND status=:status"

        sql += " GROUP BY u.id"

        if sort is not None and sort_direction is not None:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql += " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if role is not None:
            sql = sql.bindparams(role=role)

        if status is not None:
            sql = sql.bindparams(status=status)

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        results = connection.execute(sql)
        return results.all()


def delete_user(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM user 
              WHERE id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM user_email
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id, ))

        connection.execute(text(
            """
             DELETE
               FROM user_info
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id, ))

        connection.execute(text(
            """
             DELETE
               FROM user_role 
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id, ))

        connection.execute(text("""
             DELETE
               FROM user_lead
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM user_policy
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM collector
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM collector_auto
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM collector_property
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM collector_card
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id))

        connection.execute(text(
            """
             DELETE
               FROM notifier_recipient
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id)
                           )
        connection.execute(text(
            """
             DELETE
               FROM quote
              WHERE user_id=:user_id
           """).bindparams(user_id=user_id)
                           )

        if optional_connection is None:
            connection.commit()


def upsert_user(
        email,
        first_name=None,
        last_name=None,
        date_of_birth=None,
        province=None,
        postal_code=None,
        drivers_licence_number=None,
        locale=None,
        notification_preference=None,
        optional_connection=None):
    user_id = lookup_user_by_email(email)

    if postal_code is not None:
        postal_code = postal_code.replace(" ", "")

    if user_id is None:
        with get_connection(optional_connection) as connection:
            user_id = str(uuid.uuid4())

            connection.execute(text(
                """
                 INSERT 
                   INTO user (id, email, status)
                 VALUES (:user_id, :email, :status)
               """).bindparams(
                user_id=user_id,
                email=email,
                status='uploaded')
            )

            connection.execute(text(
                """
                 INSERT 
                   INTO user_info (id, first_name, last_name, date_of_birth, province, postal_code, 
                                   drivers_licence_number, locale, notification_preference)
                 VALUES (:user_id, :first_name, :last_name, :date_of_birth, :province, :postal_code, 
                         :drivers_licence_number, :locale, :notification_preference)
               """).bindparams(
                user_id=user_id,
                first_name=first_name,
                last_name=last_name,
                date_of_birth=date_of_birth,
                province=province,
                postal_code=postal_code,
                drivers_licence_number=drivers_licence_number,
                locale=locale,
                notification_preference=notification_preference)
            )

            connection.execute(text(
                """
                  INSERT 
                    INTO user_email (user_id, email, notify)
                  VALUES (:user_id, :email, 1)
                """).bindparams(
                user_id=user_id,
                email=email)
            )

            if optional_connection is None:
                connection.commit()
    else:
        with get_connection(optional_connection) as connection:
            cols = [("first_name", first_name), ("last_name", last_name), ("date_of_birth", date_of_birth),
                    ("province", province), ("postal_code", postal_code),
                    ("drivers_licence_number", drivers_licence_number),
                    ("locale", locale), ("notification_preference", notification_preference)]
            sets = [c[0] + "=:" + c[0] for c in cols if c[1] is not None]
            sql = "UPDATE user_info SET " + ",".join(sets) + " WHERE user_id=:user_id"
            binds = [c for c in cols if c[1] is not None]
            sql = text(sql).bindparams(user_id=user_id)
            for c in binds:
                sql = sql.bindparams(bindparam(c[0], value=c[1]))
            connection.execute(sql)

            if optional_connection is None:
                connection.commit()

    return user_id


def create_user(
        email,
        first_name=None,
        last_name=None,
        date_of_birth=None,
        province=None,
        postal_code=None,
        drivers_licence_number=None,
        locale='en',
        notification_preference='email',
        status="uploaded",
        optional_connection=None):
    if postal_code is not None:
        postal_code = postal_code.replace(" ", "")

    user_id = str(uuid.uuid4())

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT 
               INTO user (id, email, status)
             VALUES (:user_id, :email, :status)
           """).bindparams(
            user_id=user_id,
            email=email,
            status=status)
        )

        connection.execute(text(
            """
             INSERT 
               INTO user_role (user_id, role)
             VALUES (:user_id, :role)
           """).bindparams(
            user_id=user_id,
            role='user')
        )

        connection.execute(text("""
             INSERT 
               INTO user_info (user_id, account_name, first_name, last_name, date_of_birth, province, 
                               postal_code, drivers_licence_number, locale, notification_preference)
             VALUES (:user_id, :account_name, :first_name, :last_name, :date_of_birth, :province, 
                     :postal_code, :drivers_licence_number, :locale, :notification_preference)
           """).bindparams(
            user_id=user_id,
            account_name=" ".join([first_name, last_name]),
            first_name=first_name,
            last_name=last_name,
            date_of_birth=date_of_birth,
            province=province,
            postal_code=postal_code,
            drivers_licence_number=drivers_licence_number,
            locale=locale,
            notification_preference=notification_preference)
        )

        connection.execute(text(
            """
              INSERT 
                INTO user_email (user_id, email, notify)
              VALUES (:user_id, :email, 1)
            """).bindparams(
            user_id=user_id,
            email=email
        ))

        if optional_connection is None:
            connection.commit()

    return user_id


def connect(user_id, optional_connection=None):
    if user_id is None:
        return False

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             UPDATE user
                SET connected=1
              WHERE id=:user_id
           """).bindparams(
            user_id=user_id)
        )

        if optional_connection is None:
            connection.commit()

    return True


def disconnect(user_id, optional_connection=None):
    if user_id is None:
        return False

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             UPDATE user
                SET connected=0
              WHERE id=:user_id
           """).bindparams(
            user_id=user_id)
        )

        if optional_connection is None:
            connection.commit()

    return True


def lookup_users_by_policy_and_company(policy, company, optional_connection=None):
    if policy is None or len(policy) <= 0:
        return None

    if company is None or len(company) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
            SELECT u.email, u.id, u.reset_code, ui.first_name, ui.last_name, ui.postal_code, ui.province,
                   ui.date_of_birth, ui.drivers_licence_number
              FROM policy p, user_policy up, user u
              LEFT OUTER JOIN user_info as ui ON ui.user_id=u.id
             WHERE p.policy_number=:policy
               AND p.company=:company
               AND up.policy_id=p.id
               AND u.id=up.user_id
            """).bindparams(
            policy=policy,
            company=company)
        ).all()

        count = len(rows)

        if count == 0:
            return None

    return rows


def lookup_users_by_policy_number_company_lob(policy, company, lob, optional_connection=None):
    if not policy:
        return None

    if not company:
        return None

    if not lob:
        return None

    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
            SELECT u.email, u.id, u.reset_code, ui.first_name, ui.last_name, ui.postal_code, ui.province,
                   ui.date_of_birth, ui.drivers_licence_number
              FROM policy p, user_policy up, user u
              LEFT OUTER JOIN user_info as ui ON ui.user_id=u.id
             WHERE p.policy_number=:policy
               AND p.company=:company
               AND p.lob=:lob
               AND up.policy_id=p.id
               AND u.id=up.user_id
            """).bindparams(
            policy=policy,
            company=company,
            lob=lob)
        ).all()

        count = len(rows)

        if count == 0:
            return None

    return rows


def lookup_last_update_by_user_id(user_id, optional_connection=None):
    if user_id is None or len(user_id) <= 0:
        return None

    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
            SELECT MAX(p.last_update) as last_update
              FROM policy as p, user_policy as up
             WHERE p.id = up.policy_id
               AND up.user_id=:user_id
               AND p.active=1
            """).bindparams(
            user_id=user_id)
        ).all()

        count = len(rows)

        if count == 0 or count > 1:
            return None

    last_update = rows[0].last_update

    if last_update is not None:
        return datetime.combine(last_update, datetime.min.time())

    return None


from sqlalchemy import text


def _update_email(user_id, email, optional_connection=None):
    if not user_id or not email:
        return

    with get_connection(optional_connection) as connection:
        # Check if another user already has this email
        result = connection.execute(
            text("""
                SELECT id
                FROM user
                WHERE email = :email
                  AND id != :user_id
                LIMIT 1
            """),
            {"email": email, "user_id": user_id}
        ).fetchone()

        if result:
            raise ValueError(f"Email '{email}' is already in use by another user.")

        # Proceed with update
        connection.execute(
            text("""
                UPDATE user
                SET email = :email
                WHERE id = :user_id
            """),
            {"user_id": user_id, "email": email}
        )

        if optional_connection is None:
            connection.commit()


def update_user_policies(user_id, policies, notify=False, destructive=True, optional_connection=None):
    """
    Update the set of policies linked to a user.

    HOW IT WORKS:
    -----------------
    - If `destructive` is True:
        - Deletes **all** existing `user_policy` mappings for the given `user_id` before adding new ones.
    - If `destructive` is False:
        - For each `policy_id` in `policies`:
            - Deletes any **existing duplicate link** for that `(user_id, policy_id)` pair.
            - Re-inserts the link.
        - This ensures that there is exactly **one unique mapping** for each `(user_id, policy_id)` pair,
          cleaning up accidental duplicates.

    USE CASE:
    -----------------
    - Use `destructive=True` to **replace** all of a user’s policy links in bulk.
    - Use `destructive=False` to **add or refresh** individual policy links while cleaning up duplicates.
    - Helps maintain referential integrity where the `user_policy` table may not have a strict unique constraint.

    CONNECTION:
    -----------------
    - Uses `optional_connection` if provided for batch operations.
    - If not provided, opens its own connection and commits immediately.

    :param user_id: The unique ID of the user.
    :param policies: A list of policy IDs to link to the user.
    :param notify: Notify this user.
    :param destructive: If True, remove all existing mappings before inserting. If False, refresh individually.
    :param optional_connection: (Optional) Existing DB connection.
    :return: None
    """
    if notify is None:
        notify = False

    with get_connection(optional_connection) as connection:
        if destructive:
            connection.execute(text(
                """
                 DELETE
                   FROM user_policy 
                  WHERE user_id=:user_id
               """).bindparams(
                user_id=user_id)
            )

        for policy_id in policies:
            connection.execute(text(
                """
                 DELETE
                   FROM user_policy 
                  WHERE user_id=:user_id
                    AND policy_id=:policy_id
               """).bindparams(
                user_id=user_id,
                policy_id=policy_id)
            )

            connection.execute(text(
                """
                 INSERT
                   INTO user_policy (user_id, policy_id, notify)
                 VALUES (:user_id, :policy_id, :notify)
               """).bindparams(
                user_id=user_id,
                policy_id=policy_id,
                notify=notify)
            )

        if optional_connection is None:
            connection.commit()


def delete_user_policies(user_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM user_policy 
              WHERE user_id=:user_id
           """).bindparams(
            user_id=user_id)
        )

        if optional_connection is None:
            connection.commit()


def export_csv(out_file, optional_connection=None):
    with get_connection(optional_connection) as connection:
        legacy_cursor = connection.execute(text(
            """
            SELECT u.*,
                 (SELECT GROUP_CONCAT(e.email)
                       FROM user_email e	
                      WHERE e.user_id = u.id) as emails,
                (SELECT GROUP_CONCAT(p.policy_number)
                       FROM user_policy up, policy p
                      WHERE up.user_id=u.id
                        AND p.id=up.policy_id) as policies          
               FROM client u;
            """))
        out_file = open(out_file, "w")
        out_csv = csv.writer(out_file)
        out_csv.writerow(x[0] for x in legacy_cursor.cursor.description)
        out_csv.writerows(legacy_cursor.fetchall())
        out_file.close()


def add_policy(user_id, policy_id, notify=False, optional_connection=None):
    if notify is None:
        notify = False

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT IGNORE
               INTO user_policy (user_id, policy_id, notify)
             VALUES(:user_id, :policy_id, :notify)
           """).bindparams(
            user_id=user_id,
            policy_id=policy_id,
            notify=notify)
        )

        if optional_connection is None:
            connection.commit()


def verify_policy(user_id, policy_number, optional_connection=None):
    with get_connection(optional_connection) as connection:
        row = connection.execute(text(
            """
             SELECT up.*
               FROM user_policy up, policy p
              WHERE up.user_id=:user_id
                AND up.verified=0
                AND p.id=up.policy_id
                AND p.policy_number=:policy_number
                AND p.active=1
           """).bindparams(
            user_id=user_id,
            policy_number=policy_number)
        ).first()

        if row is not None:
            connection.execute(text(
                """
                 UPDATE user_policy
                    SET verified=1
                  WHERE user_id=:user_id
                    AND policy_id=:policy_id
                    AND verified=0           
               """).bindparams(
                user_id=user_id,
                policy_id=row.policy_id)
            )

            if optional_connection is None:
                connection.commit()

            return True

    return False


def remove_policy(user_id, policy_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             DELETE
               FROM user_policy
              WHERE user_id=:user_id
                AND policy_id=:policy_id
           """).bindparams(
            user_id=user_id,
            policy_id=policy_id)
        )

        if optional_connection is None:
            connection.commit()
