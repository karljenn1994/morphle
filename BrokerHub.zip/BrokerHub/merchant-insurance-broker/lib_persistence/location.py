from sqlalchemy import text

from lib_persistence import get_connection


def lookup_location(postal_code):
    if postal_code is None:
        return None

    # We need digits 1-3 for FSA and 4-6 is the ldu.
    fsa = postal_code[0:3]
    ldu = postal_code.replace(" ", "")[3:6]
    result = _lookup_location_exec(fsa, ldu)

    if result is None:
        # In the case we get 0 results. We need to try again, this time
        # with 1 less character on the LDU.
        ldu = ldu[:2]
        result = _lookup_location_exec(fsa, ldu)

    if result is None:
        # In the case we get 0 results. We need to try again, this time
        # with 1 less character on the LDU.
        ldu = ldu[:1]
        result = _lookup_location_exec(fsa, ldu)

    if result is None:
        result = _lookup_location_exec(fsa, None)

    return result


def _lookup_location_exec(fsa, ldu, optional_connection=None):
    with get_connection(optional_connection) as connection:
        if ldu is not None:
            sql = text(
                """
                SELECT * 
                  FROM location_index
                 WHERE FSA=:fsa
                   AND LDU like :ldu
                """
            ).bindparams(
                fsa=fsa,
                ldu="%" + ldu + "%"
            )
        else:
            sql = text(
                """
                SELECT * 
                  FROM location_index
                 WHERE FSA=:fsa
                """
            ).bindparams(
                fsa=fsa,
            )

        result = connection.execute(sql)
        row = result.first()
        location = None

        if row is not None:
            location = (row.CITY, row.GCPCID)

        return location
