from datetime import datetime

from sqlalchemy import text

from lib_common import exceptions
from lib_common.exceptions import CampaignException
from lib_common.routes_support import rows_to_list
from lib_persistence import get_connection


def list_forms(form_type, rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    if not rows_per_page:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT *
              FROM campaign_form 
             WHERE type=:form_type
        """

        if search:
            sql += """
               AND (
                name LIKE :search
                OR description LIKE :search
               )
            """

        if sort and sort_direction:
            # For some reason, you can't bind sort and direction so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql).bindparams(form_type=form_type)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page:
            sql = sql.bindparams(offset=page * rows_per_page)

        rows = connection.execute(sql).all()

    return rows_to_list(rows)


def lookup_form_by_id(form_id, locale="en", optional_connection=None):
    if not form_id:
        return None

    with get_connection(optional_connection) as connection:
        # Load the form.
        return connection.execute(text("""
              SELECT cf.*, cc.form
                 FROM campaign_form cf, campaign_form_content cc
                WHERE cf.id=:form_id
                  AND cc.form_id=cf.id
                  AND cc.locale=:locale
            """).bindparams(
            form_id=form_id,
            locale=locale
        )).first()


def upsert_form(form_id, form_type, name, description, form_data, optional_connection=None):
    if not form_id:
        return None

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
             INSERT 
               INTO campaign_form (id, type, name, description)
             VALUES (:form_id, :type, :name, :description)
             ON DUPLICATE KEY UPDATE 
                name = :name,
                description = :description;
           """
        ).bindparams(
            form_id=form_id,
            type=form_type,
            name=name,
            description=description
        ))

        connection.execute(text(
            """
             INSERT 
               INTO campaign_form_content (form_id, locale, form)
             VALUES (:form_id, :locale, :form)
             ON DUPLICATE KEY UPDATE 
                form = :form
           """
        ).bindparams(
            form_id=form_id,
            locale='en',
            form=form_data
        ))

        if not optional_connection:
            connection.commit()


def delete_form(form_id, optional_connection=None):
    with get_connection(optional_connection) as connection:
        rows = connection.execute(text(
            """
             SELECT *
               FROM campaign
              WHERE form_id=:form_id
           """
        ).bindparams(
            form_id=form_id)
        ).first()

        if rows:
            raise CampaignException("Form is in use.", error_code=exceptions.CODE_ADMIN_CAMPAIGN_FORM_IN_USE)

        result = connection.execute(text(
            """
             DELETE
               FROM campaign_form
              WHERE id=:form_id
           """
        ).bindparams(
            form_id=form_id)
        )

        if result.rowcount > 0:
            connection.execute(text(
                """
                 DELETE
                   FROM campaign_form_content
                  WHERE form_id=:form_id
               """
            ).bindparams(
                form_id=form_id)
            )

        if not optional_connection:
            connection.commit()


def _delete_form_contents(connection, form_id):
    connection.execute(text(
        """
         DELETE
           FROM campaign_form_content
          WHERE form_id=:form_id
       """
    ).bindparams(
        form_id=form_id)
    )


def lookup_form_instance(form_id, user_id, locale='en', optional_connection=None):
    if not form_id or not user_id:
        return None

    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
              SELECT f.*, c.form, d.form_data
                 FROM  campaign_form f
                 INNER JOIN campaign_form_content c ON f.id=c.form_id AND c.locale=:locale
                 LEFT OUTER JOIN campaign_form_data d ON f.id=d.form_id AND d.user_id=:user_id
                WHERE f.id=:form_id
            """).bindparams(
            form_id=form_id,
            user_id=user_id,
            locale=locale
        )).first()


def upsert_form_data(form_id, user_id, policy_id, form_data, optional_connection=None):
    if not form_id or not user_id:
        return None

    with get_connection(optional_connection) as connection:
        now = datetime.now().date()
        connection.execute(text(
            """
             INSERT 
               INTO campaign_form_data (form_id, user_id, policy_id, form_data, received_date, modified_date)
             VALUES (:form_id, :user_id, :policy_id, :form_data, :received_date, :modified_date)
             ON DUPLICATE KEY UPDATE 
                policy_id = :policy_id,
                form_data = :form_data,
                modified_date = :modified_date;
           """
        ).bindparams(
            form_id=form_id,
            user_id=user_id,
            policy_id=policy_id,
            form_data=form_data,
            received_date=now,
            modified_date=now,
        ))

        if not optional_connection:
            connection.commit()


def list_form_data(form_id, rows_per_page, page, sort, sort_direction, search, optional_connection=None):
    if not rows_per_page:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT cd.form_id, cd.user_id, cd.policy_id, cd.received_date, u.email, ui.account_name
              FROM campaign_form_data cd
             INNER JOIN user u on cd.user_id=u.id
             INNER JOIN user_info ui on cd.user_id=ui.user_id
             INNER JOIN campaign_form cf on cd.form_id=cf.id
             WHERE cd.form_id=:form_id
        """

        if search:
            sql += """
               AND (
                email LIKE :search
                OR account_name LIKE :search
               )
            """

        if sort and sort_direction:
            # For some reason you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql).bindparams(form_id=form_id)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page:
            sql = sql.bindparams(offset=page * rows_per_page)

        return connection.execute(sql).all()


def delete_form_data(form_id, user_id, optional_connection=None):
    if not form_id or not user_id:
        return

    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             DELETE
               FROM campaign_form_data
              WHERE form_id=:form_id
                AND user_id=:user_id
           """).bindparams(
            form_id=form_id,
            user_id=user_id,
        ))

        if not optional_connection:
            connection.commit()
