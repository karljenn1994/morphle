from sqlalchemy import text

from lib_common import constants
from lib_persistence import get_connection, settings


def get_counters(user_id, optional_connection=None):
    """
    Get a collection of global dashboard summary metrics plus user-specific renewal count.

    WHAT IT DOES:
    -----------------
    - Computes system-wide counts for:
      - Leads by status
      - Claims by status
      - Quotes by status
      - Draft/outbox/sent notifications
      - Total renewals across all users
      - Total active unmapped policies (policies that are active but not mapped to any user)
      - Renewals where the premium change exceeds the configured threshold
    - Computes *my_renewals* — the count of active renewals specifically linked to the given user.

    PARAMETERS:
    -----------------
    :param user_id: The user ID to calculate `my_renewals` for.
    :param optional_connection: Optional DB connection.
    :return: A single row of counts, each accessible by name.
    """
    change_threshold = settings.get_setting(constants.SETTING_RENEWALS_REPORT_THRESHOLD)

    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT leads_received,
                   claims_received, claims_reviewing, claims_completed, 
                   quotes_received, quotes_reviewing, quotes_completed, 
                   drafts, outbox, sent, 
                   total_renewals, total_unmapped_policies, total_renewals_over_threshold, total_on_hold
              FROM 
                  (SELECT COUNT(1) AS leads_received 
                     FROM user_lead WHERE status='received') AS leads_received,
                  (SELECT COUNT(1) AS claims_received 
                     FROM claim WHERE status='received') AS claims_received,
                  (SELECT COUNT(1) AS claims_reviewing 
                     FROM claim WHERE status='reviewing') AS claims_reviewing,
                  (SELECT COUNT(1) AS claims_completed 
                     FROM claim WHERE status='completed') AS claims_completed,
                  (SELECT COUNT(1) AS quotes_received 
                     FROM quote WHERE status='received') AS quotes_received,
                  (SELECT COUNT(1) AS quotes_reviewing 
                     FROM quote WHERE status='reviewing') AS quotes_reviewing,
                  (SELECT COUNT(1) AS quotes_completed 
                     FROM quote WHERE status='completed') AS quotes_completed,
                  (SELECT COUNT(1) AS drafts 
                     FROM notifier WHERE mailbox='draft') AS drafts,
                  (SELECT COUNT(1) AS outbox 
                     FROM notifier WHERE mailbox='outbox') AS outbox,      
                  (SELECT COUNT(1) AS sent 
                     FROM notifier WHERE mailbox='sent') AS sent,
                  (SELECT COUNT(*) AS total_renewals
                    FROM indexer i
                    JOIN policy p ON p.id = i.policy_id
                   WHERE i.failed = 0
                     AND i.name = 'index'
                     AND i.latest = 1
                     AND i.in_renewal_chain = 1) AS total_renewals, 
                  (SELECT COUNT(DISTINCT p.id) AS total_unmapped_policies
                     FROM policy p
                     LEFT JOIN user_policy up ON p.id = up.policy_id
                    WHERE p.active = 1 
                      AND p.xln=0
                      AND p.purge = 0
                      AND p.policy_expiry_date >= CURDATE()
                      AND up.user_id IS NULL) AS total_unmapped_policies,
                  (SELECT COUNT(DISTINCT p.id) AS total_on_hold
                     FROM policy p, indexer i
                    WHERE p.id = i.policy_id
                      AND i.hold = 1
                  ) AS total_on_hold,
                  (
                    SELECT COUNT(*) AS total_renewals_over_threshold
                      FROM (
                        SELECT pr.policy_number, pr.company, pr.lob
                          FROM indexer i
                          JOIN policy pr ON pr.id = i.policy_id
                     LEFT JOIN policy pa 
                            ON pa.policy_number = pr.policy_number
                           AND pa.company = pr.company
                           AND pa.lob = pr.lob
                           AND pa.active = 1
                         WHERE i.failed = 0
                           AND i.name = 'index'
                           AND i.latest = 1
                           AND i.in_renewal_chain = 1
                           AND pa.annual_premium IS NOT NULL
                           AND (
                             CASE
                               WHEN pr.annual_premium = pa.annual_premium THEN 0
                               WHEN pr.annual_premium > pa.annual_premium THEN (pr.annual_premium - pa.annual_premium) / pa.annual_premium * 100
                               WHEN pr.annual_premium < pa.annual_premium THEN -((pa.annual_premium - pr.annual_premium) / pa.annual_premium * 100)
                             END
                           ) > :change_threshold
                        GROUP BY pr.policy_number, pr.company, pr.lob
                      ) AS grouped
                  ) AS total_renewals_over_threshold
        """).bindparams(change_threshold=change_threshold)).first()
