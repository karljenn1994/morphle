import json
import uuid
from datetime import datetime

from sqlalchemy import text

from lib_common import constants
from lib_persistence import get_connection


def get_notification_by_id(notification_id, optional_connection=None):
    """
    Retrieve a notification by its ID, including associated campaign metadata.

    :param notification_id: ID of the notification to retrieve.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A row object containing all fields from `notifier`, plus `name` and `description` from `campaign`.
             Returns None if no notification is found with the given ID.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT n.*, c.name, c.description
              FROM notifier n
               INNER JOIN campaign c ON n.campaign_id=c.id
             WHERE n.id=:notification_id
              """).bindparams(
            notification_id=notification_id
        )).first()


def get_notifications(mailbox, optional_connection=None):
    """
    Retrieve all notifications from the specified mailbox.

    :param mailbox: The mailbox name to filter notifications by (e.g., 'outbox', 'sent', etc.).
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A list of row objects representing matching notifications.
    """
    with get_connection(optional_connection) as connection:
        # See what notifications are in the outbox ready to be sent.
        return connection.execute(text("""
            SELECT n.*
              FROM notifier n
             WHERE n.mailbox=:mailbox
              """).bindparams(mailbox=mailbox)).all()


def list_messages(
        mailbox,
        rows_per_page,
        page,
        sort="draft_date",
        sort_direction="DESC",
        search=None,
        optional_connection=None):
    """
    Retrieve a paginated, searchable list of notifications from a specific mailbox.

    :param mailbox: The mailbox name to filter notifications by (e.g., 'draft', 'outbox', 'sent').
    :param rows_per_page: Number of results per page (defaults to 10 if None).
    :param page: The page index (0-based) to retrieve.
    :param sort: The column to sort by (e.g., 'draft_date', 'sent_date'). Default is 'draft_date'.
    :param sort_direction: The sort direction ('ASC' or 'DESC'). Default is 'DESC'.
    :param search: Optional search term to match against campaign name or description.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A list of row objects, each including notification metadata, campaign name/description,
             and recipient count.
    """
    if rows_per_page is None:
        rows_per_page = 10

    if sort is None:
        sort = "draft_date"

    if sort_direction is None:
        sort_direction = "DESC"

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT n.id, n.campaign_id, n.action_date, n.draft_date, n.outbox_date, n.sent_date, 
                   c.name, c.description, COUNT(nr.notifier_id) as recipients
              FROM notifier n
              LEFT OUTER JOIN campaign c ON n.campaign_id=c.id
             INNER JOIN notifier_recipient nr ON n.id=nr.notifier_id
             WHERE n.mailbox=:mailbox             
              """

        if search is not None:
            sql += """
               AND (c.name LIKE :search 
               OR c.description LIKE :search)
            """

        sql += " GROUP BY n.id, c.name, c.description"

        if sort is not None and sort_direction is not None:
            # For some reason, you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql += " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql).bindparams(mailbox=mailbox)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        result = connection.execute(sql)
        return result.all()


def get_messages_ready_to_send(optional_connection=None):
    """
    Retrieve all notifications from the outbox that are ready to be sent.

    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A list of row objects representing ready-to-send notifications, each including
             notification ID and associated campaign metadata.
    """
    with get_connection(optional_connection) as connection:
        # See what notifications are in the outbox ready to be sent.
        sql = text("""
            SELECT n.id, c.id as campaign_id, c.type, c.marketing, c.trigger_event, c.template_id
              FROM notifier n, campaign c
             WHERE n.mailbox='outbox'
               AND (n.action_date IS NULL OR n.action_date < NOW())
               AND c.id=n.campaign_id
              """)
        result = connection.execute(sql)
        return result.all()


def get_template(template_id, locale, optional_connection=None):
    """
    Retrieve a campaign template and its localized content.

    :param template_id: ID of the campaign template to retrieve.
    :param locale: The preferred locale (e.g., 'en', 'fr', 'zh-CN') for the template content.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A row object containing the template and localized content fields,
             or None if no English fallback is available either.
    """
    with get_connection(optional_connection) as connection:
        templ = connection.execute(text("""
            SELECT *
              FROM campaign_template ct
             INNER JOIN campaign_template_content cc ON ct.id=cc.template_id AND cc.locale=:locale
             WHERE ct.id=:template_id
              """).bindparams(
            template_id=template_id,
            locale=locale
        )).first()

        if templ is None:
            # Default to English.
            templ = connection.execute(text("""
                SELECT *
                  FROM campaign_template ct
                 INNER JOIN campaign_template_content cc ON ct.id=cc.template_id AND cc.locale=:locale
                 WHERE ct.id=:template_id
                  """).bindparams(
                template_id=template_id,
                locale='en'
            )).first()

        return templ


def get_recipients(notifier_id, optional_connection=None):
    """
    Retrieve all pending recipients for a given notification.

    :param notifier_id: ID of the notification to retrieve recipients for.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A list of row objects, each representing a pending recipient and their associated user details.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT nr.id as notifier_recipient_id, nr.locale, 
                   u.id, u.status, ur.role, nr.notifier_id, u.email, u.reset_code, u.connected,
                   ui.account_name, ui.first_name, ui.last_name, ui.postal_code, ui.province, 
                   ui.date_of_birth, ui.drivers_licence_number, ui.locale, ui.notification_preference,
                   nr.regarding
              FROM notifier_recipient nr, user u, user_info ui, user_role ur
             WHERE nr.notifier_id=:notifier_id
               AND nr.status IS NULL
               AND u.id=nr.user_id
               AND ui.user_id=u.id
               AND ur.user_id=u.id
              """).bindparams(
            notifier_id=notifier_id
        )).all()


def get_recipient(notifier_recipient_id, optional_connection=None):
    """
    Retrieve a single notification recipient by its ID, including full user details.

    :param notifier_recipient_id: ID of the `notifier_recipient` record to retrieve.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A row object containing recipient and associated user details, or None if not found.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT nr.id as notifier_recipient_id, nr.locale, 
                   u.id, u.status, ur.role, nr.notifier_id, u.email, u.reset_code, u.connected,
                   ui.account_name, ui.first_name, ui.last_name, ui.postal_code, ui.province, 
                   ui.date_of_birth, ui.drivers_licence_number, ui.locale, ui.notification_preference,
                   nr.regarding
              FROM notifier_recipient nr, user u, user_info ui, user_role ur
             WHERE nr.id=:notifier_recipient_id
               AND u.id=nr.user_id
               AND ui.user_id=u.id
               AND ur.user_id=u.id
              """).bindparams(
            notifier_recipient_id=notifier_recipient_id
        )).first()


def get_notification_recipient(notifier_recipient_id, optional_connection=None):
    """
    Retrieve a raw `notifier_recipient` record by its ID.

    :param notifier_recipient_id: ID of the `notifier_recipient` record to retrieve.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A row object representing the `notifier_recipient` record, or None if not found.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM notifier_recipient
             WHERE id=:notifier_recipient_id
              """).bindparams(
            notifier_recipient_id=notifier_recipient_id
        )).first()


def count_recipients(notifier_id, optional_connection=None):
    """
    Count the number of recipients associated with a given notification.

    :param notifier_id: ID of the notification whose recipients should be counted.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: Integer count of recipients associated with the given notification.
    """
    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT COUNT(u.id) as count
              FROM notifier_recipient nr, user u, user_info ui
             WHERE nr.notifier_id=:notifier_id
               AND u.id=nr.user_id
               AND ui.user_id=u.id
              """).bindparams(
            notifier_id=notifier_id
        )).first().count


def list_recipients(notifier_id,
                    rows_per_page=10,
                    page=0,
                    sort="account_name",
                    sort_direction="ASC",
                    search=None,
                    optional_connection=None):
    """
    Retrieve a paginated, searchable, and sortable list of recipients for a given notification.

    :param notifier_id: ID of the notification whose recipients should be listed.
    :param rows_per_page: Number of results to return per page (default is 10).
    :param page: Page index (0-based) to retrieve.
    :param sort: Column to sort by (e.g., 'account_name', 'email'). Default is 'account_name'.
    :param sort_direction: Sort direction, either 'ASC' or 'DESC'. Default is 'ASC'.
    :param search: Optional text to filter results by name or email.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A list of row objects representing matching recipients with associated user data.
    """
    if rows_per_page is None:
        rows_per_page = 10

    with get_connection(optional_connection) as connection:
        sql = """
            SELECT u.id, nr.id as recipient_id, nr.status, nr.opens_count, nr.clicks_count, u.email, u.reset_code, 
                   ui.account_name, ui.first_name, ui.last_name, ui.postal_code, ui.province, ui.date_of_birth, 
                   ui.drivers_licence_number
              FROM notifier_recipient nr, user u, user_info ui
             WHERE nr.notifier_id=:notifier_id
               AND u.id=nr.user_id
               AND ui.user_id=u.id
              """

        if search is not None:
            sql += """
               AND (ui.account_name LIKE :search 
               OR ui.first_name LIKE :search 
               OR ui.last_name LIKE :search
               OR u.email LIKE :search)
            """

        if sort is not None and sort_direction is not None:
            # For some reason, you can't bind sort and direction, so they have to be
            # concatenated.
            sql = sql + " ORDER BY " + sort + " " + sort_direction

        if page is not None:
            sql = sql + " LIMIT " + str(rows_per_page) + " OFFSET :offset"

        sql = text(sql).bindparams(notifier_id=notifier_id)

        if search is not None:
            sql = sql.bindparams(search="%" + search + "%")

        if page is not None:
            sql = sql.bindparams(offset=page * rows_per_page)

        results = connection.execute(sql)
        return results.all()


def recipients_count(notification_id, optional_connection=None):
    """
    Count the number of recipients assigned to a specific notification.

    :param notification_id: ID of the notification whose recipients should be counted.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: Integer count of recipients for the given notification.
    """
    with get_connection(optional_connection) as connection:
        result = connection.execute(text("""
            SELECT COUNT(*) AS count
              FROM notifier_recipient
             WHERE notifier_id = :notification_id
        """).bindparams(notification_id=notification_id)).first()
        return result.count if result else 0


def get_pending_notification(campaign_id, action_date, optional_connection=None):
    """
    Retrieve the first pending notification for a campaign on a given action date that has space for more recipients.

    :param campaign_id: ID of the campaign to find pending notifications for.
    :param action_date: Date the notification is scheduled to be sent.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: The ID of a suitable pending notification, or None if none are available.
    """
    with get_connection(optional_connection) as connection:
        # Get all pending notifications for the campaign and date.
        notifications = connection.execute(text("""
            SELECT n.id
              FROM notifier n
             WHERE n.action_date = :action_date
               AND n.mailbox <> 'sent'
               AND n.sent_date IS NULL
               AND n.campaign_id = :campaign_id
        """).bindparams(
            action_date=action_date,
            campaign_id=campaign_id,
        )).fetchall()

        # Find the first notifier that has space.
        for row in notifications:
            count = recipients_count(row.id, optional_connection=connection)
            if count < constants.MAX_NOTIFICATION_RECIPIENTS:
                return row.id

        # No available notification with space
        return None


def create_notification(campaign_id, action_date, optional_connection=None):
    """
    Create a new notification for the given campaign and action date.

    :param campaign_id: ID of the campaign to create a notification for.
    :param action_date: Scheduled action date for the notification.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: The generated notification ID (hex UUID), or None if the campaign does not exist.
    """
    mid = uuid.uuid1().hex

    with get_connection(optional_connection) as connection:
        # Lookup the message to use for the task name provided.
        campaign = connection.execute(text("""
            SELECT template_id, approval
              FROM campaign
             WHERE id=:campaign_id
              """).bindparams(
            campaign_id=campaign_id
        )).first()

        if campaign is None:
            return None

        approval_required = campaign.approval
        now = datetime.now()
        mailbox = 'draft'
        outbox_date = None

        if not approval_required:
            mailbox = 'outbox'
            outbox_date = now

        connection.execute(text("""
             INSERT 
               INTO notifier(id, mailbox, campaign_id, action_date, draft_date, outbox_date)
             VALUES(:notification_id, :mailbox, :campaign_id, :action_date, :draft_date, :outbox_date)
           """).bindparams(
            notification_id=mid,
            campaign_id=campaign_id,
            action_date=action_date,
            draft_date=now,
            mailbox=mailbox,
            outbox_date=outbox_date))

        if optional_connection is None:
            connection.commit()

    return mid


def get_recipient_regarding_list(notifier_id, user_id, optional_connection=None):
    """
    Retrieve all "regarding" context objects for a specific user and notification.

    :param notifier_id: ID of the notification.
    :param user_id: ID of the user whose recipient contexts should be retrieved.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: A list of deserialized Python objects representing the "regarding" context for each recipient entry.
    """
    with get_connection(optional_connection) as connection:
        regarding_list = connection.execute(text("""
            SELECT nr.regarding
              FROM notifier_recipient nr
             WHERE nr.notifier_id=:notifier_id
               AND nr.user_id=:user_id
              """).bindparams(
            notifier_id=notifier_id,
            user_id=user_id
        )).all()

        if regarding_list is None or len(regarding_list) <= 0:
            return []

        return [json.loads(r.regarding.decode('utf-8')) for r in regarding_list]


def add_recipient_one_time(user_id, notifier_id, campaign_id, regarding, dry_run=False, optional_connection=None):
    """
    Add a recipient to a notification only if they have never been notified about this campaign with the same context.

    :param user_id: ID of the user to notify.
    :param notifier_id: ID of the notification to attach the recipient to.
    :param campaign_id: ID of the campaign to check uniqueness against.
    :param regarding: A context object describing what the notification is about (e.g., a policy).
    :param dry_run: If True, simulate the operation without modifying the database.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: The generated recipient ID if added, or None if the recipient already existed.
    """
    mid = None

    with get_connection(optional_connection) as connection:
        if not isinstance(regarding, str):
            regarding = json.dumps(regarding)

        # Only allow a recipient to be notified once.
        recipient = connection.execute(text("""
            SELECT nr.*
              FROM notifier_recipient nr, notifier n, campaign c
             WHERE nr.user_id=:user_id
               AND nr.regarding=:regarding
               AND n.id=nr.notifier_id
               AND c.id=n.campaign_id
               AND c.id=:campaign_id
            """).bindparams(
            campaign_id=campaign_id,
            user_id=user_id,
            regarding=regarding
        )).first()

        if recipient is None:
            # The recipient was not found, so let's add them to the notification.
            mid = uuid.uuid1().hex

            if not dry_run:
                connection.execute(text("""
                     INSERT 
                       INTO notifier_recipient(id, notifier_id, user_id, regarding)
                     VALUES(:id, :notifier_id, :user_id, :regarding)
                   """).bindparams(
                    id=mid,
                    notifier_id=notifier_id,
                    user_id=user_id,
                    regarding=regarding
                ))

                if optional_connection is None:
                    connection.commit()

    return mid


def add_recipient(user_id, notifier_id, campaign_id, regarding, locale='en', dry_run=False, optional_connection=None):
    """
    Add a recipient to the specified notification, updating or merging "regarding" context if needed.

    :param user_id: User id of the recipient.
    :param notifier_id: ID of the notification to attach the recipient to.
    :param campaign_id: ID of the campaign (used to check for existing recipient relationships).
    :param regarding: A context object (or dict) describing what the notification is about (e.g., a policy).
    :param locale: Preferred language/locale for the recipient (default is 'en').
    :param dry_run: If True, simulate the operation without modifying the database.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: The newly created recipient ID if inserted, or None if the recipient already existed and was updated.
    """
    mid = None

    with get_connection(optional_connection) as connection:
        recipient = None

        if notifier_id is not None:
            recipient = connection.execute(text("""
                SELECT nr.*
                  FROM notifier_recipient nr, notifier n, campaign c
                 WHERE n.id=:notifier_id
                   AND nr.notifier_id=n.id
                   AND c.id=n.campaign_id
                   AND nr.user_id=:user_id
                   AND c.id=:campaign_id
                """).bindparams(
                notifier_id=notifier_id,
                campaign_id=campaign_id,
                user_id=user_id
            )).first()

        if recipient is not None:
            update_regarding = existing_regarding = None

            if recipient.regarding is not None:
                existing_regarding = json.loads(recipient.regarding.decode('utf-8'))

            if existing_regarding is None:
                update_regarding = json.dumps(regarding, default=str)
            elif isinstance(existing_regarding, dict):
                if regarding != existing_regarding:
                    update_regarding = json.dumps([existing_regarding, regarding], default=str)
            elif isinstance(existing_regarding, list):
                if regarding not in existing_regarding:
                    existing_regarding.append(regarding)
                    update_regarding = json.dumps(existing_regarding, default=str)

            if update_regarding is not None:
                if not dry_run:
                    connection.execute(text("""
                        UPDATE notifier_recipient
                           SET regarding=:regarding                               
                         WHERE id=:id
                        """).bindparams(
                        id=recipient.id,
                        regarding=update_regarding
                    ))

                    if optional_connection is None:
                        connection.commit()
        else:
            # The recipient was not found, so let's add them to the notification.
            mid = uuid.uuid1().hex

            if not dry_run:
                regarding = json.dumps(regarding, default=str)

                connection.execute(text("""
                     INSERT 
                       INTO notifier_recipient(id, notifier_id, user_id, regarding, locale)
                     VALUES(:id, :notifier_id, :user_id, :regarding, :locale)
                   """).bindparams(
                    id=mid,
                    notifier_id=notifier_id,
                    user_id=user_id,
                    regarding=regarding,
                    locale=locale
                ))

                if optional_connection is None:
                    connection.commit()

    return mid


def move_to_draft(notifier_id, optional_connection=None):
    """
    Move a notification back to the 'draft' mailbox.

    :param notifier_id: ID of the notification to move back to draft status.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE notifier
                SET outbox_date=NULL,
                    mailbox='draft'
              WHERE id=:notifier_id
           """).bindparams(
            notifier_id=notifier_id,
        ))

        if optional_connection is None:
            connection.commit()


def move_to_outbox(notifier_id, optional_connection=None):
    """
    Move a notification to the 'outbox' mailbox, scheduling it for sending.

    :param notifier_id: ID of the notification to move to the outbox.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE notifier
                SET outbox_date=:outbox_date,
                    mailbox='outbox'
              WHERE id=:notifier_id
           """).bindparams(
            notifier_id=notifier_id,
            outbox_date=datetime.now()
        ))

        if optional_connection is None:
            connection.commit()


def move_to_sent(notifier_id, optional_connection=None):
    """
    Mark a notification as sent by moving it to the 'sent' mailbox.

    :param notifier_id: ID of the notification to mark as sent.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.
    """
    with get_connection(optional_connection) as connection:
        connection.execute(text("""
             UPDATE notifier
                SET sent_date=:sent_date,
                    mailbox='sent'
              WHERE id=:notifier_id
           """).bindparams(
            notifier_id=notifier_id,
            sent_date=datetime.now()
        ))

        if optional_connection is None:
            connection.commit()


def update_notifier_recipient_result(notifier_recipient_id,
                                     status,
                                     message_id=None,
                                     message=None,
                                     code=None,
                                     sent_date=None,
                                     optional_connection=None):
    """
    Update the delivery result for a specific notification recipient.

    Rules:
      - If the current status is already 'delivered', keep it 'delivered'
        (do not downgrade to a different status).
      - message_id, message, code, and sent_date are still updated.

    :param notifier_recipient_id: ID of the recipient record to update.
    :param status: Final delivery status (e.g., 'sent', 'failed', 'bounced').
    :param message_id: Optional ID returned by the delivery provider.
    :param message: Optional human-readable message or error detail.
    :param code: Optional error/status code for tracking or diagnostics.
    :param sent_date: Optional datetime when the message was sent.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.
    """
    with get_connection(optional_connection) as connection:
        connection.execute(
            text("""
                UPDATE notifier_recipient
                   SET status = CASE
                                   WHEN status = 'delivered' THEN status
                                   ELSE :status
                               END,
                       message_id = :message_id,
                       message    = :message,
                       code       = :code,
                       sent_date  = :sent_date
                 WHERE id = :notifier_recipient_id
            """).bindparams(
                notifier_recipient_id=notifier_recipient_id,
                status=status,
                message_id=message_id,
                message=message,
                code=code,
                sent_date=sent_date
            )
        )

        if optional_connection is None:
            connection.commit()


def update_notifier_message_result(notifier_recipient_id,
                                   status,
                                   opens_count,
                                   clicks_count,
                                   optional_connection=None):
    """
    Update message engagement metrics and status for a specific notification recipient.

    Rules:
      - If the current status is already 'delivered', keep it 'delivered'
        (do not downgrade to a different status).
      - opens_count and clicks_count will always be updated.

    :param notifier_recipient_id: ID of the recipient record to update.
    :param status: Current status of the message (e.g., 'delivered', 'opened', 'clicked').
    :param opens_count: Total number of times the message was opened.
    :param clicks_count: Total number of times links within the message were clicked.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.
    """
    with get_connection(optional_connection) as connection:
        connection.execute(
            text("""
                UPDATE notifier_recipient
                   SET status      = CASE
                                         WHEN status = 'delivered' THEN status
                                         ELSE :status
                                     END,
                       opens_count  = :opens_count,
                       clicks_count = :clicks_count
                 WHERE id = :notifier_recipient_id
            """).bindparams(
                notifier_recipient_id=notifier_recipient_id,
                status=status,
                opens_count=opens_count,
                clicks_count=clicks_count
            )
        )

        if optional_connection is None:
            connection.commit()


def delete_notification(notifier_id, optional_connection=None):
    """
    Permanently delete a notification and all of its associated recipients.

    :param notifier_id: ID of the notification to delete.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: None
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
             DELETE 
               FROM notifier
              WHERE id=:notifier_id
           """).bindparams(notifier_id=notifier_id)
        connection.execute(sql)

        sql = text("""
             DELETE 
               FROM notifier_recipient
              WHERE notifier_id=:notifier_id
           """).bindparams(
            notifier_id=notifier_id
        )
        connection.execute(sql)

        if optional_connection is None:
            connection.commit()


def delete_recipient(recipient_id, optional_connection=None):
    """
    Delete a single recipient from a notification. If it was the last recipient, also delete the notification.

    :param recipient_id: ID of the `notifier_recipient` record to delete.
    :param optional_connection: Optional existing DB connection. If None, a new connection is used.

    :return: None
    """
    with get_connection(optional_connection) as connection:
        sql = text("""
             SELECT nr2.*
               FROM notifier_recipient nr, notifier n, notifier_recipient nr2
              WHERE nr.id=:recipient_id
                AND n.id=nr.notifier_id
                AND nr2.notifier_id=n.id
            """).bindparams(recipient_id=recipient_id)

        results = connection.execute(sql)
        rows = results.all()

        if rows is not None:
            sql = text("""
                 DELETE 
                   FROM notifier_recipient
                  WHERE id=:recipient_id
               """).bindparams(
                recipient_id=recipient_id
            )
            connection.execute(sql)

            total_recipients = len(rows) - 1

            if total_recipients <= 0:
                notifier_id = rows[0].notifier_id
                sql = text("""
                     DELETE 
                       FROM notifier
                      WHERE id=:notifier_id
                   """).bindparams(
                    notifier_id=notifier_id
                )
                connection.execute(sql)

        if optional_connection is None:
            connection.commit()
