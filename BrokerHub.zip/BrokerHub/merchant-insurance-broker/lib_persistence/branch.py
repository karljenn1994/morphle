import logging

from sqlalchemy import text

from lib_common.constants import LOGGER
from lib_persistence import get_connection

log = logging.getLogger(LOGGER)


def lookup_branch_by_name(branch_name, optional_connection=None):
    if not branch_name:
        return None

    with get_connection(optional_connection) as connection:
        return connection.execute(text("""
            SELECT *
              FROM branch
             WHERE name = :branch_name
            """).bindparams(
            branch_name=branch_name)
        ).first()


def lookup_branch_contract_by_contract_number(contract_number, optional_connection=None):
    if not contract_number:
        return None

    with get_connection(optional_connection) as connection:
        row = connection.execute(text("""
            SELECT *
              FROM branch_contract
             WHERE contract_number = :contract_number
            """).bindparams(
            contract_number=contract_number)
        ).first()

        if not row:
            return None

        return row.branch


def lookup_branch_policy_by_policy_number(policy_number, optional_connection=None):
    if not policy_number:
        return None

    with get_connection(optional_connection) as connection:
        row = connection.execute(text("""
            SELECT *
              FROM branch_policy
             WHERE policy_number = :policy_number
            """).bindparams(
            policy_number=policy_number)
        ).first()

        if not row:
            return None

        return row.branch


def upsert_contract(branch: str,
                    contract_number: str,
                    optional_connection=None):
    if not branch or not contract_number:
        return

    with get_connection(optional_connection) as connection:
        connection.execute(text(
            """
            INSERT IGNORE INTO branch_contract (branch, contract_number)
            VALUES (:branch, :contract_number)
            """
        ).bindparams(
            branch=branch,
            contract_number=contract_number
        ))

        if optional_connection is None:
            connection.commit()


def upsert_branch_policies(branch: str,
                           policies: list[tuple[str, str, str]],
                           optional_connection=None):
    """
    Insert branch policies with (policy_number, company, lob).
    Skips duplicates based on the composite primary key.

    :param branch: Branch identifier
    :param policies: List of (policy_number, company, lob) tuples
    :param optional_connection: Optional DB connection to reuse
    """
    if not branch or not policies:
        return

    with get_connection(optional_connection) as connection:
        for policy_number, company, lob in policies:
            connection.execute(
                text("""
                    INSERT IGNORE INTO branch_policy (branch, policy_number, company, lob)
                    VALUES (:branch, :policy_number, :company, :lob)
                """).bindparams(
                    branch=branch,
                    policy_number=policy_number,
                    company=company,
                    lob=lob
                )
            )

        if optional_connection is None:
            connection.commit()
