import base64
import json
import logging
from datetime import datetime, timedelta, timezone

from flask import Response, request
from flask_restx import Namespace, Resource

from lib_common import exceptions
from lib_common.authentication import authenticate_branch_token, get_bearer_token_from_headers
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException
from lib_common.repository import Repository
from lib_common.routes_support import response_json
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import branch

api = Namespace("branch-api/web/v1", description="Provides access between branches.")
log = logging.getLogger(LOGGER)

# ---- Lease configuration -----------------------------------------------------

LEASE_SUFFIX = "__LEASED"
LEASE_FILE = ".lease.json"
LEASE_TIMEOUT_MINUTES = 1


# ---- Small helpers -----------------------------------------------------------

def _now_utc():
    return datetime.now(timezone.utc)


def _now_utc_iso():
    return _now_utc().strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _is_hidden(name: str) -> bool:
    return name.startswith(".")


def _strip_lease_suffix(name: str) -> tuple[str, bool]:
    if name.endswith(LEASE_SUFFIX):
        return name[: -len(LEASE_SUFFIX)], True
    return name, False


def _lease_file_path(fm, folder_path: str) -> str:
    return fm.join(folder_path, LEASE_FILE)


def _read_lease(fm, folder_path: str) -> dict | None:
    path = _lease_file_path(fm, folder_path)
    try:
        raw_bytes = fm.read_file(path, False)
        raw = raw_bytes.decode("utf-8", errors="strict")
        return json.loads(raw)
    except Exception:
        return None


def _write_lease(fm, folder_path: str, session_guid: str | None, ttl_minutes: int | None = None):
    lease = {
        "leased_at": _now_utc_iso(),
        "session_guid": session_guid or "unknown",
        "ttl_minutes": int(ttl_minutes or LEASE_TIMEOUT_MINUTES),
    }
    path = _lease_file_path(fm, folder_path)
    data = json.dumps(lease, ensure_ascii=False)
    fm.write_string(path, data)


def _remove_lease_file(fm, folder_path: str):
    try:
        path = _lease_file_path(fm, folder_path)
        if fm.exists(path):
            fm.remove(path)
    except Exception:
        pass


def _lease_is_expired(lease: dict | None) -> bool:
    try:
        if not lease:
            return True
        leased_at = lease.get("leased_at")
        if not leased_at:
            return True
        ttl = int(lease.get("ttl_minutes", LEASE_TIMEOUT_MINUTES))
        leased_dt = datetime.fromisoformat(leased_at.replace("Z", "+00:00"))
        return _now_utc() > (leased_dt + timedelta(minutes=ttl))
    except Exception:
        return True


def _parse_message_name_for_api(name: str) -> tuple[str, str] | None:
    base, _ = _strip_lease_suffix(name)
    parts = base.rsplit("_", 2)
    if len(parts) < 3:
        return None
    date_time = parts[0]
    guid = parts[1] + "." + parts[2]
    return date_time, guid


def _find_matching_folder_by_guid_suffix(fm, branch_root: str, message_guid: str) -> str | None:
    suffix = message_guid.replace(".", "_")
    try:
        for f in fm.listdir(branch_root):
            if _is_hidden(f):
                continue
            if f.endswith(suffix) or f.endswith(suffix + LEASE_SUFFIX):
                return fm.join(branch_root, f)
    except FileNotFoundError:
        return None
    except Exception:
        return None
    return None


def _quick_sweep_branch(fm, branch_root: str) -> int:
    released = 0
    try:
        for f in fm.listdir(branch_root):
            if _is_hidden(f) or not f.endswith(LEASE_SUFFIX):
                continue
            leased_path = fm.join(branch_root, f)
            lease = _read_lease(fm, leased_path)
            if _lease_is_expired(lease):
                base_name, _ = _strip_lease_suffix(f)
                base_path = fm.join(branch_root, base_name)
                try:
                    _remove_lease_file(fm, leased_path)
                except Exception:
                    pass
                try:
                    fm.move(leased_path, base_path)
                    released += 1
                except Exception as e:
                    log.warning("Quick sweep failed to release %s: %s", leased_path, e)
    except FileNotFoundError:
        pass
    return released


# ---- API resources -----------------------------------------------------------

@api.route("/messages", methods=["POST"])
@api.doc(description="Get messages for the branch.")
class Messages(Resource):

    @staticmethod
    def _sign_in():
        return response_json(200, {'Response': {'SessionGUID': '12345'}})

    @staticmethod
    def _sign_out():
        return response_json(200, {})

    @staticmethod
    def _list_messages(branch_name: str, page: int, page_size: int):
        fm = FileManagerFactory.create_file_manager()
        branch_root = fm.join(Repository.mail_root_location, "branches", branch_name)

        _quick_sweep_branch(fm, branch_root)

        messages = []
        try:
            for f in fm.listdir(branch_root):
                if _is_hidden(f):
                    continue
                date_guid = _parse_message_name_for_api(f)
                if not date_guid:
                    continue
                date_time, guid = date_guid
                leased = f.endswith(LEASE_SUFFIX)
                messages.append({
                    "MessageGUID": guid,
                    "DateTime": date_time,
                    "Leased": leased,
                })
        except FileNotFoundError:
            pass

        messages.sort(key=lambda m: m["DateTime"])
        messages_available = len(messages)

        if page < 1:
            page = 1
        if page_size < 1:
            page_size = 1
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        messages_window = messages[start_index:end_index]

        resp = {
            "Response": {
                "MessagesAvailable": messages_available,
                "Page": page,
                "PageSize": page_size,
                "Message": messages_window,
            }
        }
        return response_json(200, resp)

    @staticmethod
    def _retrieve_message(branch_name: str, message_guid: str, session_guid: str | None = None):
        fm = FileManagerFactory.create_file_manager()
        branch_root = fm.join(Repository.mail_root_location, "branches", branch_name)

        folder_path = _find_matching_folder_by_guid_suffix(fm, branch_root, message_guid)
        if not folder_path:
            return response_json(404, {"Response": {"Status": f"Message {message_guid} not found"}})

        folder_dirname = fm.basename(folder_path)
        base_name, is_leased = _strip_lease_suffix(folder_dirname)

        if is_leased:
            lease = _read_lease(fm, folder_path)
            if _lease_is_expired(lease):
                try:
                    _remove_lease_file(fm, folder_path)
                except Exception:
                    pass
                base_path = fm.join(branch_root, base_name)
                try:
                    fm.move(folder_path, base_path)
                    folder_path = base_path
                    is_leased = False
                except Exception as e:
                    log.warning("Failed to release expired lease for %s: %s", folder_path, e)
            else:
                if lease and lease.get("session_guid") == (session_guid or "unknown"):
                    try:
                        _write_lease(fm, folder_path, session_guid=session_guid)
                    except Exception as e:
                        log.debug("Failed to refresh lease file for %s: %s", folder_path, e)

        if not is_leased:
            leased_name = base_name + LEASE_SUFFIX
            leased_path = fm.join(branch_root, leased_name)
            try:
                fm.move(folder_path, leased_path)
                folder_path = leased_path
                _write_lease(fm, folder_path, session_guid=session_guid)
                is_leased = True
            except Exception as e:
                log.warning("Failed to acquire lease for %s: %s", folder_path, e)

        attachments = []
        try:
            for f_name in fm.listdir(folder_path):
                if _is_hidden(f_name):
                    continue
                fpath = fm.join(folder_path, f_name)
                content_bytes = fm.read_file(fpath, False)
                encoded = base64.b64encode(content_bytes).decode("ascii")
                attachments.append({
                    "@filename": fm.basename(f_name),
                    "#text": encoded,
                })
        except FileNotFoundError:
            return response_json(404, {"Response": {"Status": f"Message {message_guid} not found"}})

        attachment_obj = attachments[0] if len(attachments) == 1 else attachments

        return response_json(200, {
            "Response": {
                "Attachments": {"Attachment": attachment_obj}
            }
        })

    @staticmethod
    def _ack_message(branch_name: str, message_guid: str):
        fm = FileManagerFactory.create_file_manager()
        branch_root = fm.join(Repository.mail_root_location, "branches", branch_name)

        folder_path = _find_matching_folder_by_guid_suffix(fm, branch_root, message_guid)
        if not folder_path:
            return response_json(404, {"Response": {"Status": f"Message {message_guid} not found"}})

        try:
            fm.rmtree(folder_path)
        except Exception as e:
            log.warning("Failed to delete message folder %s: %s", folder_path, e)
            return response_json(500, {"Response": {"Status": f"Failed to delete message {message_guid}"}})

        return response_json(200, {"Response": {"Status": "OK"}})

    @staticmethod
    def _release_message(branch_name: str, message_guid: str):
        fm = FileManagerFactory.create_file_manager()
        branch_root = fm.join(Repository.mail_root_location, "branches", branch_name)

        folder_path = _find_matching_folder_by_guid_suffix(fm, branch_root, message_guid)
        if not folder_path:
            return response_json(404, {"Response": {"Status": f"Message {message_guid} not found"}})

        folder_dirname = fm.basename(folder_path)
        base_name, is_leased = _strip_lease_suffix(folder_dirname)

        if is_leased:
            base_path = fm.join(branch_root, base_name)
            try:
                _remove_lease_file(fm, folder_path)
            except Exception:
                pass
            try:
                fm.move(folder_path, base_path)
            except Exception as e:
                log.warning("Failed to release lease for %s: %s", folder_path, e)
                return response_json(500, {"Response": {"Status": f"Failed to release {message_guid}"}})

        return response_json(200, {"Response": {"Status": "OK"}})

    @staticmethod
    def _sweep_leases(branch_name: str):
        fm = FileManagerFactory.create_file_manager()
        branch_root = fm.join(Repository.mail_root_location, "branches", branch_name)

        released = _quick_sweep_branch(fm, branch_root)
        return response_json(200, {"Response": {"Released": released}})

    @staticmethod
    def post():
        try:
            json_data = request.json or {}

            # Verify the branch and get the branch's id.
            branch_name = json_data.get("Branch")
            branch_obj = branch.lookup_branch_by_name(branch_name)
            api_key = branch_obj.api_key
            branch_token = json_data.get("BranchToken")
            name = authenticate_branch_token(api_key, branch_token)

            if branch_name != name:
                raise AuthenticationException(
                    "Branch authentication failed",
                    error_code=exceptions.CODE_ADMIN_USER_AUTHENTICATION_FAILED)

            branch_name = name
            json_data = request.json or {}
            command = json_data.get("CommandType")

            if command == 'SignIn':
                return Messages._sign_in()

            elif command == 'SignOut':
                return Messages._sign_out()

            elif command == 'List':
                page = int(json_data.get("Page", 1))
                page_size = int(json_data.get("PageSize", 1))
                return Messages._list_messages(branch_name, page, page_size)

            elif command == 'Retrieve':
                message_guid = json_data.get("MessageGUID")
                session_guid = json_data.get("SessionGUID")
                if not message_guid:
                    return response_json(400, {"Response": {"Status": "MessageGUID is required"}})
                return Messages._retrieve_message(branch_name, message_guid, session_guid)

            elif command == 'Acknowledge':
                message_guid = json_data.get("MessageGUID")
                if not message_guid:
                    return response_json(400, {"Response": {"Status": "MessageGUID is required"}})
                return Messages._ack_message(branch_name, message_guid)

            elif command == 'Release':
                message_guid = json_data.get("MessageGUID")
                if not message_guid:
                    return response_json(400, {"Response": {"Status": "MessageGUID is required"}})
                return Messages._release_message(branch_name, message_guid)

            elif command == 'SweepLeases':
                return Messages._sweep_leases(branch_name)

            return Response(status=401, mimetype="application/json")

        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {"message": str(ex)})
