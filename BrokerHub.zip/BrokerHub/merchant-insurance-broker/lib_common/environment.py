import logging
import os

from lib_common.constants import LOGGER

log = logging.getLogger(LOGGER)


def get_environment_variable(var, allow_none=False):
    val = None

    if var not in os.environ:
        if not allow_none:
            raise EnvironmentError("Failed because {} is not set.".format(var))
    else:
        val = os.getenv(var)

    return val


def print_env_var(name, mask=False):
    if name in os.environ and len(os.environ[name]) > 0:
        val = os.environ[name]

        if mask:
            if len(val) > 2:
                val = val[:1] + len(val[1:-1]) * "*" + val[-1:]
            else:
                val = len(val) * "*"

        log.info("%s: %s", name, val)

    else:
        log.fatal("%s: missing", name)


def print_environment():
    # print()
    # print_env_var(constants.ENV_DB_HOST)
    # print_env_var(constants.ENV_DB_NAME)
    # print_env_var(constants.ENV_DB_USER)
    # print_env_var(constants.ENV_DB_PASSWORD)
    # print()
    pass
