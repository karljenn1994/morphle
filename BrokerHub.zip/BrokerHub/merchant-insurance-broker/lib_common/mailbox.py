import base64
import re

from lib_common import constants
from lib_common.repository import Repository
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import settings

BINARY_EXTS = (".pdf", ".xls", ".xlsx", ".csv", ".doc", ".docx", ".jpg", ".jpeg", ".png")

_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._\-\s]+")


class Mailbox(object):
    def __new__(cls, *args, **kwds):
        it = cls.__dict__.get("__it__")

        if it is not None:
            return it

        cls.__it__ = it = object.__new__(cls)
        return it

    def __init__(self):
        fm = FileManagerFactory.create_file_manager()
        self.mail_inbox_location = fm.join(
            settings.get_setting(constants.SETTING_SYSTEM_FOLDER), Repository.mail_inbox_location)
        self.purged_mail_location = fm.join(
            settings.get_setting(constants.SETTING_SYSTEM_FOLDER), Repository.purged_location)

    @staticmethod
    def safe_name(name: str, max_len: int = 255) -> str:
        name = _SAFE_NAME_RE.sub("", name or "")
        name = " ".join(name.split())
        return name[:max_len]

    def date_to_str(self, dt):
        return dt.strftime("%a %b %d %H:%M:%S %Z %Y")

    def _initialize_inbox(self):
        fm = FileManagerFactory.create_file_manager()
        if not fm.exists(Repository.mail_inbox_location):
            fm.mkdirs(Repository.mail_inbox_location)

    def _as_list(self, x):
        if not x:
            return []
        return x if isinstance(x, list) else [x]

    def _folder_name(self, message_datetime: str, message_guid: str) -> str:
        # keep message_datetime exactly as-is, no parsing/normalization
        dt_part = message_datetime
        guid_part = (message_guid or "").replace(".", "_")
        name = f"{dt_part}_{guid_part}" if guid_part else dt_part
        return Mailbox.safe_name(name)

    def save_api_attachments(
            self,
            location,
            attachments,
            message_datetime: str,
            message_guid: str,
            message_type: str | None = None,
            dry_run: bool = False):

        fm = FileManagerFactory.create_file_manager()
        attachments_saved = []

        folder_name = self._folder_name(message_datetime, message_guid)
        folder_path = fm.join(location, folder_name)

        if not dry_run:
            fm.mkdirs(folder_path)

        for attachment in self._as_list(attachments):
            name = (attachment or {}).get("@filename")
            if not name:
                continue
            safe_name = Mailbox.safe_name(name)
            if not safe_name:
                continue
            b64 = (attachment or {}).get("#text", "")
            try:
                data = base64.b64decode(b64, validate=True)
            except Exception:
                continue
            rel_path = fm.join(folder_name, safe_name)
            attachments_saved.append(rel_path)
            if not dry_run:
                full_path = fm.join(folder_path, safe_name)
                fm.write_file(full_path, data)

        attachments_saved.sort()
        return attachments_saved
