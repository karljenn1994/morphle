CODE_CSIONET_SIGNIN_FAILED = 10
CODE_CSIONET_SIGNOUT_FAILED = 11
CODE_CSIONET_COMMAND_FAILED = 12
CODE_INVALID_CONTENT_TYPE = 13
CODE_MISSING_CONTENT = 14
CODE_INVALID_ARGUMENT = 15
CODE_MISSING_CONFIGURATION = 16
CODE_TASK_FAILED = 17

CODE_ACCOUNT_CONFLICT_MORE_THEN_ONE_FOUND = 100
CODE_ACCOUNT_NOT_FOUND = 101
CODE_CONFLICTING_ACCOUNT = 102
CODE_NO_CLIENTS = 103

CODE_CARD_JSON_MISSING_INDIVIDUAL_POSTAL_CODE = 200
CODE_CARD_JSON_MISSING_INDIVIDUAL_PROVINCE = 201
CODE_CARD_JSON_MISSING_INDIVIDUAL_FULL_NAME = 202

CODE_CARD_JSON_MISSING_DRIVERS_LICENCE_NUMBER = 300
CODE_CARD_JSON_MISSING_DRIVERS_LICENCE_PROVINCE = 301
CODE_CARD_JSON_MISSING_DRIVERS_LICENCE_DOB = 302
CODE_CARD_JSON_MISSING_DRIVERS_LICENCE_FIRST_NAME = 303
CODE_CARD_JSON_MISSING_DRIVERS_LICENCE_LAST_NAME = 304

CODE_AL3_MISSING_POLICY_NUMBER = 400
CODE_AL3_MISSING_COMPANY = 401
CODE_AL3_MISSING_DATE_OF_BIRTH = 402
CODE_AL3_MISSING_POSTAL_CODE = 403

CODE_XML_MISSING_POLICY_NUMBER = 500
CODE_XML_MISSING_COMPANY_NAME = 501

CODE_ADMIN_USER_ALREADY_EXISTS = 600
CODE_ADMIN_USER_DOES_NOT_EXIST = 601
CODE_ADMIN_USER_AUTHENTICATION_FAILED = 602
CODE_ADMIN_USER_INVALID_CONFIRM_CODE = 603
CODE_ADMIN_USER_STATUS_NOT_ACTIVE = 604
CODE_ADMIN_USER_STATUS_NOT_PENDING = 605
CODE_ADMIN_USER_STATUS_NOT_FORGOT = 606
CODE_ADMIN_USER_IN_RESET_MODE = 607
CODE_ADMIN_USER_INVALID_RESET_CODE = 608
CODE_ADMIN_USER_PASSWORD_MISMATCH = 609
CODE_ADMIN_USER_STATUS_UNCONFIRMED = 610
CODE_ADMIN_USER_ACCOUNT_DISABLED = 611
CODE_ADMIN_USER_FORGOT_IN_PROGRESS = 612
CODE_ADMIN_USER_ROLE_NOT_ADMIN = 613
CODE_ADMIN_USER_STATUS_IS_GUEST = 614
CODE_ADMIN_USER_STATUS_IS_UPLOADED = 615

CODE_ADMIN_CANNOT_DELETE_YOURSELF = 700
CODE_ADMIN_MISSING_SETTING = 701

CODE_ADMIN_POLICY_ALREADY_EXISTS = 800
CODE_ADMIN_POLICY_DELETE_WITH_CLIENTS = 801
CODE_ADMIN_POLICY_DOES_NOT_EXIST = 802

CODE_ADMIN_CAMPAIGN_MISSING = 900
CODE_ADMIN_CAMPAIGN_INACTIVE = 901
CODE_ADMIN_CAMPAIGN_TEMPLATE_IN_USE = 902
CODE_ADMIN_CAMPAIGN_FORM_IN_USE = 903
CODE_ADMIN_CAMPAIGN_IN_USE = 904

CODE_UNSUPPORTED_POLICY_TYPE = 1000

CODE_ADMIN_VALIDATIONS_IN_USE = 1100

CODE_AUTH_EXPIRED_BEARER_TOKEN = 1200
CODE_AUTH_ACCESS_DENIED = 1201

CODE_ADMIN_NOTIFICATION_MISSING_VARIABLE = 1300

CODE_ADMIN_BRANCH_AUTHENTICATION_FAILED = 1400



class NotificationException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class ValidationException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class MissingCampaignException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class CampaignException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class CampaignInactiveException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class DeleteFailedException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class AlreadyExistsException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class AuthenticationException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class AuthenticationExpiredException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class AL3Exception(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class XMLException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class JSONException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class MissingFieldException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class TaskException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class SubprocessException(Exception):
    def __init__(self, result, message, error_code=None):
        self.result = result
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class HttpException(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)


class InvalidArgument(Exception):
    def __init__(self, message, error_code=None):
        self.message = message
        self.code = error_code
        super().__init__(self.message)
