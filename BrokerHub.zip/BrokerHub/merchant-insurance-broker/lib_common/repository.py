import os
from datetime import datetime

from lib_common import constants
from lib_persistence import settings


class Repository(object):
    policies_location = "policies"
    expired_location = "expired"
    claims_location = "claims"
    quotes_location = "quotes"
    mail_root_location = "mail"
    mail_all_mail_location = "all_mail"
    mail_inbox_location = "mail/inbox"
    # mail_location = "inbox"
    purged_location = "mail/purged"
    import_location = "import"
    import_policies_location = "import/policies"
    import_users_location = "import/users"
    backup_location = "backup"
    config_location = "config"
    journal_location = "journal"
    pub_location = "pub"

    def __new__(cls, *args, **kwds):
        it = cls.__dict__.get("__it__")

        if it is not None:
            return it

        cls.__it__ = it = object.__new__(cls)
        it.init(*args, **kwds)
        return it

    def init(self):
        pass

    @staticmethod
    def get_transaction_effective_date_and_number(file_name):
        file_name_parts = file_name.split("_")
        transaction_effective_date = datetime.strptime(file_name_parts[2], '%Y%m%d')
        transaction_effective_date = transaction_effective_date.strftime('%Y-%m-%d')

        number = 1
        number_str = file_name_parts[4]

        if number_str == "XLN":
            number = 100

        return transaction_effective_date, number
