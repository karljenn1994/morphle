import logging
import os
from lib_common import constants


def setup_logging(worker_pid=None):
    # Removed %(name)s from the format string
    logging_format = "%(levelname)s: %(message)s"
    log_level = logging.DEBUG

    if constants.LOGGING_LEVEL in os.environ:
        log_level = logging.getLevelName(os.environ[constants.LOGGING_LEVEL])

    # --- Configure the root logger exclusively ---
    root_logger = logging.getLogger()
    # Explicitly remove all existing handlers from the root logger
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    root_logger.setLevel(log_level)

    # Create and configure the single stream handler
    stream_handler = logging.StreamHandler()
    formatter = logging.Formatter(logging_format)
    stream_handler.setFormatter(formatter)
    stream_handler.setLevel(log_level)

    # Add the stream handler to the root logger
    root_logger.addHandler(stream_handler)

    # Silence noisy libraries
    logging.getLogger("sqlalchemy").setLevel(logging.WARNING)

    # Confirmation message using the root logger
    root_logger.info(f"Logger initialized for {'worker ' + str(worker_pid) if worker_pid else 'master process'} via Root Logger.")