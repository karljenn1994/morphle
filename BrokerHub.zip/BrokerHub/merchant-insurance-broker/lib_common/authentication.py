from datetime import datetime, timedelta, timezone

import jwt
from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt

from lib_common import constants, exceptions
from lib_common.exceptions import AuthenticationException, AuthenticationExpiredException
from lib_persistence import persistence, settings, user
from lib_vault.vault import Vault


def get_bearer_token_from_headers(headers):
    if "Authorization" in headers:
        bearer = headers.get("Authorization")
        token = bearer.split()[1]
        return token

    return None


def get_user_id_email_from_headers(headers):
    """
    This is used when requests come from mobile that include user information in the headers.
    """
    user_id = None
    email = None

    if "Authorization" in headers:
        bearer = headers.get("Authorization")
        token = bearer.split()[1]

        secret = settings.get_setting(constants.SETTING_JWT_SECRET)
        payload = jwt.decode(token, secret, algorithms=["HS256"])

        if "clientId" in payload:
            client_id = payload["clientId"]
            user_id = user.lookup_user_id_by_id(client_id)

        if "email" in payload:
            email = payload["email"]

        if user_id is None and email is not None:
            user_id = user.lookup_user_id_by_email(email)

    return user_id, email


def get_user_id_from_token(token):
    """
    This is used when we have send a guest token, then it expires. We need
    to get the user_id out of the token to send them a new guest token.
    """
    payload = jwt.decode(
        token,
        settings.get_setting(constants.SETTING_JWT_SECRET),
        algorithms=["HS256"])

    if "user_id" not in payload:
        raise AuthenticationException("Invalid bearer token")

    return payload["user_id"]


def get_user_id_from_cookies():
    """
    Get the user id of the user from JWT HTTP cookies.
    """
    claims = get_jwt()
    return claims["user_id"]


def authenticate_identity_token(token):
    """
    An identity token is given out when we need to give the user a way to log in
    with a link. For example, logging is as a guest. We give the user an identity token
    that identifies the user and allows them to login. Once logged in, access and refresh
    HTTP tokens take over.
    """
    payload = jwt.decode(token, settings.get_setting(constants.SETTING_JWT_SECRET), algorithms=["HS256"])
    required_fields = {"purpose", "expires", "user_id"}

    if not required_fields.issubset(payload) or payload["purpose"] not in {"identity"}:
        raise AuthenticationException("Invalid bearer token")

    expires = datetime.strptime(payload["expires"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)

    if datetime.now(timezone.utc) > expires:
        raise AuthenticationExpiredException(
            "Session expired",
            error_code=exceptions.CODE_AUTH_EXPIRED_BEARER_TOKEN
        )

    return payload["user_id"], expires


def authenticate_form_user(headers):
    token = get_bearer_token_from_headers(headers)

    if not token:
        raise AuthenticationException("Missing bearer token")

    return authenticate_identity_token(token)


def authenticate_form_user_token(token):
    payload = jwt.decode(token, settings.get_setting(constants.SETTING_JWT_SECRET), algorithms=["HS256"])
    required_fields = {"purpose", "expires", "user_id", "form_id"}

    if not required_fields.issubset(payload) or payload["purpose"] != 'form':
        raise AuthenticationException("Invalid bearer token")

    expires = datetime.strptime(payload["expires"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)

    if datetime.now(timezone.utc) > expires:
        raise AuthenticationExpiredException(
            "Session expired",
            error_code=exceptions.CODE_AUTH_EXPIRED_BEARER_TOKEN
        )

    return payload["user_id"], \
        payload["form_id"], \
        payload["policy_id"] if "policy_id" in payload else None, \
        expires


def authenticate_branch_token(api_key, token):
    payload = jwt.decode(token, api_key, algorithms=["HS256"])
    required_fields = {"purpose", "issuer_name"}

    if not required_fields.issubset(payload) or payload["purpose"] != 'mail':
        raise AuthenticationException("Invalid bearer token")

    return payload["issuer_name"]


def assert_admin_user():
    user_id = get_user_id_from_cookies()

    if not user_id:
        raise AuthenticationException(
            "User not found",
            error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

    user_obj = user.lookup_user_by_id(user_id)

    if not user_obj:
        raise AuthenticationException(
            "User not found",
            error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

    if user_obj.status != persistence.USER_STATUS_ACTIVE:
        raise AuthenticationException(
            "User is not active",
            error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

    if user_obj.role != persistence.ROLE_ADMIN:
        raise AuthenticationException(
            "User must be an administrator",
            error_code=exceptions.CODE_ADMIN_USER_ROLE_NOT_ADMIN)

    return user_obj


def assert_user():
    user_id = get_user_id_from_cookies()

    if not user_id:
        raise AuthenticationException(
            "User not found",
            error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

    user_obj = user.lookup_user_by_id(user_id)

    if not user_obj:
        raise AuthenticationException(
            "User not found",
            error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

    return user_obj


def assert_extension_token():
    claims = get_jwt()

    if claims.get("purpose") != "extension":
        raise AuthenticationException(
            "Invalid token",
            error_code=exceptions.CODE_ADMIN_USER_AUTHENTICATION_FAILED)

    user_obj = user.lookup_user_by_id(claims.get('user_id'))

    if not user_obj:
        raise AuthenticationException(
            "User not found",
            error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

    if user_obj.status != persistence.USER_STATUS_ACTIVE:
        raise AuthenticationException(
            "User is not active",
            error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

    if user_obj.role != persistence.ROLE_ADMIN:
        raise AuthenticationException(
            "User must be an administrator",
            error_code=exceptions.CODE_ADMIN_USER_ROLE_NOT_ADMIN)

    return user_obj


def assert_admin_role(user_obj):
    if not user_obj:
        raise AuthenticationException(
            "User not found",
            error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

    if user_obj.status != persistence.USER_STATUS_ACTIVE:
        raise AuthenticationException(
            "User is not active",
            error_code=exceptions.CODE_ADMIN_USER_STATUS_NOT_ACTIVE)

    if user_obj.role != persistence.ROLE_ADMIN:
        raise AuthenticationException(
            "User must be an administrator",
            error_code=exceptions.CODE_ADMIN_USER_ROLE_NOT_ADMIN)


def generate_ui_access_token(user_obj):
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)

    access_expires = timedelta(minutes=settings.get_int_setting(constants.SETTING_JWT_ACCESS_TOKEN_EXPIRES, 15))
    expires = (datetime.now(timezone.utc) + access_expires).strftime("%Y-%m-%dT%H:%M:%SZ")

    claims = {
        "purpose": "ui",
        "type": "api",
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "email": user_obj.email,
        "role": user_obj.role,
        "status": user_obj.status,
        "first_name": user_obj.first_name,
        "last_name": user_obj.last_name,
        "expires": expires,
    }

    access_token = create_access_token(
        identity=user_obj.email,
        additional_claims=claims,
        expires_delta=access_expires
    )

    return access_token, claims


def generate_ui_token_pair(user_obj):
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)

    access_expires = timedelta(minutes=settings.get_int_setting(constants.SETTING_JWT_ACCESS_TOKEN_EXPIRES, 15))
    refresh_expires = timedelta(minutes=settings.get_int_setting(constants.SETTING_JWT_REFRESH_TOKEN_EXPIRES, 60))

    access_exp_str = (datetime.now(timezone.utc) + access_expires).strftime("%Y-%m-%dT%H:%M:%SZ")
    refresh_exp_str = (datetime.now(timezone.utc) + refresh_expires).strftime("%Y-%m-%dT%H:%M:%SZ")

    claims = {
        "purpose": "ui",
        "type": "api",
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "email": user_obj.email,
        "role": user_obj.role,
        "status": user_obj.status,
        "first_name": user_obj.first_name,
        "last_name": user_obj.last_name,
        "expires": access_exp_str,
        "refresh_expires": refresh_exp_str,
    }

    access_token = create_access_token(
        identity=user_obj.email,
        additional_claims=claims,
        expires_delta=access_expires
    )
    refresh_token = create_refresh_token(
        identity=user_obj.email,
        expires_delta=refresh_expires
    )

    return access_token, refresh_token, claims


def generate_ui_guest_token_pair(user_obj):
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)

    access_expires = timedelta(minutes=settings.get_int_setting(
        constants.SETTING_JWT_GUEST_ACCESS_TOKEN_EXPIRES,
        default=15))
    refresh_expires = timedelta(minutes=settings.get_int_setting(
        constants.SETTING_JWT_GUEST_REFRESH_TOKEN_EXPIRES,
        default=30))

    access_exp_str = (datetime.now(timezone.utc) + access_expires).strftime("%Y-%m-%dT%H:%M:%SZ")
    refresh_exp_str = (datetime.now(timezone.utc) + refresh_expires).strftime("%Y-%m-%dT%H:%M:%SZ")

    claims = {
        "purpose": "ui",
        "type": "api",
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "email": user_obj.email,
        "role": user_obj.role,
        "status": user_obj.status,
        "first_name": user_obj.first_name,
        "last_name": user_obj.last_name,
        "expires": access_exp_str,
        "refresh_expires": refresh_exp_str,
    }

    access_token = create_access_token(identity=user_obj.email, additional_claims=claims, expires_delta=access_expires)
    refresh_token = create_refresh_token(identity=user_obj.email, expires_delta=refresh_expires)

    return access_token, refresh_token, claims


def generate_identity_token(user_obj, expires_hours=12):
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)
    expires = (datetime.now(timezone.utc) + timedelta(hours=expires_hours)).strftime("%Y-%m-%dT%H:%M:%SZ")

    encoded_jwt = jwt.encode({
        "purpose": "identity",
        "type": "api",
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "email": user_obj.email,
        "expires": expires,
    }, settings.get_setting(constants.SETTING_JWT_SECRET), algorithm="HS256")
    return encoded_jwt, expires


def generate_form_token(user_obj, form_id, policy_id=None, expires_hours=8760):
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)
    expires = (datetime.now(timezone.utc) + timedelta(hours=expires_hours)).strftime("%Y-%m-%dT%H:%M:%SZ")

    encoded_jwt = jwt.encode({
        "purpose": "form",
        "type": "api",
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "form_id": form_id,
        "policy_id": policy_id,
        "email": user_obj.email,
        "expires": expires,
    }, settings.get_setting(constants.SETTING_JWT_SECRET), algorithm="HS256")
    return encoded_jwt, expires


def generate_extension_token(user_obj, expires_hours=8760):
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)

    token_expires = timedelta(hours=expires_hours)
    expires = (datetime.now(timezone.utc) + timedelta(hours=expires_hours)).strftime("%Y-%m-%dT%H:%M:%SZ")

    claims = {
        "purpose": "extension",
        "type": "api",
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "email": user_obj.email,
        "role": user_obj.role,
        "status": user_obj.status,
        "first_name": user_obj.first_name,
        "last_name": user_obj.last_name,
        "expires": expires
    }

    token = create_access_token(identity=user_obj.email, additional_claims=claims, expires_delta=token_expires)
    return token, claims


def generate_collection_token():
    api_key = settings.get_setting(constants.SETTING_LIFES_WALLET_API_KEY)
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)
    expires = (datetime.now(timezone.utc) + timedelta(minutes=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    encoded_jwt = jwt.encode({
        "purpose": "collect",
        "type": "api",
        "issuer_key": api_key,
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "expires": expires,
    }, settings.get_setting(constants.SETTING_JWT_SECRET), algorithm="HS256")
    return encoded_jwt


def generate_vendor_user_token(user_obj):
    api_key = settings.get_setting(constants.SETTING_LIFES_WALLET_API_KEY)
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)
    expires = (datetime.now(timezone.utc) + timedelta(minutes=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    encoded_jwt = jwt.encode({
        "purpose": "pass",
        "type": "api",
        "issuer_key": api_key,
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "user_id": user_obj.id,
        "email": user_obj.email,
        "expires": expires,
    }, settings.get_setting(constants.SETTING_JWT_SECRET), algorithm="HS256")
    return encoded_jwt


def generate_push_token():
    api_key = settings.get_setting(constants.SETTING_LIFES_WALLET_API_KEY)
    vendor_id = settings.get_setting(constants.SETTING_BROKERAGE_ID)
    vendor_name = settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)
    expires = (datetime.now(timezone.utc) + timedelta(minutes=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    encoded_jwt = jwt.encode({
        "purpose": "push",
        "type": "api",
        "issuer_key": api_key,
        "issuer_id": vendor_id,
        "issuer_name": vendor_name,
        "expires": expires,
    }, settings.get_setting(constants.SETTING_JWT_SECRET), algorithm="HS256")
    return encoded_jwt


def generate_branch_mail_token(api_key):
    branch_name = settings.get_setting(constants.SETTING_SYSTEM_IDENTIFIER)
    encoded_jwt = jwt.encode({
        "purpose": "mail",
        "issuer_name": branch_name,
    }, api_key, algorithm="HS256")
    return encoded_jwt
