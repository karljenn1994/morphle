import json
import logging
import re

from flask import Response

from lib_common import exceptions
from lib_common.constants import LOGGER
from lib_common.exceptions import (
    InvalidArgument
)

log = logging.getLogger(LOGGER)

SUPPORTED_FRIENDLY_LOCALE = {
    # --- English ---
    "en": "en",       # generic English
    "en-US": "en",    # US English
    "en-CA": "en",    # Canadian English

    # --- French ---
    "fr": "fr",          # generic French
    "fr-FR": "fr",       # French (France)
    "fr-CA": "fr",       # Canadian French

    # --- Chinese (Simplified) ---
    "zh-CN": "zh_CN",    # Simplified Chinese (mainland China)
    "zh_CN": "zh_CN",    # alias for Simplified Chinese
    "zh-Hans": "zh_CN",  # Simplified Chinese script tag

    # --- Chinese (Traditional) ---
    "zh-TW": "zh_TW",    # Traditional Chinese (Taiwan)
    "zh_TW": "zh_TW",    # alias for Traditional Chinese
    "zh-Hant": "zh_TW",  # Traditional Chinese script tag

    # --- Spanish ---
    "es": "es",          # generic Spanish
    "es-ES": "es",       # Spanish (Spain)
    "es-MX": "es",       # Spanish (Mexico)
    "es-419": "es",      # Latin American Spanish (general tag)
    "es-AR": "es",       # Spanish (Argentina)
    "es-CO": "es",       # Spanish (Colombia)
    "es-CL": "es",       # Spanish (Chile)
}


def respond(status_code=200, error=None, code=None, message=None, mimetype="application/json"):
    if error is not None:
        log.error(error)

    if status_code == 200:
        return Response(json.dumps(True), status=200, mimetype=mimetype)

    return response_json(status_code, {
        "message": message,
        "code": code
    })


def response_json(status, body, mimetype="application/json"):
    return Response(
        json.dumps(body),
        status=status,
        mimetype=mimetype,
    )


def get_locale(headers):
    """
    Return the best raw language tag from Accept-Language
    (e.g. 'en-US', 'fr-FR', 'zh-CN', 'en').
    """
    accept_language = headers.get("Accept-Language", "")
    if not accept_language:
        return "en"

    # Split on commas, remove quality values
    languages = [re.split(r";", lang.strip())[0] for lang in accept_language.split(",")]

    # Just return the first tag, normalized with dash
    return languages[0]


def get_friendly_locale(headers):
    """
    Return a normalized locale from our supported set:
    'en', 'fr', 'zh_CN', or 'zh_TW'.
    """
    raw = get_locale(headers)
    lang_norm = raw.replace("_", "-")  # unify format

    # Direct match
    if lang_norm in SUPPORTED_FRIENDLY_LOCALE:
        return SUPPORTED_FRIENDLY_LOCALE[lang_norm]

    # Try just the base language
    base = lang_norm.split("-")[0]
    if base in SUPPORTED_FRIENDLY_LOCALE:
        return SUPPORTED_FRIENDLY_LOCALE[base]

    return "en"  # default fallback


def assert_not_none(value, msg):
    if value is None:
        raise InvalidArgument(msg, error_code=exceptions.CODE_INVALID_ARGUMENT)


def rows_to_list(rows):
    return [row._asdict() for row in rows] if rows is not None and len(rows) > 0 else []


def row_to_dict(row):
    return row._asdict()
