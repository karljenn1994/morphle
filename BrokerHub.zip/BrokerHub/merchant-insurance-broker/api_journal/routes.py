import logging

from flask import Response, render_template
from flask_restx import Namespace, Resource

from lib_common.constants import LOGGER
from lib_journal.journal import Journal

api = Namespace("broker-api/web/v1/status", description="Provides status information for the application instance.")
log = logging.getLogger(LOGGER)


@api.route("/report", methods=["GET"])
@api.doc(description="Returns an HTML page with that shows the system status.")
class Status(Resource):
    @staticmethod
    def get():
        """
        Provides status information for the application instance.
        """
        return Response(
            render_template("index.html", journal=Journal().to_json()),
            mimetype="text/html",
            )
