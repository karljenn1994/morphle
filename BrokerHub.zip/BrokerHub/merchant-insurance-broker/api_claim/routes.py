import json
import logging
import uuid

from flask import request
from flask_restx import Namespace, Resource

from lib_common import exceptions
from lib_common.authentication import get_user_id_email_from_headers
from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException
from lib_common.repository import Repository
from lib_common.routes_support import response_json, row_to_dict
from lib_file_manager.file_manager_factory import FileManagerFactory
from lib_persistence import claim, company, user

api = Namespace("broker-api/mobile/v1/claim", description="Provides claims.")
log = logging.getLogger(LOGGER)


@api.route("/details/company_code/<company_code>", methods=["GET"])
@api.doc(description="Get details required for submitting a claim.")
class Details(Resource):
    @staticmethod
    def get(company_code):
        """
        Get details required for submitting a claim.
        """
        try:
            user_id, _ = get_user_id_email_from_headers(request.headers)
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "User not found",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            d = row_to_dict(company.get_company_contact(company_code))
            return response_json(200, d)

        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })


@api.route("/submit-claim", methods=["POST"])
@api.doc(description="Submits a claim.")
class ClaimSubmit(Resource):
    @staticmethod
    def get_company_name(claim_data):
        for c in claim_data:
            if c == "policy":
                if "company_name" in claim_data[c]['fields']:
                    return claim_data[c]["fields"]["company_name"]
        return None

    @staticmethod
    def get_policy_number(claim_data):
        for c in claim_data:
            if c == "policy":
                if "policy_number" in claim_data[c]['fields']:
                    return claim_data[c]["fields"]["policy_number"]
        return None

    @staticmethod
    def get_lob(claim_data):
        lob = 'AUTO'
        for c in claim_data:
            if c == "policy":
                if "lob" in claim_data[c]['fields']:
                    return claim_data[c]["fields"]["lob"]
        return lob

    @staticmethod
    def get_email(claim_data):
        for c in claim_data:
            if c == "individual":
                if "email" in claim_data[c]['fields']:
                    return claim_data[c]["fields"]["email"]
        return None

    @staticmethod
    def get_phone(claim_data):
        for c in claim_data:
            if c == "individual":
                if "phone" in claim_data[c]['fields']:
                    return claim_data[c]["fields"]["phone"]
        return None

    @staticmethod
    def post():
        """
        Submits a claim.
        """
        try:
            fm = FileManagerFactory.create_file_manager()

            user_id, _ = get_user_id_email_from_headers(request.headers)
            user_obj = user.lookup_user_by_id(user_id)

            if user_obj is None:
                raise AuthenticationException(
                    "User not found",
                    error_code=exceptions.CODE_ADMIN_USER_DOES_NOT_EXIST)

            claim_data = json.loads(request.form.get('data'))
            mid = uuid.uuid1().hex
            claim_path = mid + "/CLAIM.JSON"

            try:
                policy_number = ClaimSubmit.get_policy_number(claim_data)
                company_name = ClaimSubmit.get_company_name(claim_data)
                lob = ClaimSubmit.get_lob(claim_data)
                email = ClaimSubmit.get_email(claim_data)
                phone = ClaimSubmit.get_phone(claim_data)

                # Add the claim to the database.
                claim.insert_claim(
                    mid,
                    user_obj.id,
                    email,
                    phone,
                    policy_number,
                    company_name,
                    lob.upper() if lob is not None else None,
                    claim_path)
            except Exception as ex:
                log.exception(ex, stack_info=True)
                return response_json(400, {
                    "message": str(ex)
                })

            # Make a claims folder if it doesn't exist.
            claim_folder = fm.join(Repository.claims_location, mid)
            fm.mkdir(claim_folder)

            # Save the claim data.
            claim_file = fm.join(Repository.claims_location, claim_path)
            fm.write_string(claim_file, request.form.get('data'))

            # Save the claim images.
            for item in request.files.getlist('image'):
                fm.write_file(fm.join(Repository.claims_location, mid, item.filename), item.read())

            return response_json(200, {
                "message": "Claim received"
            })

        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
            })
