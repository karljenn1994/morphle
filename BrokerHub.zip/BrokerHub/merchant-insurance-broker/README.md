# 📦 Changelog

## [1.0.1] - 2025-06-04
### ⚠️ Breaking Changes
- Add lifesWalletPassApiUrl setting
- Add systemSupportedLocales setting
- Database and CSIONet credentials need to be added to Hashicorp vault
- A new table for task status
- Added created date time on policy table
- Adds reply_to email on campaign table
### 🚧 New
- Added google-pass creation
- Added reply-to email address to settings
- Added reply-to field to campaigns
- Added total bounced emails to campaign results
- Preview email
- Added better logging to import user task
- Added unassigned policies report
- Added risky renewals report
### 🐛 Fixed
- Fixed image upload when creating campaign templates
- Fixed journal api (remove update)
- Fixed encoding when downloading and saving XML (application/xml now treated as text)
- Fixed the active policy list query to coalesce results so error count does not affect connected count
- Import user task ignores rows with missing policy number or BINDER policy numbers
- Changed routes_policies to prefer policy id parameter. This allows admin to see an active or inactive version. This is required for reports like unmapped.
- Fixed insert position for the template subject when clicking toolbar
- Import user task now strips 'XL ' and 'PA ' policy prefixes for companies like Northbridge
- Fixed paged policy query to correct total errors and connected users
- Added a schedule notifications tool to schedule and notification that match the criteria provided
- Added transaction_effective_date, policy_effective_date, and policy_expiry_date to templates
- Check for updates comparison only compares date and not datetime now
- lookup_last_update_by_user_id now only checks the active policy to work with "check for updates" process
- Marking a policy as active now updates its last_update to work with "check for updates" process
- Added tasks to the health endpoint
- Fixed campaign results query (it was expecting file_name column)
- Changed campaign results for total_email_not_delivered to be any email not marked 'delivered' instead on ones marked 'not_delivered'
- Now shows the latest policy in a renewal chain when listing renewals and showing renewal
- Don't notify of upstream renewal chain events