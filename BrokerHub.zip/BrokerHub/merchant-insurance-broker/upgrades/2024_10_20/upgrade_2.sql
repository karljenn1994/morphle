-- Modify indexer table structure
ALTER TABLE `indexer`
    RENAME COLUMN `date_entered` TO `entered`,
    RENAME COLUMN `transaction_effective_date` TO `process`,
    DROP COLUMN `policy_expiry_date`,
    DROP COLUMN `policy_effective_date`,
    DROP COLUMN `transaction_date`,
    DROP COLUMN `seq`,
    DROP COLUMN `purpose`,
    DROP COLUMN `premium`,
    DROP COLUMN `lob`,
    DROP COLUMN `company`,
    DROP COLUMN `policy_number`;

-- Remove obsolete table
DROP TABLE `indexer_company_code`;

