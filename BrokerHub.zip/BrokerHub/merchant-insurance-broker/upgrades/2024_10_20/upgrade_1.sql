-- Create table for campaign template content with localized subjects and bodies
CREATE TABLE `campaign_template_content` (
    `template_id` VARCHAR(36) NOT NULL,
    `locale` VARCHAR(10) NOT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `body` MEDIUMBLOB NOT NULL,
    PRIMARY KEY (`template_id`, `locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for insurance claims tracking
CREATE TABLE `claim` (
    `id` VARCHAR(36) NOT NULL,
    `status` VARCHAR(20) DEFAULT NULL,
    `received_date` DATE NOT NULL,
    `modified_date` DATE DEFAULT NULL,
    `user_id` VARCHAR(36) DEFAULT NULL,
    `policy_number` VARCHAR(60) DEFAULT NULL,
    `company` VARCHAR(20) NOT NULL,
    `lob` VARCHAR(5) NOT NULL,
    `file_name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) DEFAULT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for campaign form definitions
CREATE TABLE `campaign_form` (
    `id` VARCHAR(36) NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for localized campaign form content
CREATE TABLE `campaign_form_content` (
    `form_id` VARCHAR(36) NOT NULL,
    `locale` VARCHAR(10) NOT NULL,
    `form` JSON NOT NULL,
    PRIMARY KEY (`form_id`, `locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for campaign form submission data
CREATE TABLE `campaign_form_data` (
    `form_id` VARCHAR(36) NOT NULL,
    `user_id` VARCHAR(36) NOT NULL,
    `policy_id` VARCHAR(36) DEFAULT NULL,
    `form_data` JSON DEFAULT NULL,
    `received_date` DATETIME DEFAULT NULL,
    `modified_date` DATETIME DEFAULT NULL,
    PRIMARY KEY (`form_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for insurance company information
CREATE TABLE `company` (
    `code` VARCHAR(20) NOT NULL,
    `name` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for company-specific codes
CREATE TABLE `company_code` (
    `code` VARCHAR(20) NOT NULL,
    `company_code` VARCHAR(20) NOT NULL,
    PRIMARY KEY (`code`, `company_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for company contact information by region
CREATE TABLE `company_contact` (
    `code` VARCHAR(20) NOT NULL,
    `region` VARCHAR(40) NOT NULL,
    `phone_claims` VARCHAR(20) DEFAULT NULL,
    PRIMARY KEY (`code`, `region`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for tracking policy issues
CREATE TABLE `policy_issue` (
    `policy_id` VARCHAR(36) NOT NULL,
    `code` INT NOT NULL,
    `count` INT NOT NULL DEFAULT '0',
    PRIMARY KEY (`policy_id`, `code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for validation definitions
CREATE TABLE `validation` (
    `id` VARCHAR(36) NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `description` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for validation rules
CREATE TABLE `validation_rule` (
    `id` VARCHAR(36) NOT NULL,
    `validation_id` VARCHAR(36) NOT NULL,
    `enabled` TINYINT NOT NULL DEFAULT '1',
    `description` VARCHAR(255) DEFAULT NULL,
    `func` VARCHAR(100) DEFAULT NULL,
    `type` VARCHAR(50) DEFAULT NULL,
    `cfg` JSON DEFAULT NULL,
    `severity` VARCHAR(45) DEFAULT NULL,
    `code` VARCHAR(7) DEFAULT NULL,
    `message` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for validation rule templates
CREATE TABLE `validation_rule_template` (
    `code` VARCHAR(7) NOT NULL,
    `validation_type` VARCHAR(20) DEFAULT NULL,
    `enabled` TINYINT DEFAULT '0',
    `description` VARCHAR(255) DEFAULT NULL,
    `func` VARCHAR(100) DEFAULT NULL,
    `type` VARCHAR(50) DEFAULT NULL,
    `cfg` JSON DEFAULT NULL,
    `severity` VARCHAR(45) DEFAULT NULL,
    `message` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create table for validator configurations
CREATE TABLE `validator` (
    `id` VARCHAR(36) NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `name` VARCHAR(20) NOT NULL,
    `description` VARCHAR(100) DEFAULT NULL,
    `validation_id` VARCHAR(36) NOT NULL,
    `trigger_event` VARCHAR(20) DEFAULT NULL,
    `rules` JSON DEFAULT NULL,
    `active` TINYINT NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`, `validation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Modify policy table structure
ALTER TABLE `policy`
    ADD COLUMN `active` TINYINT DEFAULT '0',
    ADD COLUMN `transaction_date` DATE DEFAULT NULL,
    ADD COLUMN `seq` INT DEFAULT '0';

-- Update existing policy records
UPDATE `policy` 
SET `active` = 1 
WHERE `active` = 0;

-- Modify indexer table structure
ALTER TABLE `indexer`
    ADD COLUMN `policy_id` VARCHAR(36);

-- Add xln field to policy table for tracking
ALTER TABLE `policy`
    ADD COLUMN `xln` TINYINT DEFAULT '0';

-- Insert company data
INSERT INTO `company` VALUES
    ('AVIVA', 'Aviva Insurance'),
    ('CAA', 'CAA Insurance'),
    ('CARLETONFUNDY', 'Carleton Fundy Mutual'),
    ('COACHMEN', 'Coachman Insurance'),
    ('DEFINITY', 'Definity Insurance'),
    ('ECHELON', 'Echelon Insurance'),
    ('FORWARD', 'Forward Insurance'),
    ('GORE', 'Gore Mutual Insurance'),
    ('ICPEI', 'Insurance Company of PEI'),
    ('INTACT', 'Intact Insurance'),
    ('JEVCO', 'Jevco Insurance'),
    ('MAX', 'Max Insurance'),
    ('NORTHBRIDGE', 'Northbridge'),
    ('PAFCO', 'Pafco Insurance Company'),
    ('PEMBRIDGE', 'Pembridge Insurance'),
    ('PORTAGE', 'Portage Mutual'),
    ('SGI', 'SGI Canada'),
    ('TRAVELERS', 'Travelers Canada'),
    ('UNICA', 'Unica Insurance'),
    ('WAWANESA', 'Wawanesa Insurance'),
    ('WELLINGTON', 'Wellington Insurance');

-- Insert company codes
INSERT INTO `company_code` VALUES
    ('AVIVA', 'AVELI1'), ('AVIVA', 'AVIVR1'), ('AVIVA', 'AVTRA1'), ('AVIVA', 'CGUI'), ('AVIVA', 'ELIIN1'),
    ('AVIVA', 'ELT'), ('AVIVA', 'S&R'), ('AVIVA', 'SAY'), ('AVIVA', 'SCO&01'), ('AVIVA', 'TRG'),
    ('CAA', 'CAA'), ('CAA', 'CAA001'),
    ('CARLETONFUNDY', 'CARFU1'), ('CARLETONFUNDY', 'FUND'),
    ('COACHMEN', 'COA'), ('COACHMEN', 'COAIN1'),
    ('DEFINITY', 'DEFIN1'), ('DEFINITY', 'ECOIN1'), ('DEFINITY', 'ECON'), ('DEFINITY', 'ECOSE1'), ('DEFINITY', 'WAT'),
    ('ECHELON', 'ECHE'), ('ECHELON', 'ECHIN1'), ('ECHELON', 'EGI'),
    ('FORWARD', 'FOR'), ('FORWARD', 'FORIN1'),
    ('GORE', 'GORE'), ('GORE', 'GORMU1'),
    ('ICPEI', 'ICPEI'), ('ICPEI', 'ICPEI1'),
    ('INTACT', 'FAHAL'), ('INTACT', 'GC'), ('INTACT', 'HAL'), ('INTACT', 'INTIN1'), ('INTACT', 'NORD'), ('INTACT', 'NORIN1'),
    ('JEVCO', 'JEI'), ('JEVCO', 'JEVIN1'),
    ('MAX', 'MAX'), ('MAX', 'MAXIN1'),
    ('NORTHBRIDGE', 'LGI'), ('NORTHBRIDGE', 'LIC'), ('NORTHBRIDGE', 'LOMB'), ('NORTHBRIDGE', 'ZEN'),
    ('PAFCO', 'PAF'), ('PAFCO', 'PAFIN1'),
    ('PEMBRIDGE', 'PEMB'), ('PEMBRIDGE', 'PEMIN1'),
    ('PORTAGE', 'PORMU1'), ('PORTAGE', 'PORT'),
    ('SGI', 'SGICA1'), ('SGI', 'SGIS'),
    ('TRAVELERS', 'CHIIN1'), ('TRAVELERS', 'CIC'), ('TRAVELERS', 'DOC'), ('TRAVELERS', 'TRACA1'), ('TRAVELERS', 'TRAIN1'), ('TRAVELERS', 'TRAV'),
    ('UNICA', 'UNICA1'), ('UNICA', 'YORK'),
    ('WAWANESA', 'WAWA'), ('WAWANESA', 'WAWIN1'),
    ('WELLINGTON', 'NOVEX1'), ('WELLINGTON', 'WELL');

-- Insert company contacts
INSERT INTO `company_contact` VALUES
    ('AVIVA', 'CAN', '(866) 692-8482'),
    ('CAA', 'CAN', NULL),
    ('CARLETONFUNDY', 'CAN', NULL),
    ('COACHMEN', 'CAN', NULL),
    ('DEFINITY', 'CAN', '(800) 607-2424'),
    ('ECHELON', 'CAN', NULL),
    ('FORWARD', 'CAN', NULL),
    ('GORE', 'CAN', NULL),
    ('ICPEI', 'CAN', NULL),
    ('INTACT', 'CAN', '(866) 464-2424'),
    ('JEVCO', 'CAN', NULL),
    ('MAX', 'CAN', NULL),
    ('NORTHBRIDGE', 'CAN', NULL),
    ('PAFCO', 'CAN', NULL),
    ('PEMBRIDGE', 'CAN', NULL),
    ('PORTAGE', 'CAN', NULL),
    ('SGI', 'CAN', NULL),
    ('TRAVELERS', 'CAN', NULL),
    ('UNICA', 'CAN', NULL),
    ('WAWANESA', 'CAN', NULL),
    ('WELLINGTON', 'CAN', NULL);

-- Insert validation data
INSERT INTO `validation`
VALUES ('731eacd08e4911efbe90acde48001122', 'renewal_auto', 'Auto Renewal', 'Auto renewal validator.');

-- Insert validation rules
INSERT INTO `validation_rule` VALUES
    ('731f243a8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, '13D (Limitation of Glass Coverage Endorsement) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "13d", "description": "Coverage code"}}', 'error', '200', '13D (Limitation of Glass Coverage Endorsement) missing'),
    ('731f780e8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, '20 (Loss of Use) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "20", "description": "Coverage code"}}', 'error', '201', '20 (Loss of Use) missing'),
    ('731fb1d48e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, '27 (Liability for Damage to Non-Owned Automobiles) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "27", "description": "Coverage code"}}', 'error', '203', '27 (Liability for Damage to Non-Owned Automobiles) missing'),
    ('731fe7128e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, '43 (Limited Waiver of Depreciation Endorsement) missing', 'vehicle_coverage_missing_for_newer', 'coverage', '{"years_old": {"name": "Vehicle Age", "type": "text", "value": 7, "description": "This rule should only trigger for vehicles no older than this age."}, "coverage_code": {"name": "Coverage Code", "type": "text", "value": "43r", "description": "The coverage code for \'Limited Waiver of Depreciation Endorsement\'"}}', 'error', '210', '43 (Limited Waiver of Depreciation Endorsement) missing'),
    ('73201dcc8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Accident benefits missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "ab", "description": "Coverage code"}}', 'error', '205', 'Accident benefits missing'),
    ('73204d248e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Accident rating waiver missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "39", "description": "Coverage code"}}', 'error', '209', 'Accident waiver missing'),
    ('732081908e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'All Perils missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "ap", "description": "Coverage code"}}', 'error', '206', 'All Perils missing'),
    ('7320ad5a8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Away at school discount missing', 'vehicle_discount_missing_school_age', 'discount', '{"school_age": {"name": "School Age", "type": "number", "value": 22, "description": "Age before which this discount applies."}, "discount_code": {"name": "Discount Code", "type": "text", "value": "disas", "description": "Away at school discount code"}}', 'error', '504', 'Away at school discount missing'),
    ('7320da328e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Claims free discount missing', 'vehicle_discount_missing_claims_free', 'discount', '{"discount_code": {"name": "Discount Code", "type": "text", "value": "disscf", "description": "Claims free discount code"}}', 'error', '503', 'Claims free discount missing'),
    ('73210a2a8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Collision missing', 'vehicle_coverage_missing_for_newer', 'coverage', '{"years_old": {"name": "Vehicle Age", "type": "text", "value": 3, "description": "This rule should only trigger for vehicles no older than this age."}, "coverage_code": {"name": "Coverage Code", "type": "text", "value": "col", "description": "Coverage code"}}', 'error', '211', 'Collision missing'),
    ('73214c928e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Comprehensive missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "cmp", "description": "Coverage code"}}', 'error', '207', 'Comprehensive missing'),
    ('7321861c8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Deductible decrease', 'vehicle_deductible_decrease', 'deductible', '{"percent": {"name": "Percent", "type": "number", "value": 0, "description": "Percent"}}', 'error', '105', 'Deductible for coverage {ctx} has decreased'),
    ('7321b9488e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Deductible increase', 'vehicle_deductible_increase', 'deductible', '{"percent": {"name": "Percent", "type": "number", "value": 10, "description": "Percent"}}', 'error', '401', 'Deductible for coverage {ctx} has increased'),
    ('7321e60c8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Disappearing Deductible missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "26", "description": "Coverage code"}}', 'error', '202', 'Disappearing Deductible missing'),
    ('7322147e8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Enhanced accident benefits missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": ["idb", "wib", "dcb", "dfb", "mrb", "mrbc", "chhm"], "description": "Coverage code"}}', 'error', '212', 'Enhanced accident benefits missing'),
    ('73223c2e8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Enhanced Internal Limits missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "enhin", "description": "Coverage code"}}', 'error', '214', 'Enhanced Internal Limits missing'),
    ('732266688e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Limit decrease', 'vehicle_limit_decrease', 'limit', '{"percent": {"name": "Percent", "type": "number", "value": 0, "description": "Percent"}}', 'error', '102', 'Limit for coverage {ctx} has decreased'),
    ('732299ee8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Limit increase', 'vehicle_limit_increase', 'limit', '{"percent": {"name": "Percent", "type": "number", "value": 10, "description": "Percent"}}', 'error', '300', 'Limit for coverage {ctx} has increased'),
    ('7322c96e8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Mature driver discount missing', 'vehicle_discount_missing_mature_driver', 'discount', '{"mature_age": {"name": "Mature Age", "type": "number", "value": 55, "description": "Age above which this discount applies."}, "discount_code": {"name": "Discount Code", "type": "text", "value": "dissc", "description": "Mature driver discount code"}}', 'error', '505', 'Age related discount missing'),
    ('7322f36c8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Minor conviction protection missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "mcp", "description": "Coverage code"}}', 'error', '208', 'Minor conviction protection'),
    ('732321f28e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Multi-line discount missing', 'vehicle_discount_missing_multi_line', 'discount', '{"discount_code": {"name": "Discount", "type": "text", "value": "dismp", "description": "Multi-line Discount code"}}', 'error', '501', 'Multi-line discount missing'),
    ('732354428e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Multi-vehicle discount missing', 'vehicle_discount_missing_multi_vehicle', 'discount', '{"discount_code": {"name": "Discount", "type": "text", "value": "dismv", "description": "Multi-vehicle Discount code"}}', 'error', '500', 'Multi-vehicle discount missing'),
    ('73237e5e8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'SEF 35 (Emergency Service Expense) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "35", "description": "Coverage code"}}', 'error', '204', 'SEF 35 (Emergency Service Expense) missing'),
    ('7323a7128e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Third Party Liability limit missing', 'vehicle_limit_missing', 'limit', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "tpbi", "description": "Coverage code"}}', 'error', '301', 'Third Party Liability limit missing'),
    ('7323d3ea8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Umbrella coverage missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "perli", "description": "Coverage code"}}', 'error', '213', 'Umbrella coverage missing'),
    ('732407f28e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Winter tire discount missing', 'vehicle_discount_missing', 'discount', '{"discount_code": {"name": "Discount Code", "type": "text", "value": "dissn", "description": "Snow tire discount code"}}', 'error', '502', 'Winter tire discount missing'),
    ('7324316e8e4911efbe90acde48001122', '731eacd08e4911efbe90acde48001122', 1, 'Young drivers', 'policy_young_driver', 'policy', '{"child_age": {"name": "Child Age", "type": "number", "value": 22, "description": "Maximum age that indicates the driver may be a child."}, "parent_age_max": {"name": "Parent Age Max", "type": "number", "value": 50, "description": "Maximum age to identify a parent driver that may have children who also drive."}, "parent_age_min": {"name": "Parent Age Min", "type": "number", "value": 40, "description": "Minimum age to identify a parent that may have children who also drive."}}', 'error', '506', 'Young drivers');

-- Insert validation rule templates
INSERT INTO `validation_rule_template` VALUES
    ('102', 'renewal_auto', 1, 'Limit decrease', 'vehicle_limit_decrease', 'limit', '{"percent": {"name": "Percent", "type": "number", "value": 0, "description": "Percent"}}', 'error', 'Limit for coverage {ctx} has decreased'),
    ('105', 'renewal_auto', 1, 'Deductible decrease', 'vehicle_deductible_decrease', 'deductible', '{"percent": {"name": "Percent", "type": "number", "value": 0, "description": "Percent"}}', 'error', 'Deductible for coverage {ctx} has decreased'),
    ('200', 'renewal_auto', 1, '13D (Limitation of Glass Coverage Endorsement) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "13d", "description": "Coverage code"}}', 'error', '13D (Limitation of Glass Coverage Endorsement) missing'),
    ('201', 'renewal_auto', 1, '20 (Loss of Use) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "20", "description": "Coverage code"}}', 'error', '20 (Loss of Use) missing'),
    ('202', 'renewal_auto', 1, 'Disappearing Deductible missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "26", "description": "Coverage code"}}', 'error', 'Disappearing Deductible missing'),
    ('203', 'renewal_auto', 1, '27 (Liability for Damage to Non-Owned Automobiles) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "27", "description": "Coverage code"}}', 'error', '27 (Liability for Damage to Non-Owned Automobiles) missing'),
    ('204', 'renewal_auto', 1, 'SEF 35 (Emergency Service Expense) missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "35", "description": "Coverage code"}}', 'error', 'SEF 35 (Emergency Service Expense) missing'),
    ('205', 'renewal_auto', 1, 'Accident benefits missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "ab", "description": "Coverage code"}}', 'error', 'Accident benefits missing'),
    ('206', 'renewal_auto', 1, 'All Perils missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "ap", "description": "Coverage code"}}', 'error', 'All Perils missing'),
    ('207', 'renewal_auto', 1, 'Comprehensive missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "cmp", "description": "Coverage code"}}', 'error', 'Comprehensive missing'),
    ('208', 'renewal_auto', 1, 'Minor conviction protection missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "mcp", "description": "Coverage code"}}', 'error', 'Minor conviction protection'),
    ('209', 'renewal_auto', 1, 'Accident rating waiver missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "39", "description": "Coverage code"}}', 'error', 'Accident waiver missing'),
    ('210', 'renewal_auto', 1, '43 (Limited Waiver of Depreciation Endorsement) missing', 'vehicle_coverage_missing_for_newer', 'coverage', '{"years_old": {"name": "Vehicle Age", "type": "text", "value": 7, "description": "This rule should only trigger for vehicles no older than this age."}, "coverage_code": {"name": "Coverage Code", "type": "text", "value": "43r", "description": "The coverage code for \'Limited Waiver of Depreciation Endorsement\'"}}', 'error', '43 (Limited Waiver of Depreciation Endorsement) missing'),
    ('211', 'renewal_auto', 1, 'Collision missing', 'vehicle_coverage_missing_for_newer', 'coverage', '{"years_old": {"name": "Vehicle Age", "type": "text", "value": 3, "description": "This rule should only trigger for vehicles no older than this age."}, "coverage_code": {"name": "Coverage Code", "type": "text", "value": "col", "description": "Coverage code"}}', 'error', 'Collision missing'),
    ('212', 'renewal_auto', 1, 'Enhanced accident benefits missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": ["idb", "wib", "dcb", "dfb", "mrb", "mrbc", "chhm"], "description": "Coverage code"}}', 'error', 'Enhanced accident benefits missing'),
    ('213', 'renewal_auto', 1, 'Umbrella coverage missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "perli", "description": "Coverage code"}}', 'error', 'Umbrella coverage missing'),
    ('214', 'renewal_auto', 1, 'Enhanced Internal Limits missing', 'vehicle_coverage_missing', 'coverage', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "enhin", "description": "Coverage code"}}', 'error', 'Enhanced Internal Limits missing'),
    ('300', 'renewal_auto', 1, 'Limit increase', 'vehicle_limit_increase', 'limit', '{"percent": {"name": "Percent", "type": "number", "value": 10, "description": "Percent"}}', 'error', 'Limit for coverage {ctx} has increased'),
    ('301', 'renewal_auto', 1, 'Third Party Liability limit missing', 'vehicle_limit_missing', 'limit', '{"coverage_code": {"name": "Coverage Code", "type": "text", "value": "tpbi", "description": "Coverage code"}}', 'error', 'Third Party Liability limit missing'),
    ('401', 'renewal_auto', 1, 'Deductible increase', 'vehicle_deductible_increase', 'deductible', '{"percent": {"name": "Percent", "type": "number", "value": 10, "description": "Percent"}}', 'error', 'Deductible for coverage {ctx} has increased'),
    ('500', 'renewal_auto', 1, 'Multi-vehicle discount missing', 'vehicle_discount_missing_multi_vehicle', 'discount', '{"discount_code": {"name": "Discount", "type": "text", "value": "dismv", "description": "Multi-vehicle Discount code"}}', 'error', 'Multi-vehicle discount missing'),
    ('501', 'renewal_auto', 1, 'Multi-line discount missing', 'vehicle_discount_missing_multi_line', 'discount', '{"discount_code": {"name": "Discount", "type": "text", "value": "dismp", "description": "Multi-line Discount code"}}', 'error', 'Multi-line discount missing'),
    ('502', 'renewal_auto', 1, 'Winter tire discount missing', 'vehicle_discount_missing', 'discount', '{"discount_code": {"name": "Discount Code", "type": "text", "value": "dissn", "description": "Snow tire discount code"}}', 'error', 'Winter tire discount missing'),
    ('503', 'renewal_auto', 1, 'Claims free discount missing', 'vehicle_discount_missing_claims_free', 'discount', '{"discount_code": {"name": "Discount Code", "type": "text", "value": "disscf", "description": "Claims free discount code"}}', 'error', 'Claims free discount missing'),
    ('504', 'renewal_auto', 1, 'Away at school discount missing', 'vehicle_discount_missing_school_age', 'discount', '{"school_age": {"name": "School Age", "type": "number", "value": 22, "description": "Age before which this discount applies."}, "discount_code": {"name": "Discount Code", "type": "text", "value": "disas", "description": "Away at school discount code"}}', 'error', 'Away at school discount missing'),
    ('505', 'renewal_auto', 1, 'Mature driver discount missing', 'vehicle_discount_missing_mature_driver', 'discount', '{"mature_age": {"name": "Mature Age", "type": "number", "value": 55, "description": "Age above which this discount applies."}, "discount_code": {"name": "Discount Code", "type": "text", "value": "dissc", "description": "Mature driver discount code"}}', 'error', 'Age related discount missing'),
    ('506', 'renewal_auto', 1, 'Young drivers', 'policy_young_driver', 'policy', '{"child_age": {"name": "Child Age", "type": "number", "value": 22, "description": "Maximum age that indicates the driver may be a child."}, "parent_age_max": {"name": "Parent Age Max", "type": "number", "value": 50, "description": "Maximum age to identify a parent driver that may have children who also drive."}, "parent_age_min": {"name": "Parent Age Min", "type": "number", "value": 40, "description": "Minimum age to identify a parent that may have children who also drive."}}', 'error', 'Young drivers');

-- Insert validator data
INSERT INTO `validator` VALUES
    ('864b50f68cb411efa6d9acde48001122', 'renewal_auto', 'Auto Renewal', 'Auto renewal validations.', '731eacd08e4911efbe90acde48001122', 'RWL', '{"companies": ["AVIVA", "CAA", "CARLETONFUNDY", "COACHMEN", "DEFINITY", "ECHELON", "ELITE", "FORWARD", "GORE", "ICPEI", "INTACT", "JEVCO", "MAX", "NORDIC", "NORTHBRIDGE", "PAFCO", "PEMBRIDGE", "PORTAGE", "SCOTTISH", "SGI", "TRADERS", "TRAVELERS", "UNICA", "WATERLOO", "WAWANESA", "WELLINGTON"]}', 1);

-- Modify campaign table structure
ALTER TABLE `campaign`
	  DROP PRIMARY KEY,
    ADD PRIMARY KEY (`id`),
    ADD COLUMN `form_id` VARCHAR(36),
    ADD COLUMN `scheduled` TINYINT NOT NULL DEFAULT '0',
    ADD COLUMN `permanent` TINYINT NOT NULL DEFAULT '0',
    MODIFY `type` VARCHAR(20) NOT NULL,
    MODIFY `name` VARCHAR(100) NOT NULL,
    MODIFY `description` VARCHAR(255) DEFAULT NULL;

INSERT INTO `campaign_template_content` (`template_id`, `locale`, `subject`, `body`)
SELECT
    `id` AS `template_id`,
    'en' AS `locale`,
    `subject`,
    `body`
FROM `campaign_template`
WHERE `subject` IS NOT NULL
   OR `body` IS NOT NULL;

-- Modify campaign_template by removing content fields and enforcing type constraint
ALTER TABLE `campaign_template`
    DROP COLUMN `body`,
    DROP COLUMN `subject`,
    MODIFY COLUMN `type` VARCHAR(20) NOT NULL;

-- Add locale column to notifier_recipient with NOT NULL and default 'en'
ALTER TABLE `notifier_recipient`
    ADD COLUMN `locale` VARCHAR(10) NOT NULL DEFAULT 'en';

-- Update status field definition in user table
ALTER TABLE `user`
    MODIFY COLUMN `status` VARCHAR(20);

-- Add localization and notification preferences to user_info table
ALTER TABLE `user_info`
    ADD COLUMN `locale` VARCHAR(10) NOT NULL DEFAULT 'en',
    ADD COLUMN `notification_preference` VARCHAR(5) NOT NULL DEFAULT 'email';
