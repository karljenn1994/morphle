-- 1. Index on `policy_number`, `company`, and `lob`
CREATE INDEX idx_policy_number_company_lob
ON policy (policy_number, company, lob);

-- 2. Index on `policy_effective_date`, `policy_expiry_date`, and `transaction_effective_date`
CREATE INDEX idx_policy_dates
ON policy (policy_effective_date, policy_expiry_date, transaction_effective_date);

-- 3. Index on `id` (if not already indexed)
CREATE INDEX idx_policy_id
ON policy (id);