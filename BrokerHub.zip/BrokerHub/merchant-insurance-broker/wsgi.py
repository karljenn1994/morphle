import os
import sys

# Add your project's root directory to the Python path if wsgi.py is at the root
# This ensures modules like 'lib_common' can be found.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__))))

# Import and call setup_logging FIRST.
# This configures your loggers before any other app code has a chance to log.
from lib_common.log_config import setup_logging

setup_logging()

# Now, import your Flask app and create the instance
from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run()
