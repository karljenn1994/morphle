import json
import logging
import uuid

from django.utils.safestring import mark_safe

from lib_common import constants, exceptions
from lib_common.authentication import generate_form_token, generate_identity_token
from lib_common.constants import LOGGER
from lib_email.emailer import Emailer
from lib_common.exceptions import NotificationException
from lib_persistence import campaign, notifier, settings, user

log = logging.getLogger(LOGGER)


def notify_one_recipient(notification, recipient, group_id=None, optional_connection=None, campaign_obj=None):
    """
    Attempt to notify a single recipient for a given notification.

    :param notification: The parent notification object.
    :param recipient: The recipient row (with notifier_recipient_id, id, locale, etc.).
    :param group_id: Optional suppression group ID. If None, it will be loaded internally.
    :param optional_connection: Optional DB connection.
    :param campaign_obj: Optional preloaded campaign object for efficiency.
    :return: (success: bool, message_id: str|None)
    """

    notifier_recipient_id = recipient.notifier_recipient_id
    message_id = None

    try:
        # Resolve group_id internally if not supplied
        if group_id is None:
            group_id = settings.get_setting(constants.SETTING_SENDGRID_GROUP_ID)

        # Fresh user record
        u = user.lookup_user_by_id(recipient.id, optional_connection=optional_connection)
        r = notifier.get_recipient(notifier_recipient_id, optional_connection=optional_connection)

        reset_code = None
        if r.status in ('uploaded', 'invited'):
            # Keep uuid1 to preserve exact behavior
            reset_code = uuid.uuid1().hex

        guest_token = None
        if r.role == "user":
            guest_token, _ = generate_identity_token(u, expires_hours=48)

        # Load a campaign once (use injected if provided)
        if campaign_obj is None:
            campaign_obj = campaign.load_campaign(notification.campaign_id, optional_connection=optional_connection)

        template_obj = notifier.get_template(
            campaign_obj.template_id,
            r.locale,
            optional_connection=optional_connection
        )

        if not template_obj:
            notifier.update_notifier_recipient_result(
                notifier_recipient_id, "failed", message="Template not found",
                optional_connection=optional_connection
            )
            return False, None

        message_id, _, _ = notify_user(
            r,
            campaign_obj,
            template_obj,
            token=guest_token,
            reset_code=reset_code,
            bypass=not bool(campaign_obj.marketing),
            group_id=int(group_id),
            notifier_recipient_id=notifier_recipient_id
        )

        if message_id:
            if r.status in ('uploaded', 'invited'):
                user.invite_user(r, reset_code=reset_code)

            notifier.update_notifier_recipient_result(
                notifier_recipient_id,
                "unknown",   # leave as unknown until delivery callback
                message_id=message_id,
                optional_connection=optional_connection
            )
            return True, message_id
        else:
            notifier.update_notifier_recipient_result(
                notifier_recipient_id,
                "failed",
                message="No message_id returned",
                optional_connection=optional_connection
            )
            return False, None

    except Exception as e:
        msg = getattr(e, "message", str(e))
        log.error(f"Error notifying recipient: {msg}", exc_info=True)
        notifier.update_notifier_recipient_result(
            notifier_recipient_id,
            "failed",
            message_id=message_id,
            message=msg,
            optional_connection=optional_connection
        )
        return False, None


def notify_recipients(notification, optional_connection=None):
    """
    Notify all recipients for a given notification.

    This function retrieves all recipients tied to the provided notification,
    then iterates through them and calls `notify_one_recipient` for each.
    It ensures each recipient is attempted individually, updating their
    delivery status in the database regardless of success or failure.
    After all recipients are processed, the parent notification is marked
    as "sent".

    :param notification: Notification object containing campaign_id and ID.
    :param optional_connection: Optional existing DB connection.
                                If None, a new connection will be created.

    :return: The number of recipients successfully notified (i.e., where a
             message_id was returned by the underlying delivery provider).
    """
    group_id = settings.get_setting(constants.SETTING_SENDGRID_GROUP_ID)
    recipients = notifier.get_recipients(notification.id, optional_connection=optional_connection)
    campaign_obj = campaign.load_campaign(notification.campaign_id, optional_connection=optional_connection)

    total_notified = 0

    for r in recipients:
        success, _ = notify_one_recipient(
            notification,
            r,
            group_id,
            optional_connection=optional_connection,
            campaign_obj=campaign_obj  # reuse the loaded campaign
        )
        if success:
            total_notified += 1

    notifier.move_to_sent(notification.id, optional_connection=optional_connection)
    return total_notified


def notify_user(user_obj,
                campaign_obj,
                template_obj,
                token=None,
                reset_code=None,
                group_id=None,
                groups_to_display=None,
                bypass=True,
                notifier_recipient_id=None,
                trigger_event=None,
                dry_run=False):
    """
    Render and deliver a notification message to a single user.

    This function composes the notification context based on the user,
    campaign, and template, then dispatches it using the appropriate channel
    (push or email) via the `Emailer`. It does not update the database state
    directly; callers are responsible for recording delivery status.

    The content of the message (subject, body, context variables) is derived
    from the template and user data. Additional parameters (e.g., reset codes,
    tokens, or form URLs) are incorporated into the message URL when present.

    :param user_obj: User object or ORM row representing the recipient.
    :param campaign_obj: Campaign object tied to this notification.
    :param template_obj: Template object containing body, subject, and type.
    :param token: Optional identity token string to embed in the URL.
    :param reset_code: Optional reset code string to embed in the URL.
    :param group_id: Optional SendGrid suppression group ID to associate with
                     the message.
    :param groups_to_display: Optional list of groups to display in the email footer.
    :param bypass: If True, bypass marketing suppression checks when sending.
    :param notifier_recipient_id: ID of the notifier_recipient row in the DB.
                                  Used for logging and callback correlation.
    :param trigger_event: Optional event name to include as a query parameter
                          in the generated URL.
    :param dry_run: If True, compose the message but do not deliver.
                    Still returns what would have been sent.

    :return: Tuple of (message_id, message_subject, message_body) where:
             - message_id is a provider-specific identifier (or None if not sent),
             - message_subject is the rendered subject (or None for push),
             - message_body is the rendered body (or None for push).
    :raises NotificationException: If required, template variables (e.g., policy
                                   number, company, or lob) are missing.
    """
    auth_action = "/auth/access"

    if token is not None:
        auth_action += "/token/" + token

    if reset_code is not None:
        auth_action += "/reset_code/" + reset_code

    if trigger_event is not None:
        auth_action += "?trigger_event=" + trigger_event

    # Body/subject may be bytes or str (keep behavior if already bytes)
    body = template_obj.body
    if isinstance(body, (bytes, bytearray)):
        body = body.decode()

    subject = template_obj.subject
    if isinstance(subject, (bytes, bytearray)):
        subject = subject.decode()

    # Mapping may exist; keep original behavior but access safely
    user_map = getattr(user_obj, "_mapping", {}) or {}

    account_name = user_map.account_name if "account_name" in user_map else None

    if not account_name:
        names = []
        # Preserve the original field access pattern
        if "first_name" in user_map and user_map.first_name:
            names.append(user_obj.first_name if hasattr(user_obj, "first_name") else user_map.first_name)
        if "last_name" in user_map and user_map.last_name:
            names.append(user_map.last_name)
        account_name = " ".join(names)

    client_first = (user_map.first_name if "first_name" in user_map else None)
    client_last = (user_map.last_name if "last_name" in user_map else None)

    admin_ui_host = settings.get_setting(constants.SETTING_ADMIN_UI_HOST)

    context = {
        "client": {
            "account_name": mark_safe((account_name if account_name else "").title()),
            "first_name": mark_safe((client_first if client_first else "").capitalize()),
            "last_name": mark_safe((client_last if client_last else "").capitalize()),
            "url": mark_safe(admin_ui_host + auth_action),
        },
        "brokerage": {
            "url": mark_safe(settings.get_setting(constants.SETTING_BROKERAGE_WEBSITE_URL)),
            "contact_url": mark_safe(settings.get_setting(constants.SETTING_BROKERAGE_CONTACT_URL)),
        },
    }

    # NOTE - don't assert first and last name - we legit may not have them.
    _assert_not_missing(context["client"]["account_name"], "Notifier recipient missing account name")

    template_type = template_obj.type
    form_url = None

    if template_type == 'policy':
        policy_numbers = []
        companies = []
        lobs = []
        transaction_effective_dates = []
        policy_effective_dates = []
        policy_expiry_dates = []

        # Use the field stored on the object; keep error semantics identical
        if not getattr(user_obj, "regarding", None):
            raise NotificationException(
                "Notifier recipient is missing regarding information",
                error_code=exceptions.CODE_ADMIN_NOTIFICATION_MISSING_VARIABLE)

        raw = user_obj.regarding
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode('utf-8')

        regarding = json.loads(raw)

        if isinstance(regarding, dict):
            if "policy_number" in regarding and regarding["policy_number"] is not None:
                policy_numbers.append(regarding["policy_number"])
            if "company" in regarding and regarding["company"] is not None:
                companies.append(regarding["company"])
            if "lob" in regarding and regarding["lob"] is not None:
                lobs.append(_map_lob(regarding["lob"]))
            if "transaction_effective_date" in regarding and regarding["transaction_effective_date"] is not None:
                transaction_effective_dates.append(regarding["transaction_effective_date"])
            if "policy_effective_date" in regarding and regarding["policy_effective_date"] is not None:
                policy_effective_dates.append(regarding["policy_effective_date"])
            if "policy_expiry_date" in regarding and regarding["policy_expiry_date"] is not None:
                policy_expiry_dates.append(regarding["policy_expiry_date"])

        elif isinstance(regarding, list):
            for r in regarding:
                if "policy_number" in r and r["policy_number"] is not None:
                    policy_numbers.append(r["policy_number"])
                if "company" in r and r["company"] is not None:
                    companies.append(r["company"])
                if "lob" in r and r["lob"] is not None:
                    lobs.append(_map_lob(r["lob"]))
                if "transaction_effective_date" in r and r["transaction_effective_date"] is not None:
                    transaction_effective_dates.append(r["transaction_effective_date"])
                if "policy_effective_date" in r and r["policy_effective_date"] is not None:
                    policy_effective_dates.append(r["policy_effective_date"])
                if "policy_expiry_date" in r and r["policy_expiry_date"] is not None:
                    policy_expiry_dates.append(r["policy_expiry_date"])
        else:
            raise NotificationException(
                "Notifier recipient regarding information is malformed",
                error_code=exceptions.CODE_ADMIN_NOTIFICATION_MISSING_VARIABLE)

        # Preserve dedupe style/order
        policy_numbers = list(dict.fromkeys(policy_numbers))
        companies = list(dict.fromkeys(companies))
        lobs = list(dict.fromkeys(lobs))
        transaction_effective_dates = list(dict.fromkeys(transaction_effective_dates))
        policy_effective_dates = list(dict.fromkeys(policy_effective_dates))
        policy_expiry_dates = list(dict.fromkeys(policy_expiry_dates))

        context["policy"] = {
            "number": mark_safe(", ".join(policy_numbers)),
            "company": mark_safe(", ".join(companies)),
            "lob": mark_safe(", ".join(lobs)),
            "transaction_effective_date": mark_safe(", ".join(transaction_effective_dates)),
            "policy_effective_date": mark_safe(", ".join(policy_effective_dates)),
            "policy_expiry_date": mark_safe(", ".join(policy_expiry_dates)),
        }

        _assert_not_missing(context["policy"]["number"], "Notifier recipient missing policy number")
        _assert_not_missing(context["policy"]["company"], "Notifier recipient missing company")
        _assert_not_missing(context["policy"]["lob"], "Notifier recipient missing lob")

        # NOTE: Can't assert these yet because we do run campaigns manually and don't supply these.

    elif template_type in ['survey', 'questionnaire']:
        form_token, _ = generate_form_token(user_obj, campaign_obj.form_id)
        locale = getattr(user_obj, "locale", None) or user_map.get("locale", None) or "en"
        form_url = mark_safe(
            settings.get_setting(constants.SETTING_ADMIN_UI_HOST) + "/" + locale + "/form?token=" + form_token
        )
        context["form"] = {
            "url": form_url,
        }

    message_id = None
    message_subject = None
    message_body = None

    if not dry_run and user_obj.notification_preference == 'app' and user_obj.connected:
        message_id = Emailer(context, body, subject).send_push(
            user_obj.id,
            form_url=form_url,
            notifier_recipient_id=notifier_recipient_id)
    elif dry_run or user_obj.notification_preference == 'email':
        from_email = settings.get_setting(constants.SETTING_SENDGRID_FROM_EMAIL)

        reply_email = ((campaign_obj.reply_to if campaign_obj else None)
                       or settings.get_setting(constants.SETTING_SENDGRID_REPLY_EMAIL))

        message_id, message_subject, message_body = Emailer(context, body, subject).send_email(
            from_email,
            user_obj.email,
            reply_email=reply_email,
            group_id=group_id,
            groups_to_display=groups_to_display,
            bypass=bypass,
            notifier_recipient_id=notifier_recipient_id,
            dry_run=dry_run
        )

    return message_id, message_subject, message_body


def _map_lob(lob):
    """
    Map a line of business (LOB) code into a human-friendly string.

    Currently only handles a small set of known codes; all others are
    returned unchanged.

    :param lob: LOB code (e.g., "AUTO", "HABL"). Case-sensitive as stored.
    :return: Human-readable version ("automobile", "home") or the original code.
    """
    if lob == 'AUTO':
        return "automobile"

    if lob == 'HABL':
        return 'home'

    return lob


def _assert_not_missing(var, msg):
    """
    Ensure a required template/context variable is present.

    Used to guard against missing fields in the notification context
    (e.g., policy number, company, LOB). If the variable is falsy,
    a NotificationException is raised to stop delivery.

    :param var: The variable to check (string or other type).
    :param msg: Error message to include in the exception if missing.
    :raises NotificationException: When `var` is None, empty, or otherwise falsy.
    """
    if not var:
        raise NotificationException(msg, error_code=exceptions.CODE_ADMIN_NOTIFICATION_MISSING_VARIABLE)
