import logging

import django
import requests
from django.conf import settings
from django.template import Context, Template
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import (
    Asm, BypassUnsubscribeManagement, CustomArg, GroupId, GroupsToDisplay, Mail,
    MailSettings, Personalization, To
)

from lib_common import constants
from lib_common.authentication import generate_push_token
from lib_common.constants import LOGGER
from lib_persistence import settings as persist_settings

log = logging.getLogger(LOGGER)

TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
}]

settings.configure(TEMPLATES=TEMPLATES, INSTALLED_APPS=['django.contrib.humanize'])
django.setup()


class Emailer:
    def __init__(self, obj, body_template, subject_template):
        self.api_key = persist_settings.get_setting(constants.SETTING_SENDGRID_API_KEY)
        self.obj = obj
        self.body_template = body_template
        self.subject_template = subject_template

    def _generate(self, template):
        try:
            context = Context(self.obj)
            template = Template(template)
            txt = template.render(context)
            return txt
        except Exception as err:
            log.error(err)
            return None

    def send_email(
            self,
            from_email,
            to_email,
            reply_email=None,
            subject=None,
            body=None,
            group_id=None,
            groups_to_display=None,
            bypass=True,
            notifier_recipient_id=None,
            dry_run=False
    ):
        message_id = None
        html_content = body if body is not None else self._generate(self.body_template)
        subject = subject if subject is not None else self._generate(self.subject_template)

        if dry_run:
            return message_id, subject, html_content

        if group_id:
            # Put an email preference link at the bottom of the email.
            html_content += "<center><%asm_preferences_url%></center>"

        sg_client = SendGridAPIClient(self.api_key)
        email = Mail(
            from_email=from_email,
            subject=subject,
            html_content=html_content
        )

        if reply_email:
            email.reply_to = reply_email

        for to_addr in to_email.split(";"):
            p = Personalization()
            p.add_to(To(to_addr))

            if notifier_recipient_id:
                p.add_custom_arg(CustomArg('notifier_recipient_id', notifier_recipient_id))

            email.add_personalization(p)

        if group_id:
            # Set up the unsubscribe behavior.
            if not groups_to_display:
                groups_to_display = [group_id]

            email.asm = Asm(GroupId(group_id), GroupsToDisplay(groups_to_display))

        if bypass:
            email.mail_settings = MailSettings(bypass_unsubscribe_management=BypassUnsubscribeManagement(enable=True))

        sent = sg_client.send(email)

        if "X-Message-ID" in sent.headers:
            message_id = sent.headers["X-Message-ID"]

        return message_id, subject, html_content

    def send_push(self, user_id, subject=None, form_url=None, notifier_recipient_id=None):
        subject = subject if subject else self._generate(self.subject_template)
        company_name = persist_settings.get_setting(constants.SETTING_BROKERAGE_COMPANY_NAME)
        push_url = persist_settings.get_setting(constants.SETTING_LIFES_WALLET_MESSAGING_API_URL)

        if not push_url:
            return None

        push_endpoint = \
            push_url + "/push/" + persist_settings.get_setting(constants.SETTING_BROKERAGE_ID) + "/" + user_id

        # Build a brokerage token to authenticate the request.
        push_token = generate_push_token()

        response_from_push = requests.post(
            push_endpoint,
            json={
                "title": company_name,
                "body": subject,
                "url": form_url,
            },
            headers={
                "Authorization": "Bearer " + push_token
            }, )

        if response_from_push.status_code != 200:
            return None

        return notifier_recipient_id
