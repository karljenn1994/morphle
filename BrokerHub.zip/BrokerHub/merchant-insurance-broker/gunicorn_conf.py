import logging

from lib_common.log_config import setup_logging
from lib_persistence import initialize_persistence


def post_fork(server, worker):
    # Re-configure logging for each new worker.
    setup_logging(worker_pid=worker.pid)

    # Re-initialize persistence.
    initialize_persistence(force=True)
    logging.getLogger().info(f"Worker {worker.pid} post_fork complete.")
