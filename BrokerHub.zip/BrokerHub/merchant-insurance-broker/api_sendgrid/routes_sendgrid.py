import json
import logging

from flask import Response, request
from flask_restx import Namespace, Resource

from lib_common.constants import LOGGER
from lib_common.exceptions import AuthenticationException, HttpException, InvalidArgument
from lib_common.routes_support import response_json
from lib_persistence import notifier

api = Namespace("broker-api/web/v1/sendgrid", description="Web hook for sendgrid events.")
log = logging.getLogger(LOGGER)


@api.route("", methods=["POST"])
@api.doc(description="Web hook for sendgrid events.")
class Event(Resource):
    @staticmethod
    def post():
        """
        Web hook for sendgrid events.
        """
        try:
            json_data = request.json
            activities = sorted(json_data, key=lambda x: x['timestamp'])

            for activity in activities:
                if "notifier_recipient_id" in activity:
                    notifier_recipient_id = activity["notifier_recipient_id"]
                    recipient = notifier.get_notification_recipient(notifier_recipient_id)

                    if recipient is not None:
                        opens_count = recipient.opens_count
                        clicks_count = recipient.clicks_count
                        status = recipient.status
                        event = activity["event"] if activity["event"] is not None else "unknown"

                        if event == 'open':
                            opens_count += 1
                        elif event == 'click':
                            clicks_count += 1
                        else:
                            status = event

                        notifier.update_notifier_message_result(
                            notifier_recipient_id,
                            status,
                            opens_count,
                            clicks_count)

            return Response(json.dumps(True), status=200, mimetype="application/json")
        except (HttpException, InvalidArgument, AuthenticationException) as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": ex.message,
                "code": ex.code
                })
        except Exception as ex:
            log.exception(ex, stack_info=True)
            return response_json(400, {
                "message": str(ex)
                })
